// Browser test of the season screen (mountSeasonTrack): one screen at every size (pages, never a scroll), buttons on
// screen and ≥ 48 px under a game's hostile button CSS, claims, the theme, the platform's words in another language.
// Runs with `npm run test:browser` (needs Playwright's Chromium).

import { fileURLToPath } from 'node:url';
import { chromium, type Browser, type Page } from 'playwright';
import { createServer, type ViteDevServer } from 'vite';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

let server: ViteDevServer;
let browser: Browser;
let base = '';

beforeAll(async () => {
  server = await createServer({ root: fileURLToPath(new URL('./season-fixture', import.meta.url)), configFile: false, logLevel: 'error', server: { port: 0 } });
  await server.listen();
  base = server.resolvedUrls!.local[0];
  browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
}, 60000);

afterAll(async () => {
  await browser?.close();
  await server?.close();
});

const SIZES = [
  { width: 360, height: 800 },
  { width: 1280, height: 720 },
  { width: 800, height: 360 },
  { width: 821, height: 462 },
];

async function open(query: string, viewport = SIZES[0]): Promise<Page> {
  const page = await browser.newPage({ viewport, hasTouch: true });
  await page.goto(`${base}?${query}`);
  await page.waitForSelector('[data-gp=season]');
  return page;
}
const log = (page: Page) => page.evaluate(() => (window as unknown as { __season: { log: string[] } }).__season.log.slice());

/** Everything the one-screen rule looks at: buttons on screen and big enough, text inside the box, no scrolling panel */
const layout = (page: Page) =>
  page.evaluate(() => {
    const box = document.getElementById('gp-season')!;
    const r = box.getBoundingClientRect();
    const bad: string[] = [];
    if (r.top < 0 || r.left < 0 || r.bottom > innerHeight + 0.5 || r.right > innerWidth + 0.5) bad.push(`box ${Math.round(r.width)}×${Math.round(r.height)} off screen`);
    for (const b of box.querySelectorAll<HTMLElement>('button')) {
      if (b.closest('[hidden]')) continue;
      const q = b.getBoundingClientRect();
      if (q.left < r.left - 0.5 || q.right > r.right + 0.5 || q.top < r.top - 0.5 || q.bottom > r.bottom + 0.5) bad.push(`button ${b.dataset.gp ?? b.dataset.gpTier} outside the box`);
      if (q.height < 48 || q.width < 48) bad.push(`button ${b.dataset.gp ?? b.dataset.gpTier} ${Math.round(q.width)}×${Math.round(q.height)}`);
      if (getComputedStyle(b).backgroundColor === 'rgb(255, 0, 255)') bad.push(`button ${b.dataset.gp ?? b.dataset.gpTier} has the game's CSS`);
    }
    for (const e of box.querySelectorAll<HTMLElement>('*')) {
      const s = getComputedStyle(e);
      if ((s.overflowY === 'auto' || s.overflowY === 'scroll') && e.scrollHeight > e.clientHeight + 1) bad.push(`${e.className} scrolls`);
      if (e.children.length === 0 && e.textContent && parseFloat(s.fontSize) < 12) bad.push(`${e.className} text ${s.fontSize}`);
    }
    if (document.scrollingElement!.scrollHeight > innerHeight + 1) bad.push('the page scrolls');
    // The cards stay inside the track: none spills over the footer (a grid overflows without scrolling)
    const tr = box.querySelector('.gp-se-track')!.getBoundingClientRect();
    for (const c of box.querySelectorAll<HTMLElement>('[data-gp-tier]')) {
      const q = c.getBoundingClientRect();
      if (q.bottom > tr.bottom + 0.5 || q.right > tr.right + 0.5) bad.push(`tier ${c.dataset.gpTier} spills out of the track`);
    }
    return { bad, cells: box.querySelectorAll('[data-gp-tier]').length, pager: !box.querySelector('.gp-se-pager')!.hasAttribute('hidden') };
  });

describe('mountSeasonTrack', () => {
  it('fits one screen at every size: pages instead of a scroll, every button ≥ 48 px under the game\'s CSS', async () => {
    for (const viewport of SIZES) {
      const page = await open('xp=1450', viewport);
      const l = await layout(page);
      expect(l.bad, `${viewport.width}×${viewport.height}`).toEqual([]);
      expect(l.cells).toBeGreaterThanOrEqual(viewport.height < 500 ? 6 : 9);
      // The phone pages its 30 tiers; the desktop shows them at once
      if (viewport.width === 360) expect(l.pager).toBe(true);
      if (viewport.width === 1280) expect(l.cells).toBe(30);
      await page.close();
    }
  });

  it('shows the tier, the XP to the next one and the days left; opens on the page of the first waiting tier', async () => {
    const page = await open('xp=1450');
    expect(await page.innerText('[data-gp=season-tier]')).toBe('Tier 7/30');
    expect(await page.innerText('[data-gp=season-xp]')).toBe('50/200 XP');
    expect(await page.innerText('[data-gp=season-when]')).toBe('106 days left');
    expect(await page.getAttribute('[data-gp-tier="1"]', 'data-state')).toBe('ready');
    expect(await page.getAttribute('[data-gp-tier="8"]', 'data-state')).toBe('locked');
    expect(await page.locator('[data-gp-tier="8"][data-next]').count()).toBe(1);
    expect(await page.locator('[data-gp-tier="3"][data-major]').count()).toBe(1);
    // Drawn marks, not glyphs: the lock and the star are SVG
    expect(await page.locator('[data-gp-tier="8"] svg[data-mark=lock]').count()).toBe(1);
    expect(await page.locator('[data-gp-tier="3"] svg[data-mark=star]').count()).toBe(1);
    expect(await page.locator('[data-gp-tier="3"] canvas[data-test=paint]').count()).toBe(1);
    expect(await log(page)).toEqual(['screen:season']);
    await page.close();
  });

  it('a tap on a reached tier claims it once; Claim all takes the rest; a locked one does nothing', async () => {
    const page = await open('xp=1450');
    await page.tap('[data-gp-tier="2"]');
    // aria-disabled: Playwright would wait for it to be enabled — a player's tap anyway
    await page.tap('[data-gp-tier="2"]', { force: true });
    await page.tap('[data-gp-tier="8"]', { force: true });
    expect(await page.getAttribute('[data-gp-tier="2"]', 'data-state')).toBe('claimed');
    expect(await page.locator('[data-gp-tier="2"] svg[data-mark=check]').count()).toBe(1);
    expect(await page.innerText('[data-gp=season-claim-all]')).toBe('Claim all (6)');
    await page.tap('[data-gp=season-claim-all]');
    expect(await log(page)).toEqual(['screen:season', 'claim:2', 'claim:1,3,4,5,6,7']);
    expect(await page.isVisible('[data-gp=season-claim-all]')).toBe(false);
    await page.tap('[data-gp=season-back]');
    expect(await page.locator('[data-gp=season]').count()).toBe(0);
    expect((await log(page)).at(-1)).toBe('close');
    await page.close();
  });

  it('pages on a phone: the pager moves through the track, never past its ends', async () => {
    const page = await open('xp=0');
    expect(await page.getAttribute('[data-gp=season-prev]', 'aria-disabled')).toBe('true');
    const first = await page.locator('[data-gp-tier]').first().getAttribute('data-gp-tier');
    expect(first).toBe('1');
    let taps = 0;
    while ((await page.getAttribute('[data-gp=season-next]', 'aria-disabled')) !== 'true' && taps < 10) (await page.tap('[data-gp=season-next]'), taps++);
    expect(taps).toBeGreaterThanOrEqual(1);
    await page.tap('[data-gp=season-next]', { force: true });
    expect(await page.locator('[data-gp-tier="30"]').count()).toBe(1);
    await page.tap('[data-gp=season-prev]');
    expect(await page.locator('[data-gp-tier="30"]').count()).toBe(0);
    await page.close();
  });

  it("the game's theme wins over the defaults; the platform's words come in the player's language", async () => {
    const page = await open('xp=250&theme=1&lang=ru');
    const st = await page.evaluate(() => ({ bg: getComputedStyle(document.getElementById('gp-season')!).backgroundColor, ready: getComputedStyle(document.querySelector<HTMLElement>('[data-gp-tier="1"] .gp-se-state')!).backgroundColor }));
    expect(st).toEqual({ bg: 'rgb(1, 2, 3)', ready: 'rgb(4, 5, 6)' });
    expect(await page.innerText('[data-gp=season-tier]')).toBe('Ступень 1/30');
    expect(await page.innerText('[data-gp=season-when]')).toBe('Осталось 106 дней');
    expect((await layout(page)).bad).toEqual([]);
    await page.close();
  });

  it("a new season's screen pays the last season's unclaimed tiers with Claim all, even a single one", async () => {
    const page = await open('prior=1450&day=2027-02-03');
    expect(await page.innerText('[data-gp=season-tier]')).toBe('Tier 0/30');
    expect(await page.innerText('h2')).toBe('Chrome Riot');
    expect(await page.innerText('[data-gp=season-claim-all]')).toBe('Claim all (7)');
    await page.tap('[data-gp=season-claim-all]');
    expect((await log(page)).at(-1)).toBe('claim:1,2,3,4,5,6,7');
    await page.close();
    const one = await open('prior=200&day=2027-02-03');
    expect(await one.isVisible('[data-gp=season-claim-all]')).toBe(true);
    expect(await one.innerText('[data-gp=season-claim-all]')).toBe('Claim all (1)');
    await one.close();
  });

  it('an ended season says a new one is coming; a full track says every tier is reached', async () => {
    const page = await open('xp=99999&day=2027-01-31&tiers=12');
    expect(await page.innerText('[data-gp=season-xp]')).toBe('Every tier reached!');
    expect(await page.innerText('[data-gp=season-when]')).toBe('1 day left');
    expect(await page.innerText('.gp-se-nextseason')).toBe('Next season: Chrome Riot');
    await page.close();
  });
});
