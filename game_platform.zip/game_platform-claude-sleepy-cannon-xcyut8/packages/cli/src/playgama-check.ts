// gp playgama-check <game>: Playgama's certification, run before the owner runs it. The game plays as its Playgama build
// (the Bridge portal) against a recording fake Bridge served in place of the CDN script; the demo bot plays and the check
// reads what Playgama's QA Tool reads: initialize, game_ready, storage through the Bridge in one call, no localStorage,
// an interstitial at a natural break, a rewarded ad closed early that gives nothing, what the QA Tool's recorder films,
// the pause and audio events obeyed, sign-in offered and hidden once signed in.

import { mkdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import type { GameLocation } from './paths.ts';

/** How long the demo bot plays waiting for the first interstitial: Playgama's QA plays a short session */
export const PLAYGAMA_CHECK_SEC = 90;

export interface PlaygamaCheckResult {
  checks: { name: string; ok: boolean; detail: string }[];
  file: string;
}

/** The fake Bridge: records every call in window.__pg; ads answer as a player closing them at once */
const FAKE_BRIDGE = `(() => {
  const log = [];
  const handlers = {};
  const on = (k) => (e, f) => ((handlers[k + e] ||= []).push(f));
  const fire = (k, e, v) => (handlers[k + e] || []).forEach((f) => f(v));
  const store = {};
  window.__pg = { log, fire, store };
  window.bridge = {
    initialize: () => (log.push(['initialize']), Promise.resolve()),
    platform: {
      id: 'playgama', language: 'en', isAudioEnabled: true, isPaused: false,
      sendMessage: (m) => (log.push(['message', m]), Promise.resolve()),
      on: on('platform:'), off() {},
    },
    // Sign-in (the QA Tool's Authorization step): signed in survives the page's reload in window.name, as an account would
    player: {
      isAuthorizationSupported: true,
      get isAuthorized() { return window.name === 'gp-signed-in'; },
      name: null,
      authorize: () => (log.push(['authorize']), (window.name = 'gp-signed-in'), Promise.resolve()),
    },
    storage: {
      get: (keys) => (log.push(['storage.get', keys]), Promise.resolve(keys.map((k) => store[k] ?? null))),
      set: (keys, values) => (log.push(['storage.set', keys]), keys.forEach((k, i) => (store[k] = values[i])), Promise.resolve()),
    },
    advertisement: {
      isInterstitialSupported: true, isRewardedSupported: true,
      on: on('ad:'), off() {},
      showInterstitial() {
        log.push(['interstitial']);
        const s = (v, t) => setTimeout(() => fire('ad:', 'interstitial_state_changed', v), t);
        s('loading', 10); s('opened', 30); s('closed', 300);
      },
      showRewarded(placement) {
        log.push(['rewarded', placement ?? null]);
        // Closed before completion: never 'rewarded'
        const s = (v, t) => setTimeout(() => fire('ad:', 'rewarded_state_changed', v), t);
        s('loading', 10); s('opened', 30); s('closed', 300);
      },
    },
  };
})();`;

export async function playgamaCheck(loc: GameLocation): Promise<PlaygamaCheckResult> {
  const { chromium } = await import('playwright');
  const { buildWeb, servePreview } = await import('./vite.ts');
  // The Playgama build with the test hooks (the demo bot, the host) and the real Bridge portal
  const dist = await buildWeb(loc, 'dev', true, join(loc.dir, 'qa', 'dist-playgama-check'), { portal: 'playgama', realPortal: true });
  const server = await servePreview(loc, dist);
  const url = server.resolvedUrls?.local[0] ?? 'http://127.0.0.1:4173/';
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const checks: PlaygamaCheckResult['checks'] = [];
  const check = (name: string, ok: boolean, detail = '') => checks.push({ name, ok, detail });
  try {
    const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
    await page.route('https://bridge.playgama.com/**', (r) => r.fulfill({ contentType: 'text/javascript', body: FAKE_BRIDGE }));
    // Any other host is an external resource Playgama forbids (only the Bridge comes from its CDN)
    const external = new Set<string>();
    const local = new URL(url).host;
    page.on('request', (r) => {
      const h = new URL(r.url()).host;
      if (h && h !== local && h !== 'bridge.playgama.com' && !r.url().startsWith('data:')) external.add(h);
    });
    await page.addInitScript(() => {
      const set = Storage.prototype.setItem;
      (window as unknown as { __ls: string[] }).__ls = [];
      Storage.prototype.setItem = function (k: string, v: string) {
        (window as unknown as { __ls: string[] }).__ls.push(k);
        return set.call(this, k, v);
      };
    });
    await page.goto(`${url}?seed=1`);
    await page.waitForFunction(() => (window as any).__gp?.host?.qaDriver, null, { timeout: 30000 });
    const log = () => page.evaluate(() => (window as any).__pg.log as [string, unknown?][]);

    let l = await log();
    check('Bridge initialized before anything else', l[0]?.[0] === 'initialize', l[0]?.[0] ?? 'no call');
    const gets = l.filter((e) => e[0] === 'storage.get');
    check('Saves load through Bridge storage, all keys in one call', gets.length === 1 && Array.isArray(gets[0]![1]) && (gets[0]![1] as unknown[]).length >= 1, `${gets.length} storage.get call(s)`);
    check("game_ready sent once the game can be played", l.some((e) => e[0] === 'message' && e[1] === 'game_ready'));

    // Play: the player's own tap, then the demo bot
    const play = page.locator('[data-gp=play]').first();
    if (await play.isVisible().catch(() => false)) await play.click();
    else await page.evaluate(() => (window as any).__gp.host.qaDriver.play());
    const demo = await page.evaluate(() => {
      const d = (window as any).__gp.host.qaDriver;
      if (typeof d.demo !== 'function') return false;
      d.demo();
      return true;
    });
    check('The demo bot can play (host.qa({ demo })): the check needs it to reach a natural break', demo);
    const t0 = Date.now();
    let interstitialSec: number | null = null;
    while (Date.now() - t0 < PLAYGAMA_CHECK_SEC * 1000) {
      await page.waitForTimeout(1000);
      if ((await log()).some((e) => e[0] === 'interstitial')) {
        interstitialSec = Math.round((Date.now() - t0) / 1000);
        break;
      }
    }
    const ends = await page.evaluate(() => (window as any).__gp.events.count('round:end') as number);
    check(
      `An interstitial shows at a natural break within ${PLAYGAMA_CHECK_SEC} s of play`,
      interstitialSec !== null,
      interstitialSec !== null
        ? `after ${interstitialSec} s`
        : ends
          ? `none after ${ends} round end(s): the game doesn't call host.adBreak() there, or its own rule holds it back (Playgama's QA fails this)`
          : `the demo bot reached no round end in ${PLAYGAMA_CHECK_SEC} s: Playgama's tester must reach a break as fast — make the first one come sooner`,
    );
    l = await log();
    check('gameplay_started / gameplay_stopped sent', l.some((e) => e[1] === 'gameplay_started') && l.some((e) => e[1] === 'gameplay_stopped'));

    // A rewarded ad closed before the end gives nothing (the player's tap first: rewarded ads follow one)
    // After the interstitial: the host refuses a rewarded ad while another one is on screen
    await page.waitForFunction(() => !(window as any).__gp.host.adPending, null, { timeout: 15000 }).catch(() => {});
    await page.mouse.click(5, 5);
    const rewarded = await page.evaluate(() => (window as any).__gp.host.rewarded('playgama-check'));
    await page.waitForTimeout(1500);
    const after = await log();
    const at = after.findIndex((e) => e[0] === 'rewarded');
    const asked = at >= 0;
    // What the game told the Bridge after the early close: Playgama's QA reads a save or a resumed run there as a reward
    const then = asked ? after.slice(at + 1).map((e) => (e[0] === 'message' ? String(e[1]) : e[0])) : [];
    // The placement reaches the Bridge (bridge.advertisement.rewardedPlacement: the QA Tool logs each request by it)
    const placement = asked ? after[at]![1] : null;
    check('A rewarded ad closed before the end gives no reward (and no gameplay_started right after it); the request names its placement', asked && rewarded === false && !then.includes('gameplay_started') && placement === 'playgama-check', asked ? `host.rewarded → ${rewarded}; placement ${placement === null ? 'none (the Bridge gets null)' : `"${placement}"`}; then: ${then.join(', ') || 'nothing'}` : 'the Bridge was never asked for a rewarded ad');

    // Playgama's QA Tool films the first <canvas> only: after its recorder message that is the mirror (recorder.ts), and
    // it shows the DOM screens too. Without it the result screen above, with its "no reward", is invisible to the QA Tool
    await page.evaluate(() => window.postMessage({ type: 'recorder', action: 'take_screenshot', id: 'playgama-check' }, '*'));
    await page.waitForTimeout(300);
    const shot = await page.evaluate(() => {
      const c = document.querySelector('canvas');
      return c ? { id: c.id, url: c.toDataURL('image/png') } : null;
    });
    const recorderPng = join(loc.dir, 'qa', 'playgama-recorder.png');
    if (shot?.url.startsWith('data:image/png;base64,')) {
      mkdirSync(join(loc.dir, 'qa'), { recursive: true });
      writeFileSync(recorderPng, Buffer.from(shot.url.slice(22), 'base64'));
    }
    check("The QA Tool's recorder films the page, DOM screens included (the first <canvas> is the mirror)", shot?.id === 'gp-recorder' && shot.url.length > 1000, shot ? `first canvas: #${shot.id || '(no id)'}; what it films: qa/playgama-recorder.png` : 'no canvas on the page');

    // Pause and audio from the platform
    await page.evaluate(() => (window as any).__pg.fire('platform:', 'pause_state_changed', true));
    await page.waitForTimeout(200);
    const paused = await page.evaluate(() => (window as any).__gp.host.paused as boolean);
    await page.evaluate(() => (window as any).__pg.fire('platform:', 'pause_state_changed', false));
    check('pause_state_changed pauses the game', paused);
    await page.evaluate(() => (window as any).__pg.fire('platform:', 'audio_state_changed', false));
    await page.waitForTimeout(200);
    const muted = await page.evaluate(() => (window as any).__gp.host.portalMuted as boolean);
    check('audio_state_changed mutes the game', muted);

    const ls = await page.evaluate(() => (window as any).__ls as string[]);
    check('Nothing written to localStorage (Playgama: storage only)', ls.length === 0, ls.length ? `keys: ${[...new Set(ls)].join(', ')}` : '');
    check('No external resources (only the Bridge from its CDN)', external.size === 0, [...external].join(', '));

    // Sign-in (the QA Tool's Authorization step): a menu offers it where the platform has it, and it is gone once signed in
    // (2026-10-10: "No sign-in option found", "Login button visible for an authorized user")
    await page.evaluate(() => (window as any).__gp.host.gameplay(false));
    const signIn = page.locator('[data-gp="sign-in"]').first();
    await signIn.waitFor({ state: 'visible', timeout: 4000 }).catch(() => {});
    const offered = await signIn.isVisible().catch(() => false);
    // It never lies on the game's own controls, on a phone or a desktop, on any screen the game declares in
    // host.qa({ screens }) (2026-10-10, Rivet Clash at 360×800: it covered "Build & fight" on the robot screen); with no
    // free corner it hides on that screen
    const covered: string[] = [];
    const overText: string[] = [];
    let screens = 0;
    if (offered) {
      const names = await page.evaluate(() => {
        const s = (window as any).__gp.host.qaDriver?.screens;
        return s && typeof s === 'object' ? Object.keys(s).filter((k) => typeof s[k] === 'function') : [];
      });
      const hitTest = () =>
        page.evaluate(() => {
          const b = document.querySelector<HTMLElement>('[data-gp="sign-in"]');
          if (!b || getComputedStyle(b).display === 'none') return null;
          const r = b.getBoundingClientRect();
          for (const el of document.querySelectorAll<HTMLElement>('button,a[href],[role="button"],input,select,textarea')) {
            if (el === b || b.contains(el) || el.contains(b)) continue;
            const o = el.getBoundingClientRect();
            const cs = getComputedStyle(el);
            if (o.width < 1 || o.height < 1 || cs.visibility === 'hidden' || cs.display === 'none' || Number(cs.opacity) === 0 || cs.pointerEvents === 'none') continue;
            if (o.width * o.height > innerWidth * innerHeight * 0.5) continue;
            if (r.left < o.right && r.right > o.left && r.top < o.bottom && r.bottom > o.top) return (el.textContent || el.tagName).trim().slice(0, 40);
          }
          // Text it lies on (a HUD counter): reported, not failed — a corner with no free text is allowed
          const walk = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
          const range = document.createRange();
          for (let n = walk.nextNode(); n; n = walk.nextNode()) {
            if (!n.nodeValue?.trim() || b.contains(n)) continue;
            range.selectNodeContents(n);
            const o = range.getBoundingClientRect();
            if (o.width >= 1 && r.left < o.right && r.right > o.left && r.top < o.bottom && r.bottom > o.top) return `text:${n.nodeValue.trim().slice(0, 30)}`;
          }
          return null;
        });
      screens = names.length;
      for (const [w, h] of [[360, 800], [1280, 720]] as const) {
        await page.setViewportSize({ width: w, height: h });
        await page.waitForTimeout(700);
        const hit = await hitTest();
        if (hit) (hit.startsWith('text:') ? overText : covered).push(`${w}×${h} menu: "${hit.replace(/^text:/, '')}"`);
        for (const n of names) {
          const failed = await page
            .evaluate(async (k) => {
              try {
                await (window as any).__gp.host.qaDriver.screens[k]();
                return false;
              } catch {
                return true;
              }
            }, n)
            .catch(() => true);
          if (failed) continue; // gp qa reports a screen that doesn't open
          await page.waitForTimeout(700);
          const on = await hitTest();
          if (on) (on.startsWith('text:') ? overText : covered).push(`${w}×${h} "${n}": "${on.replace(/^text:/, '')}"`);
        }
      }
      // Back to a fresh menu for the sign-in itself: the last declared screen may be one with no free corner (Sigil Clash),
      // where the button rightly hides
      await page.setViewportSize({ width: 1280, height: 720 });
      await page.reload();
      await page.waitForFunction(() => (window as any).__gp?.host?.qaDriver, null, { timeout: 30000 }).catch(() => {});
      await page.evaluate(() => (window as any).__gp.host.gameplay(false)).catch(() => {});
      await signIn.waitFor({ state: 'visible', timeout: 6000 }).catch(() => {});
    }
    check('Sign-in lies on none of the game\'s controls (every declared screen, 360×800 and 1280×720)', covered.length === 0, covered.length ? `covers ${[...new Set(covered)].slice(0, 6).join('; ')} — place your own with signInButton() in the menu` : `the menu and ${screens} declared screen(s)${overText.length ? `; over text (no corner free of it): ${[...new Set(overText)].slice(0, 4).join('; ')}` : ''}`);
    let hidden = false;
    let clicked = false;
    if (offered && (await signIn.isVisible().catch(() => false))) {
      clicked = true;
      await Promise.all([page.waitForEvent('load', { timeout: 15000 }).catch(() => null), signIn.click({ timeout: 10000 }).catch(() => (clicked = false))]);
      await page.waitForFunction(() => (window as any).__gp?.host?.qaDriver, null, { timeout: 30000 }).catch(() => {});
      await page.waitForTimeout(2500);
      hidden = !(await page.locator('[data-gp="sign-in"]').first().isVisible().catch(() => false));
    }
    check('Sign-in offered on the menus and hidden once signed in (the QA Tool\'s Authorization; never required to play)', offered && clicked && hidden, !offered ? 'no [data-gp="sign-in"] on the menu: the host adds one on Playgama builds (autoSignIn) unless the game placed its own with signInButton()' : !clicked ? 'offered, but not visible on the menu after a reload to click it' : hidden ? 'signed in: the button is gone after the reload' : 'still shown after signing in');
  } finally {
    await browser.close();
    await server.close();
  }
  const dir = join(loc.dir, 'qa');
  mkdirSync(dir, { recursive: true });
  const file = join(dir, 'playgama-check.md');
  const lines = checks.map((c) => `- ${c.ok ? '✓' : '✗'} ${c.name}${c.detail ? ` — ${c.detail}` : ''}`);
  writeFileSync(file, `# Playgama certification, checked before the owner runs it\n\n${lines.join('\n')}\n\nNot checked here: the layout at every size and the controls (gp qa does those), and what only a person in Playgama's QA Tool sees.\n`);
  return { checks, file };
}
