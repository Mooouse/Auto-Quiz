// On-device check of a kids-kit game on an Android emulator (run by .github/workflows/android.yml).
// A port of "Pop the balloon!" tools/device-test.mjs (31/31 there): scenes by id instead of class names,
// the package, modes, round goal, ads and purchases come from the game itself (window.__gp.game).
// Installs the debug APK, drives the game with real `adb` touches and inspects it through the
// WebView DevTools socket (the E2E build exposes window.__app and window.__gp).
// Run: node packages/kit-kids/qa/device-test.mjs <app-debug.apk> <appId> <output dir>

import { execFileSync } from 'node:child_process';
import { mkdirSync, rmSync, writeFileSync } from 'node:fs';
import { cpus, totalmem } from 'node:os';
import sharp from 'sharp';

const APK = process.argv[2];
const PKG = process.argv[3];
const OUT = process.argv[4] ?? 'device-test';
if (!APK || !PKG) throw new Error('usage: device-test.mjs <apk> <appId> [output dir]');
const PKG_RE = PKG.replace(/\./g, '\\.');
rmSync(OUT, { recursive: true, force: true }); // fresh results for every run
mkdirSync(OUT, { recursive: true });

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
// A hung adb call (a frozen emulator) fails the run with a report instead of running into the job's time limit
const ADB_TIMEOUT_MS = 180000;
const adb = (...args) => execFileSync('adb', args, { encoding: 'utf8', maxBuffer: 64 << 20, timeout: ADB_TIMEOUT_MS }).trim();
const sh = (cmd) => adb('shell', cmd);

const results = [];
const check = (name, ok, details = '') => {
  results.push({ name, ok, details });
  console.log(`${ok ? 'OK  ' : 'FAIL'} ${name} ${details}`);
};
const info = (name, details) => {
  results.push({ name, ok: null, details });
  console.log(`INFO ${name} ${details}`);
};

async function shot(name) {
  const png = execFileSync('adb', ['exec-out', 'screencap', '-p'], { maxBuffer: 64 << 20, timeout: ADB_TIMEOUT_MS });
  // Shrink to keep the repository light: 540 px wide JPEG is plenty to see the screen
  await sharp(png).resize({ width: 540, withoutEnlargement: true }).jpeg({ quality: 78 }).toFile(`${OUT}/${name}.jpg`);
}

const resumedActivity = () => {
  const out = sh('dumpsys activity activities');
  const m = out.match(/(?:topResumedActivity|mResumedActivity|ResumedActivity)[^\n]*?\{[^}]*?\s([\w.]+\/[\w.$]+)/);
  return m ? m[1] : '';
};
/** FLAG_KEEP_SCREEN_ON on the game's window, as the keep-awake plugin itself reads it */
/** How many keep-screen-on reads got no answer from the native bridge in 10 s (retried; reported in the checks) */
let keepAwakeTimeouts = 0;
// A read that the native bridge doesn't answer (seen once on the 2-core emulator, after an ad failed to load) resolves
// as 'timeout' after 10 s instead of hanging the DevTools call for 90 s and ending the run: the checks retry the read
// and still need the right value; the count of such reads is in their details
const keepScreenOn = async () => {
  const v = await ev(
    () =>
      Promise.race([
        window.Capacitor.nativePromise('KeepAwake', 'isKeptAwake', {}).then((r) => r.isKeptAwake, () => null),
        new Promise((r) => setTimeout(() => r('timeout'), 10000)),
      ]),
    null,
    IDEMPOTENT,
  );
  if (v === 'timeout') keepAwakeTimeouts++;
  return v;
};

/** Android's one-time "Viewing full screen — Got it" hint: tap "Got it" if it is on screen */
/**
 * The one-time "Viewing full screen" hint dims the screen and can swallow Back until it's dismissed.
 * uiautomator sometimes fails on a busy emulator ("null root node"), so the dump is retried.
 * Returns 'dismissed' | 'none' | 'unknown' (the screen could not be read).
 */
async function dismissImmersiveHint() {
  for (let i = 0; i < 6; i++) {
    let xml = '';
    try {
      sh('rm -f /sdcard/ui.xml; uiautomator dump /sdcard/ui.xml >/dev/null');
      xml = sh('cat /sdcard/ui.xml');
    } catch {}
    if (xml.includes('<hierarchy')) {
      const m = xml.match(/text="Got it"[^>]*bounds="\[(\d+),(\d+)\]\[(\d+),(\d+)\]"/);
      if (!m) return 'none';
      const [x1, y1, x2, y2] = m.slice(1).map(Number);
      sh(`input tap ${Math.round((x1 + x2) / 2)} ${Math.round((y1 + y2) / 2)}`);
      return 'dismissed';
    }
    await sleep(2500);
  }
  return 'unknown';
}

/** Color of one screen pixel (physical coordinates) */
async function pixel(x, y) {
  const png = execFileSync('adb', ['exec-out', 'screencap', '-p'], { maxBuffer: 64 << 20, timeout: ADB_TIMEOUT_MS });
  const buf = await sharp(png).extract({ left: x, top: y, width: 1, height: 1 }).removeAlpha().raw().toBuffer();
  return [buf[0], buf[1], buf[2]];
}

/** Poll a condition on the device side (the emulator's UI thread can lag by seconds) */
async function until(fn, timeoutMs = 20000, stepMs = 700) {
  const end = Date.now() + timeoutMs;
  while (Date.now() < end) {
    if (await fn()) return true;
    await sleep(stepMs);
  }
  return false;
}

const pid = () => {
  try {
    return sh(`pidof ${PKG}`);
  } catch {
    return '';
  }
};

// --- WebView DevTools (Chrome DevTools Protocol over adb) -------------------------------------
// Every call has a timeout and a closed socket rejects what is pending: a dropped connection used to leave a call
// unanswered forever, and Node then quit mid-run ("unsettled top-level await", exit 13) without writing the report.

/** The run can't go on: the game's process or page is gone. waitFor() doesn't swallow it. */
class FatalError extends Error {}

const CDP_TIMEOUT_MS = 90000; // the longest single call (the TTS check) takes up to ~35 s on the emulator
let link = null; // { ws, id, pending: Map<id, { resolve, reject }>, closed: string | null }
let appPid = '';
let pageMark = '';
let reconnects = 0;

async function openDevTools() {
  const p = pid();
  if (!p) throw new Error('app process not found');
  adb('forward', '--remove-all');
  adb('forward', 'tcp:9222', `localabstract:webview_devtools_remote_${p}`);
  for (let i = 0; i < 20; i++) {
    try {
      const list = await (await fetch('http://127.0.0.1:9222/json', { signal: AbortSignal.timeout(5000) })).json();
      // The AdMob SDK has its own WebView in the same process — pick the game page (Capacitor serves it from localhost)
      const target = list.find((t) => t.type === 'page' && t.webSocketDebuggerUrl && /\/\/localhost\b/.test(t.url));
      if (target) {
        const ws = new WebSocket(target.webSocketDebuggerUrl);
        await new Promise((res, rej) => {
          const timer = setTimeout(() => rej(new Error('DevTools socket did not open in 10 s')), 10000);
          ws.onopen = () => (clearTimeout(timer), res());
          ws.onerror = () => (clearTimeout(timer), rej(new Error('DevTools socket error')));
        }).catch((e) => {
          try {
            ws.close();
          } catch {}
          throw e;
        });
        const l = { ws, id: 0, pending: new Map(), closed: null };
        ws.onmessage = (e) => {
          const m = JSON.parse(e.data);
          const h = m.id && l.pending.get(m.id);
          if (h) {
            l.pending.delete(m.id);
            h.resolve(m);
          }
        };
        ws.onerror = () => {}; // a close event always follows
        ws.onclose = (e) => {
          l.closed = `socket closed, code ${e.code}${e.reason ? ` ${e.reason}` : ''}`;
          for (const h of l.pending.values()) h.reject(Object.assign(new Error(`WebView DevTools: ${l.closed}`), { dropped: true }));
          l.pending.clear();
        };
        link = l;
        appPid = p;
        return;
      }
    } catch {
      // DevTools socket not ready yet
    }
    await sleep(1000);
  }
  throw new Error('WebView DevTools target not found');
}

/** First connection: marks the page, so a reconnect can tell the same page from a reloaded one */
async function connect() {
  await openDevTools();
  pageMark = `${Date.now()}-${Math.random()}`;
  await ev((m) => (window.__deviceTestMark = m), pageMark, IDEMPOTENT); // the same value twice
}

/**
 * The DevTools socket dropped. Carry on only with the same process and the same page (not reloaded, so the game's
 * state is intact); otherwise stop the run with the diagnostics. Never more than three times.
 */
async function reconnect(why) {
  console.log(`\n=== WebView DevTools connection lost: ${why} ===\n${diagnostics()}\n=== end ===\n`);
  const now = pid();
  const front = resumedActivity();
  if (!now) throw new FatalError(`the game's process is gone (${why}); in front: ${front}; see "WebView DevTools connection lost" in the job log`);
  if (now !== appPid) throw new FatalError(`the game's process was restarted (pid ${appPid} → ${now}; ${why}); see the job log`);
  if (++reconnects > 3) throw new FatalError(`the WebView DevTools connection dropped ${reconnects} times (last: ${why})`);
  await openDevTools();
  const mark = await ev(() => window.__deviceTestMark ?? null, null, IDEMPOTENT);
  if (mark !== pageMark) throw new FatalError(`the game page was reloaded (${why}); its state is gone — see the job log`);
  info('webview: DevTools connection re-established', `${why}; the same process (${now}) and the same page, not reloaded; in front: ${front}`);
}

async function cdp(method, params = {}, timeoutMs = CDP_TIMEOUT_MS) {
  if (!link) throw new Error('WebView DevTools not connected');
  if (link.closed) await reconnect(link.closed);
  const l = link;
  return new Promise((resolve, reject) => {
    const i = ++l.id;
    const timer = setTimeout(() => {
      l.pending.delete(i);
      reject(new Error(`WebView DevTools: no answer to ${method} in ${timeoutMs / 1000} s`));
    }, timeoutMs);
    l.pending.set(i, {
      resolve: (m) => (clearTimeout(timer), resolve(m)),
      reject: (e) => (clearTimeout(timer), reject(e)),
    });
    try {
      l.ws.send(JSON.stringify({ id: i, method, params }));
    } catch (e) {
      l.pending.delete(i);
      clearTimeout(timer);
      reject(e);
    }
  });
}

/** For ev(): the evaluation reads, or running it twice leaves the game as running it once — safe to send again */
const IDEMPOTENT = { idempotent: true };

/**
 * Evaluate fn(arg) inside the game's WebView. A call cut off by a dropped socket may have run in the page or not: it is
 * sent once more after the reconnect only when it is marked `{ idempotent: true }` (it reads, or running it twice is
 * harmless). Any other call cut off stops the run: sent again, it could act twice (a tap, a purchase, a scene change),
 * and not sent, the game may be in a state the next check doesn't expect.
 */
async function ev(fn, arg, { idempotent = false } = {}) {
  const expression = `(async () => (${fn.toString()})(${JSON.stringify(arg ?? null)}))()`;
  const params = { expression, awaitPromise: true, returnByValue: true };
  const r = await cdp('Runtime.evaluate', params).catch((e) => {
    if (!e.dropped) throw e;
    if (idempotent) return cdp('Runtime.evaluate', params);
    const what = fn.toString().replace(/\s+/g, ' ').slice(0, 120);
    console.log(`\n=== WebView DevTools connection lost during a state-changing evaluation ===\n${diagnostics()}\n=== end ===\n`);
    throw new FatalError(
      `the WebView DevTools connection dropped (${e.message}) during an evaluation that changes the game, not sent again: it may or may not have run, ` +
        `so the game's state is unknown — \`${what}\`. See "state-changing evaluation" in the job log. ` +
        'If running it twice is harmless, mark the call { idempotent: true } in packages/kit-kids/qa/device-test.mjs.',
    );
  });
  if (r.error) throw new Error(`Runtime.evaluate: ${r.error.message ?? JSON.stringify(r.error)}`);
  if (r.result?.exceptionDetails) throw new Error(r.result.exceptionDetails.exception?.description ?? JSON.stringify(r.result.exceptionDetails));
  return r.result?.result?.value;
}

async function waitFor(fn, arg, timeoutMs = 15000) {
  const end = Date.now() + timeoutMs;
  while (Date.now() < end) {
    // A condition only reads (waitFor's contract), so a cut-off one is asked again
    const ok = await ev(fn, arg, IDEMPOTENT).catch((e) => {
      if (e instanceof FatalError) throw e;
      return false;
    });
    if (ok) return true;
    await sleep(250);
  }
  return false;
}

const sceneName = () => ev(() => window.__app?.current?.id ?? '', null, IDEMPOTENT);
const waitScene = (name, t) => waitFor((n) => window.__app?.current?.id === n, name, t);

// --- Touch: CSS pixels of the WebView → physical screen pixels -------------------------------

let dpr = 1;
let offX = 0;
let offY = 0;
function tapCss(x, y) {
  sh(`input tap ${Math.round(offX + x * dpr)} ${Math.round(offY + y * dpr)}`);
}

/** The window with input focus, as dumpsys window reports it */
const focusedWindow = () => {
  try {
    return (sh('dumpsys window | grep mCurrentFocus').split('\n')[0] || '').trim();
  } catch {
    return '';
  }
};

/**
 * Wait until the game's window has input focus: another window in front (a system dialog, the notification shade)
 * takes the tap. Closes system dialogs while waiting. Returns what had focus at the end.
 */
async function waitForGameFocus(timeoutMs = 20000) {
  const end = Date.now() + timeoutMs;
  for (;;) {
    const seen = focusedWindow();
    if (seen.includes(PKG) || Date.now() > end) return seen;
    try {
      sh('am broadcast -a android.intent.action.CLOSE_SYSTEM_DIALOGS >/dev/null');
    } catch {}
    await sleep(2000);
  }
}

async function calibrate() {
  dpr = await ev(() => window.devicePixelRatio, null, IDEMPOTENT);
  // Every touch the page gets, in order (one listener for the whole run; the __tapProbe guard makes a second run a no-op)
  await ev(
    () => {
      window.__taps = [];
      if (!window.__tapProbe) {
        window.__tapProbe = true;
        window.addEventListener('pointerdown', (e) => window.__taps.push({ x: e.clientX, y: e.clientY }), { capture: true });
      }
    },
    null,
    IDEMPOTENT,
  );
  const clearTaps = () => ev(() => (window.__taps = [], true), null, IDEMPOTENT); // empty twice is empty
  const firstTap = async (ms) => ((await waitFor(() => window.__taps.length > 0, null, ms)) ? ev(() => window.__taps[0], null, IDEMPOTENT) : null);
  // A harmless spot: bottom center (grass). Physical screen size comes from wm size.
  const size = sh('wm size').match(/(\d+)x(\d+)/g).pop().split('x').map(Number);
  const rotation = Number(sh('settings get system user_rotation')) || 0;
  const [pw, ph] = rotation % 2 ? [size[1], size[0]] : size;
  const px = Math.round(pw / 2);
  // The very bottom edge can belong to the system gesture area (seen after a relaunch): a few spots up the grass.
  // On the busy emulator a touch can reach the page seconds late, so each spot is tapped twice: the second touch must
  // land exactly where the first one predicts — a late touch from an earlier spot can't pass for this one.
  const tries = [];
  for (const up of [12, 40, 80, 40, 80]) {
    const inFront = await waitForGameFocus();
    const py = Math.round(ph - up * dpr);
    await clearTaps();
    sh(`input tap ${px} ${py}`);
    const t = await firstTap(8000);
    if (!t) {
      tries.push(`${up} dp: no touch reached the game (focus: ${inFront || 'unknown'})`);
      await dismissImmersiveHint(); // an overlay that took the tap
      continue;
    }
    const cand = { x: px - t.x * dpr, y: py - t.y * dpr };
    await clearTaps();
    sh(`input tap ${px} ${py}`);
    const v = await firstTap(8000);
    const dx = v ? Math.abs(px - v.x * dpr - cand.x) : Infinity;
    const dy = v ? Math.abs(py - v.y * dpr - cand.y) : Infinity;
    if (dx <= 3 && dy <= 3) {
      offX = cand.x;
      offY = cand.y;
      if (tries.length) info('calibration: earlier spots', tries.join(' / '));
      return { dpr, offX, offY, pw, ph };
    }
    tries.push(v ? `${up} dp: the check touch landed ${dx.toFixed(0)},${dy.toFixed(0)} px off (a late touch?)` : `${up} dp: the check touch did not reach the game`);
  }
  await shot('calibration-failed').catch(() => {});
  console.log(`\n=== Calibration diagnostics ===\n${diagnostics()}\n=== end ===\n`);
  throw new Error(`calibration: no touch reached the game at a verified spot — ${tries.join(' / ')}; in front now: ${focusedWindow() || 'unknown'}`);
}

async function tapProp(prop) {
  const c = await ev((p) => {
    const s = window.__app.current;
    s.layout?.(); // recomputes positions from the screen size: the same twice
    return s[p];
  }, prop, IDEMPOTENT);
  tapCss(c.x, c.y);
}

async function tapCard(mode) {
  const c = await ev((m) => {
    const s = window.__app.current;
    s.layout();
    const c = s.cards.find((x) => x.mode === m);
    return { x: c.x + c.w / 2, y: c.y + c.h / 2 };
  }, mode, IDEMPOTENT);
  tapCss(c.x, c.y);
  return waitScene('round');
}

/** Pop balloons with real touches until the round ends */
async function playRound() {
  for (let guard = 0; guard < 300; guard++) {
    const st = await ev(() => {
      const app = window.__app;
      const s = app.scene;
      if (!s.field) return { done: true };
      const f = s.field;
      const r0 = f.baseRadius();
      const list = f.items
        .map((b) => ({ x: f.drawX(b), y: b.y - b.speed * 0.3, r: r0 * b.k })) // lead the target: adb taps take ~0.3 s
        .filter((b) => b.y > b.r * 1.5 && b.y < app.h - b.r * 1.5);
      return { done: s.state !== 'play', popped: s.popped, target: list[0] ?? null };
    }, null, IDEMPOTENT);
    if (st.done) return true;
    if (st.target) tapCss(st.target.x, st.target.y);
    else await sleep(200);
  }
  return false;
}

// --- The run ----------------------------------------------------------------------------------

/** Start the game and dismiss the one-time full-screen hint; returns what happened with the hint */
async function launch() {
  const started = sh(`am start -W -n ${PKG}/.MainActivity`);
  info('launch: am start', started.split('\n').filter((l) => /Status|LaunchState|TotalTime|Error/.test(l)).join(' / '));
  await sleep(7000);
  await shot('01-launch-first-run');
  const hint = await dismissImmersiveHint();
  await sleep(1500);
  await shot('02-menu');
  return hint;
}

/** Wait until the system is quiet: no ANR dialog, the launcher in front, then a short pause */
async function settle() {
  const end = Date.now() + 90000;
  while (Date.now() < end) {
    const front = resumedActivity();
    if (front.includes('launcher') || front.includes(PKG)) break;
    sh('input keyevent KEYCODE_HOME');
    await sleep(3000);
  }
  await sleep(15000);
}

/** Why the app is gone: the crash buffer and the log lines about the app, kills and ANRs */
function diagnostics() {
  try {
    const crash = adb('logcat', '-d', '-b', 'crash').split('\n').slice(-40);
    const main = adb('logcat', '-d')
      .split('\n')
      .filter((l) => (l.includes(PKG) && !/AppsFilter/.test(l)) || /AndroidRuntime: FATAL|ActivityManager: (Kill|Force)|ActivityTaskManager: Force|lowmemorykiller|ANR in/.test(l))
      .slice(-50);
    return ['--- crash buffer', ...crash, '--- main log (app, kills, ANR)', ...main].join('\n');
  } catch (e) {
    return String(e);
  }
}

async function main() {
  info('runner', `${cpus().length} CPUs, ${Math.round(totalmem() / 2 ** 30)} GB RAM (the emulator shares them)`);
  info('device', `${sh('getprop ro.product.model')}, Android ${sh('getprop ro.build.version.release')} (API ${sh('getprop ro.build.version.sdk')}), ${sh('wm size').split('\n').pop()}, ${sh('wm density').split('\n').pop()}`);
  execFileSync('adb', ['install', '-r', APK], { encoding: 'utf8', timeout: 600000 });
  // The test itself must not be interrupted by the screen timing out
  sh('svc power stayon true');
  // The CI emulator renders on the CPU; a smaller screen keeps its UI thread responsive
  sh('wm size 720x1600');
  sh('wm density 300');
  sh('settings put system screen_off_timeout 1800000');
  // The one-time "Viewing full screen" hint dims the screen and takes touches until it's dismissed; a half-dismissed one
  // swallowed the test's taps. A parent sees it once on the first launch; the test marks it as seen up front.
  sh('settings put secure immersive_mode_confirmations confirmed');
  // "Google Play services isn't responding" dialogs on a cold emulator sit on top of the game and take the test's taps.
  // Hide system error dialogs (our own crashes are still caught from logcat: FATAL EXCEPTION in our process)
  sh('settings put global hide_error_dialogs 1');
  // A cold CI emulator is still busy for a while after boot: Google Play services can stop responding (ANR) and
  // Android then kills every app that uses their providers, ours included (WebView fonts). Let it settle first.
  await settle();
  adb('logcat', '-c');
  const t0 = Date.now();
  let hint = await launch();
  let up = !!pid() && resumedActivity().includes(PKG);
  if (!up) {
    const log = diagnostics();
    console.log(`\n=== Launch diagnostics ===\n${log}\n=== end ===\n`);
    // Killed by the system because a system process died — not the game's fault: one more launch, and say so.
    // A crash of the game itself (FATAL in our process) still fails.
    const systemKill = new RegExp(`Killing \\d+:${PKG.replace(/\./g, '\\.')}/\\S+ \\(adj -?\\d+\\): depends on provider .* in dying proc`).test(log);
    const ownCrash = new RegExp(`FATAL EXCEPTION[\\s\\S]{0,400}${PKG.replace(/\./g, '\\.')}`).test(log);
    if (systemKill && !ownCrash) {
      info('launch: relaunched once', 'Android killed the app because a system process (Google Play services) stopped responding on the cold emulator; see the launch diagnostics in the job log');
      await settle();
      adb('logcat', '-c');
      hint = await launch();
      up = !!pid() && resumedActivity().includes(PKG);
    }
  }
  const hintText = {
    dismissed: 'shown on first launch; tapped "Got it" (a parent does this once)',
    none: 'not shown (the test marks it as seen before launch; a parent sees it once)',
    unknown: 'NOT VERIFIED — uiautomator could not read the screen; later Back checks may fail if the hint is still up',
  };
  info('android: one-time "Viewing full screen" hint', hintText[hint]);
  check('launch: app process is running', !!pid());
  check('launch: MainActivity is in front', resumedActivity().includes(PKG), resumedActivity());

  await connect();
  check('launch: game started, main menu shown', await waitScene('menu', 20000));
  const game = await ev(() => window.__gp.game, null, IDEMPOTENT);
  const modes = game.kit.modes.map((m) => m.id);
  const first = modes[0];
  const last = modes[modes.length - 1];
  const cal = await calibrate();
  info('screen', `dpr ${cal.dpr}, WebView offset ${cal.offX.toFixed(0)},${cal.offY.toFixed(0)}, physical ${cal.pw}×${cal.ph}`);

  // Full screen: no status/navigation bars and no black band at the camera cutout
  const view = await ev(() => ({ w: innerWidth, h: innerHeight, inset: window.__app.inset }), null, IDEMPOTENT);
  info('screen: WebView', `${view.w}×${view.h} css = ${Math.round(view.w * dpr)}×${Math.round(view.h * dpr)} px, offset ${cal.offY.toFixed(0)} px; insets ${JSON.stringify(view.inset)}`);
  const top = await pixel(Math.round(cal.pw / 2), 8);
  const bottom = await pixel(Math.round(cal.pw / 2), cal.ph - 8);
  const notBlack = (c) => c[0] + c[1] + c[2] > 90;
  check('fullscreen: no black band at the top (camera cutout) or bottom', notBlack(top) && notBlack(bottom), `top rgb ${top}, bottom rgb ${bottom}`);
  const bars = sh('dumpsys window').match(/(?:mStatusBar|statusBars)[^\n]*visible[^\n]*/gi)?.slice(0, 2).join(' / ') ?? '';
  info('fullscreen: system bars state', bars.slice(0, 200));

  // Frame rate on this emulator (software GPU — a real phone is faster)
  const fps = await ev(
    () =>
      new Promise((res) => {
        let n = 0;
        const t0 = performance.now();
        const f = () => (performance.now() - t0 < 3000 ? (n++, requestAnimationFrame(f)) : res(n / 3));
        requestAnimationFrame(f);
      }),
    null,
    IDEMPOTENT, // counts frames for 3 s
  );
  info('performance: frames per second on the emulator', fps.toFixed(1));

  // Sound: AudioContext exists and runs after the first touch (the calibration tap)
  const audio = await ev(() => window.__app.audio.ctx?.state ?? 'none', null, IDEMPOTENT);
  check('audio: WebAudio runs after the first touch', audio === 'running', audio);

  // Voice: the system TTS speaks English. On a slow emulator the engine's first start can take
  // longer than 10 s, so a timeout gets one more try once the engine is warm; it must still speak.
  // Idempotent: sent again, it only says "red" once more — nothing in the game changes.
  const tts = await ev(async () => {
    const mod = await window.__app.audio.speaker.tts;
    const langs = await mod.TextToSpeech.getSupportedLanguages().catch((e) => ({ languages: [String(e)] }));
    const say = (ms) =>
      Promise.race([
        mod.TextToSpeech.speak({ text: 'red', lang: 'en-US', rate: 0.9 }).then(() => 'spoken', (e) => 'error: ' + (e?.message ?? e)),
        new Promise((r) => setTimeout(() => r('timeout'), ms)),
      ]);
    const t0 = performance.now();
    let said = await say(10000);
    let tries = 1;
    if (said === 'timeout') {
      await mod.TextToSpeech.stop().catch(() => {});
      said = await say(20000);
      tries = 2;
    }
    const all = langs.languages ?? [];
    return { said, tries, sec: ((performance.now() - t0) / 1000).toFixed(1), en: all.includes('en-US'), langs: all.slice(0, 12).join(', ') };
  }, null, IDEMPOTENT);
  check('voice: system TTS speaks English (en-US)', tts.said === 'spoken', `${tts.said} (try ${tts.tries}, ${tts.sec} s); en-US listed: ${tts.en}; languages: ${tts.langs}`);

  // Round 1 (Colors) with real touches; the screen must stay on during the round
  check(`round 1: ${first} started by tapping its card`, await tapCard(first));
  // The round asks for the flag on entry; the plugin sets it on the UI thread, which lags by seconds on the emulator.
  // Read it while the round is on screen (nothing is tapped meanwhile, and a kids round never ends by itself).
  let keepOn = null;
  const t1 = Date.now();
  const keepOnInRound = await until(async () => (keepOn = await keepScreenOn()) === true && (await sceneName()) === 'round', 15000, 1000);
  const keepOnDetails = `${keepOnInRound ? 'set' : `flag read as ${keepOn}`} ${((Date.now() - t1) / 1000).toFixed(1)} s after the round opened`;
  await shot('03-round-colors');
  const r1 = await playRound();
  check(`round 1: ${game.round.goal} targets popped with real touches`, r1);
  check('round 1: keep-screen-on flag set during the round', keepOnInRound, keepOnDetails);
  check('round 1: "Well done!" shown (no ad after round 1)', await waitScene('reward', 15000));
  await sleep(3000);
  await shot('04-well-done');

  // Round 2: an AdMob test interstitial is expected once a minute has passed since launch
  const elapsed = (Date.now() - t0) / 1000;
  if (elapsed < 62) await sleep((62 - elapsed) * 1000);
  // "Well done!" buttons become active 2.5 s (game time) after the screen opens
  await waitFor(() => window.__app.current.t >= 2.6, null, 20000);
  await tapProp('next');
  check('round 2: "Next" starts a new round', await waitScene('round'));
  const r2 = await playRound();
  check('round 2: finished', r2);
  const roundEnd = Date.now();
  // The game waits in the post-round break until the requested ad closes, so give a slow emulator time.
  // Poll gently: the ad opened 70–120 s after the round on this 2-core emulator, and every `dumpsys activity` holds
  // the window manager's lock for most of a second — polling it back to back competes with the ad activity's start.
  let adShown = false;
  const adDeadline = Date.now() + 150000;
  while (Date.now() < adDeadline && !adShown) {
    if ((await sceneName()) === 'reward') {
      // The scene can switch in the moment the ad opens: look once more before calling it "no ad"
      adShown = resumedActivity().includes('AdActivity');
      break;
    }
    if (resumedActivity().includes('AdActivity')) adShown = true;
    else await sleep(2500);
  }
  const adAfterSec = ((Date.now() - roundEnd) / 1000).toFixed(0);
  if (adShown) info('ads: the interstitial opened', `${adAfterSec} s after round 2 ended (the game waits up to ${game.ads?.policy?.maxAdWaitSec ?? '?'} s)`);
  const adsLog = (() => {
    try {
      return adb('logcat', '-d', '-s', 'Ads:*').split('\n').filter((l) => /failed|Ad loaded|onAd|test device/i.test(l)).slice(-8).join(' | ');
    } catch {
      return '';
    }
  })();
  // "Ad failed to load : 3" is NO_FILL: Google's test network had no ad for this request. That says nothing about
  // the game — report it as not verified instead of failing (any other load error still fails the check).
  const noFill = !adShown && /Ad failed to load : 3\b/.test(adsLog) && !/Ad failed to load : [0-24-9]\b/.test(adsLog);
  if (!game.ads) info('ads', 'the game has no ads — skipped');
  else if (noFill) info('ads: AdMob test interstitial after round 2', `NOT VERIFIED — the test ad network returned no fill (code 3). ${adsLog}`);
  else check('ads: AdMob test interstitial shown after round 2', adShown, adShown ? '' : `AdMob log: ${adsLog}`);
  if (adShown) {
    await sleep(2500);
    await shot('05-admob-test-ad');
    const gameWhileAd = await sceneName();
    check('ads: "Well done!" waits until the ad is closed', gameWhileAd === 'round', `${gameWhileAd} (the ad opened ${adAfterSec} s after the round)`);
    await sleep(3500);
    // Close the ad: Back, then the usual close-button corners as a fallback
    sh('input keyevent KEYCODE_BACK');
    await sleep(1500);
    for (const [fx, fy] of [[0.94, 0.05], [0.06, 0.05], [0.94, 0.08]]) {
      if (!resumedActivity().includes('AdActivity')) break;
      sh(`input tap ${Math.round(cal.pw * fx)} ${Math.round(cal.ph * fy)}`);
      await sleep(1500);
    }
    check('ads: after closing the ad the game shows "Well done!"', await waitScene('reward', 30000), resumedActivity());
  }
  const adState = await ev(() => window.__app.ads.state, null, IDEMPOTENT);
  info('ads: limiter state', JSON.stringify(adState));
  await sleep(3000);

  // Back from "Well done!" → menu; Back in the menu → the app goes to the background (not closed)
  sh('input keyevent KEYCODE_BACK');
  check('back: from "Well done!" to the main menu', await waitScene('menu', 15000));
  const clearedOff = await until(async () => (await keepScreenOn()) === false, 30000);
  check('menu: keep-screen-on flag cleared outside rounds', clearedOff, keepAwakeTimeouts ? `${keepAwakeTimeouts} read(s) unanswered by the native bridge in 10 s, retried` : '');
  const pidBefore = pid();
  sh('input keyevent KEYCODE_BACK');
  const minimized = await until(() => !resumedActivity().includes(PKG));
  check('back: in the menu the app is minimized, not closed', minimized && pid() === pidBefore, `front: ${resumedActivity()}`);
  sh(`am start -n ${PKG}/.MainActivity`);
  await until(() => resumedActivity().includes(PKG));
  await sleep(1500);
  check('back: reopening returns to the same running game', pid() === pidBefore && (await sceneName()) === 'menu');
  const stickers = await ev(() => window.__app.save.stickers, null, IDEMPOTENT);
  check('album: 2 stickers after 2 rounds', stickers === 2, String(stickers));

  // Album → Back → menu
  await tapProp('album');
  check('album: opens from the menu', await waitScene('album'));
  await sleep(800);
  await shot('06-album');
  sh('input keyevent KEYCODE_BACK');
  check('back: from the album to the menu', await waitScene('menu', 5000));

  // Rotation to landscape in the middle of a round
  await tapCard(last);
  await sleep(1500);
  sh('settings put system accelerometer_rotation 0');
  sh('settings put system user_rotation 1');
  await sleep(3500);
  const land = await ev(() => {
    const app = window.__app;
    const f = app.scene.field;
    const r0 = f.baseRadius();
    return { w: app.w, h: app.h, inside: f.items.every((b) => f.drawX(b) - r0 * b.k >= 0 && f.drawX(b) + r0 * b.k <= app.w) };
  }, null, IDEMPOTENT);
  check('rotation: landscape works, balloons stay on screen', land.w > land.h && land.inside, `${land.w}×${land.h}`);
  await shot('07-landscape-round');
  sh('settings put system user_rotation 0');
  await sleep(3000);
  await calibrate();
  // Idempotent: home() opens the main menu, and from the menu it opens the menu again — sent twice, the same screen
  await ev(() => window.__app.home(), null, IDEMPOTENT);
  await waitScene('menu', 5000);

  // Parent gate → settings → purchase buttons (no Google account on the emulator) → privacy link
  await tapProp('lock');
  if (game.kit.parentGate) check('parent: the lock opens the gate', await waitScene('gate'));
  const code = game.kit.parentGate ? await ev(() => window.__app.current.code, null, IDEMPOTENT) : [];
  for (const d of code) {
    const k = await ev((dd) => {
      const s = window.__app.current;
      s.layout();
      const k = s.keys[dd - 1];
      return { x: k.x + k.w / 2, y: k.y + k.h / 2 };
    }, d, IDEMPOTENT);
    tapCss(k.x, k.y);
    await sleep(300);
  }
  check('parent: the right code opens settings', await waitScene('settings', 5000));
  await sleep(1500);
  const rows = await ev(() => {
    const s = window.__app.current;
    s.layout();
    return s.rows.map((r) => ({ label: r.label, x: r.x + r.w / 2, y: r.y + r.h / 2 }));
  }, null, IDEMPOTENT);
  info('settings rows', rows.map((r) => r.label).join(' | '));
  await shot('08-settings');
  const restore = rows.find((r) => r.label.startsWith(game.kit.strings.restore));
  if (restore) {
    tapCss(restore.x, restore.y);
    const got = await waitFor(() => !!window.__app.current.toast, null, 70000);
    const toast = await ev(() => window.__app.current.toast?.text ?? '', null, IDEMPOTENT);
    check('billing: "Restore purchases" answers without hanging (no Google account here)', got, toast);
  }
  const privacy = rows.find((r) => r.label.startsWith(game.kit.strings.privacy));
  if (!privacy) throw new Error('no privacy policy row in settings');
  tapCss(privacy.x, privacy.y);
  const opened = await until(() => /chrome|browser|customtab/i.test(resumedActivity()), 25000);
  check('privacy: the link opens in the browser', opened, resumedActivity());
  await sleep(3000);
  await shot('09-privacy-link');
  sh('input keyevent KEYCODE_BACK');
  check('privacy: Back returns to the game', await until(() => resumedActivity().includes(PKG)), resumedActivity());

  // Crashes and JavaScript errors in the log
  const log = adb('logcat', '-d');
  writeFileSync(`${OUT}/logcat.txt`, log.split('\n').filter((l) => l.includes(PKG) || /Capacitor|chromium|Ads|AndroidRuntime|TextToSpeech|BillingClient|NativePurchases/.test(l)).slice(-2500).join('\n'));
  // Only the game's own process counts (Google Play services on the emulator may ANR by itself)
  const crashes = log.split('\n').filter((l) => l.includes(`ANR in ${PKG}`) || new RegExp(`AndroidRuntime.*Process: ${PKG_RE}`).test(l));
  const jsErrors = log.split('\n').filter((l) => /Capacitor\/Console.*(?:ERROR|Uncaught)|Uncaught (?:TypeError|ReferenceError|Error)/.test(l));
  check('log: no crashes or ANRs', crashes.length === 0, crashes.slice(0, 3).join(' | '));
  check('log: no uncaught JavaScript errors', jsErrors.length === 0, jsErrors.slice(0, 3).join(' | '));

  // Permissions actually granted on the device
  const perms = sh(`dumpsys package ${PKG}`)
    .split('\n')
    .filter((l) => /permission\./.test(l) && /granted=true/.test(l))
    .map((l) => l.trim().split(':')[0]);
  check('permissions: no advertising ID on the device', !perms.some((p) => /AD_ID|ADSERVICES/.test(p)), [...new Set(perms)].join(', '));
}

try {
  await main();
} catch (e) {
  check('run finished without an exception', false, String(e?.stack ?? e).slice(0, 800));
  try {
    await shot('99-error');
  } catch {
    // no screen
  }
}
const failed = results.filter((r) => r.ok === false);
writeFileSync(`${OUT}/results.json`, JSON.stringify({ date: new Date().toISOString(), results }, null, 2));
const md = [
  '# On-device check (Android emulator)',
  '',
  `Run: ${new Date().toISOString()} — ${results.filter((r) => r.ok).length} passed, ${failed.length} failed.`,
  '',
  '| | Check | Details |',
  '|---|---|---|',
  ...results.map((r) => `| ${r.ok === null ? 'ℹ️' : r.ok ? '✅' : '❌'} | ${r.name} | ${String(r.details).replace(/\|/g, '/').slice(0, 300)} |`),
  '',
  'Screenshots: `*.jpg` next to this file. Filtered log: `logcat.txt`.',
].join('\n');
writeFileSync(`${OUT}/README.md`, md + '\n');
console.log(failed.length ? `\n${failed.length} check(s) failed` : '\nAll device checks passed');
process.exit(failed.length ? 1 : 0);
