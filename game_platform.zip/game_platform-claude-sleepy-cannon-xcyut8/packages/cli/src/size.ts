// The size report of a web upload: raw and gzipped, the bytes of each npm package (from the build's sourcemap, as the
// engine lab's tools/measure.mjs does), the estimated time to a tappable Play on a slow phone (@gp/spec budget.ts),
// and the budget's warnings. `gp build --target <portal>` writes it to upload/size.json; `gp forecast` and
// `gp submission` read it.

import { existsSync, readdirSync, readFileSync, statSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { gzipSync } from 'node:zlib';
import { SLOW_PHONE, embeddedDataBytes, estimateLoad, overBudget, type Budget, type PackageShare, type SizeReport } from '@gp/spec';
import { ROOT, type GameLocation } from './paths.ts';

const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
const B64_INDEX = new Map([...B64].map((c, i) => [c, i]));

/** Sourcemap "mappings" → per generated line, [generated column, source index] segments (source index carried over) */
export function decodeMappings(mappings: string): [number, number | undefined][][] {
  const lines: [number, number | undefined][][] = [];
  let src = 0;
  for (const line of mappings.split(';')) {
    const segs: [number, number | undefined][] = [];
    let col = 0;
    for (const seg of line.split(',')) {
      if (!seg) continue;
      const vals: number[] = [];
      let v = 0;
      let shift = 0;
      for (const ch of seg) {
        const d = B64_INDEX.get(ch) ?? 0;
        v += (d & 31) << shift;
        if (d & 32) shift += 5;
        else {
          vals.push(v & 1 ? -(v >>> 1) : v >>> 1);
          v = 0;
          shift = 0;
        }
      }
      col += vals[0];
      if (vals.length >= 4) {
        src += vals[1];
        segs.push([col, src]);
      } else segs.push([col, undefined]);
    }
    lines.push(segs);
  }
  return lines;
}

/** Who a source file of the bundle belongs to: an npm package by name, @gp/<package>, the game, or other */
export function sourceOwner(path: string, gameDir: string): string {
  const p = path.split('\\').join('/');
  const m = [...p.matchAll(/node_modules\/((?:@[^/]+\/)?[^/]+)/g)];
  if (m.length) return m[m.length - 1][1];
  const pkgs = join(ROOT, 'packages').split('\\').join('/') + '/';
  if (p.startsWith(pkgs)) return `@gp/${p.slice(pkgs.length).split('/')[0]}`;
  const game = gameDir.split('\\').join('/') + '/';
  if (p.startsWith(game) || p.includes('virtual:gp/')) return 'game';
  return 'other';
}

/** JS no source maps to: the resolved game.yaml (a virtual module), the bundler's glue */
export const UNMAPPED = '(unmapped: game.yaml data, bundler glue)';

/** Bytes of the minified JS in dist/assets by owner, from the hidden sourcemaps next to it */
export function bytesBySource(dist: string, gameDir: string): Map<string, number> {
  const by = new Map<string, number>();
  const add = (k: string, n: number) => by.set(k, (by.get(k) ?? 0) + n);
  const assets = join(dist, 'assets');
  if (!existsSync(assets)) return by;
  for (const f of readdirSync(assets).filter((x) => x.endsWith('.js'))) {
    const code = readFileSync(join(assets, f), 'utf8');
    const mapFile = join(assets, f + '.map');
    if (!existsSync(mapFile)) {
      add(UNMAPPED, Buffer.byteLength(code));
      continue;
    }
    const map = JSON.parse(readFileSync(mapFile, 'utf8')) as { sources: string[]; sourceRoot?: string; mappings: string };
    const owners = map.sources.map((s) => sourceOwner(s.startsWith('\0') || s.includes('virtual:') ? s : resolve(assets, map.sourceRoot ?? '', s), gameDir));
    const lines = code.split('\n');
    decodeMappings(map.mappings).forEach((segs, li) => {
      const text = lines[li] ?? '';
      if (!segs.length) {
        add(UNMAPPED, Buffer.byteLength(text));
        return;
      }
      if (segs[0][0] > 0) add(UNMAPPED, Buffer.byteLength(text.slice(0, segs[0][0])));
      for (let i = 0; i < segs.length; i++) {
        const [col, src] = segs[i];
        const end = i + 1 < segs.length ? segs[i + 1][0] : text.length;
        add(src === undefined ? UNMAPPED : (owners[src] ?? 'other'), Buffer.byteLength(text.slice(col, end)));
      }
    });
  }
  return by;
}

/** The upload's size report (written to upload/size.json by buildPortal) */
export function sizeReport(html: string, dist: string, loc: GameLocation, budget: Budget | null): SizeReport {
  const raw = Buffer.byteLength(html);
  const gzip = gzipSync(html, { level: 9 }).length;
  const data = embeddedDataBytes(html);
  const by = bytesBySource(dist, loc.dir);
  const js = [...by.values()].reduce((a, b) => a + b, 0);
  // What the JS bundles don't hold: the HTML, the stylesheet, the inliner's escapes
  if (raw > js) by.set('(html, css)', (by.get('(html, css)') ?? 0) + raw - js);
  const packages: PackageShare[] = [...by.entries()].map(([name, bytes]) => ({ name, bytes, share: Math.round((bytes / raw) * 1000) / 1000 })).sort((a, b) => b.bytes - a.bytes);
  const load = estimateLoad({ raw, gzip, data });
  return {
    file: 'index.html',
    rawBytes: raw,
    gzipBytes: gzip,
    dataBytes: data,
    packages,
    load: {
      slowPhone: SLOW_PHONE,
      downloadMs: Math.round(load.downloadMs),
      cpuMs: Math.round(load.cpuMs),
      tappableMs: Math.round(load.totalMs),
      method: 'estimate from the bytes (@gp/spec budget.ts, fitted to the engine lab\'s Chromium measurements); not measured on this build',
    },
    budget,
    over: overBudget({ raw, gzip, data }, load, budget),
  };
}

/** upload/size.json of a game, when it belongs to the upload next to it (same size); else null */
export function readSize(loc: GameLocation): SizeReport | null {
  const file = join(loc.dir, 'upload', 'size.json');
  const html = join(loc.dir, 'upload', 'index.html');
  if (!existsSync(file) || !existsSync(html)) return null;
  try {
    const r = JSON.parse(readFileSync(file, 'utf8')) as SizeReport;
    return r.rawBytes === statSync(html).size ? r : null;
  } catch {
    return null;
  }
}

const kb = (n: number) => {
  const k = n / 1024;
  return k >= 1024 ? `${(k / 1024).toFixed(1)} MB` : `${k < 10 ? k.toFixed(1) : Math.round(k).toLocaleString('en-US')} KB`;
};

/** The lines `gp build --target <portal>` prints */
export function sizeLines(r: SizeReport, hardMB?: number): string[] {
  const b = r.budget;
  const L: string[] = [];
  L.push(`  Size: ${kb(r.rawBytes)} raw, ${kb(r.gzipBytes)} gzipped${b ? ` — budget ${b.gzipKB.toLocaleString('en-US')} KB gzipped (${b.from === 'channel' ? 'the channel\'s' : 'game.yaml budget.gzipKB'}), hard limit ${hardMB ?? b.hardMB} MB raw` : ''}${r.dataBytes ? `; ${kb(r.dataBytes)} of it embedded base64 data (.wasm, images, sounds)` : ''}`);
  const top = r.packages.slice(0, 8).map((p) => `${p.name} ${kb(p.bytes)} (${Math.round(p.share * 100)}%)`);
  const rest = r.packages.slice(8).reduce((a, p) => a + p.bytes, 0);
  L.push(`  By source (minified, from the sourcemap): ${top.join(' · ')}${rest ? ` · ${r.packages.length - 8} more ${kb(rest)}` : ''}`);
  const s = r.load.slowPhone;
  L.push(`  Load: ≈ ${(r.load.tappableMs / 1000).toFixed(1)} s to a tappable Play on a slow phone (${s.downMbps.toFixed(1)} Mbps, ${s.rttMs} ms RTT, ${s.cpu}× CPU: download ${(r.load.downloadMs / 1000).toFixed(1)} s + start ${(r.load.cpuMs / 1000).toFixed(1)} s) — an estimate${b ? `; warns above ${b.warnLoadSec} s` : ''}`);
  for (const o of r.over) L.push(`  ⚠ over budget: ${o} — make it smaller (the list above says what weighs), or raise it on purpose: game.yaml budget: { gzipKB } (docs/guides/code-games.md#the-size-and-load-budget)`);
  return L;
}

/** For a game folder with an upload but no size.json: the numbers from the file itself (no package shares) */
export function uploadFacts(loc: GameLocation): { mb: number; gzipKB: number; loadSec: number } | null {
  const r = readSize(loc);
  if (r) return { mb: r.rawBytes / 1048576, gzipKB: r.gzipBytes / 1024, loadSec: r.load.tappableMs / 1000 };
  const f = join(loc.dir, 'upload', 'index.html');
  if (!existsSync(f)) return null;
  const html = readFileSync(f, 'utf8');
  const raw = Buffer.byteLength(html);
  const gzip = gzipSync(html, { level: 9 }).length;
  return { mb: raw / 1048576, gzipKB: gzip / 1024, loadSec: estimateLoad({ raw, gzip, data: embeddedDataBytes(html) }).totalMs / 1000 };
}
