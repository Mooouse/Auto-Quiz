# gp's ESRGAN runner (packages/cli/src/upscale.ts): python esrgan.py <model.pth> <in.png> <out.png>
# The sprite is laid on a dark backdrop (models want RGB), upscaled, and its alpha enlarged pixel for pixel.
import sys
import numpy as np
import torch
from PIL import Image
from spandrel import ModelLoader

model_path, src, dst = sys.argv[1:4]
model = ModelLoader().load_from_file(model_path).model.eval()
rgba = np.asarray(Image.open(src).convert('RGBA'), np.float32)
h, w = rgba.shape[:2]
pad, bg = 4, np.array([42, 35, 51], np.float32)
a = rgba[..., 3:4] / 255.0
rgb = np.pad(rgba[..., :3] * a + bg * (1 - a), ((pad, pad), (pad, pad), (0, 0)), mode='edge')
with torch.no_grad():
    out = model(torch.from_numpy(rgb / 255.0).permute(2, 0, 1)[None].float())[0].clamp(0, 1).permute(1, 2, 0).numpy() * 255
k = out.shape[0] // (h + 2 * pad)
out = out[pad * k:(pad + h) * k, pad * k:(pad + w) * k]
alpha = np.repeat(np.repeat(rgba[..., 3], k, 0), k, 1)[..., None]
Image.fromarray(np.concatenate([out, alpha], -1).clip(0, 255).astype(np.uint8), 'RGBA').save(dst)
