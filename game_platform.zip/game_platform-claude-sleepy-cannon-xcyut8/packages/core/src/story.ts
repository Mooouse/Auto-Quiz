// Story for games with their own code: the data format, a runner that plays a scene step by step, the story state kept
// in the game's save, "which scene is due now", and a checker. Pure (no DOM; the screen is dialogue-ui.ts): usable from
// the game, unit tests, balance bots and Node tools. The rules: docs/guides/story.md; the design:
// docs/research/story-2026-09.md §3.
//
// From Brew & Banter (QmaCyber/game5, dialogue.ts), which passed its QA and a code review, with its review's fixes:
// - conditions are checked when a line is reached, so a choice made earlier in the scene counts;
// - a line whose choices are all hidden works as a plain line;
// - a scene runs on a copy of the state and commitScene() writes it only when the scene is over, so an interrupted scene
//   replays clean and never pays twice (Brew & Banter's review bug #2);
// - new: a condition language (and / or / not, numbers, seen(), chose()) parsed here, never eval'ed; effects that set,
//   clear and count story vars, rewards and game events by name; choices by stable id; goto/label to join branches;
//   skip to the next choice point; scenes due at moments the game offers (`at`) under a condition (`when`).
//
// Lines: 'pip/smug: You are late.' (speaker/mood: text), 'Plain text.' (the narrator) or an object with
// who / mood / text / if / do / cue / choose / goto / label / ending / id. The YAML form `- pip/smug: text` with extra
// keys (`if: cure`) is read too.

export type StoryValue = boolean | number;
/** What the game reports at each check (day, lifetime, rep …); names are declared in `vars.game` */
export type Progress = Readonly<Record<string, StoryValue | undefined>>;
/** When the game lets the story speak: after the player's first core action, at a run's start or end, or on an event */
export type Moment = 'first-action' | 'run-start' | 'run-end' | `event:${string}`;

export interface CastMember {
  name: string;
  /** Name plate colour */
  color?: string;
  /** Talking pitch for blips (the game's own sound) */
  voice?: number;
  /** Moods this speaker has (default: the story's `moods`) */
  moods?: readonly string[];
}

export interface Effects {
  /** Story flags to set to true */
  set?: string | readonly string[];
  /** Story flags to set to false */
  clear?: string | readonly string[];
  /** Add to number vars: { trust: 1 } */
  add?: Readonly<Record<string, number>>;
  /** Rewards the game hands out after the scene is committed: { gold: 20 } (names in `rewards`) */
  give?: Readonly<Record<string, number>>;
  /** Game events to fire after the scene is committed (names in `events`) */
  fire?: string | readonly string[];
}

export interface LineDef {
  /** Stable line id (default `<scene>.<n>`): set it when a line must keep its id through edits (translations) */
  id?: string;
  /** Speaker id from `cast`; default the narrator */
  who?: string;
  mood?: string;
  text?: string;
  /** Shown only when this condition holds (checked when the line is reached) */
  if?: string;
  /** Applied when the line is reached */
  do?: Effects;
  /** A hint for the game (highlight the cauldron …): names in `cues` */
  cue?: string;
  /** 1–3 choices after this line */
  choose?: readonly ChoiceDef[];
  /** Jump to a label of this scene after this line */
  goto?: string;
  /** A jump target (a line with only a label shows nothing) */
  label?: string;
  /** Marks an ending (in the result) */
  ending?: string;
}

export type Line = string | LineDef;

export interface ChoiceDef {
  /** Stable id: save data (chose()), analytics and QA use it */
  id: string;
  text: string;
  if?: string;
  do?: Effects;
  /** The reply lines, played before the scene goes on */
  then?: readonly Line[];
}

export interface SceneDef {
  title?: string;
  /** The moment it may play (chapters default to run-start; a scene without `at` plays only when your code runs it) */
  at?: Moment;
  when?: string;
  /** Side scenes play once by default; false: again whenever due */
  once?: boolean;
  /** Among due side scenes the highest wins (then the first defined) */
  priority?: number;
  /** Why this scene may be longer than the limits (the checker accepts it) */
  long?: string;
  lines: readonly Line[];
}

export interface StoryDef {
  /** Every speaker; `narrator` is built in (no name, no portrait) */
  cast: Readonly<Record<string, CastMember>>;
  /** Default mood set (default: ['neutral']) */
  moods?: readonly string[];
  vars?: {
    /** Owned and saved by the story, with defaults. Flags named in set/clear and vars in add are declared by use */
    story?: Readonly<Record<string, StoryValue>>;
    /** Read-only, supplied by the game at each check */
    game?: readonly string[];
  };
  rewards?: readonly string[];
  events?: readonly string[];
  cues?: readonly string[];
  /** The main line, told in order, one at a time; other scenes are side scenes */
  chapters?: readonly string[];
  scenes: Readonly<Record<string, SceneDef>>;
}

/** Saved inside the game's own save (a plain JSON object, well under 2 KB for 12 chapters) */
export interface StoryState {
  v: 1;
  /** Scene id → times finished */
  seen: Record<string, number>;
  /** Scene id → the choice ids picked in its last finished play */
  chose: Record<string, string[]>;
  vars: Record<string, StoryValue>;
}

/** The line on screen */
export interface StoryLine {
  id: string;
  /** Speaker id, 'narrator' for the narrator */
  who: string;
  mood: string;
  text: string;
  cue?: string;
}

export interface StoryChoice {
  id: string;
  text: string;
}

type Op = ['set' | 'clear', string] | ['add', string, number];

export interface SceneResult {
  scene: string;
  /** The scene reached its end (only then does commitScene() write it) */
  completed: boolean;
  /** The player used Skip */
  skipped: boolean;
  /** Choice ids in the order picked */
  choices: string[];
  /** Rewards to hand out once committed */
  give: Record<string, number>;
  /** Game events to fire once committed */
  fire: string[];
  cues: string[];
  ending?: string;
  /** Story var changes, replayed onto the state by commitScene() */
  ops: Op[];
}

export const NARRATOR = 'narrator';
export const DEFAULT_MOODS: readonly string[] = ['neutral'];

// --- Conditions: a tiny language, parsed into a tree (never eval'ed)
//   day >= 3 and not politePip · seen(cat) · chose(cat.polite) · (rep > 50 or won) · trust != 0

export type Expr =
  | { k: 'lit'; v: StoryValue }
  | { k: 'var'; name: string }
  | { k: 'not'; e: Expr }
  | { k: 'and' | 'or'; a: Expr; b: Expr }
  | { k: 'cmp'; op: '==' | '!=' | '<' | '<=' | '>' | '>='; a: Expr; b: Expr }
  | { k: 'seen'; scene: string }
  | { k: 'chose'; scene: string; choice: string };

const TOKEN = /\s*(?:(-?\d+(?:\.\d+)?)|([A-Za-z_][\w-]*(?:\.[\w-]+)?)|(==|!=|<=|>=|<|>|\(|\)|!|&&|\|\|))/y;

/** Parse a condition; throws with the position on a syntax error */
export function parseCondition(src: string): Expr {
  const toks: string[] = [];
  TOKEN.lastIndex = 0;
  while (TOKEN.lastIndex < src.length) {
    const at = TOKEN.lastIndex;
    const m = TOKEN.exec(src);
    if (!m) {
      if (!src.slice(at).trim()) break;
      throw new Error(`can't read "${src.slice(at).trim()}" in "${src}"`);
    }
    toks.push(m[1] ?? m[2] ?? m[3]);
  }
  let i = 0;
  const peek = () => toks[i];
  const take = (t?: string) => {
    const x = toks[i];
    if (x === undefined || (t !== undefined && x !== t)) throw new Error(`expected ${t ?? 'a value'}${x ? ` at "${x}"` : ' at the end'} in "${src}"`);
    i++;
    return x;
  };
  const or = (): Expr => {
    let a = and();
    while (peek() === 'or' || peek() === '||') {
      i++;
      a = { k: 'or', a, b: and() };
    }
    return a;
  };
  const and = (): Expr => {
    let a = not();
    while (peek() === 'and' || peek() === '&&') {
      i++;
      a = { k: 'and', a, b: not() };
    }
    return a;
  };
  const not = (): Expr => {
    if (peek() === 'not' || peek() === '!') {
      i++;
      return { k: 'not', e: not() };
    }
    const a = atom();
    const op = peek();
    if (op === '==' || op === '!=' || op === '<' || op === '<=' || op === '>' || op === '>=') {
      i++;
      return { k: 'cmp', op, a, b: atom() };
    }
    return a;
  };
  const atom = (): Expr => {
    const t = take();
    if (t === '(') {
      const e = or();
      take(')');
      return e;
    }
    if (/^-?\d/.test(t)) return { k: 'lit', v: Number(t) };
    if (t === 'true' || t === 'false') return { k: 'lit', v: t === 'true' };
    if (t === 'seen' || t === 'chose') {
      take('(');
      const ref = take();
      take(')');
      if (t === 'seen') return { k: 'seen', scene: ref };
      const [scene, choice] = ref.split('.');
      if (!choice) throw new Error(`chose() needs scene.choice, got "${ref}" in "${src}"`);
      return { k: 'chose', scene, choice };
    }
    if (/^[A-Za-z_]/.test(t) && !t.includes('.') && !['and', 'or', 'not'].includes(t)) return { k: 'var', name: t };
    throw new Error(`unexpected "${t}" in "${src}"`);
  };
  const e = or();
  if (i < toks.length) throw new Error(`unexpected "${toks[i]}" in "${src}"`);
  return e;
}

/** "Can't tell": a game var or another scene's history while checking the story statically */
const U = '?';
type Tri = StoryValue | undefined | typeof U;

interface Env {
  get(name: string): Tri;
  seen(scene: string): number | typeof U;
  chose(scene: string, choice: string): boolean | typeof U;
}

const num = (v: StoryValue | undefined) => (v === true ? 1 : v === false || v === undefined ? 0 : v);

function ev(e: Expr, env: Env): Tri {
  switch (e.k) {
    case 'lit':
      return e.v;
    case 'var':
      return env.get(e.name);
    case 'seen':
      return env.seen(e.scene);
    case 'chose':
      return env.chose(e.scene, e.choice);
    case 'not': {
      const v = ev(e.e, env);
      return v === U ? U : !truthy(v);
    }
    case 'and': {
      const a = ev(e.a, env);
      if (a !== U && !truthy(a)) return false;
      const b = ev(e.b, env);
      if (b !== U && !truthy(b)) return false;
      return a === U || b === U ? U : true;
    }
    case 'or': {
      const a = ev(e.a, env);
      if (a !== U && truthy(a)) return true;
      const b = ev(e.b, env);
      if (b !== U && truthy(b)) return true;
      return a === U || b === U ? U : false;
    }
    case 'cmp': {
      const a = ev(e.a, env);
      const b = ev(e.b, env);
      if (a === U || b === U) return U;
      const x = num(a);
      const y = num(b);
      return e.op === '==' ? x === y : e.op === '!=' ? x !== y : e.op === '<' ? x < y : e.op === '<=' ? x <= y : e.op === '>' ? x > y : x >= y;
    }
  }
}

const truthy = (v: StoryValue | undefined) => v === true || (typeof v === 'number' && v !== 0);
const test = (e: Expr, env: Env): boolean | typeof U => {
  const v = ev(e, env);
  return v === U ? U : truthy(v);
};

function refs(e: Expr, out: { vars: string[]; seen: string[]; chose: [string, string][] }): typeof out {
  if (e.k === 'var') out.vars.push(e.name);
  else if (e.k === 'seen') out.seen.push(e.scene);
  else if (e.k === 'chose') out.chose.push([e.scene, e.choice]);
  else if (e.k === 'not') refs(e.e, out);
  else if (e.k === 'and' || e.k === 'or' || e.k === 'cmp') {
    refs(e.a, out);
    refs(e.b, out);
  }
  return out;
}

// --- Loading: lines parsed, conditions compiled, ids given

interface NLine {
  id: string;
  who: string;
  mood: string;
  text: string;
  cond?: Expr;
  src: LineDef;
  choose?: NChoice[];
  path: (string | number)[];
}

interface NChoice {
  def: ChoiceDef;
  cond?: Expr;
  then: NLine[];
  path: (string | number)[];
}

interface NScene {
  id: string;
  def: SceneDef;
  lines: NLine[];
  labels: Map<string, number>;
  when?: Expr;
}

export interface Story {
  readonly def: StoryDef;
  readonly chapters: readonly string[];
  /** Every story var with its default (declared, and flags/counters declared by use) */
  readonly defaults: Readonly<Record<string, StoryValue>>;
  /** @internal the loaded scenes */
  readonly scenes: ReadonlyMap<string, NScene>;
}

export interface StoryIssue {
  code: string;
  severity: 'error' | 'warning';
  /** Where in the story, e.g. ['scenes', 'cat', 'lines', 2] */
  path: (string | number)[];
  message: string;
  fix: string;
}

const LINE_KEYS = new Set(['id', 'who', 'mood', 'text', 'if', 'do', 'cue', 'choose', 'goto', 'label', 'ending']);
const SPEAKER = /^([A-Za-z_][\w-]*)(?:\/([A-Za-z_][\w-]*))?:\s+([\s\S]*)$/;

/** 'pip/smug: text' → { who: 'pip', mood: 'smug', text }; text without a speaker is the narrator's */
export function parseLine(line: Line): LineDef {
  if (typeof line === 'string') {
    const m = SPEAKER.exec(line);
    return m ? { who: m[1], mood: m[2], text: m[3] } : { text: line };
  }
  // The YAML form: { 'pip/smug': 'text', if: … } — one key that isn't a line field is the speaker
  const extra = Object.keys(line).filter((k) => !LINE_KEYS.has(k));
  if (extra.length === 1 && line.text === undefined && line.who === undefined) {
    const k = extra[0];
    const v = (line as Record<string, unknown>)[k];
    const [who, mood] = k.split('/');
    const rest: Record<string, unknown> = { ...line };
    delete rest[k];
    return { ...(rest as LineDef), who, mood, text: typeof v === 'string' ? v : String(v) };
  }
  return line;
}

const list = (x: string | readonly string[] | undefined): readonly string[] => (x === undefined ? [] : typeof x === 'string' ? [x] : x);

function compile(src: string | undefined, path: (string | number)[], issues: StoryIssue[]): Expr | undefined {
  if (src === undefined) return undefined;
  try {
    return parseCondition(String(src));
  } catch (e) {
    issues.push({ code: 'E_STORY_CONDITION', severity: 'error', path, message: (e as Error).message, fix: 'Use names, numbers, not / and / or, ( ), == != < <= > >=, seen(scene), chose(scene.choice).' });
    return undefined;
  }
}

function normalize(def: StoryDef, issues: StoryIssue[]): Story {
  const scenes = new Map<string, NScene>();
  const defaults: Record<string, StoryValue> = { ...def.vars?.story };
  const declare = (name: string, v: StoryValue) => {
    if (!Object.hasOwn(defaults, name)) defaults[name] = v;
  };
  const effects = (d: Effects | undefined) => {
    for (const f of [...list(d?.set), ...list(d?.clear)]) declare(f, false);
    for (const n of Object.keys(d?.add ?? {})) declare(n, 0);
  };
  const lines = (sceneId: string, src: readonly Line[] | undefined, prefix: string, path: (string | number)[]): NLine[] => {
    if (!Array.isArray(src)) {
      issues.push({ code: 'E_STORY_REF', severity: 'error', path, message: 'lines must be a list', fix: 'Write lines: [ ... ].' });
      return [];
    }
    return src.map((raw, n) => {
      const p = [...path, n];
      const d = parseLine(raw);
      const id = d.id ?? `${prefix}.${n + 1}`;
      effects(d.do);
      const who = d.who ?? NARRATOR;
      const l: NLine = { id, who, mood: d.mood ?? 'neutral', text: d.text ?? '', cond: compile(d.if, [...p, 'if'], issues), src: d, path: p };
      if (d.choose)
        l.choose = d.choose.map((c, ci) => {
          effects(c.do);
          const cp = [...p, 'choose', ci];
          return { def: c, cond: compile(c.if, [...cp, 'if'], issues), then: lines(sceneId, c.then ?? [], `${id}.${c.id}`, [...cp, 'then']), path: cp };
        });
      return l;
    });
  };
  for (const [id, s] of Object.entries(def.scenes ?? {})) {
    const path = ['scenes', id];
    const ls = lines(id, s.lines, id, [...path, 'lines']);
    const labels = new Map<string, number>();
    ls.forEach((l, i) => {
      if (l.src.label === undefined) return;
      if (labels.has(l.src.label)) issues.push({ code: 'E_STORY_IDS', severity: 'error', path: [...l.path, 'label'], message: `label "${l.src.label}" is used twice in scene "${id}"`, fix: 'Give each label its own name.' });
      else labels.set(l.src.label, i);
    });
    scenes.set(id, { id, def: s, lines: ls, labels, when: compile(s.when, [...path, 'when'], issues) });
  }
  // goto targets and chapters must exist, or the runner can't run
  const walkGoto = (s: NScene, ls: NLine[]) => {
    for (const l of ls) {
      if (l.src.goto !== undefined && !s.labels.has(l.src.goto))
        issues.push({ code: 'E_STORY_REF', severity: 'error', path: [...l.path, 'goto'], message: `goto "${l.src.goto}": no such label in scene "${s.id}"`, fix: `Add a line { label: ${l.src.goto} } at the top level of the scene, or fix the name (labels: ${[...s.labels.keys()].join(', ') || 'none'}).` });
      for (const c of l.choose ?? []) walkGoto(s, c.then);
    }
  };
  for (const s of scenes.values()) walkGoto(s, s.lines);
  (def.chapters ?? []).forEach((c, i) => {
    if (!scenes.has(c)) issues.push({ code: 'E_STORY_REF', severity: 'error', path: ['chapters', i], message: `chapter "${c}" is not a scene`, fix: 'Add the scene under scenes, or remove it from chapters.' });
  });
  return { def, chapters: (def.chapters ?? []).filter((c) => scenes.has(c)), defaults, scenes };
}

/** Load a story for playing. Throws when it can't run (a condition that doesn't parse, a goto to nowhere); run validateStory() in a unit test for everything else */
export function loadStory(def: StoryDef): Story {
  const issues: StoryIssue[] = [];
  const story = normalize(def, issues);
  if (issues.length) throw new Error(`story: ${issues.map((i) => `${formatStoryPath(i.path)}: ${i.message}`).join('; ')}`);
  return story;
}

export function formatStoryPath(path: readonly (string | number)[]): string {
  let s = '';
  for (const p of path) s += typeof p === 'number' ? `[${p}]` : s ? `.${p}` : p;
  return s || '(story)';
}

// --- State

/** A fresh state, or a saved one cleaned up: unknown scenes and vars dropped, wrong types back to defaults */
export function storyState(story: Story, saved?: unknown): StoryState {
  const s = (saved && typeof saved === 'object' ? saved : {}) as Partial<StoryState>;
  const seen: Record<string, number> = {};
  for (const [id, n] of Object.entries(s.seen ?? {})) if (story.scenes.has(id) && Number.isInteger(n) && n > 0) seen[id] = n;
  const chose: Record<string, string[]> = {};
  for (const [id, c] of Object.entries(s.chose ?? {})) if (story.scenes.has(id) && Array.isArray(c)) chose[id] = c.filter((x) => typeof x === 'string');
  const vars: Record<string, StoryValue> = { ...story.defaults };
  for (const [k, v] of Object.entries(s.vars ?? {})) if (Object.hasOwn(vars, k) && typeof v === typeof vars[k] && (typeof v !== 'number' || Number.isFinite(v))) vars[k] = v;
  return { v: 1, seen, chose, vars };
}

function stateEnv(story: Story, state: StoryState, progress: Progress): Env {
  return {
    get: (n) => (Object.hasOwn(story.defaults, n) ? (state.vars[n] ?? story.defaults[n]) : progress[n]),
    seen: (id) => state.seen[id] ?? 0,
    chose: (id, c) => !!state.chose[id]?.includes(c),
  };
}

/**
 * The scene to play at this moment, or null: the next main chapter if its `when` holds, otherwise the highest-priority
 * side scene that is due (once-only side scenes that were seen don't count). Call it at your safe points — after the
 * first core action, at a run's start or end — never in the middle of the action.
 */
export function dueScene(story: Story, state: StoryState, moment: Moment, progress: Progress = {}): string | null {
  const env = stateEnv(story, state, progress);
  const ok = (s: NScene) => !s.when || test(s.when, env) === true;
  const main = nextChapter(story, state);
  if (main) {
    const s = story.scenes.get(main)!;
    if ((s.def.at ?? 'run-start') === moment && ok(s)) return main;
  }
  let best: NScene | null = null;
  const chapters = new Set(story.chapters);
  for (const s of story.scenes.values()) {
    if (chapters.has(s.id) || s.def.at !== moment || (s.def.once !== false && state.seen[s.id]) || !ok(s)) continue;
    if (!best || (s.def.priority ?? 0) > (best.def.priority ?? 0)) best = s;
  }
  return best?.id ?? null;
}

/** The next main chapter not yet seen (for a "the next chapter unlocks when …" hint), or null when the main line is told */
export function nextChapter(story: Story, state: StoryState): string | null {
  return story.chapters.find((c) => !state.seen[c]) ?? null;
}

/** Main chapters seen, 0–100 (for a progress bar or the portal's completion percentage) */
export function storyProgress(story: Story, state: StoryState): number {
  if (!story.chapters.length) return 100;
  return Math.floor((story.chapters.filter((c) => state.seen[c]).length / story.chapters.length) * 100);
}

const committed = new WeakSet<SceneResult>();

/**
 * Write a finished scene into the state: seen, choices, var changes. Returns the new state (the old one is untouched);
 * then hand out result.give and fire result.fire, and save. An unfinished scene (interrupted, closed) and a result
 * committed before change nothing, so a scene never pays twice.
 */
export function commitScene(story: Story, state: StoryState, result: SceneResult): StoryState {
  if (!result.completed || committed.has(result)) return state;
  committed.add(result);
  const vars = { ...state.vars };
  for (const op of result.ops) {
    if (op[0] === 'add') vars[op[1]] = num(vars[op[1]] ?? story.defaults[op[1]]) + op[2];
    else vars[op[1]] = op[0] === 'set';
  }
  return {
    v: 1,
    seen: { ...state.seen, [result.scene]: (state.seen[result.scene] ?? 0) + 1 },
    chose: result.choices.length ? { ...state.chose, [result.scene]: [...result.choices] } : { ...state.chose },
    vars,
  };
}

// --- Running a scene. The same stepping code serves the runner (conditions known) and the checker (game vars unknown:
// both outcomes are followed).

interface Frame {
  lines: NLine[];
  key: string;
  i: number;
}

interface Pos {
  frames: Frame[];
  vars: Record<string, StoryValue | typeof U>;
  chose: string[];
  give: Record<string, number>;
  fire: string[];
  cues: string[];
  ops: Op[];
  ending?: string;
  /** A goto loop with no line to show */
  stuck?: boolean;
}

type Test = (e: Expr, p: Pos) => boolean | typeof U;

const clonePos = (p: Pos): Pos => ({ ...p, frames: p.frames.map((f) => ({ ...f })), vars: { ...p.vars }, chose: [...p.chose], give: { ...p.give }, fire: [...p.fire], cues: [...p.cues], ops: [...p.ops] });

const current = (p: Pos): NLine | null => {
  const f = p.frames.at(-1);
  return f ? f.lines[f.i] : null;
};

function applyEffects(d: Effects | undefined, p: Pos): void {
  if (!d) return;
  for (const f of list(d.set)) {
    p.vars[f] = true;
    p.ops.push(['set', f]);
  }
  for (const f of list(d.clear)) {
    p.vars[f] = false;
    p.ops.push(['clear', f]);
  }
  for (const [k, n] of Object.entries(d.add ?? {})) {
    const v = p.vars[k];
    p.vars[k] = v === U ? U : num(v) + n;
    p.ops.push(['add', k, n]);
  }
  for (const [k, n] of Object.entries(d.give ?? {})) p.give[k] = (p.give[k] ?? 0) + n;
  p.fire.push(...list(d.fire));
}

function jump(scene: NScene, p: Pos, label: string): void {
  p.frames = [{ lines: scene.lines, key: scene.id, i: scene.labels.get(label) ?? scene.lines.length }];
}

/** Move on to the next line to show (or the end), applying what the lines on the way do. Unknown conditions fork */
function settle(scene: NScene, p: Pos, t: Test): Pos[] {
  const out: Pos[] = [];
  for (let steps = 0; ; steps++) {
    if (steps > 10000) {
      p.stuck = true;
      return [p, ...out];
    }
    const f = p.frames.at(-1);
    if (!f) return [p, ...out];
    if (f.i >= f.lines.length) {
      p.frames.pop();
      continue;
    }
    const l = f.lines[f.i];
    if (l.cond) {
      const r = t(l.cond, p);
      if (r === U) {
        const skip = clonePos(p);
        skip.frames.at(-1)!.i++;
        out.push(...settle(scene, skip, t));
      } else if (!r) {
        f.i++;
        continue;
      }
    }
    applyEffects(l.src.do, p);
    if (l.src.cue) p.cues.push(l.src.cue);
    if (l.src.ending) p.ending = l.src.ending;
    if (l.text) return [p, ...out];
    if (l.src.goto !== undefined) jump(scene, p, l.src.goto);
    else f.i++;
  }
}

function leave(scene: NScene, p: Pos): void {
  const l = current(p)!;
  if (l.src.goto !== undefined) jump(scene, p, l.src.goto);
  else p.frames.at(-1)!.i++;
}

function pick(p: Pos, c: NChoice): void {
  p.frames.at(-1)!.i++;
  applyEffects(c.def.do, p);
  p.chose.push(c.def.id);
  if (c.then.length) p.frames.push({ lines: c.then, key: `${c.path.join('.')}`, i: 0 });
}

/**
 * Plays one scene step by step on a copy of the story state:
 *   const run = new StoryRunner(story, 'cat', save.story, { day });
 *   run.line · run.choices() · run.next() · run.choose('polite') · run.skip() · run.done · run.result
 * Then commitScene(story, save.story, run.result) — only a finished scene is written.
 */
export class StoryRunner {
  readonly scene: string;
  private readonly sc: NScene;
  private readonly p: Pos;
  private readonly env: Env;
  private skipped = false;
  private final: SceneResult | null = null;

  private readonly i18n: StoryI18n | null;

  /** `opts.i18n` (host.i18n): lines and choices in the player's language, from the `story.*` keys of strings/<code>.yaml */
  constructor(story: Story, scene: string, state: StoryState, progress: Progress = {}, opts: { i18n?: StoryI18n | null } = {}) {
    this.i18n = opts.i18n ?? null;
    const sc = story.scenes.get(scene);
    if (!sc) throw new Error(`story: no scene "${scene}"`);
    this.scene = scene;
    this.sc = sc;
    this.p = { frames: [{ lines: sc.lines, key: scene, i: 0 }], vars: { ...story.defaults, ...state.vars }, chose: [], give: {}, fire: [], cues: [], ops: [] };
    const base = stateEnv(story, state, progress);
    this.env = {
      get: (n) => (Object.hasOwn(story.defaults, n) ? this.p.vars[n] : base.get(n)),
      seen: base.seen,
      // This scene's own choices count as soon as they are made
      chose: (id, c) => (id === scene ? this.p.chose.includes(c) : base.chose(id, c)),
    };
    this.step();
  }

  private readonly t: Test = (e) => test(e, this.env);

  private step(): void {
    settle(this.sc, this.p, this.t);
    if (this.p.stuck) throw new Error(`story: scene "${this.scene}" loops through goto without a line to show`);
  }

  /** The line on screen, or null when the scene is over */
  get line(): StoryLine | null {
    const l = current(this.p);
    if (!l) return null;
    return { id: l.id, who: l.who, mood: l.mood, text: storyText(this.i18n, lineKey(l.id), l.text), ...(l.src.cue ? { cue: l.src.cue } : {}) };
  }

  get done(): boolean {
    return !current(this.p);
  }

  private visible(): NChoice[] {
    return current(this.p)?.choose?.filter((c) => !c.cond || this.t(c.cond, this.p) === true) ?? [];
  }

  /** The choices the player can pick now (conditions checked now); empty: a plain line, next() goes on */
  choices(): StoryChoice[] {
    return this.visible().map((c) => ({ id: c.def.id, text: storyText(this.i18n, choiceKey(current(this.p)!.id, c.def.id), c.def.text) }));
  }

  /** Go on from a line without choices; false when there's nothing to do (a choice is due, or the scene is over) */
  next(): boolean {
    if (this.done || this.visible().length) return false;
    leave(this.sc, this.p);
    this.step();
    return true;
  }

  /** Pick a visible choice by id; false when it isn't one */
  choose(id: string): boolean {
    const c = this.visible().find((x) => x.def.id === id);
    if (!c) return false;
    pick(this.p, c);
    this.step();
    return true;
  }

  /** Fast-forward to the next choice point (choices are the player's) or the end; skipped lines still do what they do */
  skip(): void {
    if (this.done) return;
    this.skipped = true;
    while (!this.done && !this.visible().length) this.next();
  }

  /** What happened so far; once the scene is over, the same object every time (commit it once) */
  get result(): SceneResult {
    if (this.final) return this.final;
    const p = this.p;
    const r: SceneResult = {
      scene: this.scene,
      completed: this.done,
      skipped: this.skipped,
      choices: [...p.chose],
      give: { ...p.give },
      fire: [...p.fire],
      cues: [...p.cues],
      ops: [...p.ops],
      ...(p.ending !== undefined ? { ending: p.ending } : {}),
    };
    if (this.done) this.final = r;
    return r;
  }
}

// --- The story in the player's language: its texts as strings/<code>.yaml keys (gp story --strings writes them) ------

/** What the story needs of host.i18n */
export type StoryI18n = { t(key: string): string; has(key: string, lang?: string): boolean; readonly fallback: string };

/** A line's key: `story.<line id>` ("story.cat.2", "story.cat.2.polite.1") */
export const lineKey = (lineId: string): string => `story.${lineId}`;
/** A choice's key: `story.<line id>.<choice id>` ("story.cat.2.polite") */
export const choiceKey = (lineId: string, choiceId: string): string => `story.${lineId}.${choiceId}`;
/** A bark's key: `bark.<event>.<n>`, n from 1 ("bark.run-start.2") */
export const barkKey = (event: string, index: number): string => `bark.${event}.${index + 1}`;

/**
 * The text in the player's language when strings/en.yaml has the key (gp story --strings put it there; gp translate
 * lists it for the other languages), else the story file's English as it is
 */
export function storyText(i18n: StoryI18n | null | undefined, key: string, english: string): string {
  return i18n && i18n.has(key, i18n.fallback) ? i18n.t(key) : english;
}

/** A bark in the player's language: `bark(BARKS[event][i])` → `barkText(host.i18n, event, i, BARKS[event][i])` */
export function barkText(i18n: StoryI18n | null | undefined, event: string, index: number, english: string): string {
  return storyText(i18n, barkKey(event, index), english);
}

/**
 * Every text of a story and its barks as strings keys → English: what `gp story --strings` writes into strings/en.yaml
 * (flat dotted keys) and `gp validate` keeps in step (W_STORY_STRINGS). Lines with text, choices, and each bark list
 */
export function storyStrings(def: StoryDef | null, barks: Readonly<Record<string, readonly string[]>> = {}): Record<string, string> {
  const out: Record<string, string> = {};
  if (def) {
    const story = normalize(def, []);
    const walk = (ls: NLine[]) => {
      for (const l of ls) {
        if (l.text) out[lineKey(l.id)] = l.text;
        for (const c of l.choose ?? []) {
          if (c.def.text) out[choiceKey(l.id, c.def.id)] = c.def.text;
          walk(c.then);
        }
      }
    };
    for (const sc of story.scenes.values()) walk(sc.lines);
  }
  for (const [event, lines] of Object.entries(barks)) lines.forEach((t, i) => typeof t === 'string' && t && (out[barkKey(event, i)] = t));
  return out;
}

// --- Checking a story (run it in the game's unit test: expect(errors).toEqual([]))

export interface StoryLimits {
  /** Characters per line: warning above, error above max */
  lineWarn: number;
  lineMax: number;
  /** Words per scene on its longest path: warning above, error above max (unless the scene says why it is `long`) */
  sceneWarn: number;
  sceneMax: number;
  /** The first main chapter, longest path */
  firstScene: number;
  /** A scene at the first-action moment (the premise) */
  firstAction: number;
  /** Choices per point and characters per choice (warning) */
  choices: number;
  choiceChars: number;
}

/** The web / 13+ numbers (docs/research/story-2026-09.md §3.5); child audiences are stricter */
export const STORY_LIMITS: StoryLimits = { lineWarn: 100, lineMax: 140, sceneWarn: 120, sceneMax: 200, firstScene: 60, firstAction: 20, choices: 3, choiceChars: 40 };

const ID = /^[a-z0-9][a-z0-9_-]*$/i;
const MAX_NODES = 4000;
const words = (text: string): number => text.split(/\s+/).filter(Boolean).length;

/** Every problem the checker finds; errors must be fixed, warnings read and fixed or explained */
export function validateStory(def: StoryDef, limits: Partial<StoryLimits> = {}): StoryIssue[] {
  const L = { ...STORY_LIMITS, ...limits };
  const issues: StoryIssue[] = [];
  const story = normalize(def, issues);
  const err = (code: string, path: (string | number)[], message: string, fix: string) => issues.push({ code, severity: 'error', path, message, fix });
  const warn = (code: string, path: (string | number)[], message: string, fix: string) => issues.push({ code, severity: 'warning', path, message, fix });
  const gameVars = new Set(def.vars?.game ?? []);
  const cast = def.cast ?? {};
  const lineIds = new Map<string, string>();
  const written = new Set<string>();

  for (const g of gameVars) if (Object.hasOwn(story.defaults, g)) err('E_STORY_VARS', ['vars'], `"${g}" is both a game var and a story var`, 'Rename one of them.');
  for (const [k, v] of Object.entries(def.vars?.story ?? {})) if (typeof v !== 'boolean' && typeof v !== 'number') err('E_STORY_VARS', ['vars', 'story', k], `story var "${k}" must default to true/false or a number`, 'Write `name: false` or `name: 0`.');

  const checkCond = (e: Expr | undefined, path: (string | number)[]) => {
    if (!e) return;
    const r = refs(e, { vars: [], seen: [], chose: [] });
    for (const v of r.vars) if (!Object.hasOwn(story.defaults, v) && !gameVars.has(v)) err('E_STORY_REF', path, `the condition reads "${v}", which is neither a story var nor a game var`, `Declare it under vars.story (with a default) or vars.game, or set it with do: { set: ${v} }.`);
    for (const s of r.seen) if (!story.scenes.has(s)) err('E_STORY_REF', path, `seen(${s}): no such scene`, 'Use a scene id.');
    for (const [s, c] of r.chose) {
      const sc = story.scenes.get(s);
      if (!sc) err('E_STORY_REF', path, `chose(${s}.${c}): no such scene`, 'Use scene.choice ids.');
      else if (!allChoices(sc.lines).some((x) => x.def.id === c)) err('E_STORY_REF', path, `chose(${s}.${c}): scene "${s}" has no choice "${c}"`, 'Use a choice id of that scene.');
    }
  };
  const checkEffects = (d: Effects | undefined, path: (string | number)[]) => {
    if (!d) return;
    for (const f of [...list(d.set), ...list(d.clear)]) {
      written.add(f);
      if (typeof story.defaults[f] === 'number') err('E_STORY_EFFECT', path, `set/clear "${f}", which is a number`, `Use add: { ${f}: 1 }.`);
      if (gameVars.has(f)) err('E_STORY_EFFECT', path, `"${f}" is a game var: the story can't change it`, 'Use a story var, or fire an event the game handles.');
    }
    for (const [k, n] of Object.entries(d.add ?? {})) {
      written.add(k);
      if (typeof story.defaults[k] === 'boolean') err('E_STORY_EFFECT', path, `add to "${k}", which is a flag`, `Use set/clear, or declare ${k} as a number.`);
      if (typeof n !== 'number' || !Number.isFinite(n)) err('E_STORY_EFFECT', path, `add: ${k} must be a number`, 'Write add: { name: 1 }.');
    }
    for (const r of Object.keys(d.give ?? {})) if (!def.rewards?.includes(r)) err('E_STORY_EFFECT', path, `give "${r}": not in rewards`, `Add "${r}" to rewards (the game hands them out), or fix the name.`);
    for (const e of list(d.fire)) if (!def.events?.includes(e)) err('E_STORY_EFFECT', path, `fire "${e}": not in events`, `Add "${e}" to events (the game handles them), or fix the name.`);
  };

  const checkLines = (sc: NScene, ls: NLine[], top: boolean) => {
    let narrators = 0;
    for (const l of ls) {
      const d = l.src;
      if (d.id !== undefined) {
        if (!ID.test(d.id.replace(/\./g, '-'))) err('E_STORY_IDS', [...l.path, 'id'], `line id "${d.id}" has characters ids can't have`, 'Use letters, digits, - _ and dots.');
        const was = lineIds.get(d.id);
        if (was) err('E_STORY_IDS', [...l.path, 'id'], `line id "${d.id}" is used twice (also ${was})`, 'Give each line its own id.');
        lineIds.set(d.id, formatStoryPath(l.path));
      }
      if (d.label !== undefined && !top) err('E_STORY_REF', [...l.path, 'label'], `label "${d.label}" inside a choice's reply`, 'Put labels at the top level of the scene (goto jumps there).');
      if (d.goto !== undefined && d.choose) err('E_STORY_REF', [...l.path, 'goto'], 'a line with choices can\'t goto', "Put the goto at the end of each choice's then.");
      if (l.text) {
        if (l.who !== NARRATOR && !cast[l.who]) err('E_STORY_SPEAKER', l.path, `speaker "${l.who}" is not in the cast`, `Add ${l.who} to cast, or fix the name (cast: ${Object.keys(cast).join(', ')}). Text with a colon in it needs the object form { text: … }.`);
        else if (d.mood !== undefined && (l.who === NARRATOR ? d.mood !== 'neutral' : !(cast[l.who].moods ?? def.moods ?? DEFAULT_MOODS).includes(d.mood)))
          err('E_STORY_MOOD', l.path, `mood "${l.mood}" is not one of ${l.who}'s moods`, `Use one of: ${l.who === NARRATOR ? 'none (the narrator has no face)' : (cast[l.who].moods ?? def.moods ?? DEFAULT_MOODS).join(', ')}, or declare it in moods.`);
        const n = [...l.text].length;
        if (n > L.lineMax) err('E_STORY_LINE_LONG', l.path, `${n} characters in one line (max ${L.lineMax})`, 'Split it into two lines: long lines overflow the dialogue box on phones.');
        else if (n > L.lineWarn) warn('W_STORY_LINE_LONG', l.path, `${n} characters in one line (over ${L.lineWarn})`, 'Shorter lines read better; split it.');
        narrators = l.who === NARRATOR ? narrators + 1 : 0;
        if (narrators === 3) warn('W_STORY_NARRATOR_WALL', l.path, '3 narrator lines in a row: exposition', 'Let a character say it, or cut it.');
      } else if (d.choose) err('E_STORY_REF', l.path, 'a line with choices needs text', 'Add the line the choices answer.');
      if (d.cue !== undefined && !def.cues?.includes(d.cue)) err('E_STORY_EFFECT', [...l.path, 'cue'], `cue "${d.cue}": not in cues`, `Add "${d.cue}" to cues (the game reacts to it), or fix the name.`);
      checkCond(l.cond, [...l.path, 'if']);
      checkEffects(d.do, [...l.path, 'do']);
      if (d.choose) {
        const n = d.choose.length;
        if (n < 1 || n > L.choices) err('E_STORY_CHOICES', [...l.path, 'choose'], `${n} choices (1–${L.choices})`, n ? 'Cut choices: more than three is a menu, not a conversation.' : 'Add a choice, or remove choose.');
        const texts = new Set<string>();
        for (const c of l.choose ?? []) {
          const cd = c.def;
          if (!cd.id || !ID.test(cd.id)) err('E_STORY_IDS', [...c.path, 'id'], `choice id "${cd.id ?? ''}" is missing or not a plain id`, 'Give every choice a stable id (letters, digits, - _): it is save data.');
          else if (sceneChoiceIds.has(cd.id)) err('E_STORY_IDS', [...c.path, 'id'], `choice id "${cd.id}" is used twice in scene "${sc.id}"`, 'Choice ids are unique within a scene (chose(scene.choice) reads them).');
          if (cd.id) sceneChoiceIds.add(cd.id);
          if (!cd.text?.trim()) err('E_STORY_CHOICES', [...c.path, 'text'], 'a choice without text', 'Write what the player says.');
          else if (texts.has(cd.text)) err('E_STORY_CHOICES', [...c.path, 'text'], `two choices say "${cd.text}"`, 'Make the choices different.');
          else if ([...cd.text].length > L.choiceChars) warn('W_STORY_CHOICE_LONG', [...c.path, 'text'], `${[...cd.text].length} characters in a choice (over ${L.choiceChars})`, 'A choice is a short reply; shorten it.');
          texts.add(cd.text);
          if (!cd.do && !cd.then?.length) warn('W_STORY_NO_PAYOFF', c.path, `choice "${cd.id}" changes nothing and gets no reply`, 'Add a reply (then) or an effect (do), or drop the choice.');
          checkCond(c.cond, [...c.path, 'if']);
          checkEffects(cd.do, [...c.path, 'do']);
          checkLines(sc, c.then, false);
        }
        narrators = 0;
      }
    }
  };
  let sceneChoiceIds = new Set<string>();
  for (const sc of story.scenes.values()) {
    const path = ['scenes', sc.id];
    if (!ID.test(sc.id)) err('E_STORY_IDS', path, `scene id "${sc.id}" is not a plain id`, 'Use letters, digits, - _: scene ids are save data.');
    const at = sc.def.at;
    if (at !== undefined && !['first-action', 'run-start', 'run-end'].includes(at) && !/^event:[\w-]+$/.test(at)) err('E_STORY_REF', [...path, 'at'], `at "${at}" is not a moment`, 'Use first-action, run-start, run-end or event:<name>.');
    if (!sc.lines.some((l) => l.text || l.choose)) err('E_STORY_REF', [...path, 'lines'], 'a scene with nothing to show', 'Add lines.');
    sceneChoiceIds = new Set();
    checkLines(sc, sc.lines, true);
    checkCond(sc.when, [...path, 'when']);
  }
  const seenChapters = new Set<string>();
  (def.chapters ?? []).forEach((c, i) => {
    if (seenChapters.has(c)) err('E_STORY_IDS', ['chapters', i], `chapter "${c}" is listed twice`, 'List each chapter once.');
    seenChapters.add(c);
  });
  // Stop here when the story can't be walked (broken references would only repeat as dead ends)
  if (issues.some((i) => i.severity === 'error' && (i.code === 'E_STORY_CONDITION' || (i.code === 'E_STORY_REF' && i.path.includes('goto'))))) return issues;

  // Walk every scene's paths: story vars threaded through (unknown at the start when some scene writes them), game vars
  // and other scenes' history unknown, so both outcomes are followed
  const start = (): Pos['vars'] => Object.fromEntries(Object.entries(story.defaults).map(([k, v]) => [k, written.has(k) ? U : v]));
  const staticEnv: Env = { get: (n) => (Object.hasOwn(story.defaults, n) ? (written.has(n) ? U : story.defaults[n]) : U), seen: () => U, chose: () => U };
  const chapters = new Set(story.chapters);
  for (const sc of story.scenes.values()) {
    const path = ['scenes', sc.id];
    const w = walk(sc, start());
    if (w.truncated) warn('W_STORY_PATHS', path, `more than ${MAX_NODES} states: not every path was checked`, 'Split the scene, or use fewer flags in it.');
    if (w.deadEnd) err('E_STORY_DEAD_END', path, `a path can't reach the end (${w.deadEnd})`, 'Every goto loop needs a way out (a choice that leaves it).');
    for (const l of w.allHidden) warn('W_STORY_ALL_HIDDEN', l.path, 'on some path every choice here is hidden: the line plays as a plain line', 'Add a choice without a condition, or make sure one always shows.');
    const n = w.maxWords;
    const long = sc.def.long !== undefined;
    if (n > L.sceneMax && !long) err('E_STORY_SCENE_LONG', path, `${n} words on the longest path (max ${L.sceneMax})`, `Cut it, split it into two scenes, or say why with long: "<reason>".`);
    else if (n > L.sceneWarn && !long) warn('W_STORY_SCENE_LONG', path, `${n} words on the longest path (over ${L.sceneWarn}, ≈ ${Math.round((n / 238) * 60)} s of reading)`, 'Chapters work best at ≤ 8 lines and ≤ 120 words; cut, or say why with long.');
    if (sc.def.at === 'first-action' && n > L.firstAction) err('E_STORY_FIRST_ACTION', path, `${n} words at the first action (max ${L.firstAction})`, 'The premise before play is one short line; tell the rest after the first run.');
    if (story.chapters[0] === sc.id && n > L.firstScene) err('E_STORY_FIRST_SCENE', path, `the first chapter has ${n} words on its longest path (max ${L.firstScene})`, 'Keep the first scene short: play first, story after.');
    for (const l of allLines(sc.lines)) if (l.text && !w.shown.has(l.id)) warn('W_STORY_LINE_UNREACHABLE', l.path, `line "${l.id}" is never shown on any path`, 'Check its if (it reads a flag nobody sets?), or remove it.');
    if ((chapters.has(sc.id) || sc.def.at) && sc.when && test(sc.when, staticEnv) === false)
      err('E_STORY_UNREACHABLE', [...path, 'when'], `"${sc.def.when}" can never be true (it reads story vars nothing changes)`, 'Set the flag somewhere (a choice\'s do), or fix the condition.');
  }
  return issues;
}

function allLines(ls: NLine[]): NLine[] {
  return ls.flatMap((l) => [l, ...(l.choose ?? []).flatMap((c) => allLines(c.then))]);
}

function allChoices(ls: NLine[]): NChoice[] {
  return allLines(ls).flatMap((l) => l.choose ?? []);
}

/** The scene as a graph of "a line on screen" states: dead ends, lines shown, the longest path in words */
function walk(sc: NScene, vars: Pos['vars']): { deadEnd: string | null; allHidden: NLine[]; maxWords: number; shown: Set<string>; truncated: boolean } {
  const t: Test = (e, p) => test(e, { get: (n) => (n in p.vars ? p.vars[n] : U), seen: () => U, chose: (id, c) => (id === sc.id ? p.chose.includes(c) : U) });
  const key = (p: Pos) => `${p.frames.map((f) => `${f.key}@${f.i}`).join('|')}#${JSON.stringify(p.vars)}#${[...new Set(p.chose)].sort().join(',')}`; // chose() tests membership: the set is the state
  const nodes = new Map<string, { p: Pos; succ: string[] }>();
  const hidden = new Set<NLine>();
  const shown = new Set<string>();
  const queue: string[] = [];
  const add = (ps: Pos[]): string[] =>
    ps.map((p) => {
      const k = p.stuck ? `stuck#${key(p)}` : key(p);
      if (!nodes.has(k) && nodes.size < MAX_NODES) {
        nodes.set(k, { p, succ: [] });
        queue.push(k);
      }
      return k;
    });
  const startKeys = add(settle(sc, { frames: [{ lines: sc.lines, key: sc.id, i: 0 }], vars, chose: [], give: {}, fire: [], cues: [], ops: [] }, t));
  while (queue.length) {
    const k = queue.shift()!;
    const n = nodes.get(k)!;
    const l = current(n.p);
    if (!l || n.p.stuck) continue;
    shown.add(l.id);
    const cs = (l.choose ?? []).map((c) => ({ c, v: c.cond ? t(c.cond, n.p) : true }));
    for (const { c, v } of cs)
      if (v !== false) {
        const p = clonePos(n.p);
        pick(p, c);
        n.succ.push(...add(settle(sc, p, t)));
      }
    // No choice is surely shown: the line may play as a plain one
    if (!cs.some((x) => x.v === true)) {
      if (cs.length) hidden.add(l);
      const p = clonePos(n.p);
      leave(sc, p);
      n.succ.push(...add(settle(sc, p, t)));
    }
  }
  // Which states can reach the end
  const pred = new Map<string, string[]>();
  for (const [k, n] of nodes) for (const s of n.succ) pred.set(s, [...(pred.get(s) ?? []), k]);
  const canEnd = new Set<string>([...nodes].filter(([, n]) => !current(n.p) && !n.p.stuck).map(([k]) => k));
  const todo = [...canEnd];
  while (todo.length)
    for (const q of pred.get(todo.pop()!) ?? [])
      if (!canEnd.has(q)) {
        canEnd.add(q);
        todo.push(q);
      }
  const truncated = nodes.size >= MAX_NODES;
  const bad = truncated ? undefined : [...nodes].find(([k]) => !canEnd.has(k));
  // The longest path in words (a loop is counted once)
  const memo = new Map<string, number>();
  const onPath = new Set<string>();
  const longest = (k: string): number => {
    if (memo.has(k)) return memo.get(k)!;
    const n = nodes.get(k);
    if (!n || onPath.has(k)) return 0;
    onPath.add(k);
    const l = current(n.p);
    const own = l ? words(l.text) : 0;
    const best = own + Math.max(0, ...n.succ.map(longest));
    onPath.delete(k);
    memo.set(k, best);
    return best;
  };
  return {
    deadEnd: bad ? (bad[1].p.stuck ? 'a goto loop with no line to show' : `stuck from line ${current(bad[1].p)?.id ?? '?'}`) : null,
    allHidden: [...hidden],
    maxWords: Math.max(0, ...startKeys.map(longest)),
    shown,
    truncated,
  };
}
