// The uniqueness score: a copied mechanic is a gate, a replaced one counts; the example is honest about itself.

import { cpSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterAll, describe, expect, it } from 'vitest';
import { checkGame } from '../src/game.ts';
import { locateGame, ROOT } from '../src/paths.ts';
import { borrowedVocabulary, brandsIn } from '@gp/spec';
import { containment, progressionShape, uniquenessReport } from '../src/uniqueness.ts';

const tmp = mkdtempSync(join(tmpdir(), 'gp-uniq-'));
afterAll(() => rmSync(tmp, { recursive: true, force: true }));

/** A game made from the template, its concept written; `mechanic` replaces sim.ts, `files` add or replace others */
function fromTemplate(name: string, mechanic?: string, files: Record<string, string> = {}) {
  const dir = join(tmp, name, 'games', name);
  cpSync(join(ROOT, 'templates/game-repo'), join(tmp, name), { recursive: true });
  cpSync(join(tmp, name, 'games/__ID__'), dir, { recursive: true });
  rmSync(join(tmp, name, 'games/__ID__'), { recursive: true });
  let yaml = readFileSync(join(dir, 'game.yaml'), 'utf8').replace(/__ID__/g, name).replace(/__TITLE__/g, 'Lantern Walk');
  yaml = yaml
    .replace(/  pitch: .*\n/, '  pitch: "Swing a lantern on a rope to light the path for a sleepwalker."\n')
    .replace(/  closest: .*\n/, '  closest: ["Rope Hero", "Night Walk", "Light Path"]\n')
    .replace(/  different: .*\n/, '  different: "You never control the walker: you only move the light, and the walker steps only where it falls."\n')
    .replace(/  progression: .*\n/, '  progression: "Lanterns: fireflies buy new lanterns, each lighting the path its own way"\n')
    // The money design (the template's TODOs)
    .replace(/  genre: TODO.*\n/, '  genre: puzzle\n')
    .replace(/TODO: where the breaks are[^"]*/, 'a walk ends → Next night')
    .replace(/TODO: what the player gets[^"]*/, 'the lantern relit once')
    .replace(/TODO: why a player comes back tomorrow[^"]*/, 'a new night every day');
  // The template has no music yet: a finished CrazyGames game says what plays (E_SOUND_MUSIC)
  yaml += 'sound: { music: "a soft night theme of its own, music and effects sliders" }\n';
  writeFileSync(join(dir, 'game.yaml'), yaml);
  writeFileSync(join(tmp, name, 'docs/concept.md'), '# notes\n\n| lantern | site:crazygames.com lantern | nothing close | keep |\n');
  if (mechanic) {
    writeFileSync(join(dir, 'sim.ts'), mechanic);
    for (const f of ['main.ts', 'data.ts', 'bot.ts', 'art.ts']) writeFileSync(join(dir, f), readFileSync(join(dir, f), 'utf8').replace(/PLACEHOLDER/g, 'x'));
  }
  for (const [f, text] of Object.entries(files)) writeFileSync(join(dir, f), text);
  const loc = locateGame(dir);
  const r = checkGame(loc, 'dev');
  return uniquenessReport(loc, r.game!, r.issues);
}

describe('uniqueness', () => {
  it('containment: the same code is 1, unrelated code is ~0', () => {
    const a = 'export function step(s: State, dt: number) { s.t += dt; s.x += s.vx * dt; if (s.x > 10) s.vx = -s.vx; }';
    expect(containment(a, a)).toBe(1);
    expect(containment(a, 'const lit = new Set<string>(); for (const k of keys) lit.add(k.toUpperCase());')).toBeLessThan(0.1);
  });
  it('a taken concept found only off the portal costs 5, one live on the portal 15', () => {
    const mech = 'export interface Sky { clouds: number[] }\nexport function blow(s: Sky, dir: number): number { s.clouds = s.clouds.map((c) => c + dir); return s.clouds.length; }\n';
    fromTemplate('clouds', mech);
    const dir = join(tmp, 'clouds', 'games', 'clouds');
    const taken = (pitch: string) => {
      const f = join(dir, 'game.yaml');
      writeFileSync(f, readFileSync(f, 'utf8').replace(/  pitch: .*\n/, `  pitch: "${pitch}"\n`));
      const loc = locateGame(dir);
      const r = checkGame(loc, 'dev');
      return uniquenessReport(loc, r.game!, r.issues).signals.find((s) => s.name.startsWith('No live genre'))!;
    };
    // Off the portal only (Cloud Shepherd on itch.io, Rain on Your Parade on Steam)
    expect(taken('Steer the clouds so the rain falls on every field.')).toMatchObject({ points: 20 });
    // Live on CrazyGames (Cowboy Lasso Master)
    expect(taken('Draw a lasso loop with the cursor around the cattle.')).toMatchObject({ points: 10 });
  });
  it('the untouched template is gated: its placeholder mechanic is still the game', () => {
    const rep = fromTemplate('untouched');
    expect(rep.gate).toMatch(/placeholder/);
    expect(rep.verdict).toBe('too close');
  });
  it('a replaced mechanic with a written concept and search notes scores its own points', () => {
    const rep = fromTemplate('replaced', 'export interface Walk { lamp: number; steps: number; lit: Set<string> }\nexport function advance(w: Walk, pull: number): boolean { w.lamp += pull; if (!w.lit.has(String(Math.round(w.lamp)))) return false; w.steps++; return true; }\n');
    expect(rep.gate).toBeNull();
    const own = rep.signals.find((s) => s.name.startsWith("The mechanic's code"))!;
    expect(own.points).toBe(own.max);
    // The twist isn't seen yet (no gp qa run here): declared only
    expect(rep.signals.find((s) => s.name.startsWith('The twist'))!.points).toBe(5);
    // No premise or characters yet: the story signal is 0 of 5. The skeleton's progression is a Roster, but still the
    // template's targets (only the PLACEHOLDER markers are gone): 0
    const p = rep.signals.find((s) => s.name.startsWith('The progression'))!;
    expect(p).toMatchObject({ points: 0, detail: 'the template\'s placeholder progression' });
    expect(rep.score).toBe(20 + 25 + 10 + 5 + 20 + 0 + 0);
  });
  it('the progression: the template\'s Roster counts once the game has its own roster in it', () => {
    const mech = 'export interface Walk { lamp: number; steps: number }\nexport function advance(w: Walk, pull: number): boolean { w.lamp += pull; w.steps++; return w.lamp > 0; }\n';
    // The untouched template (its PLACEHOLDER markers still there) scores 0 too
    const untouched = locateGame(join(tmp, 'untouched', 'games', 'untouched'));
    expect(progressionShape(untouched)).toMatchObject({ points: 0, detail: 'the template\'s placeholder progression' });
    const tpl = readFileSync(join(ROOT, 'templates/game-repo/games/__ID__/data.ts'), 'utf8');
    const roster = tpl.match(/export const TARGETS = \[[\s\S]*?\] as const;/)![0];
    const lanterns = `export const TARGETS = [
  { id: 'ring', name: 'Paper lantern', effect: 'Lights 3 steps', color: '#ffd166', price: 0, radius: 34, speed: 90, points: 1 },
  { id: 'star', name: 'Firefly jar', effect: 'Lights the next turn', color: '#f7aef8', price: 40, radius: 30, speed: 60, points: 2 },
  { id: 'drum', name: 'Storm lamp', effect: 'Wind can't put it out', color: '#7bdff2', price: 300, radius: 44, speed: 140, points: 2 },
  { id: 'comet', name: 'Moon lamp', effect: 'Shows the walker's dream', color: '#ff8c61', price: 1200, radius: 32, speed: 160, points: 3, requires: 'drum' },
] as const;`.replace(/can't|walker's/g, (w) => w.replace("'", "\\'"));
    const own = fromTemplate('ownroster', mech, { 'data.ts': tpl.replace(/PLACEHOLDER/g, 'x').replace(roster, lanterns) });
    expect(own.signals.find((s) => s.name.startsWith('The progression'))!).toMatchObject({ points: 5, detail: expect.stringContaining('Roster') });
  });
  it('the progression: the stock "+stat" level shop alone costs a little, the game\'s own shape counts', () => {
    const mech = 'export interface Walk { lamp: number; steps: number }\nexport function advance(w: Walk, pull: number): boolean { w.lamp += pull; w.steps++; return w.lamp > 0; }\n';
    const stock = "import { mountUpgradeShop, UpgradeShop } from '@gp/core';\nexport const SHOP = new UpgradeShop([{ id: 'speed', max: 8, baseCost: 5, growth: 1.6 }]);\nexport function show(ui: HTMLElement) { mountUpgradeShop(ui, { shop: SHOP } as never); }\n";
    const rep = fromTemplate('stockshop', mech, { 'bot.ts': 'export const x = 1;\n', 'main.ts': stock });
    const p = rep.signals.find((s) => s.name.startsWith('The progression'))!;
    expect(p.points).toBe(-5);
    expect(p.detail).toMatch(/stock level shop/);
    expect(rep.markdown).toContain('**The progression is the game\'s own:**');
    // The same shop with the game's own unlock conditions (Starsilk's depths): neutral
    const locked = stock.replace("growth: 1.6 }])", "growth: 1.6 }], { lock: () => null })");
    expect(fromTemplate('lockedshop', mech, { 'bot.ts': 'export const x = 1;\n', 'main.ts': locked }).signals.find((s) => s.name.startsWith('The progression'))!.points).toBe(0);
    // A game's own screen on the UpgradeShop math (Dread Throne's pacts): +5
    const own = "import { UpgradeShop } from '@gp/core';\nexport const SHOP = new UpgradeShop([{ id: 'vigor', max: 3, baseCost: 25, growth: 1.8 }]);\nexport function show(box: HTMLElement) { box.dataset.gp = 'shop-screen'; }\n";
    expect(progressionShape(locateGame(join(tmp, 'stockshop', 'games', 'stockshop')))).toMatchObject({ points: -5 });
    const game = fromTemplate('ownshop', mech, { 'bot.ts': 'export const x = 1;\n', 'main.ts': own });
    expect(game.signals.find((s) => s.name.startsWith('The progression'))!.points).toBe(5);
  });
  it('another hit\'s words lower the score and are named (Velvet Domino Rogue: Balatro\'s); a brand in the texts is W_TRADEMARK_TEXT', () => {
    const mech = 'export interface Walk { lamp: number; steps: number }\nexport function advance(w: Walk, pull: number): boolean { w.lamp += pull; w.steps++; return w.lamp > 0; }\n';
    const clean = fromTemplate('ownwords', mech);
    expect(clean.signals.find((s) => s.name.startsWith('The words'))).toMatchObject({ points: 0, detail: expect.stringMatching(/no other hit/) });
    // The same game whose English says Chips × Mult, a Polychrome edition and a gold seal, and drives a Ferrari
    const en = readFileSync(join(ROOT, 'templates/game-repo/games/__ID__/strings/en.yaml'), 'utf8')
      .replace('goal: "Tap the target!"', 'goal: "Score Chips × Mult: a Polychrome tile with a Gold Seal"')
      .replace('playIt: "Play it"', 'playIt: "Drive the Ferrari"');
    const dir = join(tmp, 'ownwords', 'games', 'ownwords');
    writeFileSync(join(dir, 'strings', 'en.yaml'), en);
    const loc = locateGame(dir);
    const r = checkGame(loc, 'dev');
    const rep = uniquenessReport(loc, r.game!, r.issues);
    const words = rep.signals.find((s) => s.name.startsWith('The words'))!;
    expect(words.points).toBeLessThan(0);
    expect(words.detail).toMatch(/Balatro: .*mult.*polychrome/);
    expect(words.detail).toMatch(/car brands: ferrari/);
    expect(rep.score).toBe(clean.score + words.points);
    expect(rep.markdown).toContain('**The words are the game\'s own:**');
    const tm = r.issues.filter((i) => i.code === 'W_TRADEMARK_TEXT');
    expect(tm.map((i) => i.message)).toEqual([expect.stringMatching(/"ferrari".*en:playIt/)]);
    // Ordinary words alone are no borrowing: chips, a blind and a seal (a poker table); four of them are
    expect(borrowedVocabulary(['A blind spot', 'potato chips', 'the royal seal'])).toEqual([]);
    expect(borrowedVocabulary(['Joker', 'Small Blind ahead'])[0]).toMatchObject({ hit: 'Balatro' });
    expect(brandsIn('a Tesla coil and a jaguar')).toEqual([]);
  });
  it('the code example is honest: a microbe theme and no twist score it "too close"', () => {
    const loc = locateGame(join(ROOT, 'docs/examples/code'));
    const r = checkGame(loc, 'dev');
    const rep = uniquenessReport(loc, r.game!, r.issues);
    expect(rep.score).toBeLessThan(50);
    expect(rep.markdown).toContain('site:crazygames.com');
  });
});
