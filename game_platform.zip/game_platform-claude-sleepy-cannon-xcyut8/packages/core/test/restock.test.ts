import { describe, expect, it } from 'vitest';
import { worldClock } from '../src/clock.ts';
import { loadRestock, restockShop, type StockDef } from '../src/restock.ts';

const T0 = Date.UTC(2026, 9, 19, 18, 3, 12);
const POOL: StockDef[] = [
  { id: 'quartz', weight: 40, price: 10, rarity: 'common', stock: 5 },
  { id: 'amber', weight: 30, price: 20, rarity: 'common', stock: 3 },
  { id: 'jade', weight: 20, price: 50, rarity: 'common', stock: 2 },
  { id: 'opal', weight: 6, price: 200, rarity: 'rare' },
  { id: 'aurora', weight: 1, price: 900, rarity: 'epic' },
  { id: 'onyx', weight: 3, price: 120, rarity: 'rare' },
];
const at = (t0: number) => {
  const c = { t: t0, now: () => c.t };
  return c;
};

describe('restockShop', () => {
  it('the same stock for every player in a slot; a new one each slot; nextIn counts down', () => {
    const c = at(T0);
    const clock = worldClock({ salt: 'geodes', now: c.now });
    const a = restockShop({}, { clock, slots: 3, pool: POOL });
    const b = restockShop({}, { clock: worldClock({ salt: 'geodes', now: c.now }), slots: 3, pool: POOL });
    const sa = a.state();
    expect(sa.items).toEqual(b.state().items);
    expect(sa.items).toHaveLength(3);
    expect(new Set(sa.items.map((i) => i.id)).size).toBe(3);
    expect(sa.nextIn).toBe(108);
    expect(sa.personal).toBe(false);
    const seen = new Set<string>();
    for (let k = 0; k < 20; k++) {
      c.t = T0 + k * 300_000;
      seen.add(a.state().items.map((i) => i.id).join());
    }
    expect(seen.size).toBeGreaterThan(5);
  });

  it('buying: the price through the game, the stock goes down, a slot that passes resets it (nothing is taken)', () => {
    const c = at(T0);
    const save: Record<string, unknown> = {};
    let saves = 0;
    const shop = restockShop(save, { clock: worldClock({ salt: 'g', now: c.now }), slots: 6, pool: POOL, persist: () => saves++ });
    const quartz = shop.state().items.find((i) => i.id === 'quartz')!;
    expect(quartz.left).toBe(5);
    let coins = 25;
    const pay = (p: number) => (coins >= p ? ((coins -= p), true) : false);
    expect(shop.buy('quartz', pay)!.left).toBe(4);
    expect(shop.buy('quartz', pay)!.left).toBe(3);
    expect(shop.buy('quartz', pay)).toBeNull(); // 5 coins left
    expect(coins).toBe(5);
    expect(shop.state().items.find((i) => i.id === 'quartz')!.left).toBe(3);
    expect(save.restock).toMatchObject({ bought: { quartz: 2 } });
    expect(saves).toBeGreaterThan(0);
    // The save survives a reload in the same slot
    const again = restockShop(save, { clock: worldClock({ salt: 'g', now: c.now }), slots: 6, pool: POOL });
    expect(again.state().items.find((i) => i.id === 'quartz')!.left).toBe(3);
    c.t += 300_000;
    expect(again.state().items.every((i) => i.left === i.stock)).toBe(true);
    expect(shop.buy('nope' as never)).toBeNull();
  });

  it('the world pity: every block of N restocks holds one of the rarity or better', () => {
    const c = at(T0);
    const clock = worldClock({ salt: 'pity-test', now: c.now });
    const shop = restockShop({}, { clock, slots: 2, pool: POOL, rarities: ['common', 'rare', 'epic'], pity: { rarity: 'rare', within: 4 } });
    const plain = restockShop({}, { clock, slots: 2, pool: POOL, name: 'plain' });
    const start = clock.slot().index - (clock.slot().index % 4);
    let forced = 0;
    for (let block = 0; block < 60; block++) {
      let has = false;
      for (let k = 0; k < 4; k++) {
        const items = shop.stockAt(start + block * 4 + k);
        if (items.some((i) => i.rarity !== 'common')) has = true;
        if (items.some((i) => i.pity)) forced++;
      }
      expect(has, `block ${block}`).toBe(true);
    }
    expect(forced).toBeGreaterThan(0);
    expect(plain.stockAt(start).every((i) => !i.pity)).toBe(true);
    expect(shop.state().pityIn).toBeGreaterThanOrEqual(1);
  });

  it('restock now: a personal stock, once per cooldown, never a free one when the clock goes back', () => {
    const c = at(T0);
    const save: Record<string, unknown> = {};
    const clock = worldClock({ salt: 'g', now: c.now });
    const shop = restockShop(save, { clock, slots: 3, pool: POOL, cooldown: '15m' });
    const shared = shop.state().items.map((i) => i.id);
    shop.buy(shop.state().items[0].id);
    expect(shop.state().restock).toEqual({ ready: true, in: 0 });
    expect(shop.restockNow()).toBe(true);
    const own = shop.state();
    expect(own.personal).toBe(true);
    expect(own.items.every((i) => i.left === i.stock)).toBe(true); // a fresh stock
    expect(own.slot.index).toBe(clock.slot().index);
    expect(shared).toHaveLength(3);
    expect(shop.restockNow()).toBe(false);
    expect(shop.state().restock.in).toBe(900);
    c.t += 300_000; // the next slot: the shared stock again
    expect(shop.state().personal).toBe(false);
    c.t += 600_000;
    expect(shop.state().restock.ready).toBe(true);
    // The clock set back: the slot stays the last one seen, the cooldown counts from the last restock
    shop.restockNow();
    const index = shop.state().slot.index;
    c.t -= 3600_000;
    expect(shop.state().slot.index).toBe(index);
    expect(shop.state().restock.ready).toBe(false);
  });

  it('a save made safe; a pool it can not use is refused', () => {
    expect(loadRestock({ slot: 'x', bought: { a: 2, b: -1, c: 'z' }, own: -3 })).toEqual({ slot: -1, bought: { a: 2 }, own: 0, at: 0 });
    const clock = worldClock({ salt: 'g' });
    expect(() => restockShop({}, { clock, slots: 2, pool: [] })).toThrow(/weight/);
    expect(() => restockShop({}, { clock, slots: 2, pool: POOL, rarities: ['common'], pity: { rarity: 'rare', within: 3 } })).toThrow(/rarity/);
    expect(() => restockShop({}, { clock, slots: 0, pool: POOL })).toThrow(/slots/);
  });
});
