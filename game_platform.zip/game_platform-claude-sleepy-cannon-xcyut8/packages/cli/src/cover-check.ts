// The cover click-through check (`gp covers --check`, docs/guides/covers.md): a cover measured at the size players see
// it on the portal (200 px wide) — is the title big and does it read, does the hero stand off the background, is it
// colourful, is there value contrast, how much is near-black or flat, is there something to decode without clutter.
// Proxies, not a CTR prediction: the thresholds come from thumbnail practice (docs/guides/covers.md#the-rules) and
// from our own covers (0.6–1.2 % click-through on CrazyGames, 2026-10). Pure: the pixels come in as arrays.

/** The thumbnail width the check works at: what players see on a portal's game grid */
export const THUMB_W = 200;

export interface Thumb {
  w: number;
  h: number;
  /** RGBA, 8 bits per channel, row by row */
  rgba: Uint8Array | Uint8ClampedArray;
}

/** 0/1 per thumbnail pixel (the platform's composer knows them; a plain screenshot has none) */
export interface ThumbMasks {
  /** The title's letters (their fill, without the outline) */
  titleFill?: Uint8Array;
  /** The whole lettering: fill, outline, extrusion */
  title?: Uint8Array;
  /** The hero layer */
  hero?: Uint8Array;
}

export interface CoverFacts {
  /** The words on the cover */
  titleText?: string;
  titleLines?: number;
  /** The letters' cap height at thumbnail size, px */
  letterPx?: number;
}

export type CoverShape = 'landscape' | 'portrait' | 'square';
export const shapeOf = (w: number, h: number): CoverShape => (w / h >= 1.25 ? 'landscape' : h / w >= 1.25 ? 'portrait' : 'square');

export interface CoverMetrics {
  shape: CoverShape;
  title: null | {
    /** The lettering's box width / the cover's width */
    widthShare: number;
    /** Cap height at thumbnail size, px */
    letterPx: number;
    /** WCAG contrast between the letters and the pixels right around them (the outline, or the scene) */
    contrast: number;
    words: number;
  };
  subject: {
    /** true: measured on the hero layer; false: estimated (the most distinct region against the frame's edge) */
    measured: boolean;
    /** Measured: ΔE ×100 across the hero's outline (silhouetteContrast). Estimated: the 90th percentile of every pixel's ΔE from the frame's edge */
    contrast: number;
    /** The hero's share of the cover (measured only) */
    area: number | null;
  };
  /** Hasler–Süsstrunk colourfulness (0 grey … 109 extremely colourful) */
  colourfulness: number;
  /** OKLab lightness, 95th − 5th percentile */
  valueRange: number;
  /** Share of near-black pixels (OKLab L < 0.22) */
  darkShare: number;
  /** Share of 10×10 px blocks with no detail (a flat sky, an empty wall) */
  flatShare: number;
  /** Share of edge pixels (Sobel on lightness): too few is nothing to decode, too many is clutter */
  edgeDensity: number;
  /** How many sides look like a frame around the picture (CrazyGames sends bordered covers back) */
  borderSides: number;
}

// --- Colour ----------------------------------------------------------------------------------------------------------

const LIN = new Float64Array(256);
for (let i = 0; i < 256; i++) {
  const c = i / 255;
  LIN[i] = c <= 0.04045 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
}

/** Relative luminance (WCAG) of an 8-bit sRGB colour */
export const luma = (r: number, g: number, b: number): number => 0.2126 * LIN[r]! + 0.7152 * LIN[g]! + 0.0722 * LIN[b]!;

/** OKLab of an 8-bit sRGB colour */
export function lab(r: number, g: number, b: number): [number, number, number] {
  const R = LIN[r]!;
  const G = LIN[g]!;
  const B = LIN[b]!;
  const l = Math.cbrt(0.4122214708 * R + 0.5363325363 * G + 0.0514459929 * B);
  const m = Math.cbrt(0.2119034982 * R + 0.6806995451 * G + 0.1073969566 * B);
  const s = Math.cbrt(0.0883024619 * R + 0.2817188376 * G + 0.6299787005 * B);
  return [0.2104542553 * l + 0.793617785 * m - 0.0040720468 * s, 1.9779984951 * l - 2.428592205 * m + 0.4505937099 * s, 0.0259040371 * l + 0.7827717662 * m - 0.808675766 * s];
}

export const wcag = (y1: number, y2: number): number => (Math.max(y1, y2) + 0.05) / (Math.min(y1, y2) + 0.05);

/** Hasler & Süsstrunk (2003), "Measuring colourfulness in natural images": σ and μ of rg = R−G, yb = (R+G)/2 − B */
export function colourfulness(t: Thumb): number {
  const n = t.w * t.h;
  let srg = 0, syb = 0, srg2 = 0, syb2 = 0;
  for (let i = 0; i < n; i++) {
    const r = t.rgba[i * 4]!, g = t.rgba[i * 4 + 1]!, b = t.rgba[i * 4 + 2]!;
    const rg = r - g;
    const yb = 0.5 * (r + g) - b;
    srg += rg;
    syb += yb;
    srg2 += rg * rg;
    syb2 += yb * yb;
  }
  const mrg = srg / n, myb = syb / n;
  const vrg = Math.max(0, srg2 / n - mrg * mrg), vyb = Math.max(0, syb2 / n - myb * myb);
  return Math.sqrt(vrg + vyb) + 0.3 * Math.sqrt(mrg * mrg + myb * myb);
}

// --- Masks ------------------------------------------------------------------------------------------------------------

/** The mask grown by `r` px (a square neighbourhood) */
export function dilate(m: Uint8Array, w: number, h: number, r: number): Uint8Array {
  let cur = m;
  for (let k = 0; k < r; k++) {
    const next = new Uint8Array(cur.length);
    for (let y = 0; y < h; y++)
      for (let x = 0; x < w; x++) {
        let on = 0;
        for (let dy = -1; dy <= 1 && !on; dy++)
          for (let dx = -1; dx <= 1; dx++) {
            const xx = x + dx, yy = y + dy;
            if (xx >= 0 && yy >= 0 && xx < w && yy < h && cur[yy * w + xx]) {
              on = 1;
              break;
            }
          }
        next[y * w + x] = on;
      }
    cur = next;
  }
  return cur;
}

export function bbox(m: Uint8Array, w: number, h: number): { x: number; y: number; w: number; h: number } | null {
  let x0 = w, y0 = h, x1 = -1, y1 = -1;
  for (let y = 0; y < h; y++)
    for (let x = 0; x < w; x++)
      if (m[y * w + x]) {
        if (x < x0) x0 = x;
        if (x > x1) x1 = x;
        if (y < y0) y0 = y;
        if (y > y1) y1 = y;
      }
  return x1 < 0 ? null : { x: x0, y: y0, w: x1 - x0 + 1, h: y1 - y0 + 1 };
}

const median = (a: number[]): number => {
  if (!a.length) return 0;
  const s = [...a].sort((p, q) => p - q);
  return s[s.length >> 1]!;
};
const pct = (s: Float64Array | number[], p: number): number => {
  const a = Array.from(s).sort((x, y) => x - y);
  return a.length ? a[Math.min(a.length - 1, Math.floor(p * a.length))]! : 0;
};

/** Median OKLab of the pixels where `m` is set */
function labOf(t: Thumb, m: Uint8Array): [number, number, number] | null {
  const L: number[] = [], A: number[] = [], B: number[] = [];
  for (let i = 0; i < m.length; i++)
    if (m[i]) {
      const c = lab(t.rgba[i * 4]!, t.rgba[i * 4 + 1]!, t.rgba[i * 4 + 2]!);
      L.push(c[0]);
      A.push(c[1]);
      B.push(c[2]);
    }
  return L.length ? [median(L), median(A), median(B)] : null;
}
const dE = (p: [number, number, number], q: [number, number, number]) => 100 * Math.hypot(p[0] - q[0], p[1] - q[1], p[2] - q[2]);

/**
 * How well the hero's outline reads: along the silhouette's edge, the pixel 2 px inside against the most different of
 * the pixels 1–3 px outside (along the outward normal), ΔE ×100, the median over the edge. A rim, a halo or a dark background make it high; a
 * hero the colour of the scene behind it makes it low
 */
export function silhouetteContrast(t: Thumb, hero: Uint8Array, title?: Uint8Array): number {
  const { w, h } = t;
  const at = (x: number, y: number) => (x >= 0 && y >= 0 && x < w && y < h ? y * w + x : -1);
  const px = (i: number) => lab(t.rgba[i * 4]!, t.rgba[i * 4 + 1]!, t.rgba[i * 4 + 2]!);
  const d: number[] = [];
  for (let y = 0; y < h; y++)
    for (let x = 0; x < w; x++) {
      if (!hero[y * w + x]) continue;
      let nx = 0;
      let ny = 0;
      for (let dy = -1; dy <= 1; dy++)
        for (let dx = -1; dx <= 1; dx++) {
          const j = at(x + dx, y + dy);
          if (j >= 0 && !hero[j]) {
            nx += dx;
            ny += dy;
          }
        }
      const len = Math.hypot(nx, ny);
      if (!len) continue;
      nx /= len;
      ny /= len;
      const i = at(Math.round(x - 2 * nx), Math.round(y - 2 * ny));
      if (i < 0 || !hero[i]) continue;
      // The most different of the pixels 1–3 px outside: an outline, a halo or the scene, whichever separates it
      let best = -1;
      for (const k of [1, 2, 3]) {
        const o = at(Math.round(x + k * nx), Math.round(y + k * ny));
        if (o < 0 || hero[o] || title?.[o]) continue;
        best = Math.max(best, dE(px(i), px(o)));
      }
      if (best >= 0) d.push(best);
    }
  return median(d);
}

/**
 * A border around the cover (CrazyGames: "Don't put borders around your game covers"): sides whose outer band is one
 * flat colour and different from what is just inside it. Returns how many of the four sides look like a frame
 */
export function borderSides(t: Thumb): number {
  const { w, h } = t;
  const px = (x: number, y: number) => {
    const i = y * w + x;
    return lab(t.rgba[i * 4]!, t.rgba[i * 4 + 1]!, t.rgba[i * 4 + 2]!);
  };
  // One row or column from the edge inward: its mean colour and how even it is (the middle 80 %: corners round)
  const line = (side: number, k: number) => {
    const n = side < 2 ? w : h;
    const c: [number, number, number] = [0, 0, 0];
    const L: number[] = [];
    for (let j = Math.floor(n * 0.1); j < Math.ceil(n * 0.9); j++) {
      const p = side === 0 ? px(j, k) : side === 1 ? px(j, h - 1 - k) : side === 2 ? px(k, j) : px(w - 1 - k, j);
      c[0] += p[0];
      c[1] += p[1];
      c[2] += p[2];
      L.push(p[0]);
    }
    const m = L.length;
    c[0] /= m;
    c[1] /= m;
    c[2] /= m;
    const sd = Math.sqrt(L.reduce((q, v) => q + (v - c[0]) ** 2, 0) / m);
    return { c, sd };
  };
  const frames: [number, number, number][] = [];
  for (let side = 0; side < 4; side++) {
    const depth = side < 2 ? h : w;
    const outer = line(side, 0);
    if (outer.sd > 0.03) continue;
    // Walk inward while the lines stay flat and the frame's colour; a frame ends in a clear change
    let d = 1;
    while (d < depth * 0.2) {
      const l = line(side, d);
      if (l.sd > 0.03 || dE(l.c, outer.c) > 4) break;
      d++;
    }
    if (d < Math.max(2, depth * 0.02) || d >= depth * 0.2) continue;
    const inner = line(side, Math.min(depth - 1, d + 1));
    if (dE(inner.c, outer.c) > 10) frames.push(outer.c);
  }
  // A frame is one colour all round: count the sides that match the most common one
  let best = 0;
  for (const a of frames) best = Math.max(best, frames.filter((b) => dE(a, b) < 6).length);
  return best;
}

// --- The measures -----------------------------------------------------------------------------------------------------

export function measureCover(t: Thumb, masks: ThumbMasks = {}, facts: CoverFacts = {}): CoverMetrics {
  const { w, h } = t;
  const n = w * h;
  const L = new Float64Array(n);
  const Y = new Float64Array(n);
  const A = new Float64Array(n);
  const B = new Float64Array(n);
  for (let i = 0; i < n; i++) {
    const r = t.rgba[i * 4]!, g = t.rgba[i * 4 + 1]!, b = t.rgba[i * 4 + 2]!;
    const c = lab(r, g, b);
    L[i] = c[0];
    A[i] = c[1];
    B[i] = c[2];
    Y[i] = luma(r, g, b);
  }

  // The title: its box, its letters' size, the contrast at the letters' edge
  let title: CoverMetrics['title'] = null;
  if (masks.titleFill && masks.title) {
    const box = bbox(masks.title, w, h);
    const fill = masks.titleFill;
    // The band 1–2 px outside the letters: the outline when there is one, the scene when there isn't
    const d2 = dilate(fill, w, h, 2);
    const inY: number[] = [];
    const edgeY: number[] = [];
    for (let i = 0; i < n; i++) {
      if (fill[i]) inY.push(Y[i]!);
      else if (d2[i]) edgeY.push(Y[i]!);
    }
    const lines = facts.titleLines ?? 1;
    title = {
      widthShare: box ? box.w / w : 0,
      letterPx: facts.letterPx ?? (box ? (box.h / lines) * 0.62 : 0),
      contrast: inY.length && edgeY.length ? wcag(median(inY), median(edgeY)) : 1,
      words: (facts.titleText ?? '').trim().split(/\s+/).filter(Boolean).length,
    };
  }

  // The subject: the hero layer against the ring of scene right around it; without one, the most distinct region
  let subject: CoverMetrics['subject'];
  if (masks.hero && masks.hero.some((v) => v)) {
    const hero = masks.hero;
    let area = 0;
    for (let i = 0; i < n; i++) area += hero[i]!;
    subject = { measured: true, contrast: silhouetteContrast(t, hero, masks.title), area: area / n };
  } else {
    // The frame's edge (outer 8 %) is the background; the 90th percentile of every pixel's distance from it is the subject
    const edge = new Uint8Array(n);
    const bx = Math.max(1, Math.round(w * 0.08)), by = Math.max(1, Math.round(h * 0.08));
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (x < bx || y < by || x >= w - bx || y >= h - by) edge[y * w + x] = 1;
    const bg = labOf(t, edge)!;
    const d = new Float64Array(n);
    for (let i = 0; i < n; i++) d[i] = dE([L[i]!, A[i]!, B[i]!], bg);
    subject = { measured: false, contrast: pct(d, 0.9), area: null };
  }

  // Value, darkness, flat blocks, edges
  let dark = 0;
  for (let i = 0; i < n; i++) if (L[i]! < 0.22) dark++;
  const BS = 10;
  let blocks = 0, flat = 0;
  for (let by = 0; by + BS <= h; by += BS)
    for (let bx = 0; bx + BS <= w; bx += BS) {
      let s = 0, s2 = 0, sa = 0, sa2 = 0, sb = 0, sb2 = 0;
      for (let y = by; y < by + BS; y++)
        for (let x = bx; x < bx + BS; x++) {
          const i = y * w + x;
          s += L[i]!;
          s2 += L[i]! * L[i]!;
          sa += A[i]!;
          sa2 += A[i]! * A[i]!;
          sb += B[i]!;
          sb2 += B[i]! * B[i]!;
        }
      const k = BS * BS;
      const sd = Math.sqrt(Math.max(0, s2 / k - (s / k) ** 2));
      const sdc = Math.sqrt(Math.max(0, sa2 / k - (sa / k) ** 2) + Math.max(0, sb2 / k - (sb / k) ** 2));
      blocks++;
      if (sd < 0.02 && sdc < 0.012) flat++;
    }
  let edges = 0;
  for (let y = 1; y < h - 1; y++)
    for (let x = 1; x < w - 1; x++) {
      const p = (dx: number, dy: number) => L[(y + dy) * w + x + dx]!;
      const gx = p(1, -1) + 2 * p(1, 0) + p(1, 1) - p(-1, -1) - 2 * p(-1, 0) - p(-1, 1);
      const gy = p(-1, 1) + 2 * p(0, 1) + p(1, 1) - p(-1, -1) - 2 * p(0, -1) - p(1, -1);
      if (Math.hypot(gx, gy) / 4 > 0.08) edges++;
    }
  return {
    shape: shapeOf(w, h),
    title,
    subject,
    colourfulness: colourfulness(t),
    valueRange: pct(L, 0.95) - pct(L, 0.05),
    darkShare: dark / n,
    flatShare: blocks ? flat / blocks : 0,
    edgeDensity: edges / Math.max(1, (w - 2) * (h - 2)),
    borderSides: borderSides(t),
  };
}

// --- The verdict ------------------------------------------------------------------------------------------------------

/** bad → good for each measure (a value between them scores in proportion); docs/guides/covers.md#the-check */
export const COVER_THRESHOLDS = {
  titleWidth: { landscape: [0.25, 0.4], square: [0.35, 0.55], portrait: [0.35, 0.55] } as Record<CoverShape, [number, number]>,
  letterPx: [7, 13] as [number, number],
  titleContrast: [2, 4.5] as [number, number],
  words: [5, 3] as [number, number],
  subjectContrast: [10, 30] as [number, number],
  subjectArea: [0.05, 0.15] as [number, number],
  colourfulness: [25, 55] as [number, number],
  valueRange: [0.3, 0.6] as [number, number],
  darkShare: [0.5, 0.2] as [number, number],
  flatShare: [0.6, 0.25] as [number, number],
  /** too few edges → too many: bad, good, good, bad */
  edgeDensity: [0.02, 0.06, 0.32, 0.45] as [number, number, number, number],
  /** Below this the cover gets a warning */
  score: 70,
};

const WEIGHTS = { titleWidth: 12, letterPx: 10, titleContrast: 13, words: 5, subjectContrast: 12, subjectArea: 8, colourfulness: 12, valueRange: 8, darkShare: 7, flatShare: 6, edgeDensity: 7, border: 6 };
export type CoverCheckId = keyof typeof WEIGHTS;

export interface CoverCheck {
  id: CoverCheckId;
  label: string;
  value: string;
  /** 0 (bad) … 1 (good) */
  score: number;
  /** What to change when it is weak */
  fix: string;
}

export interface CoverVerdict {
  /** 0–100, over the measures that could be taken */
  score: number;
  checks: CoverCheck[];
  /** Measures that could not be taken (no title mask, no hero layer) */
  unmeasured: string[];
  /** The title was not measured (a cover without the composer's masks): the score covers the picture only, and a
   *  partial verdict is always a warning (the picture alone can't see a small title or a small hero) */
  partial: boolean;
}

/** 0 at `bad`, 1 at `good`, linear between (either direction) */
export const ramp = (v: number, bad: number, good: number): number => Math.max(0, Math.min(1, (v - bad) / (good - bad)));

export function judgeCover(m: CoverMetrics): CoverVerdict {
  const T = COVER_THRESHOLDS;
  const checks: CoverCheck[] = [];
  const unmeasured: string[] = [];
  const add = (id: CoverCheckId, label: string, value: string, score: number, fix: string) => checks.push({ id, label, value, score, fix });
  if (m.title) {
    const [b, g] = T.titleWidth[m.shape];
    add('titleWidth', 'title width', `${Math.round(m.title.widthShare * 100)} % of the cover`, ramp(m.title.widthShare, b, g), `the title must fill ≥ ${Math.round(g * 100)} % of the ${m.shape} cover's width: fewer or shorter words, or a bigger title zone (another --variants composition)`);
    add('letterPx', 'letter height at 200 px', `${m.title.letterPx.toFixed(1)} px`, ramp(m.title.letterPx, T.letterPx[0], T.letterPx[1]), `letters under ${T.letterPx[1]} px at thumbnail size are hard to read: shorten the title on the cover (title.text: the 1–2 words players remember) or break it into two lines`);
    add('titleContrast', 'title contrast', `${m.title.contrast.toFixed(1)}:1`, ramp(m.title.contrast, T.titleContrast[0], T.titleContrast[1]), 'the letters blend into what is around them: a lighter fill with a darker outline (title.fill, title.outline), or calmer scene behind the title zone');
    add('words', 'words in the title', String(m.title.words), m.title.words <= T.words[1] ? 1 : ramp(m.title.words, T.words[0], T.words[1]), 'at most 3 words read at a glance: put a shorter form in cover.title.text');
  } else unmeasured.push('the title (no cover hook: the platform did not letter it — host.qa({ cover }), docs/guides/covers.md)');
  add(
    'subjectContrast',
    m.subject.measured ? 'hero vs. background' : 'subject vs. background (estimated)',
    `ΔE ${m.subject.contrast.toFixed(0)}`,
    ramp(m.subject.contrast, T.subjectContrast[0], T.subjectContrast[1]),
    'the hero does not stand off the scene: a lighter or more saturated hero on a darker, calmer background (value first), a stronger rim (cover.rim)',
  );
  if (m.subject.area !== null)
    add('subjectArea', 'hero size', `${Math.round(m.subject.area * 100)} % of the cover`, ramp(m.subject.area, T.subjectArea[0], T.subjectArea[1]), `the hero is small: draw it to fill layout.hero (a close-up of the face, bleeding off the edge, reads better than a full figure)`);
  else unmeasured.push('the hero\'s size (no hero layer)');
  add('colourfulness', 'colourfulness', m.colourfulness.toFixed(0), ramp(m.colourfulness, T.colourfulness[0], T.colourfulness[1]), 'muted: saturated hues (the palette\'s accent and glow), two complementary ones (warm hero, cool background)');
  add('valueRange', 'value contrast', m.valueRange.toFixed(2), ramp(m.valueRange, T.valueRange[0], T.valueRange[1]), 'everything is one lightness: bright highlights (the hero, the explosion, the title) against a deep background — check it in grayscale (the preview\'s second row)');
  add('darkShare', 'near-black area', `${Math.round(m.darkShare * 100)} %`, ramp(m.darkShare, T.darkShare[0], T.darkShare[1]), 'big black areas look empty on a dark portal page: light the background (a coloured sky, a glow behind the hero, fog)');
  add('flatShare', 'empty (flat) area', `${Math.round(m.flatShare * 100)} %`, ramp(m.flatShare, T.flatShare[0], T.flatShare[1]), 'large flat areas: fill them with the world (scenery layers, light shafts, particles) or move the hero closer');
  const [e0, e1, e2, e3] = T.edgeDensity;
  const e = m.edgeDensity;
  add('edgeDensity', 'detail', `${Math.round(e * 100)} % edges`, e < e1 ? ramp(e, e0, e1) : e > e2 ? ramp(e, e3, e2) : 1, e < e1 ? 'nothing to decode at thumbnail size: one clear action moment (an explosion, a hit, a catch) next to the hero' : 'cluttered: fewer, bigger shapes; drop small props and UI; blur or darken the background');
  add('border', 'no border', m.borderSides >= 3 ? `${m.borderSides} sides framed` : 'none', m.borderSides >= 3 ? 0 : 1, 'a frame (or a flat margin) around the picture: CrazyGames sends bordered covers back — let the art fill the whole cover, to the edges');
  let sum = 0;
  let wsum = 0;
  for (const c of checks) {
    sum += c.score * WEIGHTS[c.id];
    wsum += WEIGHTS[c.id];
  }
  return { score: Math.round((wsum ? sum / wsum : 0) * 100), checks, unmeasured, partial: !m.title };
}

/** The report lines for one cover: the score, each measure (⚠ below half), what to change */
export function formatVerdict(name: string, v: CoverVerdict): string[] {
  // Without the composer's masks the title and the hero can't be measured: a tiny title over a tiny hero can score high
  // on the picture alone (Forge Night's old cover: 94), so such a cover is always a warning
  const mark = v.score < COVER_THRESHOLDS.score || v.partial ? '⚠' : '✓';
  const L = [v.partial ? `${mark} ${name}: the picture scores ${v.score}/100, but the title and the hero were not measured (no cover hook) — look at the 200 px preview` : `${mark} ${name}: ${v.score}/100`];
  for (const c of v.checks) L.push(`    ${c.score >= 0.5 ? '·' : '⚠'} ${c.label}: ${c.value}${c.score < 0.5 ? ` → ${c.fix}` : ''}`);
  for (const u of v.unmeasured) L.push(`    ? not measured: ${u}`);
  return L;
}

// --- Masks on disk (covers.json: what the composer knew, for a later --check) ------------------------------------

export function packMask(m: Uint8Array): string {
  const out = new Uint8Array(Math.ceil(m.length / 8));
  for (let i = 0; i < m.length; i++) if (m[i]) out[i >> 3]! |= 1 << (i & 7);
  return Buffer.from(out).toString('base64');
}

export function unpackMask(s: string, n: number): Uint8Array {
  const b = Buffer.from(s, 'base64');
  const m = new Uint8Array(n);
  for (let i = 0; i < n; i++) m[i] = (b[i >> 3]! >> (i & 7)) & 1;
  return m;
}
