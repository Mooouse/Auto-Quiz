// @gp/core/sequencer — a score that plays beat by beat: a deckbuilder's hand, a combo, a match cascade, a results screen,
// offline earnings. The game computes the result as a trace of steps (its sim stays pure and testable); the sequencer
// plays it — one beat per step at its place on screen, quicker as the chain goes on (0.28 s → 0.09 s), a count-up, a
// pitch that climbs with the beat, a roll for a long chain, a final land sized by how far the total beat the target —
// and the player can see the result before committing (preview) and tap to fast-forward.
//
//   const steps: ScoreStep[] = [
//     { kind: 'combo', add: 30, mult: 4, label: 'Pair' },        // the hand's base
//     { kind: 'card', at: 0, add: 11 },                          // `at`: a key your `where` turns into a point…
//     { kind: 'relic', at: { x: 640, y: 80 }, times: 2 },        // …or a point
//   ];
//   const seq = new ScoreSequencer({
//     host,                                                      // the host's pause stops it
//     where: (at) => cardXY(at),
//     onStep: ({ step, pitch, point }) => { sfx.play('tick', { rate: pitch }); fx.sparks(point); },
//     onRoll: ({ k, sec }) => sfx.play('roll', { vol: k }),
//     onLand: ({ total, big }) => { sfx.play('thud', { vol: 0.6 + big * 0.4 }); camera.shake(big); },
//     onDone: (total) => run.add(total),
//   });
//   hud.text = `= ${previewScore(steps).total}`;                 // before the player plays it: "how much will I get"
//   seq.play(steps, { target: round.target });
//   // each frame: seq.update(dt); draw seq.shown (the count-up) and seq.labels() (or drawScoreLabels)
//   canvas.onpointerdown = () => seq.playing && seq.skip();     // a tap: to the result at once
//
// Pure (no DOM, no audio): the game makes the sounds and the sparks in the hooks; tests drive it with update(dt).

/** One beat of a score */
export interface ScoreStep {
  /** What scored (the game's own: 'card', 'joint', 'relic', 'cascade'…) */
  kind: string;
  /** Where it happens: a point (the screen's px), or a key your `where` hook turns into one; none: the hooks get null */
  at?: { x: number; y: number } | string | number;
  /** Added to the count (chips, points, coins) */
  add?: number;
  /** Added to the multiplier (+mult) */
  mult?: number;
  /** The multiplier multiplied (×mult) */
  times?: number;
  /** The words over its spot (default: its numbers — "+12", "+4", "×2") */
  label?: string;
}

/** The running score: total = add × mult × times */
export interface ScoreTally {
  add: number;
  mult: number;
  times: number;
  total: number;
}

/** Where a score starts (default add 0, mult 1, times 1): a deckbuilder's hand may start at mult 0 and add its base */
export type ScoreBase = Partial<Omit<ScoreTally, 'total'>>;

const totalOf = (t: Omit<ScoreTally, 'total'>) => t.add * t.mult * t.times;

/** The tally after each step (pure): what the screen shows beat by beat */
export function tallySteps(steps: readonly ScoreStep[], base: ScoreBase = {}): ScoreTally[] {
  let add = base.add ?? 0;
  let mult = base.mult ?? 1;
  let times = base.times ?? 1;
  return steps.map((s) => {
    add += s.add ?? 0;
    mult += s.mult ?? 0;
    times *= s.times ?? 1;
    return { add, mult, times, total: totalOf({ add, mult, times }) };
  });
}

/** The result before it is played (pure): a hand's score before the player commits — "how much will I get" */
export function previewScore(steps: readonly ScoreStep[], base: ScoreBase = {}): ScoreTally {
  const all = tallySteps(steps, base);
  return all.at(-1) ?? { add: base.add ?? 0, mult: base.mult ?? 1, times: base.times ?? 1, total: totalOf({ add: base.add ?? 0, mult: base.mult ?? 1, times: base.times ?? 1 }) };
}

/** The beat's length (s) after beat `i`: 0.28 s, quicker by 0.018 s a beat, never under 0.09 s (Velvet's scoring) */
export const BEAT = { start: 0.28, min: 0.09, quicken: 0.018 } as const;
/** A chain longer than this rolls: its beats run together into a drum roll (onRoll, once, at ROLL.at) */
export const ROLL = { after: 12, at: 6 } as const;
/** The pitch climbs a semitone a beat, up to 18 (an octave and a half) */
export const PITCH = { step: 2 ** (1 / 12), cap: 18 } as const;
/** How long the landed total stays before onDone, s */
export const LAND_HOLD = 0.9;

/** `big` of the land, 0–1: how far the total beat the target, on a log scale (a quarter of the target 0.3, the target 0.9) */
export function landSize(total: number, target?: number): number {
  if (!target || target <= 0) return 0.5;
  return Math.min(1, Math.max(0, Math.log10(Math.max(1, total) / Math.max(1, target / 4)) + 0.3));
}

/** The beat lengths of a chain of `n` steps (s): the gap after each beat, the last one before the land */
export function beatTimes(n: number, tempo: Partial<typeof BEAT> = {}): number[] {
  const t = { ...BEAT, ...tempo };
  return Array.from({ length: n }, (_, i) => Math.max(t.min, t.start - i * t.quicken));
}

export interface StepEvent {
  step: ScoreStep;
  index: number;
  /** × the pitch for this beat's sound (1, then a semitone up each beat) */
  pitch: number;
  /** The score after it */
  tally: ScoreTally;
  /** Where it happens (null: nowhere on screen) */
  point: { x: number; y: number } | null;
  /** Fast-forwarded (a tap): apply it, skip the big effects */
  fast: boolean;
}

export interface LandEvent {
  total: number;
  /** 0–1: landSize(total, target) — scale the land's sound, shake, flash and number with it */
  big: number;
  tally: ScoreTally;
  fast: boolean;
}

/** A floating number over a step's spot, placed clear of the others */
export interface ScoreLabel {
  text: string;
  /** Which number it shows (colour it): 'add', 'mult', 'times', or 'label' for a step's own words */
  kind: 'add' | 'mult' | 'times' | 'label';
  /** Its centre, px */
  x: number;
  y: number;
  w: number;
  h: number;
  /** Seconds since it appeared */
  age: number;
  /** 1 → 0 over its last third */
  alpha: number;
  /** 1.3 → 1 as it pops in */
  scale: number;
}

export interface ScoreSequencerOptions {
  /** The host: while it is paused (an ad, a hidden tab) the score stands still */
  host?: { readonly paused: boolean };
  /** A step's `at` key → a point on screen (a card's index, a relic's slot); a point `at` is used as it is */
  where?(at: string | number, step: ScoreStep): { x: number; y: number } | null;
  onStep?(e: StepEvent): void;
  /** Once per chain longer than ROLL.after, at beat ROLL.at: `k` 0–1 how long it is, `sec` how long the rest lasts */
  onRoll?(e: { k: number; sec: number }): void;
  onLand?(e: LandEvent): void;
  /** The total, after the land has stood LAND_HOLD s (or a second tap) */
  onDone?(total: number): void;
  /** The beats' tempo (default BEAT) */
  tempo?: Partial<typeof BEAT>;
  /** The labels: their size (px, default 22), life (s, default 0.9), how wide a text is (default ≈ 0.58 em a character) */
  labels?: { size?: number; life?: number; measure?(text: string, size: number): number; bounds?: { w: number; h: number } };
}

export interface PlayOptions {
  base?: ScoreBase;
  /** The round's target: the land's size from it (landSize) */
  target?: number;
  /** The game's own total, when its rules aren't add × mult × times (the count-up still follows the steps) */
  total?: number;
}

type Phase = 'idle' | 'beats' | 'land' | 'done';

export class ScoreSequencer {
  private steps: ScoreStep[] = [];
  private tallies: ScoreTally[] = [];
  private base: ScoreTally = { add: 0, mult: 1, times: 1, total: 0 };
  private target: number | undefined;
  private finalTotal = 0;
  private times: number[] = [];
  private phase: Phase = 'idle';
  private t = 0;
  private next = 0;
  private i = 0;
  private beatAt = 0;
  private from: ScoreTally = this.base;
  private live: (ScoreLabel & { life: number; y0: number })[] = [];
  private held = false;

  private readonly opts: ScoreSequencerOptions;

  constructor(opts: ScoreSequencerOptions = {}) {
    this.opts = opts;
  }

  /** Play a score from its first beat (one still playing is finished at once first: its onDone fires) */
  play(steps: readonly ScoreStep[], o: PlayOptions = {}): void {
    if (this.playing) this.finish();
    const b = o.base ?? {};
    this.base = { add: b.add ?? 0, mult: b.mult ?? 1, times: b.times ?? 1, total: 0 };
    this.base.total = totalOf(this.base);
    this.steps = [...steps];
    this.tallies = tallySteps(this.steps, b);
    this.target = o.target;
    this.finalTotal = o.total ?? this.tallies.at(-1)?.total ?? this.base.total;
    this.times = beatTimes(this.steps.length, this.opts.tempo);
    this.phase = 'beats';
    this.t = 0;
    this.next = 0;
    this.i = 0;
    this.beatAt = 0;
    this.from = this.base;
  }

  /** The result of what is playing (or played last), before it lands */
  preview(): ScoreTally {
    return this.tallies.at(-1) ?? this.base;
  }

  /** Beats or the land are on (a tap now means skip) */
  get playing(): boolean {
    return this.phase === 'beats' || this.phase === 'land';
  }

  /** Where it is: 'idle' (nothing played yet), 'beats', 'land' (the total stands), 'done' */
  get state(): Phase {
    return this.phase;
  }

  /** Beats played so far */
  get beat(): number {
    return this.i;
  }

  /** The score after the beats played so far */
  get tally(): ScoreTally {
    return this.i > 0 ? this.tallies[this.i - 1] : this.base;
  }

  /** The count-up: each part eases from the last beat's value to this beat's (draw this, not `tally`) */
  get shown(): ScoreTally {
    if (this.phase === 'land' || this.phase === 'done') return { ...this.tally, total: this.finalTotal };
    const to = this.tally;
    const span = Math.min(0.2, this.i > 0 ? this.times[this.i - 1] : 0.2);
    const k = span > 0 ? Math.min(1, (this.t - this.beatAt) / span) : 1;
    const e = 1 - (1 - k) ** 3;
    const mix = (a: number, b: number) => a + (b - a) * e;
    return { add: mix(this.from.add, to.add), mult: mix(this.from.mult, to.mult), times: mix(this.from.times, to.times), total: mix(this.from.total, to.total) };
  }

  /** Hold it still (your own pause screen); the host's pause holds it by itself */
  pause(on: boolean): void {
    this.held = on;
  }

  /**
   * Fast-forward (a tap): during the beats every step left is applied at once (onStep with fast: true — skip their
   * sparks and sounds) and the total lands; during the land, it is done
   */
  skip(): void {
    if (this.phase === 'beats') {
      while (this.i < this.steps.length) this.fire(true);
      this.land(true);
    } else if (this.phase === 'land') this.done();
  }

  /** Finish now, with every hook: the beats, the land and onDone */
  finish(): void {
    if (this.phase === 'beats') this.skip();
    if (this.phase === 'land') this.done();
  }

  /** Advance by `dt` seconds (your frame's): beats fire at their times, labels age */
  update(dt: number): void {
    if (this.held || this.opts.host?.paused) return;
    const d = Math.max(0, Math.min(0.25, dt));
    this.t += d;
    for (const l of this.live) l.age += d;
    this.live = this.live.filter((l) => l.age < l.life);
    // A slow frame fires the beats it covered, in order
    while (this.phase === 'beats' && this.t >= this.next) {
      if (this.i < this.steps.length) {
        const at = this.next;
        this.fire(false);
        this.beatAt = at;
        this.next = at + this.times[this.i - 1];
      } else this.land(false);
    }
    if (this.phase === 'land' && this.t >= this.next) this.done();
  }

  /** The floating labels now, placed clear of each other */
  labels(): ScoreLabel[] {
    return this.live.map((l) => {
      const k = l.age / l.life;
      return {
        text: l.text,
        kind: l.kind,
        x: l.x,
        // Drifts up a little as it fades
        y: l.y0 - 18 * k,
        w: l.w,
        h: l.h,
        age: l.age,
        alpha: k < 2 / 3 ? 1 : Math.max(0, 1 - (k - 2 / 3) * 3),
        scale: 1 + 0.3 * Math.max(0, 1 - l.age / 0.12),
      };
    });
  }

  private fire(fast: boolean): void {
    const index = this.i;
    const step = this.steps[index];
    this.from = this.shown;
    this.i++;
    const point = this.pointOf(step);
    const pitch = PITCH.step ** Math.min(index, PITCH.cap);
    if (!fast && point) this.label(step, point);
    this.opts.onStep?.({ step, index, pitch, tally: this.tallies[index], point, fast });
    const n = this.steps.length;
    if (!fast && n > ROLL.after && index === ROLL.at) {
      const sec = this.times.slice(index).reduce((a, b) => a + b, 0);
      this.opts.onRoll?.({ k: Math.min(1, n / 30), sec });
    }
  }

  private land(fast: boolean): void {
    this.phase = 'land';
    this.next = this.t + LAND_HOLD;
    const tally = this.tally;
    this.opts.onLand?.({ total: this.finalTotal, big: landSize(this.finalTotal, this.target), tally, fast });
  }

  private done(): void {
    this.phase = 'done';
    this.opts.onDone?.(this.finalTotal);
  }

  private pointOf(step: ScoreStep): { x: number; y: number } | null {
    const at = step.at;
    if (at === undefined) return null;
    if (typeof at === 'object') return at;
    return this.opts.where?.(at, step) ?? null;
  }

  /** The step's labels over its point, each moved clear of the ones still showing (up first, then to the sides) */
  private label(step: ScoreStep, p: { x: number; y: number }): void {
    const L = this.opts.labels ?? {};
    const size = L.size ?? 22;
    const life = L.life ?? 0.9;
    const measure = L.measure ?? ((t: string, s: number) => t.length * s * 0.58 + 6);
    const parts: { text: string; kind: ScoreLabel['kind'] }[] = [];
    if (step.label) parts.push({ text: step.label, kind: 'label' });
    else {
      if (step.add) parts.push({ text: `${step.add > 0 ? '+' : ''}${fmt(step.add)}`, kind: 'add' });
      if (step.mult) parts.push({ text: `${step.mult > 0 ? '+' : ''}${fmt(step.mult)}`, kind: 'mult' });
      if (step.times && step.times !== 1) parts.push({ text: `×${fmt(step.times)}`, kind: 'times' });
    }
    for (const part of parts) {
      const w = measure(part.text, size);
      const h = size * 1.15;
      const spot = this.clear(p.x, p.y - size * 1.2, w, h, L.bounds);
      this.live.push({ ...part, x: spot.x, y: spot.y, y0: spot.y, w, h, age: 0, alpha: 1, scale: 1.3, life });
    }
  }

  /** The nearest free place for a w×h box at (x, y): up in steps of its height, then left and right */
  private clear(x: number, y: number, w: number, h: number, bounds?: { w: number; h: number }): { x: number; y: number } {
    const fit = (cx: number, cy: number) => {
      if (!bounds) return { x: cx, y: cy };
      return { x: Math.max(w / 2, Math.min(bounds.w - w / 2, cx)), y: Math.max(h / 2, Math.min(bounds.h - h / 2, cy)) };
    };
    const hits = (c: { x: number; y: number }) =>
      this.live.some((l) => {
        const ly = l.y0 - 18 * (l.age / l.life);
        return Math.abs(l.x - c.x) * 2 < l.w + w && Math.abs(ly - c.y) * 2 < l.h + h;
      });
    const tries: [number, number][] = [[0, 0]];
    for (let k = 1; k <= 6; k++) tries.push([0, -k], [k * 0.6, -k + 0.5], [-k * 0.6, -k + 0.5]);
    for (const [dx, dy] of tries) {
      const c = fit(x + dx * w, y + dy * h * 1.05);
      if (!hits(c)) return c;
    }
    return fit(x, y);
  }
}

/** 12, 1.5, 2.25 — no float noise in a label */
function fmt(v: number): string {
  return String(Math.round(v * 100) / 100);
}

/** Draw the labels on a 2D canvas: outlined numbers, coloured by kind (the defaults: Velvet's chips blue, mult red, ×mult gold) */
export function drawScoreLabels(
  g: CanvasRenderingContext2D,
  labels: readonly ScoreLabel[],
  style: { font?: string; colors?: Partial<Record<ScoreLabel['kind'], string>>; outline?: string; size?: number } = {},
): void {
  const colors = { add: '#8fc0ff', mult: '#ff8f84', times: '#ffd166', label: '#fff1cf', ...style.colors };
  const size = style.size ?? 22;
  g.save();
  g.textAlign = 'center';
  g.textBaseline = 'middle';
  g.lineJoin = 'round';
  for (const l of labels) {
    g.globalAlpha = l.alpha;
    g.font = `800 ${Math.round(size * l.scale)}px ${style.font ?? 'system-ui, sans-serif'}`;
    g.lineWidth = Math.max(3, size * 0.18);
    g.strokeStyle = style.outline ?? '#120a06';
    g.strokeText(l.text, l.x, l.y);
    g.fillStyle = colors[l.kind];
    g.fillText(l.text, l.x, l.y);
  }
  g.restore();
}
