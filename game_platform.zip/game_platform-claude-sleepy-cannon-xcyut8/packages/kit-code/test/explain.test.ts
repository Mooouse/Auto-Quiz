import { describe, expect, it } from 'vitest';
import { episodes, judgeExplanation, normalizeText, type ExplainSample } from '../qa/explain.ts';

const HINT = 'Your echo flies the dotted path again — catch what it misses.';
/** Samples every 50 ms over [0, to): visible where `on(t)` */
function run(to: number, on: (t: number) => boolean, text = HINT, where: 'dom' | 'canvas' = 'dom'): ExplainSample[] {
  const out: ExplainSample[] = [];
  for (let i = 0; i * 0.05 < to - 1e-9; i++) {
    const t = +(i * 0.05).toFixed(2);
    out.push(on(t) ? { t, visible: true, text, where } : { t, visible: false });
  }
  return out;
}

describe('episodes', () => {
  it('a stretch ends at the first sample that does not show it; one still showing is open', () => {
    const e = episodes(run(3, (t) => (t >= 0.5 && t < 1) || t >= 2));
    expect(e.map((x) => [x.start, x.end, x.open])).toEqual([
      [0.5, 1, false],
      [2, 2.95, true],
    ]);
  });
});

describe('judgeExplanation', () => {
  it('Echoflies before its playtest: the line on screen for 30 ms at the twist fails', () => {
    // One sample caught it, at the twist (12.3 s)
    const v = judgeExplanation({ samples: run(14, (t) => t === 12.3), twistAt: 12.3, phrase: 'dotted path' });
    expect(v.ok).toBe(false);
    expect(v.text).toMatch(/visible 0\.05 s at most/);
    expect(v.text).toMatch(/needed to read its 61 characters/);
  });
  it('shown at the twist (the next frame) and kept until read passes', () => {
    const v = judgeExplanation({ samples: run(18.5, (t) => t >= 12.35 && t < 18), twistAt: 12.3, phrase: 'dotted path' });
    expect(v.ok).toBe(true);
    expect(v.needSec).toBeCloseTo(5.05, 2);
  });
  it('shown before the twist, long enough, then gone: passes', () => {
    expect(judgeExplanation({ samples: run(10, (t) => t >= 1 && t < 4, 'Tap the target!'), twistAt: 8, phrase: 'tap the target' }).ok).toBe(true);
  });
  it('shown only well after the twist: fails, and says so', () => {
    const v = judgeExplanation({ samples: run(20, (t) => t >= 14), twistAt: 12, phrase: 'dotted path' });
    expect(v.ok).toBe(false);
    expect(v.text).toMatch(/after the twist at 12\.0 s/);
  });
  it('never visible: fails with why it did not count', () => {
    const samples = run(5, () => false).map((s) => ({ ...s, why: 'faded (opacity 0.00)' }));
    const v = judgeExplanation({ samples, twistAt: 2, phrase: 'dotted path' });
    expect(v.ok).toBe(false);
    expect(v.text).toMatch(/never visible.*faded/);
  });
  it('a stretch still open at the end counts with what was seen', () => {
    expect(judgeExplanation({ samples: run(6, (t) => t >= 0.5, 'Tap the target!'), twistAt: 1, phrase: 'tap the target' }).ok).toBe(true);
    expect(judgeExplanation({ samples: run(2, (t) => t >= 0.5, 'Tap the target!'), twistAt: 1, phrase: 'tap the target' }).ok).toBe(false);
  });
  it('the twist never fired: any stretch long enough passes', () => {
    expect(judgeExplanation({ samples: run(30, (t) => t >= 20 && t < 25, 'Tap the target!'), twistAt: null, phrase: 'tap the target' }).ok).toBe(true);
  });
  it('a canvas explanation is said to be one', () => {
    expect(judgeExplanation({ samples: run(6, (t) => t < 5, 'Echoes replay the dots', 'canvas'), twistAt: 1, phrase: 'echoes replay' }).text).toMatch(/\(canvas\)/);
  });
});

describe('normalizeText', () => {
  it('ignores case, spacing and curly quotes', () => {
    expect(normalizeText('  Your  ECHO\n flies — it’s “here” ')).toBe(`your echo flies — it's "here"`);
  });
});
