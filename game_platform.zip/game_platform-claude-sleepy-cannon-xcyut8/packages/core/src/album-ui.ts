// The album: a collection's entries a page at a time (never a list to scroll), each group on its own pages, each row
// labelled (its material, its class: what the reviewer of Craft Pickaxe missed in 88 identical silhouettes), found
// entries in their own picture, missing ones as a silhouette (tinted by their row when the game gives a tint), secret
// ones as "?", a "new" mark until the player has seen it. A tap on an entry names it on the info line. One screen at
// 360×800, 1280×720 and a phone on its side.
//
//   mountAlbum(null, album, {
//     host,
//     view: (id) => ({ icon: pickIcon(id), name: host.t(`pick.${id}`) }),
//     rowName: (group, row) => ({ label: host.t(`mat.${row}`), icon: blockIcon(row), tint: MAT[row].color }),
//     groupName: (g) => host.t(`album.${g}`),
//   });
//
// Themeable: --gp-album-bg, -panel, -ink, -muted, -accent, -accent-ink, -radius, -font (the shared --gp-theme-* first),
// -silhouette, -new, and the rarities -common … -legendary on #gp-album. data-gp="album", "album-cell" (data-gp-entry,
// data-found, data-new), "album-info", "album-close", "album-prev"/"album-next" for QA.

import type { Collection, CollectionCell } from './collection.ts';
import type { Rarity } from './goals.ts';
import type { GameHost } from './host.ts';
import { button, buttonReset, el, iconOf, injectCss, mark, modal, pager, pagerCss, themeVars, VEIL_CSS, type UiIcon } from './ui-kit.ts';

export interface AlbumTexts {
  title: string;
  found: (n: number, max: number) => string;
  bonus: (bonus: string) => string;
  unknown: string;
  secret: string;
  isNew: string;
  rarity: (r: Rarity) => string;
  page: (n: number, max: number) => string;
  close: string;
}

export function albumTexts(t: (key: string, params?: Record<string, string | number>) => string): AlbumTexts {
  return {
    title: t('gp.album.title'),
    found: (n, max) => t('gp.album.found', { n, max }),
    bonus: (bonus) => t('gp.album.bonus', { bonus }),
    unknown: t('gp.album.unknown'),
    secret: t('gp.goals.secret'),
    isNew: t('gp.album.new'),
    rarity: (r) => t(`gp.rarity.${r}`),
    page: (n, max) => t('gp.season.page', { n, max }),
    close: t('gp.back'),
  };
}

export interface AlbumOptions {
  host: Pick<GameHost, 'minTouchPx' | 'screen' | 't'>;
  /** An entry's picture and name (`found` false: what a silhouette is made from — the same picture by default) */
  view: (id: string, found: boolean) => { icon?: UiIcon; name: string; silhouette?: UiIcon };
  /** A row's label, its icon and the tint of its silhouettes */
  rowName?: (group: string, row: string) => { label: string; icon?: UiIcon; tint?: string };
  /** A group's name (the page's title line) */
  groupName?: (group: string) => string;
  /** How the collection's bonus reads (default "+12 %"); null hides it */
  formatBonus?: ((bonus: number) => string) | null;
  /** The group it opens on (default: the first page with something new) */
  group?: string;
  onClose?(): void;
  texts?: Partial<AlbumTexts>;
}

export interface AlbumScreen {
  el: HTMLElement;
  close(): void;
  refresh(): void;
}

const NS = 'album';
const ID = 'gp-album';
const GAP = 6;

const CSS = `
${themeVars(ID, NS, [
  ['off', 'rgba(255, 255, 255, 0.16)'],
  ['silhouette', 'rgba(255, 255, 255, 0.07)'],
  ['new', '#ff5d73'],
  ['common', '#c9d2dc'],
  ['rare', '#4aa8ff'],
  ['epic', '#b26bff'],
  ['legendary', '#ffb02e'],
])}
${VEIL_CSS}
#${ID} { position: relative; box-sizing: border-box; width: min(96vw, 900px); height: min(96vh, 660px); display: flex; flex-direction: column; gap: 8px;
  padding: 14px; border-radius: var(--gp-album-radius); background: var(--gp-album-bg); color: var(--gp-album-ink); font: 600 15px var(--gp-album-font);
  font-variant-numeric: tabular-nums; text-align: left; pointer-events: auto; }
${buttonReset(ID)}
${pagerCss(ID, NS)}
#${ID} header { display: flex; align-items: center; gap: 10px; }
#${ID} h2 { margin: 0; font-size: 24px; line-height: 1.15; flex: 1 1 auto; min-width: 0; }
#${ID} .gp-al-count { font-size: 14px; color: var(--gp-album-muted); white-space: nowrap; }
#${ID} .gp-al-x { border-radius: 999px; display: inline-flex; align-items: center; justify-content: center; color: var(--gp-album-muted); }
#${ID} .gp-al-sub { display: flex; gap: 10px; align-items: baseline; flex-wrap: wrap; font-size: 14px; color: var(--gp-album-muted); }
#${ID} .gp-al-sub b { color: var(--gp-album-ink); font-size: 16px; }
#${ID} .gp-al-bonus { color: var(--gp-album-accent); }
#${ID} .gp-al-track { flex: 1 1 0; min-height: 0; display: flex; flex-direction: column; gap: ${GAP}px; }
#${ID} .gp-al-line { display: flex; gap: ${GAP}px; align-items: stretch; }
#${ID} .gp-al-label { flex: none; display: flex; align-items: center; gap: 4px; font-size: 12px; line-height: 1.15; color: var(--gp-album-muted); overflow: hidden; }
#${ID} .gp-al-label span { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
#${ID} .gp-al-label.gp-al-narrow { flex-direction: column; justify-content: center; text-align: center; gap: 2px; }
#${ID} .gp-al-label.gp-al-narrow span { max-width: 100%; }
#${ID} .gp-al-label > img, #${ID} .gp-al-label > canvas, #${ID} .gp-al-label > svg { width: 22px; height: 22px; object-fit: contain; flex: none; }
#${ID} .gp-al-cell { position: relative; flex: none; box-sizing: border-box; border-radius: 12px; background: var(--gp-album-panel); border: 2px solid transparent;
  display: flex; align-items: center; justify-content: center; overflow: hidden; font-size: 24px; line-height: 1; }
#${ID} .gp-al-cell > img, #${ID} .gp-al-cell > canvas, #${ID} .gp-al-cell > svg { width: 72%; height: 72%; object-fit: contain; }
#${ID} .gp-al-cell[data-found] { border-color: var(--gp-r, transparent); }
#${ID} .gp-al-cell:not([data-found]) { background: color-mix(in srgb, var(--gp-tint, transparent) 22%, var(--gp-album-silhouette)); }
#${ID} .gp-al-cell:not([data-found]) > img, #${ID} .gp-al-cell:not([data-found]) > canvas { filter: brightness(0); opacity: 0.38; }
#${ID} .gp-al-cell:not([data-found]) > svg { color: var(--gp-album-muted); opacity: 0.6; }
#${ID} .gp-al-cell[data-rarity=rare] { --gp-r: var(--gp-album-rare); }
#${ID} .gp-al-cell[data-rarity=epic] { --gp-r: var(--gp-album-epic); }
#${ID} .gp-al-cell[data-rarity=legendary] { --gp-r: var(--gp-album-legendary); }
#${ID} .gp-al-cell[data-new]::after { content: ''; position: absolute; top: 4px; right: 4px; width: 10px; height: 10px; border-radius: 50%; background: var(--gp-album-new); }
#${ID} .gp-al-cell[aria-pressed=true] { box-shadow: inset 0 0 0 2px var(--gp-album-accent); }
#${ID} .gp-al-info:empty { visibility: hidden; }
#${ID} .gp-al-info { min-height: 44px; display: flex; align-items: center; gap: 10px; padding: 0 10px; border-radius: 12px; background: var(--gp-album-panel); font-size: 14px; }
#${ID} .gp-al-info > img, #${ID} .gp-al-info > canvas, #${ID} .gp-al-info > svg { width: 32px; height: 32px; object-fit: contain; flex: none; }
#${ID} .gp-al-info small { color: var(--gp-album-muted); font-size: 13px; }
#${ID} footer { display: flex; justify-content: center; }
@media (max-height: 520px) {
  #${ID} { height: 98vh; padding: 8px 12px; gap: 5px; }
  #${ID} h2 { font-size: 19px; }
  #${ID} .gp-al-info { min-height: 36px; }
}
`;

type Line = { group: string; row: string; first: boolean; cells: CollectionCell[] };

/** The album, open now in `root` (a modal veil; null: document.body). host.screen('album') */
export function mountAlbum(root: HTMLElement | null, coll: Collection, opts: AlbumOptions): AlbumScreen {
  const { host } = opts;
  injectCss('gp-album-css', CSS);
  const words: AlbumTexts = { ...albumTexts((k, p) => host.t(k, p)), ...opts.texts };
  const touch = host.minTouchPx;
  const used = new WeakSet<Element>();
  const fmtBonus = opts.formatBonus === undefined ? (b: number) => `+${Math.round(b * 100)} %` : opts.formatBonus;

  const dismiss = () => {
    m.close();
    opts.onClose?.();
  };
  /** Entries shown with their "new" mark: seen once the player turns the page or closes the album */
  const shownNew = new Set<string>();
  const flushSeen = () => {
    if (shownNew.size) coll.markSeen([...shownNew]);
    shownNew.clear();
  };
  const m = modal(ID, words.title, root, dismiss, () => {
    removeEventListener('resize', onResize);
    flushSeen();
  });
  const box = m.box;
  box.dataset.gp = 'album';
  const head = el('header');
  const h = el('h2', '', words.title);
  const count = el('span', 'gp-al-count');
  count.dataset.gp = 'album-count';
  const x = button('gp-al-x', 'album-close');
  x.append(mark('close', 22));
  x.setAttribute('aria-label', words.close);
  x.style.minWidth = x.style.minHeight = `${touch}px`;
  x.addEventListener('click', dismiss);
  head.append(h, count, x);
  const sub = el('div', 'gp-al-sub');
  const track = el('div', 'gp-al-track');
  track.dataset.gp = 'album-track';
  const info = el('div', 'gp-al-info');
  info.dataset.gp = 'album-info';
  info.setAttribute('aria-live', 'polite');
  const foot = el('footer');
  let page = -1;
  let pages: Line[][] = [];
  let picked: string | null = null;
  const pg = pager(NS, touch, words.page, (d) => {
    flushSeen();
    page += d;
    picked = null;
    draw();
  });
  foot.append(pg.el);
  box.append(head, sub, track, info, foot);

  const rowOf = (g: string, r: string) => (r ? opts.rowName?.(g, r) : undefined);

  /** Cut the groups into pages: rows split into lines of `cols`, as many lines a page as fit */
  const layout = (cols: number, perPage: number): Line[][] => {
    const out: Line[][] = [];
    for (const g of coll.state().groups) {
      const lines: Line[] = [];
      for (const r of g.rows) for (let i = 0; i < r.cells.length; i += cols) lines.push({ group: g.id, row: r.id, first: i === 0, cells: r.cells.slice(i, i + cols) });
      for (let i = 0; i < lines.length; i += perPage) out.push(lines.slice(i, i + perPage));
    }
    return out.length ? out : [[]];
  };

  const describe = (c: CollectionCell, g: string) => {
    const v = opts.view(c.id, c.found);
    info.replaceChildren();
    if (c.found && v.icon !== undefined) info.append(iconOf(v.icon, used));
    else info.append(mark(c.secret ? 'question' : 'lock', 24));
    const t = el('div');
    const row = rowOf(g, coll.entries.find((e) => e.id === c.id)?.row ?? '');
    t.append(el('b', '', c.secret ? words.secret : c.found ? v.name : words.unknown));
    const bits = [words.rarity(c.rarity), row?.label ?? ''].filter(Boolean);
    if (c.found && c.bonus && fmtBonus) bits.push(fmtBonus(c.bonus));
    t.append(document.createElement('br'), el('small', '', bits.join(' · ')));
    info.append(t);
  };

  const cellOf = (c: CollectionCell, g: string, row: string, size: number): HTMLElement => {
    const b = button('gp-al-cell', 'album-cell');
    b.dataset.gpEntry = c.id;
    b.dataset.rarity = c.rarity;
    if (c.found) b.dataset.found = '';
    if (c.isNew) b.dataset.new = '';
    b.style.width = b.style.height = `${size}px`;
    const tint = rowOf(g, row)?.tint;
    if (tint) b.style.setProperty('--gp-tint', tint);
    const v = c.secret ? null : opts.view(c.id, c.found);
    if (c.secret) b.append(mark('question', Math.round(size * 0.5)));
    else if (c.found) b.append(v?.icon !== undefined ? iconOf(v.icon, used) : document.createTextNode(v?.name.slice(0, 1) ?? '?'));
    else {
      const s = v?.silhouette ?? v?.icon;
      b.append(s !== undefined ? iconOf(s, used) : mark('lock', Math.round(size * 0.4)));
    }
    b.setAttribute('aria-label', c.secret ? words.secret : c.found ? (v?.name ?? c.id) : words.unknown);
    if (picked === c.id) b.setAttribute('aria-pressed', 'true');
    b.addEventListener('click', () => {
      picked = c.id;
      for (const o of track.querySelectorAll('[aria-pressed=true]')) o.removeAttribute('aria-pressed');
      b.setAttribute('aria-pressed', 'true');
      describe(c, g);
    });
    return b;
  };

  const draw = () => {
    const st = coll.state();
    count.textContent = words.found(st.found, st.total);
    // The cell's size: the longest row on one line if it fits at the touch size, else as many as fit; a label column
    const w = track.clientWidth;
    const hh = track.clientHeight;
    const named = st.groups.some((g) => g.rows.some((r) => r.id));
    const labelW = named ? (w < 480 ? 64 : 120) : 0;
    const room = w - (named ? labelW + GAP : 0);
    const longest = Math.max(1, ...st.groups.flatMap((g) => g.rows.map((r) => r.cells.length)));
    let cols = Math.max(1, Math.floor((room + GAP) / (touch + GAP)));
    if (longest <= cols) cols = longest;
    const size = Math.max(touch, Math.min(76, Math.floor((room + GAP) / cols - GAP)));
    const perPage = Math.max(1, Math.floor((hh + GAP) / (size + GAP)));
    pages = layout(cols, perPage);
    if (page < 0) {
      const want = opts.group;
      const i = want !== undefined ? pages.findIndex((p) => p[0]?.group === want) : pages.findIndex((p) => p.some((l) => l.cells.some((c) => c.isNew)));
      page = Math.max(0, i);
    }
    page = Math.max(0, Math.min(pages.length - 1, page));
    const lines = pages[page];
    const g = lines[0]?.group ?? '';
    const gs = st.groups.find((x) => x.id === g);
    sub.replaceChildren();
    if (st.groups.length > 1 || opts.groupName) sub.append(el('b', '', opts.groupName ? opts.groupName(g) : g), el('span', '', gs ? `${gs.found}/${gs.total}` : ''));
    if (fmtBonus && st.bonus > 0) sub.append(el('span', 'gp-al-bonus', words.bonus(fmtBonus(st.bonus))));
    sub.hidden = !sub.childElementCount;
    track.replaceChildren(
      ...lines.map((l) => {
        const line = el('div', 'gp-al-line');
        if (named) {
          const lab = el('span', labelW < 100 ? 'gp-al-label gp-al-narrow' : 'gp-al-label');
          lab.style.width = `${labelW}px`;
          const r = l.first ? rowOf(l.group, l.row) : undefined;
          if (r?.icon !== undefined) lab.append(iconOf(r.icon, used));
          if (r) {
            lab.append(el('span', '', r.label));
            lab.title = r.label;
          }
          line.append(lab);
        }
        line.append(...l.cells.map((c) => cellOf(c, l.group, l.row, size)));
        return line;
      }),
    );
    pg.set(page, pages.length);
    // Seen now: the marks stay while this page is open, gone the next time
    for (const l of lines) for (const c of l.cells) if (c.isNew) shownNew.add(c.id);
    if (!picked) info.replaceChildren();
  };
  const onResize = () => draw();
  addEventListener('resize', onResize);
  draw();
  // The pager's room known now (it hides on a single page): lay out once more to its final height
  draw();
  host.screen('album');
  return { el: box, close: () => m.close(), refresh: draw };
}
