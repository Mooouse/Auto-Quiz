// Pixel-art upscaling: the scalers' sizes, whole pixels in the palette after a smooth scaler, details kept.

import { describe, expect, it } from 'vitest';
import { coloursOf, keepDetails, nearest, scale2x, snap, xbr, xbrz, type Rgba } from '../src/upscale.ts';

const R = [236, 58, 63, 255], K = [26, 16, 32, 255], W = [255, 255, 255, 255], _ = [0, 0, 0, 0];
const img = (w: number, rows: number[][]): Rgba => ({ w, h: rows.length / w, d: new Uint8ClampedArray(rows.flat()) });
// a 4×4 red diamond with a white eye in the middle, outlined dark
const diamond = img(4, [_, K, K, _, K, R, W, K, K, R, R, K, _, K, K, _]);

describe('pixel-art upscalers', () => {
  it('make the image bigger by the factor', async () => {
    expect([nearest(diamond, 3).w, scale2x(diamond).w, xbrz(diamond, 4).w, (await xbr(diamond, 2)).w]).toEqual([12, 8, 16, 8]);
  });
  it('Scale2x rounds a diagonal step and never invents a colour', () => {
    const s = scale2x(diamond);
    expect(coloursOf(s).sort()).toEqual(coloursOf(diamond).sort());
    // the top-left corner of the first outline pixel follows the transparent diagonal
    expect(s.d[(0 * 8 + 2) * 4 + 3]).toBe(0);
  });
  it('a smooth scaler comes back to whole pixels in the palette', () => {
    const out = snap(xbrz(diamond, 4), 2, ['#ec3a3f', '#1a1020', '#ffffff']);
    expect(out.w).toBe(8);
    for (let i = 0; i < out.d.length; i += 4) if (out.d[i + 3]) expect(['ec3a3f', '1a1020', 'ffffff']).toContain([out.d[i]!, out.d[i + 1]!, out.d[i + 2]!].map((v) => v.toString(16).padStart(2, '0')).join(''));
    expect(new Set(Array.from({ length: out.d.length / 4 }, (_, i) => out.d[i * 4 + 3])).size).toBeLessThanOrEqual(2); // 0 or 255
  });
  it('keeps a lone detail pixel for pixel (the eye), not the outline', () => {
    const face = img(5, [K, K, K, K, K, K, R, R, R, K, K, R, W, R, K, K, R, R, R, K, K, K, K, K, K]);
    const big = keepDetails(face, nearest(img(5, Array(25).fill(R)), 2));
    const at = (x: number, y: number) => Array.from(big.d.subarray((y * 10 + x) * 4, (y * 10 + x) * 4 + 4));
    expect([at(4, 4), at(5, 5), at(0, 0), at(3, 3)]).toEqual([W, W, R, R]);
  });
});
