// The rewards hub: a modal with up to three tabs — Gifts (the playtime ladder, a countdown on the next one), Wheel (a
// drawn wheel with each slice's amount on it, the free spin, then an extra spin for a rewarded ad, a paid spin) and
// Offers (the day's offers, the first free, currency for a rewarded ad) — and the boost's time left in its header.
// One screen at 360×800, 1280×720 and a phone on its side (the gifts and offers a page at a time). What Craft Pickaxe
// Idle's reviewer asked of its wheel is the rule here: the prize shows when the wheel stops, never before (it is
// decided and saved at the spin: a reload keeps it); "Extra spin" only after the free one; the amount on every slice.
//
//   mountRewardsHub(null, {
//     host, gifts, wheel, offers, boost,
//     view: (r) => (r.gems ? { icon: gemIcon, label: `${r.gems}` } : { icon: coinIcon, label: formatAmount(r.coins) }),
//     currency: { icon: gemIcon, amount: () => save.gems },
//     pay: (price) => (save.gems >= price ? ((save.gems -= price), true) : false),
//     onPrize: (r) => { give(r); host.save(save); },
//   });
//
// Rewarded placements: 'wheel-spin' (kind spin) and 'free-currency' (kind currency) by default — declare them in
// game.yaml money.rewarded. Themeable: --gp-rewards-bg, -panel, -ink, -muted, -accent, -accent-ink, -radius, -font
// (the shared --gp-theme-* first), -slice-a, -slice-b, -slice-c, -slice-ink on #gp-rewards. data-gp="rewards",
// "rewards-tab", "rewards-gift" (data-gp-gift), "rewards-take", "rewards-wheel", "rewards-spin-free", "rewards-spin-paid",
// "rewards-won", "rewards-offer" (data-gp-offer), "rewards-buy", "rewards-close".

import type { GameHost } from './host.ts';
import type { DailyOffers, LuckyWheel, PlaytimeGifts, SpinKind, TimedBoost } from './rewards.ts';
import { rewardedButton } from './rewarded-button.ts';
import { button, buttonReset, clockText, el, fitGrid, iconOf, injectCss, mark, modal, pager, pagerCss, reducedMotion, SVG_NS, tabs, tabsCss, themeVars, VEIL_CSS, type UiIcon } from './ui-kit.ts';

export interface RewardView {
  icon?: UiIcon;
  label: string;
}

export type RewardSource = 'gift' | 'wheel' | 'offer' | 'ad';

export interface RewardsTexts {
  title: string;
  gifts: string;
  wheel: string;
  offers: string;
  minutes: (n: number) => string;
  take: string;
  takeAll: (n: number) => string;
  carried: (n: number) => string;
  playMore: (time: string) => string;
  spinFree: string;
  spinAd: string;
  spinPaid: (price: string) => string;
  spinTomorrow: string;
  won: (prize: string) => string;
  free: string;
  today: string;
  adCurrency: (reward: string) => string;
  boost: (factor: number, time: string) => string;
  page: (n: number, max: number) => string;
  close: string;
}

export function rewardsTexts(t: (key: string, params?: Record<string, string | number>) => string): RewardsTexts {
  return {
    title: t('gp.rewards.title'),
    gifts: t('gp.rewards.gifts'),
    wheel: t('gp.rewards.wheel'),
    offers: t('gp.rewards.offers'),
    minutes: (n) => t('gp.rewards.minutes', { n }),
    take: t('gp.goals.claim'),
    takeAll: (n) => t('gp.goals.claimAll', { n }),
    carried: (n) => t('gp.goals.carried', { n }),
    playMore: (time) => t('gp.rewards.playMore', { time }),
    spinFree: t('gp.rewards.spinFree'),
    spinAd: t('gp.rewards.spinAd'),
    spinPaid: (price) => t('gp.rewards.spinPaid', { price }),
    spinTomorrow: t('gp.rewards.spinTomorrow'),
    won: (prize) => t('gp.rewards.won', { prize }),
    free: t('gp.rewards.free'),
    today: t('gp.rewards.today'),
    adCurrency: (reward) => t('gp.rewards.adCurrency', { reward }),
    boost: (factor, time) => t('gp.rewards.boost', { factor, time }),
    page: (n, max) => t('gp.season.page', { n, max }),
    close: t('gp.back'),
  };
}

type Tab = 'gifts' | 'wheel' | 'offers';

export interface RewardsHubOptions<R> {
  host: Pick<GameHost, 'minTouchPx' | 'screen' | 't' | 'rewarded' | 'rewardedAvailable'> & Partial<Pick<GameHost, 'i18n' | 'adPending'>>;
  gifts?: PlaytimeGifts<R> | null;
  wheel?: LuckyWheel<R> | null;
  offers?: DailyOffers<R> | null;
  /** Its time left shows in the header while it runs */
  boost?: TimedBoost | null;
  /** How a reward reads: an icon and a short amount ("50", "×2 10 min") — the amount goes on the wheel's slice */
  view: (reward: R, from: RewardSource) => RewardView;
  /** The currency offers cost: its icon and the wallet now (shown in the header) */
  currency?: { icon?: UiIcon; amount: () => number; format?: (n: number) => string };
  /** Take `price` of the currency for an offer: true when paid */
  pay?: (price: number) => boolean;
  /** A reward was won or bought: give it, and save */
  onPrize(reward: R, from: RewardSource, id?: string): void;
  onClose?(): void;
  /** Rewarded placements (default 'wheel-spin', 'free-currency') */
  placements?: { spin?: string; currency?: string };
  tab?: Tab;
  texts?: Partial<RewardsTexts>;
}

export interface RewardsHub {
  el: HTMLElement;
  close(): void;
  refresh(): void;
}

const NS = 'rewards';
const ID = 'gp-rewards';
const GAP = 6;
const SPIN_MS = 2600;

const CSS = `
${themeVars(ID, NS, [
  ['off', 'rgba(255, 255, 255, 0.16)'],
  ['slice-a', '#3b5bdb'],
  ['slice-b', '#7048e8'],
  ['slice-c', '#1098ad'],
  ['slice-ink', '#ffffff'],
])}
${VEIL_CSS}
#${ID} { position: relative; box-sizing: border-box; width: min(96vw, 760px); height: min(96vh, 660px); display: flex; flex-direction: column; gap: 10px;
  padding: 14px; border-radius: var(--gp-rewards-radius); background: var(--gp-rewards-bg); color: var(--gp-rewards-ink); font: 600 15px var(--gp-rewards-font);
  font-variant-numeric: tabular-nums; text-align: left; pointer-events: auto; }
#${ID}[data-busy] .gp-b { pointer-events: none; }
${buttonReset(ID)}
${tabsCss(ID, NS)}
${pagerCss(ID, NS)}
#${ID} header { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
#${ID} h2 { margin: 0; font-size: 24px; line-height: 1.15; flex: 1 1 auto; min-width: 0; }
#${ID} .gp-rw-wallet, #${ID} .gp-rw-boost { display: inline-flex; align-items: center; gap: 4px; font-weight: 800; white-space: nowrap; }
#${ID} .gp-rw-boost { color: var(--gp-rewards-accent); font-size: 14px; }
#${ID} .gp-rw-wallet > img, #${ID} .gp-rw-wallet > canvas, #${ID} .gp-rw-wallet > svg { width: 22px; height: 22px; object-fit: contain; }
#${ID} .gp-rw-x { border-radius: 999px; display: inline-flex; align-items: center; justify-content: center; color: var(--gp-rewards-muted); }
#${ID} .gp-rw-body { flex: 1 1 0; min-height: 0; display: flex; flex-direction: column; gap: 8px; }
#${ID} .gp-rw-grid { flex: 1 1 0; min-height: 0; display: grid; gap: ${GAP}px; align-content: start; }
#${ID} .gp-rw-card { box-sizing: border-box; min-width: 0; display: flex; flex-direction: column; align-items: center; justify-content: space-between; gap: 4px; padding: 8px 6px;
  border-radius: 14px; background: var(--gp-rewards-panel); border: 2px solid transparent; text-align: center; overflow: hidden; }
#${ID} .gp-rw-card[data-state=ready] { border-color: var(--gp-rewards-accent); }
#${ID} .gp-rw-card[data-state=taken] { opacity: 0.65; }
#${ID} .gp-rw-k { font-size: 12px; color: var(--gp-rewards-muted); display: inline-flex; align-items: center; gap: 3px; white-space: nowrap; }
#${ID} .gp-rw-icon { flex: 1 1 auto; min-height: 0; display: flex; align-items: center; justify-content: center; font-size: 28px; line-height: 1; }
#${ID} .gp-rw-icon > img, #${ID} .gp-rw-icon > canvas, #${ID} .gp-rw-icon > svg { width: 38px; height: 38px; object-fit: contain; }
#${ID} .gp-rw-label { font-size: 14px; font-weight: 800; line-height: 1.15; max-width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
#${ID} .gp-rw-act { min-height: 48px; display: flex; align-items: center; justify-content: center; width: 100%; }
#${ID} .gp-rw-btn { border-radius: 999px; padding: 0 14px; background: var(--gp-rewards-accent); color: var(--gp-rewards-accent-ink); font-weight: 800;
  display: inline-flex; align-items: center; justify-content: center; gap: 6px; white-space: nowrap; max-width: 100%; }
#${ID} .gp-rw-btn[aria-disabled=true] { opacity: 0.5; cursor: default; }
#${ID} .gp-rw-btn.gp-rw-plain { background: var(--gp-rewards-panel); color: var(--gp-rewards-ink); box-shadow: inset 0 0 0 2px var(--gp-rewards-off); }
#${ID} .gp-rw-btn > img, #${ID} .gp-rw-btn > canvas, #${ID} .gp-rw-btn > svg { width: 20px; height: 20px; object-fit: contain; }
#${ID} .gp-rw-wait { font-size: 13px; color: var(--gp-rewards-muted); display: inline-flex; align-items: center; gap: 4px; }
#${ID} .gp-rw-done { color: var(--gp-rewards-accent); }
#${ID} .gp-rw-row { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; justify-content: center; }
#${ID} .gp-rw-line { font-size: 14px; color: var(--gp-rewards-muted); text-align: center; min-height: 20px; }
#${ID} .gp-rw-won { font-size: 18px; font-weight: 800; color: var(--gp-rewards-accent); text-align: center; min-height: 24px; display: flex; align-items: center; justify-content: center; gap: 6px; }
#${ID} .gp-rw-won > img, #${ID} .gp-rw-won > canvas, #${ID} .gp-rw-won > svg { width: 26px; height: 26px; object-fit: contain; }
#${ID} .gp-rw-stage { flex: 1 1 0; min-height: 0; min-width: 0; display: flex; align-items: center; justify-content: center; position: relative; }
#${ID} .gp-rw-stage > svg { width: auto; height: 100%; max-width: 100%; max-height: 100%; aspect-ratio: 1; overflow: visible; }
#${ID} .gp-rw-wheel { transform-box: view-box; transform-origin: 0 0; }
#${ID} .gp-rw-wheel text { fill: var(--gp-rewards-slice-ink); font: 800 13px var(--gp-rewards-font); paint-order: stroke; stroke: rgba(0, 0, 0, 0.35); stroke-width: 3px; }
#${ID} .gp-rw-wheelbox { flex: 1 1 0; min-height: 0; display: flex; flex-direction: column; gap: 8px; }
#${ID} .gp-rw-side { display: flex; flex-direction: column; gap: 8px; justify-content: center; }
@media (orientation: landscape) {
  #${ID} .gp-rw-wheelbox { flex-direction: row; align-items: stretch; }
  #${ID} .gp-rw-stage { flex: 1 1 55%; }
  #${ID} .gp-rw-side { flex: 1 1 45%; }
  #${ID} .gp-rw-side .gp-rw-row { flex-direction: column; align-items: stretch; }
}
#${ID} .gp-rw-tag { font-size: 12px; color: var(--gp-rewards-accent); }
@media (max-height: 520px) {
  #${ID} { height: 98vh; padding: 8px 12px; gap: 6px; }
  #${ID} h2 { font-size: 19px; }
  #${ID} .gp-rw-won { min-height: 20px; font-size: 16px; }
}
`;

/** Three colours round the wheel, never the same twice side by side (the last slice meets the first) */
export function sliceColor(i: number, n: number): number {
  const c = i % 3;
  if (i !== n - 1 || n < 3) return n === 2 ? i : c;
  const before = (n - 2) % 3;
  return c !== 0 && c !== before ? c : [0, 1, 2].find((k) => k !== 0 && k !== before)!;
}

/** The rewards hub, open now in `root` (a modal veil; null: document.body). host.screen('rewards') */
export function mountRewardsHub<R>(root: HTMLElement | null, opts: RewardsHubOptions<R>): RewardsHub {
  const { host } = opts;
  injectCss('gp-rewards-css', CSS);
  const words: RewardsTexts = { ...rewardsTexts((k, p) => host.t(k, p)), ...opts.texts };
  const touch = host.minTouchPx;
  const used = new WeakSet<Element>();
  const { gifts, wheel, offers, boost } = opts;
  if (!gifts && !wheel && !offers) throw new Error('mountRewardsHub: give it gifts, a wheel, offers or some of them');
  const fmt = opts.currency?.format ?? ((n: number) => String(Math.floor(n)));

  let spinning: { done(): void } | null = null;
  const dismiss = () => {
    m.close();
    opts.onClose?.();
  };
  const m = modal(ID, words.title, root, dismiss, () => {
    removeEventListener('resize', onResize);
    clearInterval(ticker);
    // Closed while the wheel turns: the prize is still the player's — paid now
    spinning?.done();
  });
  const box = m.box;
  box.dataset.gp = 'rewards';

  const head = el('header');
  const h = el('h2', '', words.title);
  const boostEl = el('span', 'gp-rw-boost');
  boostEl.dataset.gp = 'rewards-boost';
  const wallet = el('span', 'gp-rw-wallet');
  wallet.dataset.gp = 'rewards-wallet';
  const x = button('gp-rw-x', 'rewards-close');
  x.append(mark('close', 22));
  x.setAttribute('aria-label', words.close);
  x.style.minWidth = x.style.minHeight = `${touch}px`;
  x.addEventListener('click', dismiss);
  head.append(h, boostEl, wallet, x);

  const items: { id: Tab; label: string }[] = [];
  if (gifts) items.push({ id: 'gifts', label: words.gifts });
  if (wheel) items.push({ id: 'wheel', label: words.wheel });
  if (offers) items.push({ id: 'offers', label: words.offers });
  let tab: Tab = opts.tab && items.some((i) => i.id === opts.tab) ? opts.tab : items[0].id;
  const bar = tabs(NS, items, touch, (id) => {
    if (spinning) return;
    tab = id;
    page = 0;
    draw();
  });
  const body = el('div', 'gp-rw-body');
  const foot = el('footer');
  let page = 0;
  const pg = pager(NS, touch, words.page, (d) => {
    page += d;
    draw();
  });
  foot.append(pg.el);
  box.append(head, bar.el, body, foot);

  const viewNode = (r: R, from: RewardSource, cls = 'gp-rw-icon') => {
    const v = opts.view(r, from);
    const i = el('span', cls);
    if (v.icon !== undefined) i.append(iconOf(v.icon, used));
    return { icon: i, label: v.label, view: v };
  };
  const btn = (gp: string, label: string, onTap: () => void, plain = false) => {
    const b = button(`gp-rw-btn${plain ? ' gp-rw-plain' : ''}`, gp, label);
    b.style.minHeight = `${touch}px`;
    b.addEventListener('click', onTap);
    return b;
  };
  const prize = (r: R, from: RewardSource, id?: string) => opts.onPrize(r, from, id);

  /** A rewarded button with the drawn play mark; the other buttons wait while its ad runs */
  const adButton = (placement: string, label: string, onReward: () => void) => {
    const b = rewardedButton({
      host: host as Parameters<typeof rewardedButton>[0]['host'],
      placement,
      label,
      className: 'gp-b gp-rw-btn',
      onReward: () => {
        delete box.dataset.busy;
        onReward();
      },
    });
    if (!b) return null;
    b.dataset.gp = `rewards-ad-${placement}`;
    b.style.minHeight = `${touch}px`;
    b.prepend(mark('play', 16, true));
    b.addEventListener('click', () => {
      box.dataset.busy = '';
      const poll = setInterval(() => {
        if (!host.adPending) {
          clearInterval(poll);
          setTimeout(() => {
            delete box.dataset.busy;
            if (b.getAttribute('aria-disabled') === 'true') draw();
          }, 50);
        }
      }, 200);
    });
    return b;
  };

  // --- Header ---------------------------------------------------------------------------------------------------
  const drawHead = () => {
    if (opts.currency) {
      wallet.replaceChildren();
      if (opts.currency.icon !== undefined) wallet.append(iconOf(opts.currency.icon, used));
      wallet.append(document.createTextNode(fmt(opts.currency.amount())));
    }
    wallet.hidden = !opts.currency;
    const b = boost && boost.active ? boost.left : 0;
    boostEl.textContent = b > 0 ? words.boost(boost!.factor() || 1, clockText(b)) : '';
    boostEl.hidden = !(b > 0);
    if (gifts) bar.badge('gifts', gifts.state().ready);
    if (wheel) {
      const w = wheel.state();
      bar.badge('wheel', w.canFree || w.pending ? 1 : 0);
    }
    if (offers) bar.badge('offers', offers.state().offers.some((o) => o.free && !o.bought) ? 1 : 0);
  };

  // --- Gifts ----------------------------------------------------------------------------------------------------
  const grid = el('div', 'gp-rw-grid');
  const drawGifts = () => {
    const s = gifts!.state();
    const cards: HTMLElement[] = s.gifts.map((g) => {
      const c = el('div', 'gp-rw-card');
      c.dataset.gp = 'rewards-gift';
      c.dataset.gpGift = String(g.index);
      c.dataset.state = g.state;
      const k = el('span', 'gp-rw-k');
      k.append(mark('clock', 13), document.createTextNode(words.minutes(g.min)));
      const v = viewNode(g.reward, 'gift');
      const act = el('div', 'gp-rw-act');
      if (g.state === 'ready')
        act.append(
          btn('rewards-take', words.take, () => {
            const r = gifts!.take(g.index);
            if (r !== null) prize(r, 'gift');
            draw();
          }),
        );
      else if (g.state === 'taken') {
        const d = el('span', 'gp-rw-done');
        d.append(mark('check', 22));
        act.append(d);
      } else {
        const w = el('span', 'gp-rw-wait');
        w.dataset.gp = 'rewards-gift-wait';
        w.append(document.createTextNode(clockText(g.inSec)));
        act.append(w);
      }
      c.append(k, v.icon, el('span', 'gp-rw-label', v.label), act);
      return c;
    });
    const top: HTMLElement[] = [];
    if (s.carried.length) {
      const row = el('div', 'gp-rw-row');
      row.dataset.gp = 'rewards-carried';
      row.append(
        el('span', 'gp-rw-line', words.carried(s.carried.length)),
        btn('rewards-take-all', words.takeAll(s.carried.length), () => {
          for (const t of gifts!.takeAll()) prize(t.reward, 'gift');
          draw();
        }),
      );
      top.push(row);
    }
    const line = el('div', 'gp-rw-line', s.next ? words.playMore(clockText(s.next.inSec)) : '');
    line.dataset.gp = 'rewards-gift-next';
    body.replaceChildren(...top, grid, line);
    paged(cards, 120, 128);
  };

  /** The cards a page at a time in the grid */
  const paged = (cards: HTMLElement[], w: number, hh: number) => {
    pg.set(0, 2);
    let per = fitGrid(grid, cards.length, w, hh, GAP);
    if (cards.length <= per) {
      pg.set(0, 1);
      per = fitGrid(grid, cards.length, w, hh, GAP);
    }
    const pages = Math.max(1, Math.ceil(cards.length / per));
    page = Math.max(0, Math.min(pages - 1, page));
    grid.replaceChildren(...cards.slice(page * per, page * per + per));
    pg.set(page, pages);
  };

  // --- The wheel ------------------------------------------------------------------------------------------------
  let angle = 0;
  const drawWheel = () => {
    const s = wheel!.state();
    pg.set(0, 1);
    const n = s.slices.length;
    const stage = el('div', 'gp-rw-stage');
    stage.dataset.gp = 'rewards-wheel';
    const svg = document.createElementNS(SVG_NS, 'svg');
    svg.setAttribute('viewBox', '-110 -116 220 226');
    svg.setAttribute('role', 'img');
    const g = document.createElementNS(SVG_NS, 'g');
    g.classList.add('gp-rw-wheel');
    const fills = ['var(--gp-rewards-slice-a)', 'var(--gp-rewards-slice-b)', 'var(--gp-rewards-slice-c)'];
    const R = 100;
    const labels: string[] = [];
    s.slices.forEach((sl, i) => {
      const a0 = -Math.PI / 2 + ((i - 0.5) / n) * Math.PI * 2;
      const a1 = a0 + (Math.PI * 2) / n;
      const p = document.createElementNS(SVG_NS, 'path');
      p.setAttribute('d', `M0 0L${R * Math.cos(a0)} ${R * Math.sin(a0)}A${R} ${R} 0 0 1 ${R * Math.cos(a1)} ${R * Math.sin(a1)}Z`);
      p.setAttribute('fill', fills[sliceColor(i, n)]);
      p.setAttribute('stroke', 'rgba(0,0,0,0.35)');
      p.setAttribute('stroke-width', '1.5');
      p.dataset.slice = String(i);
      g.append(p);
      // The amount on the slice, along its middle; an image icon nearer the rim
      const v = opts.view(sl.reward, 'wheel');
      labels.push(v.label);
      const mid = -90 + (i / n) * 360;
      // Along the slice's middle, never upside down: the left half reads from the rim inwards
      const rad = (mid * Math.PI) / 180;
      const flip = Math.cos(rad) < -1e-6 || (Math.abs(Math.cos(rad)) <= 1e-6 && Math.sin(rad) > 0);
      const t = document.createElementNS(SVG_NS, 'text');
      t.textContent = v.label;
      t.setAttribute('x', flip ? '-58' : '58');
      t.setAttribute('y', '0');
      t.setAttribute('text-anchor', 'middle');
      t.setAttribute('dominant-baseline', 'central');
      t.setAttribute('transform', `rotate(${flip ? mid + 180 : mid})`);
      t.dataset.gp = 'rewards-slice-label';
      if (typeof v.icon === 'string' && /^(data:image\/|blob:|https?:|\.{0,2}\/)|\.(png|svg|webp|avif|gif|jpe?g)/i.test(v.icon)) {
        const im = document.createElementNS(SVG_NS, 'image');
        im.setAttribute('href', v.icon);
        im.setAttribute('x', '74');
        im.setAttribute('y', '-11');
        im.setAttribute('width', '22');
        im.setAttribute('height', '22');
        im.setAttribute('transform', `rotate(${mid})`);
        t.setAttribute('x', flip ? '-50' : '50');
        g.append(im);
      }
      g.append(t);
    });
    const rim = document.createElementNS(SVG_NS, 'circle');
    rim.setAttribute('r', String(R));
    rim.setAttribute('fill', 'none');
    rim.setAttribute('stroke', 'var(--gp-rewards-ink)');
    rim.setAttribute('stroke-width', '4');
    const hub = document.createElementNS(SVG_NS, 'circle');
    hub.setAttribute('r', '12');
    hub.setAttribute('fill', 'var(--gp-rewards-accent)');
    hub.setAttribute('stroke', 'var(--gp-rewards-ink)');
    hub.setAttribute('stroke-width', '3');
    const pointer = document.createElementNS(SVG_NS, 'path');
    pointer.setAttribute('d', 'M-11 -114L11 -114L0 -92Z');
    pointer.setAttribute('fill', 'var(--gp-rewards-accent)');
    pointer.setAttribute('stroke', 'var(--gp-rewards-ink)');
    pointer.setAttribute('stroke-width', '2.5');
    pointer.setAttribute('stroke-linejoin', 'round');
    svg.append(g, rim, hub, pointer);
    svg.setAttribute('aria-label', labels.join(', '));
    stage.append(svg);
    /** The rotation that puts slice i under the pointer (slice 0 is under it at 0°) */
    const restOn = (i: number) => -(i / n) * 360;
    const won = el('div', 'gp-rw-won');
    won.dataset.gp = 'rewards-won';
    const row = el('div', 'gp-rw-row');
    const line = el('div', 'gp-rw-line');

    const showWon = (slice: number) => {
      const v = viewNode(s.slices[slice].reward, 'wheel', 'gp-rw-icon');
      won.replaceChildren(...v.icon.childNodes, document.createTextNode(words.won(v.label)));
    };
    const settle = () => {
      const got = wheel!.collect();
      spinning = null;
      if (got) {
        showWon(got.slice);
        prize(got.reward, 'wheel');
      }
      drawHead();
      drawButtons();
    };
    const spin = (how: SpinKind) => {
      if (spinning) return;
      const r = wheel!.spin(how);
      if (!r) return drawButtons();
      won.replaceChildren();
      // Four turns and onto the slice; the prize shows when it stops (decided and saved already)
      const target = restOn(r.slice);
      const base = angle - (((angle % 360) + 360) % 360);
      angle = base + 360 * 4 + ((target % 360) + 360) % 360;
      const ms = reducedMotion() ? 0 : SPIN_MS;
      g.style.transition = ms ? `transform ${ms}ms cubic-bezier(0.15, 0.8, 0.2, 1)` : 'none';
      g.style.transform = `rotate(${angle}deg)`;
      for (const b of row.querySelectorAll('button')) b.setAttribute('aria-disabled', 'true');
      const timer = setTimeout(() => spinning?.done(), ms + 60);
      spinning = {
        done: () => {
          clearTimeout(timer);
          settle();
        },
      };
    };
    const drawButtons = () => {
      const st = wheel!.state();
      row.replaceChildren();
      if (st.canFree) row.append(btn('rewards-spin-free', words.spinFree, () => spin('free')));
      if (st.canAd) {
        const ad = adButton(opts.placements?.spin ?? 'wheel-spin', words.spinAd, () => spin('ad'));
        if (ad) row.append(ad);
      }
      if (st.price !== null) {
        const p = btn('rewards-spin-paid', '', () => spin('paid'), true);
        if (opts.currency?.icon !== undefined) p.append(iconOf(opts.currency.icon, used));
        p.append(document.createTextNode(words.spinPaid(fmt(st.price))));
        if (!st.canPaid || (opts.currency && opts.currency.amount() < st.price)) p.setAttribute('aria-disabled', 'true');
        row.append(p);
      }
      line.textContent = !st.canFree && !st.canAd && !st.pending ? words.spinTomorrow : '';
    };
    // A prize spun before a reload: the wheel stands on it, and it is paid now
    const pend = s.pending;
    angle = pend ? restOn(pend.slice) : angle;
    g.style.transform = `rotate(${angle}deg)`;
    const side = el('div', 'gp-rw-side');
    side.append(won, row, line);
    const wrap = el('div', 'gp-rw-wheelbox');
    wrap.append(stage, side);
    body.replaceChildren(wrap);
    if (pend) settle();
    else drawButtons();
  };

  // --- Offers ---------------------------------------------------------------------------------------------------
  const drawOffers = () => {
    const s = offers!.state();
    const cards: HTMLElement[] = s.offers.map((o) => {
      const c = el('div', 'gp-rw-card');
      c.dataset.gp = 'rewards-offer';
      c.dataset.gpOffer = o.id;
      c.dataset.state = o.bought ? 'taken' : o.free ? 'ready' : 'open';
      const k = el('span', 'gp-rw-tag', o.daily ? words.today : '');
      const v = viewNode(o.reward, 'offer');
      const act = el('div', 'gp-rw-act');
      if (o.bought) {
        const d = el('span', 'gp-rw-done');
        d.append(mark('check', 22));
        act.append(d);
      } else {
        const b = btn('rewards-buy', o.free ? words.free : '', () => {
          const r = offers!.buy(o.id, (price) => opts.pay?.(price) ?? false);
          if (r !== null) prize(r, 'offer', o.id);
          draw();
        }, !o.free);
        if (!o.free) {
          if (opts.currency?.icon !== undefined) b.append(iconOf(opts.currency.icon, used));
          b.append(document.createTextNode(fmt(o.price)));
          if (opts.currency && opts.currency.amount() < o.price) b.setAttribute('aria-disabled', 'true');
        }
        act.append(b);
      }
      c.append(k, v.icon, el('span', 'gp-rw-label', v.label), act);
      return c;
    });
    const extra: HTMLElement[] = [];
    if (s.ad && s.ad.left > 0) {
      const v = opts.view(s.ad.reward, 'ad');
      const ad = adButton(opts.placements?.currency ?? 'free-currency', words.adCurrency(v.label), () => {
        const r = offers!.adClaim();
        if (r !== null) prize(r, 'ad');
        draw();
      });
      if (ad) {
        const row = el('div', 'gp-rw-row');
        row.append(ad);
        extra.push(row);
      }
    }
    body.replaceChildren(grid, ...extra);
    paged(cards, 120, 136);
  };

  const draw = () => {
    bar.select(tab);
    box.dataset.tab = tab;
    drawHead();
    if (tab === 'gifts') drawGifts();
    else if (tab === 'wheel') drawWheel();
    else drawOffers();
  };
  // The countdowns and the boost's time once a second (the gifts' time moves while the game plays under it)
  let last = '';
  const ticker = setInterval(() => {
    if (spinning) return;
    const key = `${gifts ? JSON.stringify(gifts.state().gifts.map((g) => [g.state, Math.ceil(g.inSec)])) : ''}|${boost ? Math.ceil(boost.left) : ''}`;
    if (key === last) return;
    last = key;
    if (tab === 'gifts') drawGifts();
    drawHead();
  }, 1000);
  const onResize = () => {
    if (!spinning) draw();
  };
  addEventListener('resize', onResize);
  draw();
  host.screen('rewards');
  return { el: box, close: () => m.close(), refresh: draw };
}
