# __TITLE__

A game for CrazyGames (13+) on [game_platform](https://github.com/QmaCyber/game_platform) (`kit: code`), created with `gp init`.

```sh
scripts/setup.sh                 # the platform next to this repository (or GP_PLATFORM=…), remembered; node_modules linked
scripts/gp.sh validate           # the rules: concept, listing, channel
scripts/gp.sh dev                # play it in the browser (test ads; ?seed=1; ?ads=fail plays Basic Launch)
scripts/gp.sh qa                 # the platform's QA (≈ 5 min; --quick while iterating); it also checks the twist
scripts/gp.sh uniqueness         # how unique the game is (0–100) and what to change — after every big change
scripts/gp.sh balance            # the progression curve from bot.ts balance() against the portal's targets
scripts/gp.sh review             # after the full QA: the quality brief for a second agent (games/__ID__/qa/review-brief.md);
                                 # it writes games/__ID__/quality.md — fix every [blocking] finding (review --check)
scripts/gp.sh submission         # everything the portal form asks for, checked: games/__ID__/submission/
                                 # (it runs build --target crazygames, covers and video itself)
scripts/gp.sh explain money     # platform commands without a game: explain, catalog, doctor, forecast --idea
                                 # several games in games/? name one: scripts/gp.sh qa <id> --quick
./node_modules/.bin/vitest run games/     # the game's own tests and balance bot
./node_modules/.bin/tsc -p tsconfig.json  # types
```

| File | What it is |
|---|---|
| `games/__ID__/game.yaml` | the game for the platform: channel, audience, concept, listing |
| `games/__ID__/main.ts` | screens and the host (start here) |
| `games/__ID__/sim.ts` | the rules as pure logic — tests and the bot play it |
| `games/__ID__/art.ts` (the Canvas skeleton) | the look, drawn with the platform's `@gp/art`: a parallax dusk, a lit target that idles, a light, effects and a shake on every tap (PLACEHOLDER art: keep the approach, the platform's docs/guides/art.md). A skeleton made with `--engine` or `--physics` has no art.ts: it draws in view.ts |
| `games/__ID__/data.ts` | every balance number, and the progression's data |
| `games/__ID__/bot.ts`, `sim.test.ts` | the balance bot (its `balance()` report is what `gp balance` and `gp qa` check) and the game's tests |
| `games/__ID__/video.mjs` | what the preview video shows |
| `games/__ID__/package.json` (optional) | the game's own npm dependencies (an engine): `scripts/setup.sh` installs them into `games/__ID__/node_modules`, never at the root (its node_modules is the platform's) |
| `games/__ID__/view.ts` (with `gp init --engine pixi\|phaser\|three`) | the drawing through the engine's adapter (`@gp/core/engines/<name>`); game.yaml `engine` pins the version, the same as in package.json (the platform's code-games.md → Engines) |
| `games/__ID__/sim.ts` on Rapier (with `gp init --physics`) | the rules on a physics world through the physics block (`@gp/physics`): a fresh world at every run, one world step per sim step, the same physics in the bot; game.yaml `engine.physics` pins Rapier's version, the same as in package.json, and `budget` raises the portal's size budget on purpose (the platform's code-games.md → Physics) |
| `docs/concept.md` | the originality check, written before building |
| `games/__ID__/quality.md` | the quality review by a second agent (`scripts/gp.sh review`): `gp submission` refuses a `[blocking]` finding |
| `games/__ID__/REPORT.md` | the report for the platform team |
