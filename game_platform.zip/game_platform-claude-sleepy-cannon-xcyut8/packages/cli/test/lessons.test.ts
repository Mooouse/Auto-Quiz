// The lessons from the people who judged our games: well-formed, and in the review brief

import { describe, expect, it } from 'vitest';
import { LESSONS, lessonsMarkdown, lessonsSection } from '../src/lessons.ts';

describe('lessons', () => {
  it('each has an id of its own, a flaw, how to see it, a fix and at least one remark with its source', () => {
    expect(new Set(LESSONS.map((l) => l.id)).size).toBe(LESSONS.length);
    for (const l of LESSONS) {
      expect(l.flaw && l.look && l.fix, l.id).toBeTruthy();
      expect(l.sources.length, l.id).toBeGreaterThan(0);
      for (const x of l.sources) expect(x.game && x.who && /^\d{4}-\d{2}-\d{2}$/.test(x.date) && x.text, `${l.id}: ${x.text}`).toBeTruthy();
    }
  });
  it('the brief section is a table row per lesson; gp lessons quotes the remarks', () => {
    const sec = lessonsSection().join('\n');
    expect(sec.split('\n').filter((r) => /^\| \d+ \|/.test(r))).toHaveLength(LESSONS.length);
    expect(lessonsMarkdown()).toContain('«Сделай анимацию и разнообразь ближнее оружие (на следующее обновление)»');
  });
  it('the 2026-10-10 lessons: the start sound, dominant strategies, visible phone controls, the first visit, results that continue, a visible daily, drawn icons', () => {
    const ids = LESSONS.map((l) => l.id);
    for (const id of ['start-sound', 'dominant-strategy', 'mobile-controls-visible', 'first-visit-gameplay', 'results-continue', 'daily-visible', 'drawn-icons']) expect(ids, id).toContain(id);
    const md = lessonsMarkdown();
    expect(md).toContain('Убрать оглушайющий звук кипения при старте');
    expect(md).toContain('В Kate Royal можно просто низко лететь и выигрывать');
    expect(md).toContain('The fight still plays itself.');
    expect(md).toContain('На телефоне добавить внешний вид стика управления сейчас его вообще нет.');
    expect(md).toContain('a maximum of 1 click is allowed');
    expect(md).toContain('бесконечный режим он никак не усложняется');
    expect(md).toContain('Сделать  10 актов в каждом по 30 уровней.');
    expect(md).toContain('Везде где используются эмодзи замени их на нарисованные иконки в стиле игры.');
    // Candle Crypt's 16 remarks of 2026-10-10, each in a lesson
    const candle = LESSONS.flatMap((l) => l.sources).filter((x) => x.game === 'Candle Crypt' && x.date === '2026-10-10' && x.who === 'Свин');
    expect(new Set(candle.map((x) => x.text)).size).toBe(15);
  });
  it('the 2026-10-18 lessons (Frankengun, the first 3D game): themed platform screens, side systems later, the cover hero; and the lessons it extends', () => {
    const ids = LESSONS.map((l) => l.id);
    for (const id of ['themed-platform-screens', 'side-systems-later', 'cover-hero']) expect(ids, id).toContain(id);
    const md = lessonsMarkdown();
    expect(md).toContain('I was DOWN after about 35 s of wave 1');
    expect(md).toContain('the same six upgrades keep dropping');
    expect(md).toContain('a win in 24/120 runs (4 of 20)');
    expect(md).toContain('so at this aspect you see only about 43° across');
    // Each Frankengun remark extends a lesson that was there, or starts one of the three new ones
    const by = (id: string) => LESSONS.find((l) => l.id === id)!.sources.filter((x) => x.game === 'Frankengun').length;
    for (const id of ['variety', 'balance', 'ui-layout', 'first-minute', 'drawn-icons', 'cover-hero']) expect(by(id), id).toBe(1);
    for (const id of ['themed-platform-screens', 'side-systems-later']) expect(by(id), id).toBe(2);
  });
});
