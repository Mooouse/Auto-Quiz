// The resolved game, produced from games/<id>/game.yaml by the gp Vite plugin (packages/cli/src/vite-plugin.ts)
declare module 'virtual:gp/game' {
  import type { ResolvedGame } from '@gp/spec';
  const game: ResolvedGame;
  export default game;
}

// kit: code — the game's own module (game.yaml `entry`); null for the other kits
declare module 'virtual:gp/entry' {
  import type { StartGame } from '@gp/core';
  const start: StartGame | null;
  export default start;
}

// The game's texts per language (games/<id>/strings/<code>.yaml, flattened; only its declared languages)
declare module 'virtual:gp/strings' {
  import type { Strings } from '@gp/core';
  const strings: Strings;
  export default strings;
}

// Set by the gp Vite plugin: the game's kit ("kids", "casual", "code")
interface ImportMetaEnv {
  readonly GP_KIT: string;
  /** The channel's platform ("android", "web"): a web build has no native plugins (src/web-native.ts) */
  readonly GP_PLATFORM: string;
}
