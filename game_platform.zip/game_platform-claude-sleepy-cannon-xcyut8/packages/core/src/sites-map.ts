// The map screen of an idle game's sites (Sites, sites.ts): the game paints each view's background itself (a world map,
// a solar system, a town — `draw(ctx, w, h, t)`), the platform gives the generic parts: a pin per site at a point of
// the view (0..1), open / locked with the level, the income and the price from Sites; pan, pinch and wheel zoom; a
// switch between views with a cross-fade when there is more than one; a tap on an open pin enters it, a tap on a closed
// one opens a card with its price and the Open button. One screen (no page or panel scrolls — gp qa's one-screen check),
// touch and mouse, every target ≥ minTouchPx, texts in the player's language (gp.sites.*).
//
//   mountSitesMap(ui, sites, {
//     views: [{ id: 'town', draw: (g, w, h, t) => drawTown(g, w, h, t), pins: { bakery: { x: 0.3, y: 0.6 }, … } }],
//     items: { bakery: { name: host.t('bakery'), icon: '🥐' }, … },
//     minTouchPx: host.minTouchPx, i18n: host.i18n,
//     onEnter: (id) => showSite(id), onBack: showTitle,
//   });
//
// Pins are DOM buttons over the canvas (gp qa sees them): a pin whose point is on the map shows with its head pulled
// inside the edge (never cut), one whose point is off it hides; captions never cover each other or a head
// (layoutMapPins: below, above, right or left of the head, else hidden until the pin is selected).
// Themeable: screenTheme() for every platform screen at once, or --gp-sites-bg, -ink, -muted, -panel, -accent,
// -accent-ink, -open, -here, -locked, -font on #gp-sites. The platform's marks (the coin, the lock, zoom, close) are
// drawn (@gp/core/icons); a site's icon is a drawn element, an image URL or text.
//
// From Idle Garage Evolution 1.4 (QmaCyber/game19, map.ts: the Earth and the Solar System, each pin a garage).
// @genre idle

import { FONT_FALLBACK, type I18n } from './i18n.ts';
import { icon as drawn } from './icons.ts';
import { DEFAULT_CURRENCY, screenIcon } from './screen-icon.ts';
import { iconNode, type ShopIcon } from './shop-ui.ts';
import type { SiteRow, Sites } from './sites.ts';
import { formatAmount } from './upgrades.ts';

// --- The camera (pure: Node tests it) ---------------------------------------------------------------------------

/** A point of a view: 0..1 across its width and down its height */
export interface MapPoint {
  x: number;
  y: number;
}

export interface MapCameraOptions {
  /** The view's width ÷ height (default: the stage's own, so the view fills it at zoom 1) */
  aspect?: number;
  /** Zoom 1 shows the whole view; the range the player may zoom in (default 1..4) */
  minZoom?: number;
  maxZoom?: number;
  /** CSS px of room around the view at zoom 1, so pins at its edges still fit with their labels (default 32) */
  pad?: number;
}

/** What the game's draw() gets besides the size: the zoom, the part of the view on screen (view px) and the pixel ratio */
export interface MapCameraInfo {
  zoom: number;
  visible: { x: number; y: number; w: number; h: number };
  dpr: number;
}

/**
 * The map's camera: the view's point at the stage centre (`x`, `y`, 0..1) and the zoom. At zoom 1 the whole view fits
 * the stage less its padding (contain, at the view's aspect); the view never leaves the stage (an axis that fits is
 * centred). Screen coordinates are the stage's CSS px.
 */
export class MapCamera {
  x = 0.5;
  y = 0.5;
  zoom = 1;
  /** The stage in CSS px */
  w = 1;
  h = 1;
  readonly minZoom: number;
  readonly maxZoom: number;
  readonly pad: number;
  readonly aspect: number | undefined;

  constructor(opts: MapCameraOptions = {}) {
    this.minZoom = Math.max(0.1, opts.minZoom ?? 1);
    this.maxZoom = Math.max(this.minZoom, opts.maxZoom ?? 4);
    this.pad = Math.max(0, opts.pad ?? 32);
    this.aspect = opts.aspect && opts.aspect > 0 ? opts.aspect : undefined;
    this.zoom = this.minZoom;
  }

  resize(w: number, h: number): void {
    this.w = Math.max(1, w);
    this.h = Math.max(1, h);
    this.clamp();
  }

  /** The view's size in CSS px at zoom 1 */
  base(): { w: number; h: number } {
    const aw = Math.max(1, this.w - 2 * this.pad);
    const ah = Math.max(1, this.h - 2 * this.pad);
    if (!this.aspect) return { w: aw, h: ah };
    return aw / ah > this.aspect ? { w: ah * this.aspect, h: ah } : { w: aw, h: aw / this.aspect };
  }

  /** A point of the view (0..1) on the stage */
  toScreen(p: MapPoint): [number, number] {
    const b = this.base();
    return [this.w / 2 + (p.x - this.x) * b.w * this.zoom, this.h / 2 + (p.y - this.y) * b.h * this.zoom];
  }

  /** A stage point as a point of the view (0..1) */
  toView(sx: number, sy: number): MapPoint {
    const b = this.base();
    return { x: this.x + (sx - this.w / 2) / (b.w * this.zoom), y: this.y + (sy - this.h / 2) / (b.h * this.zoom) };
  }

  /** Move the view by a drag of dx, dy stage px */
  pan(dx: number, dy: number): void {
    const b = this.base();
    this.x -= dx / (b.w * this.zoom);
    this.y -= dy / (b.h * this.zoom);
    this.clamp();
  }

  /** Zoom by `f` about a stage point (it stays under the finger or the cursor) */
  zoomAt(f: number, sx = this.w / 2, sy = this.h / 2): void {
    if (!(f > 0) || !Number.isFinite(f)) return;
    const p = this.toView(sx, sy);
    this.zoom = Math.max(this.minZoom, Math.min(this.maxZoom, this.zoom * f));
    const b = this.base();
    this.x = p.x - (sx - this.w / 2) / (b.w * this.zoom);
    this.y = p.y - (sy - this.h / 2) / (b.h * this.zoom);
    this.clamp();
  }

  /** Centre on a point of the view, optionally at a zoom */
  center(p: MapPoint, zoom = this.zoom): void {
    this.zoom = Math.max(this.minZoom, Math.min(this.maxZoom, zoom));
    this.x = p.x;
    this.y = p.y;
    this.clamp();
  }

  /** Keep the view on the stage: an axis that fits is centred, a bigger one can't leave a gap past the padding */
  clamp(): void {
    if (!Number.isFinite(this.zoom)) this.zoom = this.minZoom;
    this.zoom = Math.max(this.minZoom, Math.min(this.maxZoom, this.zoom));
    const b = this.base();
    const axis = (c: number, size: number, stage: number) => {
      const vw = size * this.zoom;
      if (vw <= stage - 2 * this.pad + 0.5) return 0.5;
      const half = (stage / 2 - this.pad) / vw;
      return Math.max(half, Math.min(1 - half, Number.isFinite(c) ? c : 0.5));
    };
    this.x = axis(this.x, b.w, this.w);
    this.y = axis(this.y, b.h, this.h);
  }

  /** The canvas transform from view px (0..base) to stage CSS px: [a, b, c, d, e, f] */
  transform(): [number, number, number, number, number, number] {
    const b = this.base();
    return [this.zoom, 0, 0, this.zoom, this.w / 2 - this.x * b.w * this.zoom, this.h / 2 - this.y * b.h * this.zoom];
  }

  /** The part of the view on the stage, in view px (it may reach past 0..base: paint the surroundings there too) */
  visible(): { x: number; y: number; w: number; h: number } {
    const [z, , , , e, f] = this.transform();
    return { x: -e / z, y: -f / z, w: this.w / z, h: this.h / z };
  }
}

// --- Placing the pins and their captions (pure: Node tests it) ---------------------------------------------------

/** A pin on the stage: its point (CSS px), its caption's size (0: none), its rank and its caption's place last time */
export interface MapPinBox {
  x: number;
  y: number;
  cw: number;
  ch: number;
  /** Higher first: the selected pin, the player's site, open sites, the next one, the rest */
  prio: number;
  /** The slot its caption took last frame (-1: none) */
  last?: number;
}

/** Where a pin's head goes (its top-left, or null: hidden) and its caption (or null: no room, hidden) */
export interface MapPinPlace {
  head: [number, number] | null;
  cap: [number, number] | null;
  slot: number;
}

/** The room kept between a pin's head and the stage's edge, CSS px */
export const MAP_PIN_EDGE = 4;

/**
 * Heads and captions of a view's pins, so none is cut and no caption covers another or a head (Idle Garage 1.3's map:
 * "Le Mans" on "Monaco", Mumbai's label over Dubai's, the São Paulo pin cut at the left edge). A pin whose point is on
 * the stage shows, its head pulled inside by MAP_PIN_EDGE px; a point off the stage hides it. Captions go in rank order
 * to the first free place of: below, above, right, left (each slid along the edge to stay on the stage) — the place it
 * had last frame first, so moving pins don't flicker. A caption with no free place is hidden, except the selected pin's
 * and the player's site's (they take the first place that stays on the stage).
 */
export function layoutMapPins(pins: readonly MapPinBox[], W: number, H: number, head: number, edge = MAP_PIN_EDGE): MapPinPlace[] {
  type R = [number, number, number, number];
  const hit = (a: R, b: R) => a[0] < b[0] + b[2] && b[0] < a[0] + a[2] && a[1] < b[1] + b[3] && b[1] < a[1] + a[3];
  const lo = edge;
  const out: MapPinPlace[] = pins.map((p) => {
    if (!(p.x >= 0 && p.x <= W && p.y >= 0 && p.y <= H)) return { head: null, cap: null, slot: -1 };
    const left = Math.round(Math.max(lo, Math.min(W - edge - head, p.x - head / 2)));
    const top = Math.round(Math.max(lo, Math.min(H - edge - head, p.y - head / 2)));
    return { head: [left, top], cap: null, slot: -1 };
  });
  // Every head is taken from the start (a caption never covers a pin), then each placed caption
  const taken: { r: R; of: number }[] = out.flatMap((o, i) => (o.head ? [{ r: [o.head[0], o.head[1], head, head] as R, of: i }] : []));
  const ranked = pins.map((_, i) => i).filter((i) => out[i].head && pins[i].cw > 0).sort((a, b) => pins[b].prio - pins[a].prio || a - b);
  const gap = 3;
  for (const i of ranked) {
    const p = pins[i];
    const [hx, hy] = out[i].head!;
    const own: R = [hx, hy, head, head];
    const slide = (x: number, y: number): R => [Math.round(Math.max(edge, Math.min(W - edge - p.cw, x))), Math.round(Math.max(edge, Math.min(H - edge - p.ch, y))), p.cw, p.ch];
    const slots = [
      slide(hx + (head - p.cw) / 2, hy + head + gap),
      slide(hx + (head - p.cw) / 2, hy - gap - p.ch),
      slide(hx + head + gap, hy + (head - p.ch) / 2),
      slide(hx - gap - p.cw, hy + (head - p.ch) / 2),
    ];
    const tryOrder = p.last !== undefined && p.last >= 0 && p.last < 4 ? [p.last, ...[0, 1, 2, 3].filter((k) => k !== p.last)] : [0, 1, 2, 3];
    // Not on its own head (slid there in a corner) nor on anything placed before it
    const onStage = (k: number) => !hit(slots[k], own);
    const free = (k: number) => onStage(k) && !taken.some((t) => t.of !== i && hit(slots[k], t.r));
    let k = tryOrder.find(free);
    if (k === undefined && p.prio >= 4) k = tryOrder.find(onStage) ?? 0;
    if (k === undefined) continue;
    out[i].cap = [slots[k][0], slots[k][1]];
    out[i].slot = k;
    taken.push({ r: slots[k], of: i });
  }
  return out;
}

// --- The screen -------------------------------------------------------------------------------------------------

/** One view of the map: the game paints it, the platform puts the pins on it */
export interface SitesMapView<S extends string = string> {
  id: string;
  /** Its tab in the switcher (shown when there is more than one view) */
  label?: string;
  icon?: ShopIcon;
  /**
   * Paint the view: the context is transformed so (0, 0)–(w, h) is the whole view (CSS px at zoom 1); `t` is seconds
   * since the map opened (animate with it: orbits, clouds); `cam.visible` is the part on screen — paint the surroundings
   * there (the sea past the coast) if the view doesn't fill the stage. Called every frame while the view shows
   */
  draw(ctx: CanvasRenderingContext2D, w: number, h: number, t: number, cam: MapCameraInfo): void;
  /** Where each site's pin is (0..1 of the view); a function for pins that move (a planet on its orbit) */
  pins: Partial<Record<S, MapPoint>> | ((t: number) => Partial<Record<S, MapPoint>>);
  /** Width ÷ height of the view (default: the stage's) */
  aspect?: number;
  minZoom?: number;
  maxZoom?: number;
  pad?: number;
  /** The colour around the view (default the screen's background) */
  background?: string;
  /** The camera when the view first shows */
  start?: { x?: number; y?: number; zoom?: number };
}

export interface SitesMapItem {
  name: string;
  /** In the pin's head: an emoji, an image URL or an element (default: the level, or a lock) */
  icon?: ShopIcon;
  /** One more short thing on an open pin ("🤖 3": its workers) */
  badge?: () => string | null;
}

export interface SitesMapTexts {
  title: string;
  back: string;
  /** The button that buys a closed site: "Open" */
  open: string;
  /** "Need 🪙 980" */
  need: string;
  /** "🔒 Needs Tokyo" */
  needs: string;
  locked: string;
  here: string;
  zoomIn: string;
  zoomOut: string;
  /** "Lv 3" on an open pin */
  level: (n: number) => string;
  /** "+1.2K/s" */
  rate: (amount: string) => string;
}

export const SITES_MAP_TEXTS_EN: SitesMapTexts = {
  title: 'Map',
  back: 'Back',
  open: 'Open',
  need: 'Need',
  needs: 'Needs',
  locked: 'Locked',
  here: 'You are here',
  zoomIn: 'Zoom in',
  zoomOut: 'Zoom out',
  level: (n) => `Lv ${n}`,
  rate: (a) => `+${a}/s`,
};

/** The map's words in the player's language (the platform's gp.sites.* texts) */
export function sitesMapTexts(i18n: I18n): SitesMapTexts {
  const t = (k: string, p?: Record<string, number | string>) => i18n.t(k, p);
  return {
    title: t('gp.sites.title'),
    back: t('gp.back'),
    open: t('gp.sites.open'),
    need: t('gp.shop.need'),
    needs: t('gp.shop.needs'),
    locked: t('gp.sites.locked'),
    here: t('gp.sites.here'),
    zoomIn: t('gp.sites.zoomIn'),
    zoomOut: t('gp.sites.zoomOut'),
    level: (n) => t('gp.sites.level', { n }),
    rate: (amount) => t('gp.sites.rate', { amount }),
  };
}

export interface SitesMapOptions<S extends string> {
  /** One view or more (most games have one: a town; Idle Garage has the Earth and the Solar System) */
  views: readonly SitesMapView<S>[];
  /** Each site's name (translated) and icon */
  items: Record<S, SitesMapItem>;
  /** The audience's smallest touch target (host.minTouchPx) */
  minTouchPx: number;
  /** An open pin was tapped: the map has moved the player there (sites.travel); show its scene */
  onEnter(id: S): void;
  /** A site was bought on the map (sites.unlock went through): default — enter it */
  onUnlock?(id: S): void;
  /** The player tried to buy a site they can't afford (a "no" sound) */
  onDenied?(id: S): void;
  /** The Back button (none without it) */
  onBack?(): void;
  /** The view changed (by its tab or focus()) */
  onView?(id: string): void;
  /** The view to show first (default the first one; or the one with the player's site, `focus`) */
  view?: string;
  /** Centre the first view on the player's site (default true) */
  focusHere?: boolean;
  /** The currency: its icon (default the platform's drawn coin; a drawn icon, a URL or text) and its name for screen readers */
  currency?: { icon: ShopIcon; name: string };
  /** host.i18n: the map's words in the player's language (default English) */
  i18n?: I18n;
  /** Your own words for any of the map's (they win over `i18n`) */
  texts?: Partial<SitesMapTexts>;
  /** How amounts read (default formatAmount: prices rounded up, the balance and income down) */
  format?: (n: number, round: 'down' | 'up') => string;
}

export interface SitesMap {
  /** Re-read Sites now (it also does so four times a second by itself) */
  refresh(): void;
  /** Show a view (cross-fade) */
  setView(id: string, instant?: boolean): void;
  /** Show the view with this site's pin and centre on it */
  focus(id: string, zoom?: number): void;
  readonly view: string;
  readonly camera: MapCamera;
  destroy(): void;
}

const FADE_MS = 380;
const SLOP = 7;

const CSS = `
:where(#gp-sites) { --gp-sites-bg: var(--gp-theme-bg, #0d1626); --gp-sites-ink: var(--gp-theme-ink, #f2f7ff); --gp-sites-muted: var(--gp-theme-muted, #a9b9cc);
  --gp-sites-panel: var(--gp-theme-panel, rgba(12, 18, 32, 0.86)); --gp-sites-accent: var(--gp-theme-accent, #ffd166);
  --gp-sites-accent-ink: var(--gp-theme-accent-ink, #18222e); --gp-sites-open: var(--gp-theme-accent, #ffd166); --gp-sites-here: var(--gp-theme-accent2, #7fe0ff);
  --gp-sites-locked: #7c8594; --gp-sites-font: var(--gp-theme-font, ${FONT_FALLBACK}); }
#gp-sites { position: fixed; inset: 0; z-index: 30; display: flex; flex-direction: column; background: var(--gp-sites-bg); color: var(--gp-sites-ink);
  font: 600 15px var(--gp-sites-font); font-variant-numeric: tabular-nums; pointer-events: auto; user-select: none; -webkit-user-select: none; overflow: hidden; }
#gp-sites .gp-sites-bal, #gp-sites .gp-pin-line, #gp-sites .gp-c-line, #gp-sites .gp-c-go { display: flex; align-items: center; gap: 0.25em; }
#gp-sites .gp-sites-bal { justify-content: flex-end; }
#gp-sites .gp-pin-line { justify-content: center; }
#gp-sites .gp-c-go { justify-content: center; }
#gp-sites .gp-sites-zoom button, #gp-sites .gp-c-x { display: flex; align-items: center; justify-content: center; }
#gp-sites img.gp-cur { width: 1.15em; height: 1.15em; object-fit: contain; }
#gp-sites .gp-pin-lock { width: 20px; height: 20px; border-radius: 50%; background: #ffffff; box-shadow: 0 1px 4px rgba(0, 0, 0, 0.45);
  display: flex; align-items: center; justify-content: center; }
#gp-sites .gp-pin-lock svg { width: 13px; height: 13px; color: #18222e; }
#gp-sites button { font: inherit; border: 0; cursor: pointer; touch-action: manipulation; min-width: 0; margin: 0; padding: 0 12px;
  box-shadow: none; text-transform: none; letter-spacing: normal; background: var(--gp-sites-panel); color: var(--gp-sites-ink); border-radius: 999px; }
#gp-sites > header { flex: none; display: flex; align-items: center; gap: 10px; padding: 6px 10px; }
#gp-sites h2 { margin: 0; font-size: 20px; flex: 1; min-width: 0; overflow-wrap: anywhere; font-family: var(--gp-theme-display, inherit); }
#gp-sites .gp-sites-wallet { text-align: right; line-height: 1.2; }
#gp-sites .gp-sites-bal { font-size: 19px; font-weight: 800; white-space: nowrap; }
#gp-sites .gp-sites-rate { font-size: 13px; color: var(--gp-sites-muted); white-space: nowrap; }
#gp-sites .gp-sites-stage { position: relative; flex: 1; min-height: 0; overflow: hidden; touch-action: none; cursor: grab; }
#gp-sites .gp-sites-stage.gp-drag { cursor: grabbing; }
#gp-sites canvas { position: absolute; inset: 0; width: 100%; height: 100%; display: block; }
#gp-sites .gp-pins { position: absolute; inset: 0; z-index: 1; pointer-events: none; transition: opacity ${FADE_MS}ms ease; }
#gp-sites .gp-pin { position: absolute; left: 0; top: 0; padding: 0; background: transparent; border-radius: 50%; display: block;
  pointer-events: auto; touch-action: none; will-change: transform; }
#gp-sites .gp-pin-head { position: relative; box-sizing: border-box; border-radius: 50%; display: flex; align-items: center; justify-content: center;
  background: var(--gp-sites-locked); color: #18222e; border: 3px solid #1b1f2a; font-weight: 900; font-size: 18px; box-shadow: 0 3px 8px rgba(0, 0, 0, 0.35); }
#gp-sites .gp-pin-head > img, #gp-sites .gp-pin-head > svg, #gp-sites .gp-pin-head > canvas { width: 70%; height: 70%; object-fit: contain; }
#gp-sites .gp-pin[data-state=open] .gp-pin-head { background: var(--gp-sites-open); }
#gp-sites .gp-pin[data-state=affordable] .gp-pin-head { background: #ffffff; }
#gp-sites .gp-pin[data-state=too-expensive] .gp-pin-head { background: #c9d2de; }
#gp-sites .gp-pin.gp-here .gp-pin-head { background: var(--gp-sites-here); }
#gp-sites .gp-pin.gp-here .gp-pin-head::after { content: ''; position: absolute; inset: -9px; border-radius: 50%; border: 3px solid var(--gp-sites-here); opacity: 0.7; }
#gp-sites .gp-pin.gp-sel .gp-pin-head { outline: 3px solid var(--gp-sites-accent); outline-offset: 3px; }
#gp-sites .gp-pin-lock { position: absolute; right: -6px; bottom: -6px; font-size: 14px; line-height: 1; }
#gp-sites .gp-pin-cap { position: absolute; left: 0; top: 0; pointer-events: auto; cursor: pointer; will-change: transform; background: var(--gp-sites-panel); border-radius: 9px; padding: 2px 8px 3px; text-align: center;
  white-space: nowrap; line-height: 1.25; }
#gp-sites .gp-pin-name { font-size: 13px; font-weight: 800; color: var(--gp-sites-ink); }
#gp-sites .gp-pin-line { font-size: 12px; color: var(--gp-sites-accent); }
#gp-sites .gp-pin[data-state=too-expensive] .gp-pin-line { color: var(--gp-sites-muted); }
#gp-sites .gp-sites-zoom { position: absolute; z-index: 2; right: 10px; bottom: 10px; display: flex; flex-direction: column; gap: 8px; }
#gp-sites .gp-sites-zoom button { padding: 0; font-size: 24px; font-weight: 800; }
#gp-sites .gp-sites-card { position: absolute; z-index: 2; left: 10px; bottom: 10px; box-sizing: border-box; max-width: min(360px, calc(100% - 20px));
  display: grid; grid-template-columns: auto 1fr auto; align-items: center; gap: 4px 10px; padding: 10px 12px; border-radius: 16px;
  background: var(--gp-sites-panel); }
#gp-sites .gp-sites-card .gp-c-icon { grid-row: 1 / 3; font-size: 28px; }
#gp-sites .gp-sites-card .gp-c-icon > img, #gp-sites .gp-sites-card .gp-c-icon > svg, #gp-sites .gp-sites-card .gp-c-icon > canvas { width: 36px; height: 36px; object-fit: contain; }
#gp-sites .gp-sites-card .gp-c-name { font-weight: 800; font-size: 17px; }
#gp-sites .gp-sites-card .gp-c-line { grid-column: 2; font-size: 13px; color: var(--gp-sites-muted); }
#gp-sites .gp-sites-card .gp-c-x { grid-column: 3; grid-row: 1; padding: 0; background: transparent; font-size: 22px; color: var(--gp-sites-muted); }
#gp-sites .gp-sites-card .gp-c-go { grid-column: 1 / 4; background: var(--gp-sites-accent); color: var(--gp-sites-accent-ink); font-weight: 800; font-size: 17px; }
#gp-sites .gp-sites-card .gp-c-go[aria-disabled=true] { background: var(--gp-sites-locked); color: var(--gp-sites-ink); }
#gp-sites > footer { flex: none; display: flex; justify-content: center; gap: 8px; padding: 6px 10px; }
#gp-sites > footer button[aria-pressed=true] { background: var(--gp-sites-accent); color: var(--gp-sites-accent-ink); font-weight: 800; }
#gp-sites .gp-back { background: var(--gp-sites-ink); color: var(--gp-sites-bg); padding: 0 16px; }
#gp-sites [hidden] { display: none !important; }
@media (prefers-reduced-motion: no-preference) {
  #gp-sites .gp-pin.gp-here .gp-pin-head::after { animation: gp-sites-pulse 1.6s ease-out infinite; }
  #gp-sites .gp-deny { animation: gp-sites-deny 0.3s ease-in-out; }
}
@keyframes gp-sites-pulse { 0% { transform: scale(0.85); opacity: 0.8; } 100% { transform: scale(1.25); opacity: 0; } }
@keyframes gp-sites-deny { 20%, 60% { transform: translateX(-5px); } 40%, 80% { transform: translateX(5px); } }
/* A phone on its side: a slimmer header and footer, so the map keeps its height */
@media (max-height: 420px) {
  #gp-sites > header, #gp-sites > footer { padding: 3px 10px; }
  #gp-sites h2 { font-size: 17px; }
}
`;

function el<K extends keyof HTMLElementTagNameMap>(tag: K, cls?: string, text?: string): HTMLElementTagNameMap[K] {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text !== undefined) e.textContent = text;
  return e;
}

/** An icon's node; an element already on screen (the same site's pin in another view, the card) gets a copy */
const iconCopy = (icon: ShopIcon): Node => screenIcon(icon);

/** A line of words with drawn icons in it: the lock, the coin */
function iconLine(e: HTMLElement, ...parts: (Node | string)[]): HTMLElement {
  e.replaceChildren(...parts);
  return e;
}

const ease = (k: number) => (k <= 0 ? 0 : k >= 1 ? 1 : k * k * (3 - 2 * k));

interface Pin {
  el: HTMLButtonElement;
  head: HTMLElement;
  cap: HTMLElement;
  sig: string;
  /** The caption's size (measured when it changes) and where it sits now */
  cw: number;
  ch: number;
  cx: number;
  cy: number;
  /** The caption's place last frame (layoutMapPins keeps it while it stays free: no flicker) */
  slot: number;
}

interface ViewState<S extends string> {
  def: SitesMapView<S>;
  cam: MapCamera;
  layer: HTMLElement;
  pins: Map<S, Pin>;
  started: boolean;
}

/**
 * Mount the map of `sites` into `root` (it replaces root's children): returns refresh(), setView(), focus(), destroy().
 * @genre idle
 */
export function mountSitesMap<S extends string, U extends string, D>(root: HTMLElement, sites: Sites<S, U, D>, opts: SitesMapOptions<S>): SitesMap {
  if (!opts.views.length) throw new Error('mountSitesMap: at least one view');
  const ids = new Set<string>();
  for (const v of opts.views) {
    if (ids.has(v.id)) throw new Error(`mountSitesMap: view ${v.id} is defined twice`);
    ids.add(v.id);
  }
  const words = opts.i18n ? sitesMapTexts(opts.i18n) : SITES_MAP_TEXTS_EN;
  const t: SitesMapTexts = { ...words, ...opts.texts };
  const cur: { icon: ShopIcon; name: string } = opts.currency ?? { icon: DEFAULT_CURRENCY, name: opts.i18n ? opts.i18n.t('gp.shop.coins') : 'coins' };
  const coin = () => screenIcon(cur.icon);
  const lock = () => drawn('lock', { className: 'gp-mark', stroke: 2.2 });
  const fmt = opts.format ?? ((n: number, r: 'down' | 'up') => formatAmount(n, r));
  const min = opts.minTouchPx;
  const minPx = `${min}px`;

  if (!document.getElementById('gp-sites-css')) {
    const style = el('style');
    style.id = 'gp-sites-css';
    style.textContent = CSS;
    document.head.append(style);
  }
  const box = el('section');
  box.id = 'gp-sites';
  box.dataset.gp = 'sites-map';
  box.setAttribute('aria-label', t.title);
  const header = el('header');
  const back = el('button', 'gp-back', t.back);
  back.dataset.gp = 'sites-back';
  back.style.minHeight = minPx;
  back.hidden = !opts.onBack;
  const title = el('h2', undefined, t.title);
  const wallet = el('div', 'gp-sites-wallet');
  const bal = el('div', 'gp-sites-bal');
  bal.dataset.gp = 'sites-balance';
  bal.setAttribute('aria-live', 'polite');
  const rate = el('div', 'gp-sites-rate');
  rate.dataset.gp = 'sites-rate';
  wallet.append(bal, rate);
  header.append(back, title, wallet);
  const stage = el('div', 'gp-sites-stage');
  stage.dataset.gp = 'sites-stage';
  const canvas = el('canvas');
  canvas.setAttribute('aria-hidden', 'true');
  stage.append(canvas);
  const zoom = el('div', 'gp-sites-zoom');
  const zin = el('button');
  zin.append(drawn('plus', { size: 24, stroke: 2.6 }));
  zin.dataset.gp = 'sites-zoom-in';
  zin.setAttribute('aria-label', t.zoomIn);
  const zout = el('button');
  zout.append(drawn('minus', { size: 24, stroke: 2.6 }));
  zout.dataset.gp = 'sites-zoom-out';
  zout.setAttribute('aria-label', t.zoomOut);
  for (const b of [zin, zout]) b.style.width = b.style.height = minPx;
  zoom.append(zin, zout);
  // The card of a closed site: its name, its price or lock, the Open button
  const card = el('div', 'gp-sites-card');
  card.dataset.gp = 'sites-card';
  card.hidden = true;
  const cIcon = el('div', 'gp-c-icon');
  cIcon.setAttribute('aria-hidden', 'true');
  const cName = el('div', 'gp-c-name');
  const cLine = el('div', 'gp-c-line');
  const cX = el('button', 'gp-c-x');
  cX.append(drawn('close', { size: 22, stroke: 2.4 }));
  cX.dataset.gp = 'sites-card-close';
  cX.setAttribute('aria-label', t.back);
  cX.style.width = cX.style.height = minPx;
  const cGo = el('button', 'gp-c-go');
  cGo.dataset.gp = 'sites-open';
  cGo.style.minHeight = minPx;
  card.append(cIcon, cName, cX, cLine, cGo);
  const footer = el('footer');
  footer.setAttribute('role', 'group');
  box.append(header, stage, footer);
  root.replaceChildren(box);

  const g = canvas.getContext('2d');
  const views: ViewState<S>[] = opts.views.map((def) => {
    const layer = el('div', 'gp-pins');
    layer.dataset.view = def.id;
    stage.append(layer);
    return { def, cam: new MapCamera({ aspect: def.aspect, minZoom: def.minZoom, maxZoom: def.maxZoom, pad: def.pad }), layer, pins: new Map(), started: false };
  });
  stage.append(zoom, card);
  const tabs = new Map<string, HTMLButtonElement>();
  for (const v of views) {
    if (views.length < 2) break;
    const b = el('button');
    b.dataset.gpView = v.def.id;
    b.style.minHeight = minPx;
    if (v.def.icon !== undefined) b.append(iconNode(v.def.icon), document.createTextNode(' '));
    b.append(document.createTextNode(v.def.label ?? v.def.id));
    b.addEventListener('click', () => setView(v.def.id));
    footer.append(b);
    tabs.set(v.def.id, b);
  }
  footer.hidden = views.length < 2;

  let active = views.find((v) => v.def.id === opts.view) ?? views[0];
  let prev: ViewState<S> | null = null;
  let fadeFrom = 0;
  let selected: S | null = null;
  let suppressClick = false;
  let W = 1;
  let H = 1;
  let dpr = 1;
  const t0 = performance.now();
  let raf = 0;
  let alive = true;
  let lastTexts = -Infinity;
  let rows = new Map<S, SiteRow<S>>();
  let screenBg = '';

  const now = () => (performance.now() - t0) / 1000;
  const pinsOf = (v: ViewState<S>, time: number): Partial<Record<S, MapPoint>> => {
    const p = v.def.pins;
    try {
      return (typeof p === 'function' ? p(time) : p) ?? {};
    } catch {
      return {};
    }
  };

  function resize(): void {
    const r = stage.getBoundingClientRect();
    W = Math.max(1, r.width);
    H = Math.max(1, r.height);
    dpr = Math.min(2, window.devicePixelRatio || 1);
    canvas.width = Math.round(W * dpr);
    canvas.height = Math.round(H * dpr);
    for (const v of views) {
      v.cam.resize(W, H);
      if (!v.started && W > 1 && H > 1) start(v);
    }
    frame();
  }

  /** The first camera of a view: its `start`, or (focusHere) centred on the player's site, or the whole view */
  function start(v: ViewState<S>): void {
    v.started = true;
    const s = v.def.start;
    v.cam.zoom = s?.zoom ?? v.cam.minZoom;
    v.cam.x = s?.x ?? 0.5;
    v.cam.y = s?.y ?? 0.5;
    const here = opts.focusHere === false || s ? undefined : pinsOf(v, now())[sites.at];
    if (here) v.cam.center(here, v.cam.zoom);
    v.cam.clamp();
  }

  function pin(v: ViewState<S>, id: S): Pin {
    let p = v.pins.get(id);
    if (p) return p;
    const b = el('button', 'gp-pin');
    b.type = 'button';
    b.dataset.gpSite = id;
    const head = el('span', 'gp-pin-head');
    head.style.width = head.style.height = minPx;
    head.setAttribute('aria-hidden', 'true');
    b.append(head);
    // The caption is not inside the button (gp qa: no text out of its button) but takes the same tap
    const cap = el('div', 'gp-pin-cap');
    cap.dataset.gpCap = id;
    for (const e of [b, cap])
      e.addEventListener('click', () => {
        if (suppressClick) return;
        tap(id);
      });
    v.layer.append(b, cap);
    p = { el: b, head, cap, sig: '', cw: 0, ch: 0, cx: NaN, cy: NaN, slot: -1 };
    v.pins.set(id, p);
    return p;
  }

  /** A pin's head and caption from its row: changed only when what it shows changed */
  function paintPin(id: S, p: Pin): void {
    const r = rows.get(id);
    if (!r) return;
    const item = opts.items[id];
    const badge = r.state === 'open' ? (item?.badge?.() ?? null) : null;
    const showCap = r.state === 'open' || r.next || r.state === 'affordable' || selected === id;
    // The words (for the screen reader and the change check); the caption shows them with the drawn lock or coin
    const line =
      r.state === 'open'
        ? [t.level(r.level), r.rate > 0 ? t.rate(fmt(r.rate, 'down')) : '', badge ?? ''].filter(Boolean).join(' · ')
        : r.state === 'locked'
          ? t.locked
          : `${fmt(r.price, 'up')} ${cur.name}`;
    const sig = [r.state, r.here, r.level, line, showCap, selected === id].join('|');
    if (sig === p.sig) return;
    p.sig = sig;
    p.el.dataset.state = r.state;
    p.el.classList.toggle('gp-here', r.here);
    p.el.classList.toggle('gp-sel', selected === id);
    p.el.style.zIndex = p.cap.style.zIndex = String(r.here ? 4 : selected === id ? 5 : r.state === 'open' ? 3 : r.next ? 2 : 1);
    if (r.here) p.el.setAttribute('aria-current', 'location');
    else p.el.removeAttribute('aria-current');
    const name = item?.name ?? id;
    p.el.setAttribute('aria-label', `${name}: ${r.here ? `${t.here}, ` : ''}${line}`);
    p.head.replaceChildren();
    const icon = item?.icon;
    if (icon !== undefined) p.head.append(iconCopy(icon));
    else p.head.append(r.state === 'open' ? document.createTextNode(String(r.level)) : lock());
    if (icon !== undefined && r.state !== 'open') p.head.append(iconLine(el('span', 'gp-pin-lock'), lock()));
    p.cap.replaceChildren();
    p.cap.hidden = !showCap;
    if (showCap) {
      const shown = r.state === 'open' ? [line] : r.state === 'locked' ? [lock(), t.locked] : [coin(), fmt(r.price, 'up')];
      p.cap.append(el('div', 'gp-pin-name', name), iconLine(el('div', 'gp-pin-line'), ...shown));
    }
    p.cw = showCap ? p.cap.offsetWidth : 0;
    p.ch = showCap ? p.cap.offsetHeight : 0;
    p.cx = p.cy = NaN;
  }

  function texts(): void {
    rows = new Map(sites.rows().map((r) => [r.id, r]));
    iconLine(bal, coin(), fmt(sites.coins, 'down'));
    bal.setAttribute('aria-label', `${fmt(sites.coins, 'down')} ${cur.name}`);
    rate.textContent = t.rate(fmt(sites.totalRate(), 'down'));
    for (const v of views) for (const [id, p] of v.pins) paintPin(id, p);
    paintCard();
    for (const [id, b] of tabs) b.setAttribute('aria-pressed', String(id === active.def.id));
  }

  function paintCard(): void {
    const r = selected ? rows.get(selected) : undefined;
    if (!selected || !r || r.state === 'open') {
      card.hidden = true;
      return;
    }
    card.hidden = false;
    const item = opts.items[selected];
    if (cIcon.dataset.site !== selected) {
      cIcon.dataset.site = selected;
      cIcon.replaceChildren(item?.icon !== undefined ? iconCopy(item.icon) : drawn('mapPin', { style: 'duo', size: 36 }));
    }
    cName.textContent = item?.name ?? selected;
    if (r.state === 'locked') {
      iconLine(cLine, lock(), r.needs ? `${t.needs} ${opts.items[r.needs]?.name ?? r.needs}` : (r.lockReason ?? t.locked));
      cGo.hidden = true;
      return;
    }
    cGo.hidden = false;
    iconLine(cGo, `${t.open} · `, coin(), fmt(r.price, 'up'));
    cGo.setAttribute('aria-disabled', String(r.state !== 'affordable'));
    if (r.state === 'affordable') iconLine(cLine, coin(), fmt(r.price, 'up'));
    else iconLine(cLine, `${t.need} `, coin(), fmt(r.price - sites.coins, 'up'));
  }

  function tap(id: S): void {
    const r = sites.rows().find((x) => x.id === id);
    if (!r) return;
    if (r.state === 'open') {
      select(null);
      sites.travel(id);
      texts();
      opts.onEnter(id);
      return;
    }
    select(selected === id ? null : id);
  }

  function select(id: S | null): void {
    selected = id;
    texts();
  }

  cX.addEventListener('click', () => select(null));
  cGo.addEventListener('click', () => {
    const id = selected;
    if (!id) return;
    if (!sites.unlock(id)) {
      card.classList.remove('gp-deny');
      void card.offsetWidth; // restart the animation
      card.classList.add('gp-deny');
      opts.onDenied?.(id);
      return;
    }
    select(null);
    if (opts.onUnlock) {
      texts();
      opts.onUnlock(id);
    } else tap(id);
  });

  function setView(id: string, instant = false): void {
    const v = views.find((x) => x.def.id === id);
    if (!v || v === active) return;
    if (!v.started) start(v);
    prev = instant ? null : active;
    active = v;
    fadeFrom = performance.now();
    select(null);
    opts.onView?.(id);
  }

  // --- Drawing and placing the pins, every frame

  function drawView(v: ViewState<S>, alpha: number, time: number): void {
    if (!g || alpha <= 0) return;
    g.save();
    g.globalAlpha = alpha;
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.fillStyle = v.def.background ?? (screenBg ||= getComputedStyle(box).getPropertyValue('--gp-sites-bg').trim() || '#0d1626');
    g.fillRect(0, 0, W, H);
    const [a, b, c, d, e, f] = v.cam.transform();
    g.setTransform(a * dpr, b * dpr, c * dpr, d * dpr, e * dpr, f * dpr);
    const base = v.cam.base();
    try {
      v.def.draw(g, base.w, base.h, time, { zoom: v.cam.zoom, visible: v.cam.visible(), dpr });
    } catch (err) {
      console.error('sites map: a view failed to draw', err);
    }
    g.restore();
  }

  function placePins(v: ViewState<S>, shown: boolean, time: number): void {
    const pts = pinsOf(v, time);
    for (const id of Object.keys(pts) as S[]) if (rows.has(id)) pin(v, id);
    const input: MapPinBox[] = [];
    const order: Pin[] = [];
    for (const [id, p] of v.pins) {
      const pt = pts[id];
      if (!p.sig) paintPin(id, p);
      const r = rows.get(id);
      if (!shown || !pt || !r) {
        p.el.style.visibility = p.cap.style.visibility = 'hidden';
        continue;
      }
      const [x, y] = v.cam.toScreen(pt);
      input.push({ x, y, cw: p.cw, ch: p.ch, prio: selected === id ? 5 : r.here ? 4 : r.state === 'open' ? 3 : r.next ? 2 : 1, last: p.slot });
      order.push(p);
    }
    const out = layoutMapPins(input, W, H, min);
    out.forEach((o, i) => {
      const p = order[i];
      p.el.style.visibility = o.head ? 'visible' : 'hidden';
      p.cap.style.visibility = o.head && o.cap ? 'visible' : 'hidden';
      if (o.head) p.el.style.transform = `translate(${o.head[0]}px, ${o.head[1]}px)`;
      p.slot = o.slot;
      if (!o.cap) return;
      const [cx, cy] = o.cap;
      if (cx !== p.cx || cy !== p.cy) {
        p.cx = cx;
        p.cy = cy;
        p.cap.style.transform = `translate(${cx}px, ${cy}px)`;
      }
    });
  }

  function frame(): void {
    if (!alive) return;
    const ms = performance.now();
    const time = (ms - t0) / 1000;
    if (ms - lastTexts > 250) {
      lastTexts = ms;
      texts();
    }
    const k = prev ? ease((ms - fadeFrom) / FADE_MS) : 1;
    if (prev && k >= 1) {
      prev.layer.style.opacity = '0';
      placePins(prev, false, time);
      prev = null;
    }
    if (g) {
      g.setTransform(1, 0, 0, 1, 0, 0);
      g.clearRect(0, 0, canvas.width, canvas.height);
    }
    if (prev) drawView(prev, 1, time);
    drawView(active, k, time);
    for (const v of views) {
      const shown = v === active || v === prev;
      v.layer.style.opacity = v === active ? String(k) : v === prev ? String(1 - k) : '0';
      v.layer.style.pointerEvents = 'none';
      placePins(v, shown, time);
      // Only the active view's pins take taps (not the one fading out)
      for (const p of v.pins.values()) p.el.style.pointerEvents = p.cap.style.pointerEvents = v === active ? 'auto' : 'none';
    }
  }

  function loop(): void {
    if (!alive) return;
    frame();
    raf = requestAnimationFrame(loop);
  }

  // --- Input: drag to move, pinch or wheel to zoom, a tap on a pin enters or selects it

  const pointers = new Map<number, { x: number; y: number }>();
  let moved = 0;
  let pinch: { d: number; x: number; y: number } | null = null;
  const local = (e: PointerEvent | WheelEvent) => {
    const r = stage.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  };
  const onControl = (e: Event) => !!(e.target as HTMLElement).closest?.('.gp-sites-zoom, .gp-sites-card');
  stage.addEventListener('pointerdown', (e) => {
    if (onControl(e)) return;
    if (pointers.size === 0) {
      moved = 0;
      suppressClick = false;
    }
    pointers.set(e.pointerId, local(e));
    if (pointers.size === 2) {
      const [a, b] = [...pointers.values()];
      pinch = { d: Math.hypot(a.x - b.x, a.y - b.y), x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
    }
  });
  stage.addEventListener('pointermove', (e) => {
    const was = pointers.get(e.pointerId);
    if (!was) return;
    const p = local(e);
    pointers.set(e.pointerId, p);
    const cam = active.cam;
    if (pointers.size >= 2 && pinch) {
      const [a, b] = [...pointers.values()];
      const d = Math.hypot(a.x - b.x, a.y - b.y);
      const mx = (a.x + b.x) / 2;
      const my = (a.y + b.y) / 2;
      cam.pan(mx - pinch.x, my - pinch.y);
      if (pinch.d > 0) cam.zoomAt(d / pinch.d, mx, my);
      pinch = { d, x: mx, y: my };
      moved += SLOP;
    } else {
      moved += Math.abs(p.x - was.x) + Math.abs(p.y - was.y);
      if (moved < SLOP) return;
      cam.pan(p.x - was.x, p.y - was.y);
    }
    if (moved >= SLOP && !suppressClick) {
      // A drag, not a tap: the pin under the finger doesn't take it; the stage keeps the pointer past its edge
      suppressClick = true;
      stage.classList.add('gp-drag');
      for (const id of pointers.keys()) {
        try {
          stage.setPointerCapture(id);
        } catch {
          // The pointer is gone already
        }
      }
    }
  });
  const up = (e: PointerEvent) => {
    if (!pointers.delete(e.pointerId)) return;
    if (pointers.size < 2) pinch = null;
    if (pointers.size === 0) stage.classList.remove('gp-drag');
  };
  stage.addEventListener('pointerup', up);
  stage.addEventListener('pointercancel', up);
  stage.addEventListener('lostpointercapture', up);
  stage.addEventListener('click', (e) => {
    // A tap on the map itself (not a pin or a control) closes the card
    const target = e.target as HTMLElement;
    if (!suppressClick && !target.closest('.gp-pin, .gp-pin-cap, .gp-sites-card, .gp-sites-zoom')) select(null);
    suppressClick = false;
  });
  const onWheel = (e: WheelEvent) => {
    e.preventDefault();
    const p = local(e);
    // A mouse wheel's notch (≈100) is a 1.2× step; a touchpad's small deltas zoom smoothly
    const dy = e.deltaMode === 1 ? e.deltaY * 33 : e.deltaY;
    active.cam.zoomAt(Math.exp(-Math.max(-300, Math.min(300, dy)) * 0.0018), p.x, p.y);
  };
  stage.addEventListener('wheel', onWheel, { passive: false });
  zin.addEventListener('click', () => active.cam.zoomAt(1.4));
  zout.addEventListener('click', () => active.cam.zoomAt(1 / 1.4));
  back.addEventListener('click', () => opts.onBack?.());
  // Keyboard: arrows move the map, + and − zoom (on the map or one of its pins)
  box.addEventListener('keydown', (e) => {
    const step = 60;
    const k: Record<string, () => void> = {
      ArrowLeft: () => active.cam.pan(step, 0),
      ArrowRight: () => active.cam.pan(-step, 0),
      ArrowUp: () => active.cam.pan(0, step),
      ArrowDown: () => active.cam.pan(0, -step),
      '+': () => active.cam.zoomAt(1.25),
      '=': () => active.cam.zoomAt(1.25),
      '-': () => active.cam.zoomAt(1 / 1.25),
    };
    const f = k[e.key];
    if (!f || (e.target as HTMLElement).closest?.('input, textarea')) return;
    e.preventDefault();
    f();
  });

  const onResize = () => resize();
  addEventListener('resize', onResize);
  const watch = typeof ResizeObserver === 'function' ? new ResizeObserver(onResize) : null;
  watch?.observe(stage);
  texts();
  resize();
  raf = requestAnimationFrame(loop);

  return {
    refresh: () => {
      lastTexts = performance.now();
      texts();
    },
    setView,
    focus(id: string, z?: number) {
      const time = now();
      const v = views.find((x) => pinsOf(x, time)[id as S]) ?? null;
      if (!v) return;
      if (v !== active) setView(v.def.id);
      v.cam.center(pinsOf(v, time)[id as S]!, z ?? Math.max(v.cam.zoom, Math.min(v.cam.maxZoom, 1.6)));
    },
    get view() {
      return active.def.id;
    },
    get camera() {
      return active.cam;
    },
    destroy() {
      alive = false;
      cancelAnimationFrame(raf);
      removeEventListener('resize', onResize);
      watch?.disconnect();
      box.remove();
    },
  };
}
