// The look checks of the code kit's QA, judged without a browser (qa/look.ts): the hero's size, a 3D camera's field of
// view in portrait, bitmaps drawn magnified, the face text renders in

import { describe, expect, it } from 'vitest';
import { heroVerdict, HERO_MIN_SHARE, horizontalFovDeg, judgeMagnified, MAG_FAIL, MAG_WARN, PORTRAIT_MIN_HFOV, renderingFace, systemFontVerdict, TITLE_MAX_CHOICES } from '../qa/look.ts';

describe('the hero is no speck (host.qa({ hero }))', () => {
  it('√(w·h) against the short side: 6 % passes, a 32 px cell at 1280×720 (4.4 %) fails, at 360×800 (8.9 %) passes', () => {
    expect(HERO_MIN_SHARE).toBe(0.06);
    const desk = heroVerdict({ x: 600, y: 300, w: 32, h: 32 }, { width: 1280, height: 720 });
    expect(desk.ok).toBe(false);
    expect(desk.share).toBeCloseTo(32 / 720, 5);
    expect(desk.text).toMatch(/4\.4 % of the short side 720 px — under 6\.0 %/);
    expect(heroVerdict({ x: 100, y: 300, w: 32, h: 32 }, { width: 360, height: 800 }).ok).toBe(true);
    // A tall thin hero counts by its area: 10×100 is a 31.6 px object
    expect(heroVerdict({ x: 0, y: 0, w: 10, h: 100 }, { width: 800, height: 450 }).share).toBeCloseTo(Math.sqrt(1000) / 450, 5);
    expect(heroVerdict({ x: 0, y: 0, w: 27, h: 27 }, { width: 821, height: 462 }).ok).toBe(false);
    expect(heroVerdict({ x: 0, y: 0, w: 28, h: 28 }, { width: 821, height: 462 }).ok).toBe(true);
  });
  it('off the screen fails, whatever its size', () => {
    const v = heroVerdict({ x: 1400, y: 10, w: 200, h: 200 }, { width: 1280, height: 720 });
    expect(v.ok).toBe(false);
    expect(v.text).toMatch(/off the 1280×720 screen/);
  });
});

describe('a three camera in portrait (≥ 60° across)', () => {
  it("from three's vertical fov and the aspect: 75° at 360×800 is ≈ 38° across; 104° vertical gives 60°", () => {
    expect(PORTRAIT_MIN_HFOV).toBe(60);
    const a = 360 / 800;
    expect(horizontalFovDeg({ isPerspectiveCamera: true, fov: 75, aspect: a })).toBeCloseTo(38.1, 1);
    const need = (2 * Math.atan(Math.tan((60 * Math.PI) / 360) / a) * 180) / Math.PI;
    expect(horizontalFovDeg({ isPerspectiveCamera: true, fov: need, aspect: a })).toBeCloseTo(60, 5);
    // In landscape the same fov is wide
    expect(horizontalFovDeg({ isPerspectiveCamera: true, fov: 75, aspect: 16 / 9 })!).toBeGreaterThan(100);
  });
  it('zoom narrows it; a missing aspect takes the view; hfov given wins; orthographic and empty are not judged', () => {
    const z1 = horizontalFovDeg({ fov: 75, aspect: 0.45 })!;
    expect(horizontalFovDeg({ fov: 75, aspect: 0.45, zoom: 2 })!).toBeLessThan(z1);
    expect(horizontalFovDeg({ fov: 75 }, 0.45)).toBeCloseTo(z1, 5);
    expect(horizontalFovDeg({ hfov: 72, fov: 10, aspect: 0.1 })).toBe(72);
    expect(horizontalFovDeg({ isOrthographicCamera: true, fov: 50, aspect: 1 })).toBeNull();
    expect(horizontalFovDeg({})).toBeNull();
    expect(horizontalFovDeg(null)).toBeNull();
  });
});

describe('bitmaps drawn magnified', () => {
  it(`over ${MAG_FAIL}× fails, over ${MAG_WARN}× warns, worst first, named with the screen and the size`, () => {
    const j = judgeMagnified([
      { image: 'car.png', w: 64, h: 40, screen: 'play', scale: 1.4, n: 3 },
      { image: 'a canvas', w: 128, h: 128, screen: 'shop', scale: 3.1, n: 1 },
      { image: 'gem.png', w: 32, h: 32, screen: 'title', scale: 2.4, n: 9 },
      { image: 'bg.png', w: 512, h: 512, screen: 'play', scale: 1.1, n: 60 },
    ]);
    expect(j.fail).toEqual(['a canvas 128×128 drawn at 3.10× on "shop"', 'gem.png 32×32 drawn at 2.40× on "title" (9 draws)']);
    expect(j.warn).toEqual(['car.png 64×40 drawn at 1.40× on "play" (3 draws)']);
    expect(judgeMagnified([])).toEqual({ fail: [], warn: [] });
  });
});

describe('the face text renders in (W_SYSTEM_FONT)', () => {
  const faces = { loaded: new Set(['bungee']), declared: new Set(['bungee', 'broken face']) };
  it('the first family that renders: a loaded FontFace is the game\'s; generic and named system faces are not; emoji and failed faces fall through', () => {
    expect(renderingFace('Bungee, system-ui', faces)).toEqual({ name: 'Bungee', game: true });
    expect(renderingFace('"Broken Face", Georgia, serif', faces)).toEqual({ name: 'Georgia', game: false });
    expect(renderingFace('system-ui, -apple-system, "Segoe UI", Roboto', faces)).toEqual({ name: 'system-ui', game: false });
    expect(renderingFace('"Noto Color Emoji", "Bungee"', faces)).toEqual({ name: 'Bungee', game: true });
    expect(renderingFace('"Apple Color Emoji"', faces).game).toBe(false);
  });
  it('most of the visible characters in a system face warns; a game face for most passes; little text is not judged', () => {
    const sys = systemFontVerdict([
      { name: 'system-ui', game: false, chars: 300 },
      { name: 'Bungee', game: true, chars: 100 },
      { name: 'system-ui', game: false, chars: 50 },
    ]);
    expect(sys.warn).toBe(true);
    expect(sys.share).toBeCloseTo(350 / 450, 5);
    expect(sys.text).toMatch(/^78 % of 450 visible characters in a system face \(system-ui 78 %, Bungee \(loaded by the game\) 22 %\)/);
    expect(systemFontVerdict([{ name: 'Bungee', game: true, chars: 300 }, { name: 'Arial', game: false, chars: 100 }]).warn).toBe(false);
    expect(systemFontVerdict([{ name: 'Arial', game: false, chars: 12 }]).warn).toBe(false);
  });
  it('the title-choices limit is 6', () => {
    expect(TITLE_MAX_CHOICES).toBe(6);
  });
});
