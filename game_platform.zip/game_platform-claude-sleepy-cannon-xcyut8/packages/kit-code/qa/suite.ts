// QA suite of the code kit: the platform can't know a code game's mechanics, so it checks what every game on the
// channel must get right, through the host and a few conventions (docs/guides/code-games.md):
//   - the Play button has data-gp="play" (the production run taps it — no test hooks there);
//   - dev builds register host.qa({ play, end, lose? });
//   - buttons for rewarded ads have data-gp-rewarded="<placement>".
// The game's own mechanics need the game's own tests on top (unit tests, a balance bot).

import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import type { Browser, Page } from 'playwright';
import { runSections, type QaContext, type QaSection, type QaSuite } from '@gp/qa';
import { MAX_READING_SEC } from '@gp/core/reading';
import { EXPLAIN_GRACE_SEC, judgeExplanation, type ExplainSample, type ExplainVerdict } from './explain.ts';
import { boxPixels, emptyLayout, FLAT_FAIL_LIMITS, flatFrameOf, flatText } from '@gp/qa/flat';
import { gameGenre, SCOPE_MAX_SCREENS } from '@gp/spec';
import { ICON_GLYPH_SOURCE, TEXT_ARROW_SOURCE } from '@gp/qa/glyphs';
import {
  heroRequired,
  heroVerdict,
  HERO_MIN_SHARE,
  HUD_NUMBER_MIN_PX,
  isPlaceholderImage,
  judgePlayText,
  LATER_PLAY_SEC,
  PANEL_MIN_ALPHA,
  parseColor,
  PLAY_TEXT_MIN_CONTRAST,
  PLAY_TEXT_MIN_PX,
  silhouettesVerdict,
  textBackground,
  titleCoverVerdict,
  TITLE_COVER_FAIL,
  TITLE_COVER_WARN,
  type PlayText,
  horizontalFovDeg,
  judgeMagnified,
  MAG_FAIL,
  MAG_WARN,
  PORTRAIT_MIN_HFOV,
  renderingFace,
  systemFontVerdict,
  TITLE_MAX_CHOICES,
  type CameraLike,
  type FaceUse,
  type Magnified,
} from './look.ts';
import { runFeel } from './feel.ts';
import { runSound } from './sound.ts';
import {
  audioReport,
  canvasContexts,
  canvasTexts,
  domHidden,
  installProbe,
  legibility,
  judgeFps,
  machineLoad,
  MIN_FPS,
  MIN_TEXT_PX,
  pixelStats,
  PORTAL_FRAMES,
  sampleFps,
  stillness,
  type CanvasUiRect,
  type FpsSample,
} from '@gp/qa/probe';

/* eslint-disable @typescript-eslint/no-explicit-any */
declare global {
  interface Window {
    __gp: any;
    __portal: { calls: { fn: string; t: number }[] };
  }
}

const VIEWPORTS = [
  { name: 'phone-portrait-360x800', width: 360, height: 800, touch: true },
  { name: 'phone-landscape-800x360', width: 800, height: 360, touch: true },
  { name: 'desktop-1280x720', width: 1280, height: 720, touch: false },
];

/** The host refuses a rewarded ad without the player's tap and says so — expected in one check below */
const REFUSED = 'a rewarded ad must follow the player';

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/**
 * QA plays a RETURNING player everywhere (the title, Play, the results, the shop…) — every page gets window.__gpVisit =
 * 'returning', so host.firstVisit is false — except the first minute, which opens fresh pages as a new player sees them
 * (a first visit that lands in gameplay is checked there: docs/guides/first-minute.md)
 */
type CodeQaContext = QaContext & { freshBrowser?: Browser };
function asReturning(ctx: QaContext): QaContext {
  const raw = ctx.browser;
  const browser = new Proxy(raw, {
    get(target, prop) {
      if (prop === 'newContext')
        return async (o?: Parameters<Browser['newContext']>[0]) => {
          const c = await target.newContext(o);
          await c.addInitScript(() => {
            (window as unknown as { __gpVisit: string }).__gpVisit = 'returning';
          });
          return c;
        };
      const v = Reflect.get(target, prop, target);
      return typeof v === 'function' ? v.bind(target) : v;
    },
  });
  return { ...ctx, browser, freshBrowser: raw } as CodeQaContext;
}
/** The browser for a new player's pages (no "returning" flag) */
const freshBrowser = (ctx: QaContext): Browser => (ctx as CodeQaContext).freshBrowser ?? ctx.browser;
const gameplayCalls = (page: Page) => page.evaluate(() => window.__portal.calls.map((c) => c.fn).filter((f) => f.startsWith('gameplay')));
const lastGameplay = async (page: Page) => (await gameplayCalls(page)).at(-1) ?? null;
const alternate = (c: string[]) => c.every((x, i) => (i === 0 ? x === 'gameplayStart' : x !== c[i - 1]));
const roundEnds = (page: Page): Promise<number> => page.evaluate(() => window.__gp.events.count('round:end'));

/** A lost run's offer may come after a death animation (Dread Throne's did): wait for it, up to 3 s */
const OFFER_WAIT_MS = 3000;
async function offerAppears(page: Page): Promise<boolean> {
  const shown = await page
    .locator('[data-gp-rewarded]:visible')
    .first()
    .waitFor({ state: 'visible', timeout: OFFER_WAIT_MS })
    .then(() => true)
    .catch(() => false);
  // Let the offer screen settle (a panel sliding in) before anything is measured on it
  if (shown) await sleep(400);
  return shown;
}

/** The top-level save fields that differ, for a message */
/**
 * The save with the offline stamp left out: an offline log of `offlineEarnings` / `stampOffline` (`{ at, pending }`,
 * under any field name, at any depth) gets `at: 0`. An idle game stamps the time away on pagehide and at start, as
 * offline.ts tells it to (Craft Pickaxe Idle's report): a reload moves the stamp, and that is not a lost or rewritten save
 */
export function withoutOfflineStamp(raw: string | null): string | null {
  if (raw === null) return null;
  let data: unknown;
  try {
    data = JSON.parse(raw);
  } catch {
    return raw;
  }
  const walk = (v: unknown): unknown => {
    if (Array.isArray(v)) return v.map(walk);
    if (!v || typeof v !== 'object') return v;
    const o = v as Record<string, unknown>;
    const keys = Object.keys(o).sort().join(',');
    if (keys === 'at,pending' && typeof o.at === 'number') return { at: 0, pending: o.pending };
    return Object.fromEntries(Object.entries(o).map(([k, x]) => [k, walk(x)]));
  };
  return JSON.stringify(walk(data));
}

function changedKeys(a: string | null, b: string | null): string {
  try {
    const x = JSON.parse(a ?? 'null') ?? {};
    const y = JSON.parse(b ?? 'null') ?? {};
    const keys = [...new Set([...Object.keys(x), ...Object.keys(y)])].filter((k) => JSON.stringify(x[k]) !== JSON.stringify(y[k]));
    return keys.length ? keys.slice(0, 6).join(', ') : 'the text, not the fields';
  } catch {
    return 'not JSON';
  }
}

async function setHidden(page: Page, hidden: boolean): Promise<void> {
  await page.evaluate((h) => {
    Object.defineProperty(document, 'hidden', { value: h, configurable: true });
    Object.defineProperty(document, 'visibilityState', { value: h ? 'hidden' : 'visible', configurable: true });
    document.dispatchEvent(new Event('visibilitychange'));
  }, hidden);
}

/**
 * Every visible button-like element: on screen and at least the audience's touch size. Scrolling is allowed where the
 * player can scroll: a button clipped inside a scrolling panel (a long shop list on a phone) is scrolled into the part of
 * the panel that is on screen and must then be on screen, inside that part of the panel, big enough and tappable (the
 * topmost element at its centre) — Brew & Banter, Germ Bait and Candle Crypt all had to ask. Only panels a player can
 * scroll are moved (overflow auto/scroll with more content than room), by their own scroll position; never the page or an
 * overflow:hidden box. (Not scrollIntoView: it scrolls those too, so a button no player can reach passed.) The scroll
 * positions are put back afterwards, so screenshots show what the player sees.
 */
export async function tappables(page: Page, min: number): Promise<{ count: number; bad: string[]; scrolled: number }> {
  return page.evaluate((m) => {
    const bad: string[] = [];
    let count = 0;
    let scrolled = 0;
    const W = innerWidth;
    const H = innerHeight;
    const onScreen = (r: DOMRect) => r.left >= -1 && r.top >= -1 && r.right <= W + 1 && r.bottom <= H + 1;
    const root = document.scrollingElement;
    /** The axes a player can scroll a box along: overflow auto/scroll with more content than room */
    const axes = (p: HTMLElement) => {
      const st = getComputedStyle(p);
      return {
        y: /(auto|scroll)/.test(st.overflowY) && p.scrollHeight > p.clientHeight + 1,
        x: /(auto|scroll)/.test(st.overflowX) && p.scrollWidth > p.clientWidth + 1,
      };
    };
    /** The ancestors a player can scroll, the nearest first (not the page: a portal game must not scroll it) */
    const scrollers = (el: HTMLElement): HTMLElement[] => {
      const out: HTMLElement[] = [];
      for (let p = el.parentElement; p && p !== document.body && p !== root; p = p.parentElement) {
        const a = axes(p);
        if (a.x || a.y) out.push(p);
      }
      return out;
    };
    /** The part of a panel's scrolling area (its padding box, without scrollbars) that is on screen */
    const visibleBox = (p: HTMLElement) => {
      const pr = p.getBoundingClientRect();
      const left = pr.left + p.clientLeft;
      const top = pr.top + p.clientTop;
      return { left: Math.max(0, left), top: Math.max(0, top), right: Math.min(W, left + p.clientWidth), bottom: Math.min(H, top + p.clientHeight) };
    };
    /** Not wholly inside the on-screen part of the panel */
    const clipped = (r: DOMRect, p: HTMLElement) => {
      const b = visibleBox(p);
      return r.top < b.top - 1 || r.bottom > b.bottom + 1 || r.left < b.left - 1 || r.right > b.right + 1;
    };
    /** The least scroll that brings [a, b] inside [lo, hi] (its start first when it doesn't fit) */
    const delta = (a: number, b: number, lo: number, hi: number) => (a < lo ? a - lo : b > hi ? Math.min(b - hi, a - lo) : 0);
    const tappable = (el: HTMLElement, r: DOMRect) => {
      const hit = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
      return !!hit && (hit === el || el.contains(hit));
    };
    const restore = new Map<HTMLElement, [number, number]>();
    for (const el of document.querySelectorAll<HTMLElement>('button, [role=button], a[href], input, select')) {
      let r = el.getBoundingClientRect();
      const st = getComputedStyle(el);
      if (r.width === 0 || r.height === 0 || st.visibility === 'hidden' || st.display === 'none') continue;
      count++;
      const name = (el.textContent || el.getAttribute('aria-label') || el.tagName).trim().slice(0, 30);
      const panels = scrollers(el);
      const viaScroll = panels.length > 0 && (!onScreen(r) || panels.some((p) => clipped(r, p)));
      if (viaScroll) {
        // The nearest panel first, then the ones around it; the browser clamps each to what a player can reach
        for (const p of panels) {
          if (!restore.has(p)) restore.set(p, [p.scrollTop, p.scrollLeft]);
          const a = axes(p);
          const b = visibleBox(p);
          r = el.getBoundingClientRect();
          if (a.y) p.scrollTop += delta(r.top, r.bottom, b.top, b.bottom);
          if (a.x) p.scrollLeft += delta(r.left, r.right, b.left, b.right);
        }
        r = el.getBoundingClientRect();
        scrolled++;
      }
      if (!onScreen(r) || (viaScroll && panels.some((p) => clipped(r, p)))) bad.push(`${name}: off screen${viaScroll ? ' (even scrolled as far as a player can)' : ''}`);
      else if (r.width < m - 0.5 || r.height < m - 0.5) bad.push(`${name}: ${Math.round(r.width)}×${Math.round(r.height)}`);
      else if (viaScroll && !tappable(el, r)) bad.push(`${name}: covered once scrolled into view`);
    }
    for (const [p, [top, left]] of [...restore].reverse()) {
      p.scrollTop = top;
      p.scrollLeft = left;
    }
    return { count, bad, scrolled };
  }, min);
}

/** The tappables line for the report: how many, and how many were reached by scrolling */
const tapInfo = (t: { count: number; scrolled: number }) => `${t.count} buttons${t.scrolled ? ` (${t.scrolled} scrolled into view)` : ''}`;

async function tapSelector(page: Page, sel: string, touch: boolean): Promise<boolean> {
  const el = page.locator(sel).first();
  if (!(await el.isVisible().catch(() => false))) return false;
  if (touch) await el.tap();
  else await el.click();
  return true;
}

/**
 * What the game draws on the canvas that a player reads or taps (host.qa({ canvasUi })), checked like DOM controls: on
 * screen, buttons ≥ `min` px with no DOM element on top (the topmost element at five points of the rect is a canvas),
 * and with `minFontPx` text at least that big (fontPx, or the rect's height without it). null: the game declares none
 */
export async function canvasUi(page: Page, min: number, minFontPx = 0): Promise<{ rects: CanvasUiRect[]; bad: string[] } | null> {
  return page.evaluate(
    ({ min, minFontPx }) => {
      const d = window.__gp?.host?.qaDriver;
      if (!d || typeof d.canvasUi !== 'function') return null;
      let list: unknown;
      try {
        list = d.canvasUi();
      } catch (e) {
        return { rects: [], bad: [`canvasUi() threw: ${String(e)}`] };
      }
      if (!Array.isArray(list)) return { rects: [], bad: ['canvasUi() must return an array of { name, kind, x, y, w, h, fontPx? }'] };
      const W = innerWidth;
      const H = innerHeight;
      const rects: CanvasUiRect[] = [];
      const bad: string[] = [];
      for (const r of list as CanvasUiRect[]) {
        const name = String(r?.name ?? '?');
        if (!r || (r.kind !== 'text' && r.kind !== 'button') || ![r.x, r.y, r.w, r.h].every(Number.isFinite) || r.w <= 0 || r.h <= 0) {
          bad.push(`${name}: not a rect { name, kind: 'text' | 'button', x, y, w, h } in CSS px`);
          continue;
        }
        rects.push({ name, kind: r.kind, x: r.x, y: r.y, w: r.w, h: r.h, ...(r.fontPx !== undefined ? { fontPx: r.fontPx } : {}), ...(typeof r.text === 'string' ? { text: r.text } : {}) });
        const at = `${Math.round(r.x)},${Math.round(r.y)} ${Math.round(r.w)}×${Math.round(r.h)}`;
        if (r.x < -1 || r.y < -1 || r.x + r.w > W + 1 || r.y + r.h > H + 1) {
          bad.push(`${name}: off screen (${at} on ${W}×${H})`);
          continue;
        }
        if (r.kind === 'button') {
          if (r.w < min - 0.5 || r.h < min - 0.5) bad.push(`${name}: ${Math.round(r.w)}×${Math.round(r.h)} (a canvas button under ${min} px)`);
          const top = [[0.5, 0.5], [0.2, 0.2], [0.8, 0.2], [0.2, 0.8], [0.8, 0.8]]
            .map(([fx, fy]) => document.elementFromPoint(r.x + r.w * fx, r.y + r.h * fy))
            .find((el) => el && el.tagName !== 'CANVAS');
          if (top) {
            const desc = `${top.tagName.toLowerCase()}${top.id ? `#${top.id}` : ''}${typeof top.className === 'string' && top.className ? `.${top.className.split(/\s+/)[0]}` : ''}`;
            bad.push(`${name}: a DOM element is on top of the canvas button (${desc}) — it takes the taps`);
          }
        }
        if (minFontPx && (r.kind === 'text' || r.fontPx !== undefined)) {
          const f = r.fontPx ?? r.h;
          if (f < minFontPx - 0.01) bad.push(`${name}: ${f.toFixed(1)} px text${r.fontPx === undefined ? ' (its height: no fontPx)' : ''}, under ${minFontPx} px`);
        }
      }
      return { rects, bad };
    },
    { min, minFontPx },
  );
}

/** Where a still screen is checked: the first screen (the title), the pause screen, a midgame ad */
export type StillScreen = 'title' | 'pause' | 'ad';

/**
 * The fix a still-screen failure names: the exact host API, for an engine adapter and for a loop of the game's own, and
 * (only on the title) the opt-in for a title that animates on purpose. Candle Crypt, Dread Throne and Starsilk ran their
 * loop on the title and under ads; Echoflies' title animates on purpose but never said so (backlog item 4)
 */
export function stillFix(where: StillScreen): string {
  const why =
    where === 'ad'
      ? 'the loop runs under the ad (host.paused is true there, reason "ad")'
      : where === 'pause'
        ? 'the loop runs on the pause screen (host.paused, or no run on)'
        : 'the loop runs on the title (no run is on)';
  const adapter = "with an engine adapter (@gp/core/engines/<name>): eng.setRunning(state === 'play') on every change of screen — the adapter stops on host.onPause and redraws on host.onResume by itself; never start the engine's own loop (app.ticker, renderer.setAnimationLoop, game.loop.wake())";
  const own = 'with your own requestAnimationFrame loop: request the next frame only while a run is on and !host.paused, restart it in host.onResume, and draw a still screen once — on a change of screen, a resize and in host.onResume (the gp init skeleton\'s wake())';
  const opt = where === 'title' ? ". A title that animates on purpose: host.qa({ …, idleAnimation: true }) — the pause screen and ads must still stand still" : '';
  return `${why} — ${adapter}; ${own}${opt}. docs/guides/code-games.md#still-screens`;
}

/**
 * Nothing runs on a screen that stands still: no requestAnimationFrame loop, no canvas frames (the engine lab's Pixi ran
 * 60 rAF callbacks a second on its menus). A title that animates on purpose says so: host.qa({ idleAnimation: true })
 */
async function stillCheck(ctx: QaContext, page: Page, scope: string, screen: string, where: StillScreen): Promise<void> {
  const s = await stillness(page);
  if (!s) return;
  if (where === 'title' && !s.quiet && (await page.evaluate(() => window.__gp.host.qaDriver?.idleAnimation === true))) {
    ctx.info(scope, `${screen}: animates (host.qa idleAnimation: true)`, s.text);
    return;
  }
  ctx.check(scope, `${screen}: nothing runs — no requestAnimationFrame loop, no canvas frames`, s.quiet, s.quiet ? s.text : `${s.text}: ${stillFix(where)}`);
}

/**
 * After a click on the canvas, Tab must reach the DOM buttons: a focusable canvas that swallows Tab (Kaplay's tabIndex 0
 * and its keydown preventDefault) traps keyboard players. The click lands where the canvas is the topmost element
 */
async function focusEscape(page: Page): Promise<{ checked: boolean; ok: boolean; text: string }> {
  const pt = await page.evaluate(() => {
    for (const fy of [0.08, 0.92, 0.5, 0.25, 0.75])
      for (const fx of [0.06, 0.94, 0.5, 0.25, 0.75]) {
        const x = Math.round(innerWidth * fx);
        const y = Math.round(innerHeight * fy);
        const el = document.elementFromPoint(x, y);
        if (el && el.tagName === 'CANVAS') return { x, y, tabIndex: (el as HTMLCanvasElement).tabIndex };
      }
    return null;
  });
  if (!pt) return { checked: false, ok: true, text: 'no point where the canvas is the topmost element' };
  const controls = await page.evaluate(
    () =>
      [...document.querySelectorAll<HTMLElement>('button, [role=button], a[href], input, select, textarea')].filter((b) => {
        const r = b.getBoundingClientRect();
        return r.width > 0 && r.height > 0 && getComputedStyle(b).visibility !== 'hidden' && !(b as HTMLButtonElement).disabled;
      }).length,
  );
  if (!controls) return { checked: false, ok: true, text: 'no DOM controls on this screen' };
  await page.mouse.click(pt.x, pt.y);
  await sleep(100);
  const seen: string[] = [];
  for (let i = 0; i < controls + 2; i++) {
    await page.keyboard.press('Tab');
    const a = await page.evaluate(() => {
      const el = document.activeElement as HTMLElement | null;
      if (!el || el === document.body) return { control: false, name: 'body' };
      const r = el.getBoundingClientRect();
      const control = el.tagName !== 'CANVAS' && r.width > 0 && r.height > 0;
      return { control, name: `${el.tagName.toLowerCase()}${el.id ? `#${el.id}` : ''}${el.tagName === 'CANVAS' ? ` tabindex=${el.getAttribute('tabindex')}` : ` "${(el.textContent ?? '').trim().slice(0, 20)}"`}` };
    });
    if (a.control) return { checked: true, ok: true, text: `Tab × ${i + 1} → ${a.name}` };
    seen.push(a.name);
  }
  const stuck = seen.every((s) => s.startsWith('canvas'));
  return {
    checked: true,
    ok: false,
    text: `after a click on the canvas (tabIndex ${pt.tabIndex}), ${controls + 2} × Tab never reached a button: focus on ${[...new Set(seen)].join(', ')}${stuck ? ' — the canvas keeps the focus (an engine that sets tabIndex and swallows Tab: remove the attribute, canvas.removeAttribute("tabindex"))' : ''}`,
  };
}

/** How long sampleFps() watches the game play */
const FPS_SAMPLE_MS = 2000;

/** How much slower a mid-range phone's CPU is than the QA machine, for the phone hint (Chrome DevTools' "4× slowdown" preset) */
export const PHONE_CPU_SLOWDOWN = 4;

/**
 * A hint, never a failure: the frame rate at a phone size with the CPU slowed down like a mid-range phone's. The
 * QA machine is several times faster than a phone, so a game that is smooth here can stutter there (Candle Crypt 1.4:
 * smooth in QA, «лагает на телефоне» for the owner). Off on a quiet machine only: called from runFps / runViewport
 */
async function phoneFpsHint(ctx: QaContext, page: Page, V: string): Promise<void> {
  let cdp: import('playwright').CDPSession | null = null;
  try {
    cdp = await page.context().newCDPSession(page);
    await cdp.send('Emulation.setCPUThrottlingRate', { rate: PHONE_CPU_SLOWDOWN });
    const s = await sampleFps(page, FPS_SAMPLE_MS);
    if (s.ran === false) return;
    const ok = s.fps >= MIN_FPS;
    ctx.info(
      V,
      `play: on a phone's CPU (${PHONE_CPU_SLOWDOWN}× slower, a hint)`,
      `${s.fps.toFixed(1)} fps${s.mainMs !== null ? `, main thread ${s.mainMs.toFixed(1)} ms per frame` : ''}${ok ? '' : ` — under ${MIN_FPS}: it will stutter on a mid-range phone; bake, fewer particles on AutoQuality, no full-screen passes (docs/guides/art.md → Performance)`}`,
    );
  } catch {
    // No CDP (another browser): no hint
  } finally {
    await cdp?.send('Emulation.setCPUThrottlingRate', { rate: 1 }).catch(() => {});
    await cdp?.detach().catch(() => {});
  }
}

/** The frame rate while playing, told from the machine's load (judgeFps): re-measured once when it is low and the machine busy */
async function fpsCheck(ctx: QaContext, page: Page, V: string): Promise<void> {
  const samples: FpsSample[] = [await sampleFps(page, FPS_SAMPLE_MS)];
  let load: ReturnType<typeof machineLoad> | null = null;
  let dropped = '';
  if (samples[0].fps < MIN_FPS) {
    load = machineLoad();
    if (load.busy) {
      await sleep(1000);
      // The re-run counts only if the game's loop ran through it (a run that ended meanwhile leaves QA's loop alone at 60 fps)
      const again = await sampleFps(page, FPS_SAMPLE_MS);
      if (again.ran === false) dropped = ` (a re-run didn't count: the game's loop stopped during it, ${again.fps.toFixed(1)} fps)`;
      else samples.push(again);
    }
  }
  const v = judgeFps(samples, load);
  ctx.check(V, `play: smooth (≥ ${MIN_FPS} fps in the browser, the machine's load told apart)`, v.ok, v.text + dropped);
  // Too slow for the look: the architecture changes, not the art (the owner, 2026-10-10: «если не получается добиться
  // хороших показателей производительности из-за архитектуры с учетом более сильной графики — меняй архитектуру»)
  if (!v.ok)
    ctx.info(V, 'play: too slow — change the architecture, not the art', 'profile the frame, then bake what doesn\'t change (Baked, SpriteCache), cache the layers, drop per-frame gradients, filters and shadowBlur — and if Canvas 2D still can\'t carry the look, move the drawing to WebGL (Pixi or three: docs/guides/code-games.md#engines). Never pass this by making the game uglier (docs/guides/art.md § 3)');
  // Two game loops draw every frame twice (Rivet Clash 2.0: a wake() inside update() started a second one, 60 → ~10 fps in
  // a battle). A hint, not a failure: a game may run a second requestAnimationFrame on purpose (a DOM tween)
  const loops = samples[0].loops;
  if (loops !== null && loops >= 1.8)
    ctx.info(V, 'play: more than one game loop (a hint)', `${loops.toFixed(1)} requestAnimationFrame callbacks per frame — if it is your main loop twice: in frame(), request the next frame only when none is pending (\`if (running() && !raf)\`), as the gp init skeleton does`);
}

async function runViewport(ctx: QaContext, vp: (typeof VIEWPORTS)[number], opts: { fps: boolean } = { fps: true }): Promise<void> {
  const { game, check, info } = ctx;
  const V = vp.name;
  const min = game.minTouchPx;
  // The checks that don't depend on the size run at the first one (the one --quick runs): glyphs, faces, the title's choices
  const first = vp.name === VIEWPORTS[0].name;
  const desktop = !vp.touch;
  const faces: FaceUse[] = [];
  const context = await ctx.browser.newContext({ viewport: { width: vp.width, height: vp.height }, hasTouch: vp.touch, isMobile: vp.touch });
  await context.addInitScript(installProbe);
  const page = await context.newPage();
  const errors: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message));
  page.on('console', (m) => {
    if (m.type() === 'error' && !m.text().includes('favicon') && !m.text().includes(REFUSED)) errors.push(m.text());
  });
  /** The canvas UI the game declares on this screen, checked like its DOM buttons */
  const canvasUiCheck = async (screen: string) => {
    const cu = await canvasUi(page, min);
    if (cu && cu.rects.length + cu.bad.length > 0)
      check(V, `${screen}: canvas UI (host.qa canvasUi) on screen, buttons ≥ ${min} px with no DOM on top`, cu.bad.length === 0, cu.bad.join('; ') || `${cu.rects.length} rects: ${cu.rects.map((r) => r.name).join(', ')}`);
  };
  try {
    await page.goto(`${ctx.url}?seed=7`);
    await page.waitForFunction(() => window.__gp?.host && window.__portal?.calls.some((c) => c.fn === 'loadingStop'), null, { timeout: 20000 });
    await sleep(500);
    const boot = await page.evaluate(() => window.__portal.calls.map((c) => c.fn));
    check(V, 'portal: init → loadingStart → loadingStop', boot.slice(0, 3).join() === 'init,loadingStart,loadingStop', boot.join(', '));
    check(V, 'first screen: not gameplay yet (menus are breaks)', !boot.includes('gameplayStart'));
    const firstShot = await page.screenshot({ path: `${ctx.outDir}/${V}-1-first-screen.png` });
    if (desktop) await desktopLook(ctx, page, V, 'first screen', firstShot);
    if (first) {
      await glyphCheck(ctx, page, V, 'first screen');
      faces.push(...(await faceUses(page)));
    }
    const t1 = await tappables(page, min);
    check(V, `first screen: buttons on screen and ≥ ${min} px`, t1.bad.length === 0, t1.bad.join('; ') || tapInfo(t1));
    await canvasUiCheck('first screen');
    const hasPlay = await page.locator('[data-gp=play]').first().isVisible().catch(() => false);
    check(V, 'first screen: the Play button has data-gp="play" (the production check taps it)', hasPlay);
    await stillCheck(ctx, page, V, 'first screen', 'title');
    const driver = await page.evaluate(() => {
      const d = window.__gp.host.qaDriver;
      return d ? { play: typeof d.play === 'function', end: typeof d.end === 'function', lose: typeof d.lose === 'function' } : null;
    });
    check(V, 'dev: the game registers host.qa({ play, end })', !!driver?.play && !!driver.end, JSON.stringify(driver));
    if (!driver?.play || !driver.end) return;

    // Play with a real tap: gameplay starts
    if (hasPlay) await tapSelector(page, '[data-gp=play]', vp.touch);
    else await page.evaluate(() => window.__gp.host.qaDriver.play());
    await page.waitForFunction(() => window.__portal.calls.at(-1)?.fn === 'gameplayStart', null, { timeout: 5000 }).catch(() => {});
    check(V, 'play: gameplayStart when the run starts', (await lastGameplay(page)) === 'gameplayStart');
    // A story scene right after Play (data-gp="dialog", mountDialogue marks it): it must be skippable, and the words a new
    // player meets before the first action are reported (docs/guides/story.md: ≤ 20 before the first action)
    await sleep(300);
    const dialog = await page.evaluate(() => {
      const d = document.querySelector<HTMLElement>('[data-gp=dialog]');
      const r = d?.getBoundingClientRect();
      if (!d || !r || r.width === 0 || r.height === 0 || getComputedStyle(d).display === 'none') return null;
      const skip = d.querySelector<HTMLElement>('[data-gp=dialog-skip]');
      const sr = skip?.getBoundingClientRect();
      return { skip: !!sr && sr.width > 0 && sr.height > 0, words: (d.innerText.match(/[\p{L}\p{N}']+/gu) ?? []).length };
    });
    if (dialog) {
      check(V, 'story: a dialog right after Play has a visible Skip (data-gp="dialog-skip")', dialog.skip);
      info(V, 'story: words on screen before the first action (≤ 20 is the rule)', String(dialog.words));
      await page.locator('[data-gp=dialog-skip]').first().click().catch(() => {});
      await sleep(300);
    }
    // The portal's mute setting (CrazyGames settings.muteAudio) silences the host's audio, and un-muting brings it back.
    // It is on from here to the results: the sounds of play, a Resume tap and the end (a death sting) must stay silent
    const muted = await page.evaluate(() => {
      (window.__portal as unknown as { setMuted(m: boolean): void }).setMuted(true);
      return { on: window.__gp.host.portalMuted as boolean, t: performance.now() };
    });
    // Move a bit (keys and a drag both work for games that steer; others ignore it). In a puzzle, D can be a whole move:
    // Nimbus Drift's first level was solved by one swipe right, so the run ended here and end() counted a second roundEnd
    const endsBeforeMove = await roundEnds(page);
    await page.keyboard.down('KeyD');
    await sleep(400);
    await page.keyboard.up('KeyD');
    // A solved level shows its result after a short beat (Nimbus Drift: ½ s): give it a second
    await page.waitForFunction((n) => window.__gp.events.count('round:end') > n, endsBeforeMove, { timeout: 1200 }).catch(() => {});
    if ((await roundEnds(page)) > endsBeforeMove) {
      info(V, 'play: holding D (the steering test) ended the run by itself', 'a first level one move right solves — QA starts the run again with host.qa play(); better make level 1 need another move');
      await page.evaluate(() => window.__gp.host.qaDriver.play());
      await page.waitForFunction(() => window.__portal.calls.at(-1)?.fn === 'gameplayStart', null, { timeout: 5000 }).catch(() => {});
    }
    const endsBase = await roundEnds(page);
    await sleep(300);
    // The hero at the start of the run (a run may end before the play screenshot), and a three game's camera in portrait
    await heroCheck(ctx, page, V, { gate: first });
    await fovCheck(ctx, page, V);
    // The frame rate is measured here when sections run one at a time; in parallel, alone at the end (runFps), and the
    // play screenshot still comes as far into the run
    if (opts.fps) {
      await fpsCheck(ctx, page, V);
      if (vp.touch) await phoneFpsHint(ctx, page, V);
    } else await sleep(FPS_SAMPLE_MS);
    const playShot = await page.screenshot({ path: `${ctx.outDir}/${V}-2-play.png` });
    // The look, as a hint (never a failure): a play frame that is mostly one flat colour, few values, featureless areas
    const look = await flatFrameOf(page, playShot).catch(() => null);
    if (look) info(V, `look: depth in the play frame (${look.flat ? 'flat — a hint' : 'a hint, fine'})`, flatText(look));
    if (desktop) await desktopLook(ctx, page, V, 'play', playShot, { recheck: `${ctx.outDir}/${V}-2-play-again.png` });
    // The HUD in play: no text over another, over a button or a touch control, none off the frame — measured again
    // 400 ms later, so a text sliding in doesn't count
    const hud0 = await playTextFindings(page);
    let hud = hud0;
    if (hud0.length) {
      await sleep(400);
      const same = (a: PlayTextFinding, b: PlayTextFinding) => a.kind === b.kind && a.text === b.text && (a.kind === 'off-frame' || a.where === b.where);
      hud = (await playTextFindings(page)).filter((f) => hud0.some((g) => same(f, g)));
    }
    check(V, 'play: no HUD text over another text, a button or a touch control, none off the frame', hud.length === 0, hud.length ? `${hud.slice(0, 4).map(playTextLine).join('; ')}${hud.length > 4 ? ` (+${hud.length - 4} more)` : ''} — give each HUD text its own place (E_QA_HUD_OVERLAP)` : '');
    if (first) {
      await glyphCheck(ctx, page, V, 'play');
      faces.push(...(await faceUses(page)));
    }
    const t2 = await tappables(page, min);
    check(V, `play: buttons on screen and ≥ ${min} px`, t2.bad.length === 0, t2.bad.join('; ') || tapInfo(t2));
    await canvasUiCheck('play');

    // A hidden tab stops gameplay and sound; coming back is the game's call (a pause screen is fine)
    await setHidden(page, true);
    await sleep(300);
    const hid = await page.evaluate(() => ({ paused: window.__gp.host.paused, audio: window.__gp.host.audio?.ctx.state ?? 'none' }));
    check(V, 'hidden tab: gameplayStop, the game is paused, sound suspended', (await lastGameplay(page)) === 'gameplayStop' && hid.paused && hid.audio !== 'running', `audio ${hid.audio}`);
    await setHidden(page, false);
    await sleep(300);
    check(V, 'tab back: the host is no longer paused', !(await page.evaluate(() => window.__gp.host.paused)));
    // The game may show its own pause screen after a hidden tab: nothing may run there; then go on with the run
    if (!(await page.evaluate(() => window.__portal.calls.at(-1)?.fn === 'gameplayStart'))) {
      await stillCheck(ctx, page, V, 'pause screen (after a hidden tab)', 'pause');
      const resumed = (await tapSelector(page, '[data-gp=resume]', vp.touch)) || (await tapSelector(page, 'button:has-text("Resume")', vp.touch));
      if (!resumed) await page.evaluate(() => window.__gp.host.qaDriver.play());
      await sleep(300);
    }

    // End the run: one round:end, gameplay stops, progress saved
    await page.evaluate(() => window.__gp.host.qaDriver.end());
    await sleep(600);
    const ends = (await roundEnds(page)) - endsBase;
    check(V, 'end: host.roundEnd() once per run', ends === 1, `round:end × ${ends}`);
    check(V, 'end: gameplayStop on the results screen', (await lastGameplay(page)) === 'gameplayStop');
    const resultsShot = await page.screenshot({ path: `${ctx.outDir}/${V}-3-results.png` });
    if (desktop) await desktopLook(ctx, page, V, 'results', resultsShot);
    if (first) {
      await glyphCheck(ctx, page, V, 'results');
      faces.push(...(await faceUses(page)));
    }
    const t3 = await tappables(page, min);
    check(V, `results: buttons on screen and ≥ ${min} px`, t3.bad.length === 0, t3.bad.join('; ') || tapInfo(t3));
    const primary = await resultsPrimary(page);
    if (primary) check(V, 'results: the primary action continues play (the biggest button is "Play again" / "Next": data-gp="again" / "next")', primary.ok, primary.text);
    else info(V, 'results: the primary action continues play', 'no buttons on the results screen (it goes on by itself?) — not checked');
    await canvasUiCheck('results');
    const heard = await audioReport(page, muted.t);
    const off = await page.evaluate(() => {
      (window.__portal as unknown as { setMuted(m: boolean): void }).setMuted(false);
      return window.__gp.host.portalMuted as boolean;
    });
    check(V, "portal mute setting: the host's sound goes silent and comes back", muted.on && !off, JSON.stringify({ on: muted.on, off }));
    if (heard && heard.startedSince === 0) info(V, 'portal mute: no sound plays while it is on', 'no sound started while muted (play, Resume, the end) — not checked');
    else if (heard)
      check(
        V,
        'portal mute: no sound plays while it is on',
        heard.audibleSince === 0,
        `${heard.startedSince} started while muted, ${heard.audibleSince} audible${heard.audibleSince ? ': connect every sound to host.audio.out (the host mutes it), never to ctx.destination or another AudioContext' : ''}`,
      );
    // The whole session so far (title, play, the end): one AudioContext — the host's —, every sound through its output
    if (heard) {
      check(
        V,
        "sound: one AudioContext on the page, the host's",
        heard.others === 0,
        `${heard.contexts} AudioContext(s)${heard.others ? `, ${heard.others} not the host's (${heard.otherStates.join('; ')}): an engine or a library made its own — hand it host.audio.ctx, or keep it from being made (a second context isn't paused for ads, hidden tabs or the portal mute)` : ''}`,
      );
      if (heard.sounds + heard.media === 0) info(V, 'sound: every sound through host.audio.out', 'no sound started in this session — not checked');
      else
        check(
          V,
          'sound: every sound goes through host.audio.out (what the portal mute and the ad pause silence)',
          heard.bypass === 0 && heard.otherContext === 0 && heard.media === 0,
          `${heard.sounds} sounds started${heard.bypass ? `, ${heard.bypass} reach the speakers around host.audio.out` : ''}${heard.otherContext ? `, ${heard.otherContext} on another AudioContext` : ''}${heard.media ? `, ${heard.media} <audio>/<video> elements played: they bypass the host — decode them into host.audio.ctx` : ''}`,
        );
    }
    const saved = await page.evaluate((k) => localStorage.getItem(k), game.saveKey);
    check(V, `save: progress written under "${game.saveKey}" after the run`, !!saved, saved?.slice(0, 120) ?? 'nothing');
    // Play again is a natural break, but no midgame ad in the first minute
    const again = await tapSelector(page, '[data-gp=again]', vp.touch);
    await sleep(800);
    const adShown = await page.evaluate(() => !!document.querySelector('[data-test-ad]'));
    if (again) check(V, 'play again: no midgame ad in the first minute', !adShown);
    // What a reload must keep is the save as it is right before the reload. Play again may already have written it (a run
    // counter, "chapter seen" at a run's start — Candle Crypt, Brew & Banter): that is said, and not what this check fails on
    const beforeReload = await page.evaluate((k) => localStorage.getItem(k), game.saveKey);
    if (again && beforeReload !== saved)
      info(V, 'save: Play again wrote the save at the start of the next run', `changed: ${changedKeys(saved, beforeReload)} — fine for a counter; a reward written at a run's start pays twice after a reload`);
    await page.reload();
    await page.waitForFunction(() => window.__gp?.host, null, { timeout: 20000 });
    await sleep(300);
    const after = await page.evaluate((k) => localStorage.getItem(k), game.saveKey);
    // The offline stamp (stampOffline on pagehide, offlineEarnings at start) may move: the rest must not
    const same = withoutOfflineStamp(after) === withoutOfflineStamp(beforeReload);
    check(V, 'save: survives a reload unchanged', same, same ? `${after?.slice(0, 120) ?? 'nothing'}${after !== beforeReload ? ' (only the offline stamp moved)' : ''}` : `the reload changed: ${changedKeys(beforeReload, after)} (a save written while loading or on leaving the page)`);
    // The title as a returning player sees it after a run: every choice it offers (Frankengun's had 9)
    if (first) {
      if (await page.locator('[data-gp=play]').first().isVisible().catch(() => false)) {
        const choices = await titleChoices(page);
        const many = choices.length > TITLE_MAX_CHOICES;
        info(V, `title after the first run: at most ${TITLE_MAX_CHOICES} choices${many ? ' — W_TITLE_CHOICES (a warning)' : ''}`, `${choices.length}: ${choices.map((c) => `"${c}"`).join(', ')}${many ? ' — a new player reads every one before Play: keep Play big and alone, fold the rest into one menu (settings, language, credits) or open them later (W_TITLE_CHOICES)' : ''}`);
      } else info(V, `title after the first run: at most ${TITLE_MAX_CHOICES} choices`, 'after the reload no Play button is on screen (a resumed run?) — not counted');
    }
    // The progression screen, if the game has one (data-gp="shop": the platform's mountUpgradeShop or the game's own)
    if (await page.locator('[data-gp=shop]').first().isVisible().catch(() => false)) {
      const hasGrant = await page.evaluate(() => typeof window.__gp.host.qaDriver.grant === 'function');
      let granted = false;
      if (hasGrant) {
        const before = await page.evaluate((k) => localStorage.getItem(k), game.saveKey);
        await page.evaluate(() => window.__gp.host.qaDriver.grant(100000));
        await sleep(200);
        const after = await page.evaluate((k) => localStorage.getItem(k), game.saveKey);
        granted = after !== before;
        // QA reloads the page to show the granted currency: a grant that isn't saved is gone by then (Dread Throne)
        check(V, 'shop: host.qa grant() saves the currency (QA reloads the page)', granted, granted ? '' : "grant() didn't persist: call host.save() — host.qa({ grant: (n) => { save.coins += n; host.save(save); } })");
        // Re-open the first screen so it shows the granted coins
        await page.reload();
        await page.waitForFunction(() => window.__gp?.host, null, { timeout: 20000 });
        await sleep(300);
      }
      await tapSelector(page, '[data-gp=shop]', vp.touch);
      await page.waitForSelector('[data-gp=shop-screen], [data-gp-buy]', { timeout: 5000 }).catch(() => {});
      await sleep(300);
      const shopShot = await page.screenshot({ path: `${ctx.outDir}/${V}-4-shop.png` });
      if (desktop) await desktopLook(ctx, page, V, 'shop', shopShot);
      if (first) await glyphCheck(ctx, page, V, 'shop');
      const t4 = await tappables(page, min);
      check(V, `shop: buttons on screen and ≥ ${min} px`, t4.bad.length === 0, t4.bad.join('; ') || tapInfo(t4));
      const buy = page.locator('[data-gp-buy][aria-disabled=false]').first();
      if (await buy.isVisible().catch(() => false)) {
        const bal = page.locator('[data-gp=shop-balance]');
        const before = await bal.textContent().catch(() => null);
        if (vp.touch) await buy.tap();
        else await buy.click();
        await sleep(250);
        const after = await bal.textContent().catch(() => null);
        const undoVisible = await page.locator('[data-gp=shop-undo]').isVisible().catch(() => false);
        check(V, 'shop: a purchase spends coins and offers undo', before !== null && after !== before && undoVisible, `${before} → ${after}`);
        if (undoVisible) {
          await tapSelector(page, '[data-gp=shop-undo]', vp.touch);
          await sleep(250);
          check(V, 'shop: undo gives the coins back exactly', (await bal.textContent().catch(() => null)) === before, `${await bal.textContent().catch(() => '')}`);
        }
      } else ctx.info(V, 'shop: purchase', !hasGrant ? 'nothing affordable (the game has no host.qa grant()) — not checked' : granted ? 'nothing affordable after grant(100000) — not checked' : "nothing affordable: grant() didn't persist (call host.save()) — not checked");
      if (await tapSelector(page, '[data-gp=shop-back]', vp.touch)) {
        await sleep(300);
        check(V, 'shop: Back returns to a screen with Play', await page.locator('[data-gp=play]').first().isVisible().catch(() => false));
      }
    }
    check(V, 'gameplayStart/Stop always alternate', alternate(await gameplayCalls(page)), (await gameplayCalls(page)).join(','));
    await magnifiedCheck(ctx, page, V);
    if (first) {
      faces.push(...(await faceUses(page, true)));
      const fv = systemFontVerdict(faces);
      info(V, `text: in a face the game loaded, not the system's${fv.warn ? ' — W_SYSTEM_FONT (a warning)' : ''}`, fv.text + (fv.warn ? ' (W_SYSTEM_FONT)' : ''));
    }
    check(V, 'console: no errors', errors.length === 0, errors.slice(0, 3).join(' | '));
  } finally {
    await context.close();
  }
}

/** Ads: midgame after the channel's first minute at a natural break; rewarded only after the player's tap */
async function runAds(ctx: QaContext): Promise<void> {
  const { game, check, info } = ctx;
  const S = 'ads';
  if (!game.ads) return info(S, 'ads', 'the game has no ads — skipped');
  const context = await ctx.browser.newContext({ viewport: { width: 1280, height: 720 } });
  await context.addInitScript(installProbe);
  const page = await context.newPage();
  try {
    await page.goto(ctx.url);
    await page.waitForFunction(() => window.__gp?.host?.qaDriver, null, { timeout: 20000 });
    // The player's first key unlocks the sound (the host makes its AudioContext): the ad below must silence a live one
    await page.keyboard.press('Shift');
    // Past the no-ads time, one run over: still too early if the channel waits for round N. With a time path
    // (firstAdAfterSec: CrazyGames, round 3 or 5 min, whichever comes first) the session is put just past the no-ads
    // time, inside the window; without one, an hour in
    const { firstAdAfterRound: first, firstAdAfterSec: bySec, noAdsAfterLaunchSec: quiet } = game.ads.policy;
    const windowOk = bySec === undefined || bySec - quiet >= 60;
    await page.evaluate(() => window.__gp.host.qaDriver.play());
    await sleep(300);
    await page.evaluate((ago) => {
      const st = window.__gp.host.ads.state;
      st.sessionStartSec = Math.min(st.sessionStartSec, performance.now() / 1000 - ago);
      return window.__gp.host.qaDriver.end();
    }, bySec === undefined || !windowOk ? 3600 : quiet + 5);
    await sleep(400);
    if (first > 1 && windowOk) {
      await page.evaluate(() => window.__gp.host.adBreak());
      const early = await page.evaluate(() => !!document.querySelector('[data-test-ad]'));
      check(S, `midgame: none before the end of round ${first}${bySec === undefined ? '' : ` while the session is under ${bySec} s`}`, !early);
      if (bySec === undefined) {
        // Pretend enough runs were played
        await page.evaluate((n) => (window.__gp.host.ads.state.roundsThisSession = n), first);
      } else {
        // The time path: an hour into the session, still before round N — the length alone lets the first ad through
        await page.evaluate(() => (window.__gp.host.ads.state.sessionStartSec -= 3600));
        info(S, 'midgame: the time path', `the first ad may come at round ${first} or after ${bySec} s of the session, whichever is first; checked at run 1 an hour in`);
      }
    }
    const breakDone = page.evaluate(() => window.__gp.host.adBreak());
    await page.waitForSelector('[data-test-ad=midgame]', { timeout: 5000 }).catch(() => {});
    const during = await page.evaluate(() => ({
      ad: !!document.querySelector('[data-test-ad=midgame]'),
      paused: window.__gp.host.paused,
      audio: window.__gp.host.audio?.ctx.state ?? 'none',
      last: window.__portal.calls.map((c) => c.fn).filter((f) => f.startsWith('gameplay')).at(-1),
    }));
    check(S, 'midgame: shows at a natural break once the limits allow', during.ad);
    check(S, 'midgame: the game is paused, sound off, no gameplay during the ad', during.paused && during.audio !== 'running' && during.last !== 'gameplayStart', JSON.stringify(during));
    if (during.ad) {
      // The ad is the screen: the game's loop stands still under it, and no engine resumes a sound (Phaser's sound manager
      // resumed the context every frame in the engine lab)
      const still = await stillness(page, 1200);
      const au = await audioReport(page);
      if (still) check(S, 'midgame: nothing runs during the ad — no requestAnimationFrame loop, no canvas frames', still.quiet, still.quiet ? still.text : `${still.text}: ${stillFix('ad')}`);
      if (au) check(S, 'midgame: every AudioContext on the page is silent during the ad', au.running === 0, `${au.contexts} AudioContext(s), ${au.running} running${au.running ? ': something resumed a context under the ad (an engine\'s sound manager, an unlock listener)' : ''}`);
    }
    await breakDone;
    check(S, 'midgame: the game goes on after the ad', !(await page.evaluate(() => window.__gp.host.paused)));
    // A second break right away: the channel's interval holds it back
    await page.evaluate(() => window.__gp.host.adBreak());
    check(S, 'midgame: not again within the channel interval', !(await page.evaluate(() => !!document.querySelector('[data-test-ad]'))), `${game.ads.policy.minIntervalSec} s`);

    if (!game.ads.rewarded) {
      info(S, 'rewarded', 'rewarded ads are off for this game/channel');
      return;
    }
    // Rewarded without the player's tap: refused
    const scripted = await page.evaluate(async () => {
      const ok = await window.__gp.host.rewarded('qa-scripted');
      return { ok, ad: !!document.querySelector('[data-test-ad]') };
    });
    check(S, 'rewarded: refused without the player\'s tap', !scripted.ok && !scripted.ad);
    // Rewarded from its button, when the game offers one after losing
    const d = await page.evaluate(() => typeof window.__gp.host.qaDriver.lose === 'function');
    if (!d) {
      info(S, 'rewarded: from its button', 'the game has no host.qa lose() — not checked');
      return;
    }
    await page.evaluate(() => window.__gp.host.qaDriver.play());
    await sleep(600);
    const inPlay = await page.locator('[data-gp-rewarded]:visible').first().isVisible().catch(() => false);
    check(S, 'rewarded: no offer on the active gameplay screen', !inPlay);
    await page.evaluate(() => window.__gp.host.qaDriver.lose());
    const btn = page.locator('[data-gp-rewarded]:visible').first();
    if (!(await offerAppears(page))) {
      info(S, 'rewarded: from its button', `no [data-gp-rewarded] button within ${OFFER_WAIT_MS / 1000} s of losing — not checked`);
      return;
    }
    const placement = await btn.getAttribute('data-gp-rewarded');
    // CrazyGames: the "continue without watching" choice is there at once, "the same size, font, color" as the offer
    const parity = await page.evaluate(() => {
      const vis = (b: HTMLElement) => {
        const r = b.getBoundingClientRect();
        const st = getComputedStyle(b);
        return r.width > 0 && r.height > 0 && st.visibility !== 'hidden' && st.display !== 'none';
      };
      const ad = [...document.querySelectorAll<HTMLElement>('[data-gp-rewarded]')].find(vis)!;
      const others = [...document.querySelectorAll<HTMLElement>('button, [role=button]')].filter((b) => b !== ad && vis(b) && !b.hasAttribute('data-gp-rewarded'));
      const desc = (b: HTMLElement) => {
        const r = b.getBoundingClientRect();
        const st = getComputedStyle(b);
        return { text: (b.textContent ?? '').trim().slice(0, 24), w: r.width, h: r.height, font: parseFloat(st.fontSize), bg: st.backgroundColor, color: st.color };
      };
      const a = desc(ad);
      // The skip choice: the biggest other button on the offer screen
      const skip = others.map(desc).sort((x, y) => y.w * y.h - x.w * x.h)[0] ?? null;
      return { a, skip };
    });
    const { a, skip } = parity;
    // One-sided: a skip bigger than the offer is fine; a smaller, fainter one is the dark pattern the portal names
    const same = !!skip && skip.h >= a.h * 0.85 && skip.w >= a.w * 0.6 && skip.font >= a.font * 0.9;
    check(S, 'rewarded: a "no thanks" choice is on the offer screen at once, at least as big and in the same font size as the offer', same, skip ? `offer "${a.text}" ${Math.round(a.w)}×${Math.round(a.h)} ${a.font}px · skip "${skip.text}" ${Math.round(skip.w)}×${Math.round(skip.h)} ${skip.font}px` : 'no other button');
    if (skip && (skip.bg !== a.bg || skip.color !== a.color)) info(S, 'rewarded: offer and skip colours differ (CrazyGames asks for the same colour)', `offer ${a.bg} / ${a.color} · skip ${skip.bg} / ${skip.color}`);
    await btn.click();
    await page.waitForSelector('[data-test-ad=rewarded]', { timeout: 5000 }).catch(() => {});
    const r = await page.evaluate(() => ({ ad: !!document.querySelector('[data-test-ad=rewarded]'), paused: window.__gp.host.paused }));
    check(S, `rewarded: "${placement}" button shows the ad, the game waits`, r.ad && r.paused);
    await page.waitForFunction(() => window.__gp.events.count('ad:rewarded') >= 2, null, { timeout: 15000 }).catch(() => {});
    const ev = await page.evaluate(() => window.__gp.events.log.filter((e: any) => e.type === 'ad:rewarded').at(-1)?.data);
    check(S, 'rewarded: watched to the end → the game gets ok = true', ev?.ok === true, JSON.stringify(ev));
    await page.screenshot({ path: `${ctx.outDir}/ads-after-rewarded.png` });
    await lateReward(ctx, page);
  } finally {
    await context.close();
  }
  await runAdsFail(ctx);
}

/**
 * The offer tapped, then "No thanks" under the loading ad (a tap that lands before the portal's overlay covers the page,
 * or Enter on the focused button), then the reward arrives: Frankengun's code review, bug #1 — the skip ended the run,
 * the late reward revived it over the results screen, a softlock at the next death. Under the pending ad the other
 * buttons must be out of reach (the host makes #ui inert; rewardedOffer() disables its skip), and a reward that comes
 * after the run ended must change nothing.
 */
async function lateReward(ctx: QaContext, page: Page): Promise<void> {
  const { check, info } = ctx;
  const S = 'ads';
  await page.waitForFunction(() => !window.__gp.host.adPending, null, { timeout: 10000 }).catch(() => {});
  await page.evaluate(() => window.__gp.host.qaDriver.end());
  await sleep(400);
  await page.evaluate(() => window.__gp.host.qaDriver.play());
  await sleep(600);
  await page.evaluate(() => window.__gp.host.qaDriver.lose!());
  if (!(await offerAppears(page))) return info(S, 'rewarded: a late reward after "No thanks"', `no second offer within ${OFFER_WAIT_MS / 1000} s of losing a new run — not checked`);
  const before = await page.evaluate(() => ({ ended: window.__gp.events.count('round:end'), ads: window.__gp.events.count('ad:rewarded') }));
  await page.locator('[data-gp-rewarded]:visible').first().click();
  const under = await page.evaluate(() => {
    const vis = (b: HTMLElement) => {
      const r = b.getBoundingClientRect();
      const st = getComputedStyle(b);
      return r.width > 0 && r.height > 0 && st.visibility !== 'hidden' && st.display !== 'none';
    };
    const skip =
      [...document.querySelectorAll<HTMLElement>('button, [role=button]')]
        .filter((b) => vis(b) && !b.hasAttribute('data-gp-rewarded') && !b.closest('[data-test-ad]'))
        .sort((x, y) => y.getBoundingClientRect().width * y.getBoundingClientRect().height - x.getBoundingClientRect().width * x.getBoundingClientRect().height)[0] ?? null;
    const blocked = !skip || (skip as HTMLButtonElement).disabled || skip.getAttribute('aria-disabled') === 'true' || !!skip.closest('[inert]');
    const text = (skip?.textContent ?? '').trim().slice(0, 24);
    const pending = window.__gp.host.adPending;
    // The tap that slipped through before the ad covered the page
    skip?.click();
    return { blocked, text, pending, found: !!skip };
  });
  if (!under.found) return info(S, 'rewarded: a late reward after "No thanks"', 'no other button on the offer screen — not checked');
  check(S, 'rewarded: under the pending ad the other buttons are out of reach (the UI inert, or disabled)', !under.pending || under.blocked, `"${under.text}"${under.blocked ? '' : ' is live under the ad: put it in #ui (the host makes it inert) or use rewardedOffer()'}`);
  await page.waitForFunction((n) => window.__gp.events.count('ad:rewarded') > n, before.ads, { timeout: 15000 }).catch(() => {});
  await sleep(600);
  const after = await page.evaluate(() => ({ ended: window.__gp.events.count('round:end'), playing: window.__gp.host.isPlaying }));
  if (after.ended > before.ended)
    check(S, 'rewarded: a reward that arrives after "No thanks" ended the run changes nothing (the run stays over)', !after.playing, after.playing ? 'the late reward put the ended run back into play: ignore it (rewardedOffer() does, or check the run is still on in onReward)' : '');
  else info(S, 'rewarded: a late reward after "No thanks"', `"${under.text}" did nothing under the ad (disabled): the reward went to the offer`);
}

/**
 * Every ad fails (`?ads=fail`): an ad blocker, no fill, or CrazyGames' Basic Launch, where monetization is off. A midgame
 * break must let the game go on; a rewarded button must say it failed (Petri Panic's run silently ended instead) and
 * leave the player a way on, and no more rewarded buttons are offered that session (Yeet the Gnome's rule).
 */
async function runAdsFail(ctx: QaContext): Promise<void> {
  const { game, check, info } = ctx;
  const S = 'ads fail';
  if (!game.ads) return;
  const context = await ctx.browser.newContext({ viewport: { width: 1280, height: 720 } });
  const page = await context.newPage();
  try {
    await page.goto(`${ctx.url}${ctx.url.includes('?') ? '&' : '?'}ads=fail`);
    await page.waitForFunction(() => window.__gp?.host?.qaDriver, null, { timeout: 20000 });
    await page.evaluate(() => window.__gp.host.qaDriver.play());
    await sleep(300);
    await page.evaluate(() => {
      window.__gp.host.ads.state.sessionStartSec -= 3600;
      window.__gp.host.ads.state.roundsThisSession = 99;
      return window.__gp.host.qaDriver.end();
    });
    await sleep(400);
    const broke = await page.evaluate(async () => {
      await window.__gp.host.adBreak();
      return { paused: window.__gp.host.paused, pending: window.__gp.host.adPending };
    });
    check(S, 'midgame: a failed ad lets the game go on (not paused, nothing pending)', !broke.paused && !broke.pending, JSON.stringify(broke));
    if (!game.ads.rewarded) return;
    const lose = await page.evaluate(() => typeof window.__gp.host.qaDriver.lose === 'function');
    if (!lose) return info(S, 'rewarded', 'the game has no host.qa lose() — not checked');
    await page.evaluate(() => window.__gp.host.qaDriver.play());
    await sleep(300);
    await page.evaluate(() => window.__gp.host.qaDriver.lose());
    const btn = page.locator('[data-gp-rewarded]:visible').first();
    if (!(await offerAppears(page))) return info(S, 'rewarded', `no [data-gp-rewarded] button within ${OFFER_WAIT_MS / 1000} s of losing — not checked`);
    const label = (await btn.textContent())?.trim() ?? '';
    const others = async () =>
      page.evaluate(() =>
        [...document.querySelectorAll<HTMLElement>('button, [role=button]')].filter((b) => {
          const r = b.getBoundingClientRect();
          return r.width > 0 && r.height > 0 && !b.hasAttribute('data-gp-rewarded') && !(b as HTMLButtonElement).disabled;
        }).length,
      );
    await btn.click();
    await sleep(1200);
    const after = await page.evaluate(() => {
      const b = [...document.querySelectorAll<HTMLButtonElement>('[data-gp-rewarded]')].find((x) => x.getBoundingClientRect().width > 0) ?? null;
      const r = b?.getBoundingClientRect();
      const visible = !!b && !!r && r.width > 0 && r.height > 0;
      return {
        visible,
        text: b?.textContent?.trim() ?? '',
        disabled: !!b && (b.disabled || b.getAttribute('aria-disabled') === 'true'),
        // Anything on screen that tells the player why nothing happened
        told: /no ads?\b|not available|unavailable|couldn.?t (load|show)|try again later/i.test(document.body.innerText),
        available: window.__gp.host.rewardedAvailable,
        paused: window.__gp.host.paused,
      };
    });
    check(S, 'rewarded: a failed ad says so ("No ad available right now"), never a silent nothing', after.told, `"${label}" → ${after.visible ? `"${after.text}"${after.disabled ? ', disabled' : ''}` : 'button gone'}`);
    const left = await others();
    const playing = (await lastGameplay(page)) === 'gameplayStart';
    check(S, 'rewarded: after a failed ad the player can go on (a button or the game running, not paused)', !after.paused && (left > 0 || playing), `other buttons: ${left}${playing ? ', playing' : ''}`);
    check(S, 'rewarded: after a failure the host offers no more (rewardedAvailable = false)', after.available === false);
    await page.screenshot({ path: `${ctx.outDir}/ads-fail-rewarded.png` });
    // The next screen with an offer: none this session
    await page.evaluate(() => window.__gp.host.qaDriver.play());
    await sleep(300);
    await page.evaluate(() => window.__gp.host.qaDriver.lose());
    const again = await offerAppears(page);
    check(S, 'rewarded: no more rewarded buttons that session after one failed', !again);
  } finally {
    await context.close();
  }
}

/**
 * The buttons on the results screen that lead to a menu rather than into the next run, best first (what a player taps
 * to leave): Menu / Home / Title / Back / Quit, then a level map, then Shop / Settings
 */
export const NAV_BUTTON = [/^(main menu|menu|home|title|title screen|quit|exit|back)\b/i, /^(map|levels?|level select|nights|stages)\b/i, /^(shop|store|settings|options)\b/i];

/** The navigational button to tap among the results screen's labels, or -1: never Play again, an offer or Play */
export function pickNavButton(labels: readonly { text: string; gp?: string | null; rewarded?: boolean }[]): number {
  for (const re of NAV_BUTTON) {
    const i = labels.findIndex((b) => !b.rewarded && b.gp !== 'again' && b.gp !== 'play' && re.test(b.text.replace(/^[^\p{L}\p{N}]+/u, '').trim()));
    if (i >= 0) return i;
  }
  return -1;
}

/**
 * No midgame ad on a navigational button (CrazyGames: "Do not show a midgame ad on a navigational button (e.g. when
 * clicking the main menu icon …)", D51). The results screen's Menu must not call host.adBreak(): the break goes on the
 * way into the next run. Echoflies' review found it in its own game; Candle Crypt, Spin Brawl and Brew & Banter shipped
 * it. host.adBreak() is counted whether or not the channel's limits would let an ad through.
 */
async function runAdsNav(ctx: QaContext): Promise<void> {
  const { game, check, info } = ctx;
  const S = 'ads';
  if (!game.ads) return;
  const context = await ctx.browser.newContext({ viewport: { width: 1280, height: 720 } });
  const page = await context.newPage();
  try {
    await page.goto(ctx.url);
    await page.waitForFunction(() => window.__gp?.host?.qaDriver, null, { timeout: 20000 });
    await page.evaluate(() => window.__gp.host.qaDriver.play());
    await sleep(300);
    await page.evaluate(() => window.__gp.host.qaDriver.end());
    // Past a results screen's guard against a stray tap (Echoflies ignores taps in its first 350 ms)
    await sleep(700);
    const labels = await page.evaluate(() => {
      const w = window as unknown as { __gpQaBreaks: number };
      const host = window.__gp.host;
      const adBreak = host.adBreak;
      w.__gpQaBreaks = 0;
      host.adBreak = function (this: unknown, ...args: unknown[]) {
        w.__gpQaBreaks++;
        return adBreak.apply(this, args);
      };
      const shown = [...document.querySelectorAll<HTMLElement>('button, [role=button]')].filter((b) => {
        const r = b.getBoundingClientRect();
        const st = getComputedStyle(b);
        return r.width > 0 && r.height > 0 && st.visibility !== 'hidden' && st.display !== 'none' && !(b as HTMLButtonElement).disabled;
      });
      shown.forEach((b, i) => (b.dataset.gpQaNav = String(i)));
      return shown.map((b) => ({ text: (b.textContent ?? '').trim() || b.getAttribute('aria-label') || '', gp: b.dataset.gp ?? null, rewarded: b.hasAttribute('data-gp-rewarded') }));
    });
    const i = pickNavButton(labels);
    if (i < 0) {
      info(S, 'midgame: not on a navigational button', `no Menu, Home, Back, map or Shop button on the results screen (${labels.map((l) => `"${l.text.slice(0, 20)}"`).join(', ') || 'no buttons'}) — not checked`);
      return;
    }
    await page.locator(`[data-gp-qa-nav="${i}"]`).click();
    await sleep(800);
    const breaks = await page.evaluate(() => (window as unknown as { __gpQaBreaks: number }).__gpQaBreaks);
    check(
      S,
      'midgame: not on a navigational button (the results screen\'s Menu asks for no ad)',
      breaks === 0,
      `"${labels[i].text.slice(0, 24)}"${breaks ? ` called host.adBreak() ${breaks}×: CrazyGames — "Do not show a midgame ad on a navigational button". Put the break on the way into the next run (Play again, Next level), never on Menu, Shop or Settings` : ''}`,
    );
  } finally {
    await context.close();
  }
}

/**
 * Samples the screen from the Play tap on, on every animation frame (a 30 ms flash is two frames): is the phrase visible — in the DOM
 * (the smallest rendered element whose text holds it: ≥ 90 % of it on screen, opacity ≥ 0.5 up its ancestors, text
 * ≥ 12 px) or in a host.qa canvasUi rect whose `text` holds it (on screen, fontPx ≥ 12 when given) — and the first time
 * the twist event fires. Exported for the browser test
 */
export async function startExplanationSampler(page: Page, phrase: string, event: string): Promise<void> {
  await page.evaluate(
    ({ phrase, event, minPx }) => {
      const norm = (s: string) => s.normalize('NFKC').replace(/[\u2018\u2019]/g, "'").replace(/[\u201c\u201d]/g, '"').replace(/\s+/g, ' ').trim().toLowerCase();
      const P = norm(phrase);
      const st: { t0: number | null; twistAt: number | null; samples: { t: number; visible: boolean; text?: string; where?: string; why?: string }[]; stop: boolean } = {
        t0: null,
        twistAt: null,
        samples: [],
        stop: false,
      };
      (window as any).__gpExplain = st;
      // The Play tap starts the clock (a click, a tap or host.qa play(): the first pointer or the first gameplayStart)
      const start = () => {
        if (st.t0 === null) st.t0 = performance.now();
      };
      window.addEventListener('pointerdown', start, { capture: true, once: true });
      window.__gp.events.on((e: any) => {
        if (e.type === 'twist' && e.data?.event === event && st.twistAt === null && st.t0 !== null) st.twistAt = (performance.now() - st.t0) / 1000;
      });
      const rendered = (el: Element) => el.getClientRects().length > 0;
      const look = (): { visible: boolean; text?: string; where?: string; why?: string } => {
        const W = innerWidth;
        const H = innerHeight;
        let why: string | undefined;
        if (norm(document.body.innerText).includes(P)) {
          let el: HTMLElement = document.body;
          for (;;) {
            const next = [...el.children].find((c): c is HTMLElement => c instanceof HTMLElement && rendered(c) && norm(c.innerText).includes(P));
            if (!next) break;
            el = next;
          }
          const r = el.getBoundingClientRect();
          const ix = Math.max(0, Math.min(r.right, W) - Math.max(r.left, 0));
          const iy = Math.max(0, Math.min(r.bottom, H) - Math.max(r.top, 0));
          let opacity = 1;
          for (let p: HTMLElement | null = el; p; p = p.parentElement) opacity *= Number(getComputedStyle(p).opacity);
          const font = parseFloat(getComputedStyle(el).fontSize);
          const text = el.innerText.replace(/\s+/g, ' ').trim();
          if (r.width * r.height === 0 || (ix * iy) / (r.width * r.height) < 0.9) why = 'off screen';
          else if (opacity < 0.5) why = `faded (opacity ${opacity.toFixed(2)})`;
          else if (font < minPx - 0.01) why = `${font.toFixed(1)} px text (under ${minPx})`;
          else return { visible: true, text, where: 'dom' };
        }
        const d = window.__gp.host.qaDriver;
        if (typeof d?.canvasUi === 'function') {
          let rects: any[] = [];
          try {
            rects = d.canvasUi() ?? [];
          } catch {
            rects = [];
          }
          for (const r of Array.isArray(rects) ? rects : []) {
            if (typeof r?.text !== 'string' || !norm(r.text).includes(P)) continue;
            const on = r.x >= -1 && r.y >= -1 && r.x + r.w <= W + 1 && r.y + r.h <= H + 1;
            if (!on) why = 'off screen (canvas)';
            else if (r.fontPx !== undefined && r.fontPx < minPx - 0.01) why = `${Number(r.fontPx).toFixed(1)} px canvas text (under ${minPx})`;
            else return { visible: true, text: r.text.replace(/\s+/g, ' ').trim(), where: 'canvas' };
          }
        }
        return { visible: false, why };
      };
      let last = -Infinity;
      const frame = () => {
        if (st.stop) return;
        requestAnimationFrame(frame);
        const now = performance.now();
        if (st.t0 === null && window.__portal?.calls.some((c) => c.fn === 'gameplayStart')) start();
        if (st.t0 === null || now - last < 12 || st.samples.length > 20000) return;
        last = now;
        st.samples.push({ t: (now - st.t0) / 1000, ...look() });
      };
      requestAnimationFrame(frame);
    },
    { phrase, event, minPx: MIN_TEXT_PX },
  );
}

/** The sampled run so far */
async function explanationState(page: Page): Promise<{ samples: ExplainSample[]; twistAt: number | null }> {
  return page.evaluate(() => {
    const st = (window as any).__gpExplain;
    return { samples: st.samples, twistAt: st.twistAt };
  });
}

/**
 * Once the twist check is done: watch on until the explanation has been readable long enough, it is gone past the twist
 * (+ the grace), or the longest a text can need has passed — at most MAX_READING_SEC + 1.5 s after the twist (or now,
 * when it never fired). Exported for the browser test
 */
export async function finishExplanation(page: Page, phrase: string): Promise<ExplainVerdict> {
  const startedAt = Date.now();
  for (;;) {
    const { samples, twistAt } = await explanationState(page);
    const v = judgeExplanation({ samples, twistAt, phrase });
    const now = samples.at(-1)?.t ?? 0;
    const from = twistAt ?? now - (Date.now() - startedAt) / 1000;
    const settled = now > (twistAt ?? -Infinity) + EXPLAIN_GRACE_SEC && !samples.at(-1)?.visible;
    if (v.ok || settled || now > from + MAX_READING_SEC + 1.5 || Date.now() - startedAt > (MAX_READING_SEC + 3) * 1000) {
      await page.evaluate(() => ((window as any).__gpExplain.stop = true));
      return v;
    }
    await sleep(150);
  }
}

/**
 * The twist, in play: the game's demo bot plays a fresh run and the twist declared in concept.twist must happen
 * (host.twist(event)) within `within` seconds — the concept on paper has to be the game a new player meets. The result
 * goes to qa/uniqueness.json for `gp uniqueness` and `gp submission`.
 */
export async function runTwist(ctx: QaContext): Promise<void> {
  const { game, check, info } = ctx;
  const S = 'uniqueness';
  const twist = game.concept?.twist;
  const out = (data: Record<string, unknown>) => writeFileSync(join(ctx.outDir, 'uniqueness.json'), JSON.stringify({ at: new Date().toISOString(), ...data }, null, 2));
  if (!twist) {
    info(S, 'twist', 'no concept.twist declared: the twist is not checked in play (gp uniqueness scores it low)');
    out({ declared: false });
    return;
  }
  const within = twist.within ?? 30;
  const context = await ctx.browser.newContext({ viewport: { width: 1280, height: 720 } });
  const page = await context.newPage();
  try {
    await page.goto(ctx.url);
    await page.waitForFunction(() => window.__gp?.host?.qaDriver, null, { timeout: 20000 });
    if (twist.explained) await startExplanationSampler(page, twist.explained, twist.event);
    const play = page.locator('[data-gp=play]').first();
    if (await play.isVisible().catch(() => false)) await play.click();
    else await page.evaluate(() => window.__gp.host.qaDriver.play());
    const t0 = Date.now();
    const demo = await page.evaluate(() => {
      const d = window.__gp.host.qaDriver;
      if (typeof d.demo !== 'function') return false;
      d.demo();
      return true;
    });
    if (!demo) {
      check(S, `twist "${twist.event}": the demo bot can play (host.qa({ demo })), so QA can see the twist`, false, 'no demo() in host.qa');
      out({ declared: true, event: twist.event, within, demo: false, seenSec: null });
      return;
    }
    const seen = await page
      .waitForFunction((ev) => window.__gp.events.log.some((e: any) => e.type === 'twist' && e.data?.event === ev), twist.event, { timeout: within * 1000 })
      .then(() => (Date.now() - t0) / 1000)
      .catch(() => null);
    const other = await page.evaluate(() => [...new Set(window.__gp.events.log.filter((e: any) => e.type === 'twist').map((e: any) => e.data?.event))]);
    await page.screenshot({ path: `${ctx.outDir}/uniqueness-twist.png` });
    check(S, `twist "${twist.event}" happens within ${within} s of play (the demo bot playing)`, seen !== null, seen !== null ? `${seen.toFixed(1)} s` : other.length ? `other twist events fired: ${other.join(', ')}` : 'host.twist() never called');
    // The words that explain it: on screen before or when it fires, long enough to read (the same run, sampled from Play)
    let explained: ExplainVerdict | null = null;
    if (twist.explained) {
      explained = await finishExplanation(page, twist.explained);
      await page.screenshot({ path: `${ctx.outDir}/uniqueness-explained.png` });
      check(S, `twist explained: "${twist.explained}" readable before or when "${twist.event}" fires (2 s + 50 ms a character)`, explained.ok, explained.text);
    } else info(S, 'twist explained', 'no concept.twist.explained: whether a new player is told what the twist is is not checked (W_TWIST_UNEXPLAINED)');
    out({ declared: true, event: twist.event, within, demo: true, seenSec: seen, ...(explained ? { explained: { phrase: twist.explained, ok: explained.ok, needSec: explained.needSec, shownSec: explained.best ? explained.best.end - explained.best.start : 0, text: explained.text } } : {}) });
  } finally {
    await context.close();
  }
}

/**
 * Text a player can't read on the screen as it is (Candle Crypt's tools/responsive.mjs checked this on 13 screens × 12
 * sizes by hand): text off screen (outside a panel a player can scroll), text cut off by a box with overflow hidden or
 * clip (an ellipsis too), text spilling out of its button, and a page that scrolls. Text inside a panel the player can
 * scroll counts as reachable. Exported for the browser test
 */
export async function textFit(page: Page): Promise<{ offscreen: string[]; clipped: string[]; spills: string[]; scroll: boolean }> {
  return page.evaluate(() => {
    const W = innerWidth;
    const H = innerHeight;
    const offscreen = new Set<string>();
    const clipped = new Set<string>();
    const spills = new Set<string>();
    const root = document.scrollingElement;
    const scrollable = (p: Element) => {
      const st = getComputedStyle(p);
      return (/(auto|scroll)/.test(st.overflowY) && p.scrollHeight > p.clientHeight + 1) || (/(auto|scroll)/.test(st.overflowX) && p.scrollWidth > p.clientWidth + 1);
    };
    // Visually hidden on purpose — the sr-only pattern, text for a screen reader such as the dialogue's aria-live
    // .gp-live (Frankengun's QA flagged it as cut off): a box of 1 px or less that clips, clip: rect() of no area,
    // clip-path: inset(50%), or a live region placed off screen
    const srOnly = (el: Element) => {
      for (let p: Element | null = el; p && p !== document.body; p = p.parentElement) {
        const st = getComputedStyle(p);
        const b = p.getBoundingClientRect();
        if (b.width <= 1.5 && b.height <= 1.5 && /(hidden|clip)/.test(st.overflowX + st.overflowY)) return true;
        const rect = /^(absolute|fixed)$/.test(st.position) ? st.clip.match(/rect\(([^)]*)\)/) : null;
        const [t, r, bt, l] = rect ? rect[1]!.split(/[\s,]+/).map((v) => parseFloat(v)) : [];
        if (rect && [t, r, bt, l].every((v) => Number.isFinite(v)) && r! - l! <= 1 && bt! - t! <= 1) return true;
        if (/inset\(\s*(5\d|[6-9]\d|100)(\.\d+)?%/.test(st.clipPath)) return true;
        const live = p.hasAttribute('aria-live') || /^(status|alert|log|timer|marquee)$/.test(p.getAttribute('role') ?? '');
        if (live && (b.right <= 0 || b.bottom <= 0 || b.left >= innerWidth || b.top >= innerHeight)) return true;
      }
      return false;
    };
    const label = (t: string) => `"${t.length > 28 ? `${t.slice(0, 27)}…` : t}"`;
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    const range = document.createRange();
    for (let n = walker.nextNode(); n; n = walker.nextNode()) {
      const text = (n.textContent ?? '').replace(/\s+/g, ' ').trim();
      const el = n.parentElement;
      if (!text || !el || el.closest('script, style, noscript, [aria-hidden=true]') || srOnly(el)) continue;
      const st = getComputedStyle(el);
      if (st.visibility === 'hidden' || el.getClientRects().length === 0) continue;
      let opacity = 1;
      for (let p: Element | null = el; p; p = p.parentElement) opacity *= Number(getComputedStyle(p).opacity);
      if (opacity < 0.05) continue;
      range.selectNodeContents(n);
      const r = range.getBoundingClientRect();
      if (r.width === 0 || r.height === 0) continue;
      // The boxes around the text, nearest first, up to the first panel a player can scroll (its content is reachable)
      let inScroller = false;
      for (let p: HTMLElement | null = el; p && p !== document.body && p !== root; p = p.parentElement) {
        if (scrollable(p)) {
          inScroller = true;
          break;
        }
        const ps = getComputedStyle(p);
        const box = p.getBoundingClientRect();
        // clientWidth and clientLeft are in the box's own CSS px: under CSS zoom or a transform (Candle Crypt zooms its
        // panels on big screens) they are scaled to the viewport px the text's rect is in
        const sx = p.offsetWidth ? box.width / p.offsetWidth : 1;
        const sy = p.offsetHeight ? box.height / p.offsetHeight : 1;
        const left = box.left + p.clientLeft * sx;
        const top = box.top + p.clientTop * sy;
        const cx = /(hidden|clip)/.test(ps.overflowX);
        const cy = /(hidden|clip)/.test(ps.overflowY);
        const cut =
          (cx && (r.left < left - 1 || r.right > left + p.clientWidth * sx + 1)) ||
          (cy && (r.top < top - 1 || r.bottom > top + p.clientHeight * sy + 1)) ||
          (p === el && cx && ps.textOverflow === 'ellipsis' && p.scrollWidth > p.clientWidth + 1);
        if (cut) {
          clipped.add(`${label(text)} cut off by ${p.tagName.toLowerCase()}${p.className && typeof p.className === 'string' ? `.${p.className.split(/\s+/)[0]}` : ''}`);
          break;
        }
      }
      const btn = el.closest<HTMLElement>('button, [role=button]');
      if (btn) {
        const b = btn.getBoundingClientRect();
        if (r.left < b.left - 1 || r.right > b.right + 1 || r.top < b.top - 1 || r.bottom > b.bottom + 1) spills.add(`${label(text)} out of its button`);
      }
      if (!inScroller && (r.left < -1 || r.top < -1 || r.right > W + 1 || r.bottom > H + 1))
        offscreen.add(`${label(text)} at ${Math.round(r.left)},${Math.round(r.top)}–${Math.round(r.right)},${Math.round(r.bottom)}`);
    }
    const scroll = document.documentElement.scrollWidth > W + 1 || document.documentElement.scrollHeight > H + 1;
    return { offscreen: [...offscreen], clipped: [...clipped], spills: [...spills], scroll };
  });
}

/** A screen name as a file name: kebab-case, nothing else */
export const screenFile = (name: string): string =>
  name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '') || 'screen';

/** How long QA lets a declared screen settle (a panel sliding in) before it measures and shoots */
export const SCREEN_SETTLE_MS = 350;

/**
 * Panels a player has to scroll (Жаслан, 2026-10-10: «бесит что игры не помещаются в весь экран и приходится туда-сюда
 * двигать по оси y … всё помещается в один экран, кроме сообщений, уведомлений и т. д. по необходимости»): a visible box
 * with overflow auto/scroll whose content doesn't fit, at this size. A screen fits one screen: fewer or smaller rows,
 * columns, tabs or pages instead. The exception is text that may run long — a message, a notification, a log, a story
 * line, a list of languages: mark that box (or an ancestor) with data-gp-scroll="<why>", and it is listed as allowed.
 * Exported for the browser test
 */
export async function panelScrolls(page: Page): Promise<{ bad: string[]; allowed: string[] }> {
  return page.evaluate(() => {
    const bad: string[] = [];
    const allowed: string[] = [];
    const name = (p: HTMLElement) =>
      `${p.tagName.toLowerCase()}${p.id ? `#${p.id}` : ''}${p.className && typeof p.className === 'string' && p.className.trim() ? `.${p.className.trim().split(/\s+/)[0]}` : ''}`;
    for (const p of document.body.querySelectorAll<HTMLElement>('*')) {
      const st = getComputedStyle(p);
      const y = /(auto|scroll)/.test(st.overflowY) && p.scrollHeight > p.clientHeight + 2;
      const x = /(auto|scroll)/.test(st.overflowX) && p.scrollWidth > p.clientWidth + 2;
      if (!x && !y) continue;
      if (st.visibility === 'hidden' || p.getClientRects().length === 0 || p.clientHeight === 0) continue;
      const why = p.closest<HTMLElement>('[data-gp-scroll]');
      const what = `${name(p)} (${y ? `${p.scrollHeight} px of content in ${p.clientHeight}` : `${p.scrollWidth} px wide in ${p.clientWidth}`})`;
      if (why) allowed.push(`${what}: ${why.dataset.gpScroll || 'marked'}`);
      else bad.push(what);
    }
    return { bad, allowed };
  });
}

/** The sizes the declared screens are opened at: the viewports (one with --quick) and a portal's two small frames at DPR 1 */
export function screenSizes(quick: boolean, portal: boolean): { name: string; width: number; height: number; touch: boolean; frame: boolean }[] {
  return [
    ...(quick ? VIEWPORTS.slice(0, 1) : VIEWPORTS).map((v) => ({ ...v, frame: false })),
    ...(quick || !portal ? [] : PORTAL_FRAMES.map((f) => ({ ...f, touch: false, frame: true }))),
  ];
}

/**
 * What a declared screen is checked for, at one size: buttons on screen and ≥ minTouchPx (scrolling panels scrolled),
 * text inside its box and on screen, no page scroll, the canvas UI it declares, and in a portal frame text ≥ 12 px.
 * `extra`: more findings from the caller (the language pass adds English left on a translated screen)
 */
async function screenFindings(page: Page, ctx: QaContext, frame: boolean, extra: string[] = []): Promise<{ bad: string[]; what: string; details: string }> {
  const t = await tappables(page, ctx.game.minTouchPx);
  const fit = await textFit(page);
  const panels = await panelScrolls(page);
  const cu = await canvasUi(page, ctx.game.minTouchPx, frame ? MIN_TEXT_PX : 0);
  const small = frame ? (await legibility(page)).small : [];
  const bad = [
    ...t.bad,
    ...fit.offscreen.map((x) => `text off screen: ${x}`),
    ...fit.clipped.map((x) => `text ${x}`),
    ...fit.spills.map((x) => `text ${x}`),
    ...(fit.scroll ? ['the page scrolls'] : []),
    ...panels.bad.map((x) => `a panel scrolls: ${x} — the screen must fit one screen (fewer or smaller rows, tabs or pages); only a message or a long text may scroll: data-gp-scroll="<why>"`),
    ...(cu?.bad ?? []).map((x) => `canvas UI: ${x}`),
    ...small.map((x) => `text under ${MIN_TEXT_PX} px: ${x}`),
    ...extra,
  ];
  const what = `buttons on screen and ≥ ${ctx.game.minTouchPx} px, text inside its box and on screen, one screen (no page or panel scroll)${cu ? ', canvas UI' : ''}${frame ? `, text ≥ ${MIN_TEXT_PX} px` : ''}`;
  const allowed = panels.allowed.length ? `; scrolls by data-gp-scroll: ${panels.allowed.slice(0, 3).join('; ')}` : '';
  const details = bad.length ? bad.slice(0, 6).join('; ') + (bad.length > 6 ? ` (+${bad.length - 6} more)` : '') : `${tapInfo(t)}${cu ? `, ${cu.rects.length} canvas rects` : ''}${allowed}`;
  return { bad, what, details };
}

/**
 * Every screen the game declares (host.qa({ screens })), at every size of the matrix (screenSizes). On each: a screenshot
 * (screen-<name>-<size>.png) and the first screen's checks — buttons on screen and ≥ minTouchPx (scrolling panels
 * scrolled), text inside its box and on screen, no page scroll, the canvas UI it declares; in the portal frames DOM and
 * canvas text ≥ 12 px; at the desktop size, Tab after a click on the canvas (then the page is reloaded: the click may
 * have started a run). The screens open one after another, in the declared order, each from the screen the previous
 * left. Candle Crypt wrote 148 lines (tools/responsive.mjs) for this; platform QA reached 5 screens. Exported for the
 * browser test
 */
export async function runScreens(ctx: QaContext): Promise<void> {
  const S = 'screens';
  const sizes = screenSizes(ctx.quick, !!ctx.game.portal);
  const t0 = Date.now();
  let names: string[] | null = null;
  for (const [si, size] of sizes.entries()) {
    const context = await ctx.browser.newContext({
      viewport: { width: size.width, height: size.height },
      hasTouch: size.touch,
      isMobile: size.touch,
      ...(size.frame ? { deviceScaleFactor: 1 } : {}),
    });
    const page = await context.newPage();
    const errors: string[] = [];
    page.on('pageerror', (e) => errors.push(e.message));
    page.on('console', (m) => {
      if (m.type() === 'error' && !m.text().includes('favicon') && !m.text().includes(REFUSED)) errors.push(m.text());
    });
    const load = async () => {
      await page.goto(`${ctx.url}${ctx.url.includes('?') ? '&' : '?'}seed=7`);
      await page.waitForFunction(() => window.__gp?.host?.qaDriver && window.__portal?.calls.some((c) => c.fn === 'loadingStop'), null, { timeout: 20000 });
      await sleep(300);
    };
    try {
      await load();
      if (!names) {
        const declared = await page.evaluate(() => {
          const s = window.__gp.host.qaDriver.screens;
          if (s === undefined) return null;
          if (!s || typeof s !== 'object') return 'not an object';
          return Object.keys(s).filter((k) => typeof s[k] === 'function');
        });
        if (declared === null) {
          ctx.info(S, 'every screen (host.qa screens)', 'the game declares no screens: QA checks the ones it reaches by itself (first screen, play, results, shop, pause) — declare the others: host.qa({ screens: { journal: () => openJournal() } })');
          return;
        }
        if (typeof declared === 'string' || declared.length === 0) {
          ctx.check(S, 'host.qa screens: { name: () => open it }', false, typeof declared === 'string' ? 'screens is not an object of functions' : 'no functions in screens');
          return;
        }
        names = declared;
        const files = names.map(screenFile);
        const dup = files.filter((f, i) => files.indexOf(f) !== i);
        if (dup.length) ctx.check(S, 'host.qa screens: the names are distinct as file names (kebab-case)', false, dup.join(', '));
        // Scope: the rejected games declared 16–20 screens, the approved 10–12 (docs/research/qa-calibration-2026-10.md)
        const scope = `scope: at most ${SCOPE_MAX_SCREENS} declared screens`;
        if (names.length > SCOPE_MAX_SCREENS)
          warnLine(ctx, S, `${scope} — W_SCOPE_SCREENS (a warning)`, `${names.length} screens: our rejected games declared 16–20, the approved 10–12 — every screen a reviewer opens must look finished: fold side screens together, cut the ones that aren't drawn and animated (W_SCOPE_SCREENS)`);
        else ctx.info(S, scope, `${names.length} screens`);
      }
      const desktop = !size.frame && !size.touch;
      for (const [i, name] of names.entries()) {
        const at = `"${name}" ${size.name}`;
        const opened = await page
          .evaluate(async (n) => {
            try {
              await window.__gp.host.qaDriver.screens[n]();
              return null;
            } catch (e) {
              return String((e as Error)?.stack ?? e).slice(0, 300);
            }
          }, name)
          .catch((e: Error) => String(e.message).slice(0, 300));
        if (opened !== null) {
          ctx.check(S, `${at}: opens (host.qa screens["${name}"]())`, false, opened);
          continue;
        }
        await sleep(SCREEN_SETTLE_MS);
        const shot = await page.screenshot({ path: `${ctx.outDir}/screen-${screenFile(name)}-${size.name}.png` });
        const found = await screenFindings(page, ctx, size.frame);
        ctx.check(S, `${at}: ${found.what}`, found.bad.length === 0, found.details);
        // Desktop decides: a screen that is a phone column in an empty field, or one flat colour, fails on crazygames
        if (DESKTOP_SIZES.has(size.name)) await desktopLook(ctx, page, S, at, shot);
        if (si === 0) {
          await glyphCheck(ctx, page, S, `"${name}"`);
          await silhouetteCheck(ctx, page, S, `"${name}"`, shot);
        }
        if (size.name === 'desktop-1280x720' && TITLE_SCREEN.test(name)) await titleCoverCheck(ctx, page, S, at);
        if (desktop) {
          const f = await focusEscape(page);
          if (f.checked) {
            ctx.check(S, `${at}: after a click on the canvas, Tab reaches the buttons`, f.ok, f.text);
            // The click may have changed the screen (started a run): the next screen opens from a fresh page
            if (i < names.length - 1) await load();
          }
        }
      }
      ctx.check(S, `${size.name}: no console errors on the screens`, errors.length === 0, errors.slice(0, 3).join(' | '));
    } finally {
      await context.close();
    }
  }
  if (names) ctx.info(S, 'time', `${names.length} screens × ${sizes.length} sizes in ${((Date.now() - t0) / 1000).toFixed(1)} s`);
}

// --- Languages ---------------------------------------------------------------------------------------------------

/**
 * The sizes the language pass opens the game at: a phone in portrait (long words wrap, buttons grow) and the portal's
 * smallest frame at DPR 1 (a short height, 12 px text) — or a phone on its side for a game off the portals. --quick: the phone
 */
export function languageSizes(quick: boolean, portal: boolean): { name: string; width: number; height: number; touch: boolean; frame: boolean }[] {
  const phone = { ...VIEWPORTS[0], frame: false };
  if (quick) return [phone];
  const small = portal ? { ...PORTAL_FRAMES[PORTAL_FRAMES.length - 1], touch: false, frame: true } : { ...VIEWPORTS[1], frame: false };
  return [phone, small];
}

/**
 * The language whose texts are longest (the sum of every key's text, parameters left out): the one that overflows first.
 * English is the main run's language, so the longest other one. Exported for the browser test
 */
export function longestLanguage(lengths: Record<string, number>): string | null {
  const other = Object.entries(lengths).filter(([l]) => l !== 'en');
  if (!other.length) return null;
  return other.sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))[0][0];
}

/** Every language's total text length, measured in the page (host.i18n.dump: the game's keys and the platform's) */
async function languageLengths(page: Page): Promise<Record<string, number>> {
  return page.evaluate(() => {
    const i = window.__gp.host.i18n;
    const own = Object.keys(i.dump('en')).filter((k: string) => !k.startsWith('gp.'));
    const out: Record<string, number> = {};
    for (const l of i.languages as string[]) {
      const d = i.dump(l) as Record<string, string>;
      // The game's own texts decide it; the platform's are the same in every game
      out[l] = (own.length ? own : Object.keys(d)).reduce((n: number, k: string) => n + (d[k] ?? '').replace(/\{[A-Za-z_]\w*\}/g, '').length, 0);
    }
    return out;
  });
}

/**
 * English left on a translated screen: a visible text (DOM, or a canvas rect's `text`) that is exactly an English text of
 * the game or the platform whose translation differs — a string written into the code instead of host.t(key), or a
 * screen not re-rendered after a switch. Texts with parameters match as patterns ("Best: {time}" → "Best: 12.3 s").
 * Exported for the browser test
 */
export async function englishLeft(page: Page, lang: string): Promise<string[]> {
  return page.evaluate((lang) => {
    const i = window.__gp.host.i18n;
    const en = i.dump('en') as Record<string, string>;
    const cur = i.dump(lang) as Record<string, string>;
    const esc = (x: string) => x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const pats: { re: RegExp; key: string }[] = [];
    for (const [k, v] of Object.entries(en)) {
      const t = v.trim();
      if (!t || cur[k] === undefined || cur[k].trim() === t) continue;
      const fixed = t.replace(/\{[A-Za-z_]\w*\}/g, '');
      if ((fixed.match(/\p{L}/gu) ?? []).length < 3) continue;
      const re = new RegExp(`^${t.split(/\{[A-Za-z_]\w*\}/).map(esc).join('.+?')}$`, 'u');
      pats.push({ re, key: k });
    }
    const found = new Set<string>();
    const look = (text: string) => {
      const x = text.replace(/\s+/g, ' ').trim();
      if (!x) return;
      const hit = pats.find((p) => p.re.test(x));
      if (hit) found.add(`"${x.length > 32 ? `${x.slice(0, 31)}…` : x}" (English of ${hit.key})`);
    };
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    for (let n = walker.nextNode(); n; n = walker.nextNode()) {
      const el = n.parentElement;
      if (!el || el.closest('script, style, noscript, [aria-hidden=true]') || el.getClientRects().length === 0) continue;
      if (getComputedStyle(el).visibility === 'hidden') continue;
      look(n.textContent ?? '');
    }
    for (const el of document.querySelectorAll<HTMLElement>('button, [role=button]')) look(el.innerText ?? '');
    const d = window.__gp.host.qaDriver;
    try {
      for (const r of (typeof d?.canvasUi === 'function' ? d.canvasUi() : []) ?? []) if (typeof r?.text === 'string') look(r.text);
    } catch {
      // canvasUi is checked elsewhere
    }
    return [...found];
  }, lang);
}

/** How long the demo bot plays in the longest language at each size, a sample of every text a second (runLanguages) */
export const LANG_PLAY_SEC = 15;

/** A text that left the frame, meets a button or a touch control, or lies over another text, in play (playTextFindings) */
export interface PlayTextFinding {
  kind: 'off-frame' | 'over-button' | 'over-touch' | 'over-text';
  text: string;
  /** off-frame: where the text is (CSS px); over-button / over-touch: the control's label; over-text: the other text */
  where: string;
}

/** A finding as one line of the report */
export function playTextLine(f: PlayTextFinding): string {
  if (f.kind === 'off-frame') return `"${f.text}" leaves the frame (${f.where})`;
  if (f.kind === 'over-touch') return `"${f.text}" covers the touch control "${f.where}" (or lies under it)`;
  if (f.kind === 'over-text') return `"${f.text}" lies over the text "${f.where}" (the HUD overlaps)`;
  return `"${f.text}" covers the button "${f.where}" (or lies under it)`;
}

/**
 * Every visible DOM text box of the page now, as the player sees it in play: a text that leaves the frame (beyond the
 * viewport, after the boxes that clip it; a panel the player can scroll is reachable), a text that covers a visible
 * button or an on-screen touch control (data-gp-touch) or lies under one (their line boxes overlap by more than 2 px,
 * and at that spot the control is not under something else: a full-screen overlay the text is on hides it), and a text
 * that lies over another text (their line boxes overlap by more than a third of the smaller line's height, and no
 * opaque dialog covers the lower one: two HUD labels drawn into each other — Frankengun's ammo count over its wave
 * banner; a toast on its own panel over the score counts too). A
 * control's own label is its own; a text inside another's element is part of it. The declared screens are checked once
 * each; this samples what play shows — a hint, a toast, a combo line (German and Polish hints ran off the screen while
 * every screen passed). Exported for the browser test
 */
export async function playTextFindings(page: Page): Promise<PlayTextFinding[]> {
  return page.evaluate(() => {
    const W = innerWidth;
    const H = innerHeight;
    const out = new Map<string, { kind: 'off-frame' | 'over-button' | 'over-touch' | 'over-text'; text: string; where: string }>();
    const label = (t: string) => (t.length > 40 ? `${t.slice(0, 39)}…` : t);
    const seen = (el: Element) => {
      let o = 1;
      for (let p: Element | null = el; p; p = p.parentElement) {
        const st = getComputedStyle(p);
        if (st.visibility === 'hidden' || st.display === 'none') return false;
        o *= Number(st.opacity);
      }
      return o >= 0.05 && el.getClientRects().length > 0;
    };
    const buttons = [...document.querySelectorAll<HTMLElement>('button, [role=button], [data-gp=play], [data-gp-touch]')]
      .filter((b) => seen(b))
      .map((b) => ({
        b,
        r: b.getBoundingClientRect(),
        touch: b.hasAttribute('data-gp-touch'),
        name: label((b.innerText || b.getAttribute('aria-label') || b.dataset.gpTouch || b.dataset.gp || b.tagName.toLowerCase()).replace(/\s+/g, ' ').trim()),
      }))
      // A touch zone (half the screen steers) is no control a text can cover: only controls under a quarter of the screen
      .filter((x) => x.r.width > 0 && x.r.height > 0 && !(x.touch && x.r.width * x.r.height > 0.25 * W * H));
    // Each text's line boxes (clipped by the boxes around it), for the text-over-text pass after the walk
    const lines: { el: HTMLElement; text: string; rects: { left: number; top: number; right: number; bottom: number }[] }[] = [];
    const big = (x: Element) => {
      const r = x.getBoundingClientRect();
      return r.width * r.height >= 0.5 * W * H;
    };
    // Visually hidden on purpose — the sr-only pattern, text for a screen reader such as the dialogue's aria-live
    // .gp-live (Frankengun's QA flagged it as cut off): a box of 1 px or less that clips, clip: rect() of no area,
    // clip-path: inset(50%), or a live region placed off screen
    const srOnly = (el: Element) => {
      for (let p: Element | null = el; p && p !== document.body; p = p.parentElement) {
        const st = getComputedStyle(p);
        const b = p.getBoundingClientRect();
        if (b.width <= 1.5 && b.height <= 1.5 && /(hidden|clip)/.test(st.overflowX + st.overflowY)) return true;
        const rect = /^(absolute|fixed)$/.test(st.position) ? st.clip.match(/rect\(([^)]*)\)/) : null;
        const [t, r, bt, l] = rect ? rect[1]!.split(/[\s,]+/).map((v) => parseFloat(v)) : [];
        if (rect && [t, r, bt, l].every((v) => Number.isFinite(v)) && r! - l! <= 1 && bt! - t! <= 1) return true;
        if (/inset\(\s*(5\d|[6-9]\d|100)(\.\d+)?%/.test(st.clipPath)) return true;
        const live = p.hasAttribute('aria-live') || /^(status|alert|log|timer|marquee)$/.test(p.getAttribute('role') ?? '');
        if (live && (b.right <= 0 || b.bottom <= 0 || b.left >= innerWidth || b.top >= innerHeight)) return true;
      }
      return false;
    };
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    const range = document.createRange();
    for (let n = walker.nextNode(); n; n = walker.nextNode()) {
      const text = (n.textContent ?? '').replace(/\s+/g, ' ').trim();
      const el = n.parentElement;
      if (!text || !el || el.closest('script, style, noscript, [aria-hidden=true]') || !seen(el) || srOnly(el)) continue;
      range.selectNodeContents(n);
      const r = range.getBoundingClientRect();
      if (r.width === 0 || r.height === 0) continue;
      // Clipped by the boxes around it; inside a panel the player can scroll, it is reachable
      let [x0, y0, x1, y1] = [r.left, r.top, r.right, r.bottom];
      let reachable = false;
      for (let p: HTMLElement | null = el; p && p !== document.body && p !== document.documentElement; p = p.parentElement) {
        const ps = getComputedStyle(p);
        if ((/(auto|scroll)/.test(ps.overflowY) && p.scrollHeight > p.clientHeight + 1) || (/(auto|scroll)/.test(ps.overflowX) && p.scrollWidth > p.clientWidth + 1)) {
          reachable = true;
          break;
        }
        const b = p.getBoundingClientRect();
        if (/(hidden|clip)/.test(ps.overflowX)) [x0, x1] = [Math.max(x0, b.left), Math.min(x1, b.right)];
        if (/(hidden|clip)/.test(ps.overflowY)) [y0, y1] = [Math.max(y0, b.top), Math.min(y1, b.bottom)];
      }
      if (x1 - x0 <= 0 || y1 - y0 <= 0) continue;
      if (!reachable && (x0 < -1 || y0 < -1 || x1 > W + 1 || y1 > H + 1))
        out.set(`off:${text}`, { kind: 'off-frame', text: label(text), where: `${Math.round(x0)},${Math.round(y0)}–${Math.round(x1)},${Math.round(y1)} in ${W}×${H}` });
      lines.push({
        el,
        text,
        rects: [...range.getClientRects()]
          .map((lr) => ({ left: Math.max(lr.left, x0), top: Math.max(lr.top, y0), right: Math.min(lr.right, x1), bottom: Math.min(lr.bottom, y1) }))
          .filter((q) => q.right - q.left > 1 && q.bottom - q.top > 1),
      });
      // Over a button or a touch control (or under one): per line box, so a short last line doesn't count the room beside it
      for (const { b, r: br, name, touch } of buttons) {
        if (b.contains(el) || (touch && el.contains(b))) continue;
        for (const lr of range.getClientRects()) {
          const ix0 = Math.max(lr.left, br.left, x0);
          const ix1 = Math.min(lr.right, br.right, x1);
          const iy0 = Math.max(lr.top, br.top, y0);
          const iy1 = Math.min(lr.bottom, br.bottom, y1);
          if (ix1 - ix0 <= 2 || iy1 - iy0 <= 2) continue;
          // At that spot: the button, with nothing above it but the text's own box (an overlay the text is on hides it)
          const stack = document.elementsFromPoint((ix0 + ix1) / 2, (iy0 + iy1) / 2);
          const ib = stack.findIndex((e) => e === b || b.contains(e));
          if (ib < 0) continue;
          const above = stack.slice(0, ib);
          if (above.some((e) => !(e === el || e.contains(el)) || (e !== el && big(e)))) continue;
          out.set(`btn:${text}:${name}`, { kind: touch ? 'over-touch' : 'over-button', text: label(text), where: name });
          break;
        }
      }
    }
    // Text over text: every pair of line boxes from unrelated elements. Hit-testing sees through pointer-events: none (a
    // HUD has it), so for this pass every element takes part in it; the lower text is out of sight (no finding) only
    // under an opaque box of half the screen or more between the two at that spot (a dialog over the HUD)
    const opaque = (e: Element) => {
      if (/^(IMG|CANVAS|VIDEO|svg|SVG)$/.test(e.tagName)) return true;
      const st = getComputedStyle(e);
      if (st.backgroundImage && st.backgroundImage !== 'none') return true;
      const m = st.backgroundColor.match(/[\d.]+/g);
      return !!m && (m.length < 4 ? m.length >= 3 : Number(m[3]) >= 0.6);
    };
    const CONTROL = 'button, [role=button], [data-gp=play], [data-gp-touch]';
    if (lines.length > 1 && lines.length < 400) {
      const hit = document.createElement('style');
      hit.textContent = '* { pointer-events: auto !important; }';
      document.head.append(hit);
      try {
        for (let i = 0; i < lines.length; i++)
          for (let j = i + 1; j < lines.length; j++) {
            const a = lines[i];
            const b = lines[j];
            if (a.el === b.el || a.el.contains(b.el) || b.el.contains(a.el)) continue;
            // A control's label: the text over it is the over-button / over-touch finding above
            if (a.el.closest(CONTROL) || b.el.closest(CONTROL)) continue;
            if (out.has(`txt:${a.text}:${b.text}`) || out.has(`txt:${b.text}:${a.text}`)) continue;
            pairs: for (const ra of a.rects)
              for (const rb of b.rects) {
                const ix0 = Math.max(ra.left, rb.left);
                const ix1 = Math.min(ra.right, rb.right);
                const iy0 = Math.max(ra.top, rb.top);
                const iy1 = Math.min(ra.bottom, rb.bottom);
                const hmin = Math.min(ra.bottom - ra.top, rb.bottom - rb.top);
                if (ix1 - ix0 <= 2 || iy1 - iy0 <= Math.max(2, hmin / 3)) continue;
                const stack = document.elementsFromPoint((ix0 + ix1) / 2, (iy0 + iy1) / 2);
                const ia = stack.indexOf(a.el);
                const ib = stack.indexOf(b.el);
                if (ia < 0 || ib < 0) continue;
                const [upper, lower, lo] = ia < ib ? [a, b, ib] : [b, a, ia];
                // Above the lower one: a dialog that covers the screen (opaque, half the screen or more) hides it — a toast
                // or a banner on a small panel of its own still lands on the HUD text
                if (stack.slice(0, lo).some((e) => !lower.el.contains(e) && !e.contains(lower.el) && opaque(e) && big(e))) continue;
                out.set(`txt:${upper.text}:${lower.text}`, { kind: 'over-text', text: label(upper.text), where: label(lower.text) });
                break pairs;
              }
          }
      } finally {
        hit.remove();
      }
    }
    return [...out.values()];
  });
}

/**
 * The longest language in play: a fresh page in `lang`, a run started and the demo bot playing (host.qa({ demo }); without
 * one the run as it goes), every visible text sampled each second for LANG_PLAY_SEC (or until the run ends, its end
 * screen sampled too). A finding is measured again 400 ms later, so a text sliding in doesn't count; a confirmed one
 * fails with the text, the second and a screenshot lang-<code>-play-<size>-<s>s.png
 */
async function playTextChecks(ctx: QaContext, lang: string, size: { name: string; width: number; height: number; touch: boolean; frame: boolean }): Promise<void> {
  const S = 'languages';
  const context = await ctx.browser.newContext({ viewport: { width: size.width, height: size.height }, hasTouch: size.touch, isMobile: size.touch, ...(size.frame ? { deviceScaleFactor: 1 } : {}) });
  const page = await context.newPage();
  try {
    await page.goto(`${ctx.url}${ctx.url.includes('?') ? '&' : '?'}seed=7&lang=${encodeURIComponent(lang)}`);
    await page.waitForFunction(() => window.__gp?.host?.qaDriver && window.__portal?.calls.some((c) => c.fn === 'loadingStop'), null, { timeout: 20000 });
    await sleep(300);
    const playing = await page.evaluate(() => window.__portal.calls.at(-1)?.fn === 'gameplayStart' && !window.__gp.host.paused);
    if (!playing) await startRun(page);
    const demo = await page.evaluate(() => {
      const d = window.__gp.host.qaDriver;
      if (typeof d.demo !== 'function') return false;
      d.demo();
      return true;
    });
    const from = await page.evaluate(() => performance.now() / 1000);
    const found = new Map<string, string>();
    const shots: string[] = [];
    let sec = 0;
    let ended = false;
    for (; sec < LANG_PLAY_SEC && !ended; sec++) {
      await sleep(1000);
      ended = await page.evaluate((t) => window.__portal.calls.some((c) => c.fn === 'gameplayStop' && c.t > t) && !window.__gp.host.paused, from);
      // The end screen once more after it settles
      if (ended) await sleep(SCREEN_SETTLE_MS);
      const first = await playTextFindings(page);
      if (!first.length) continue;
      await sleep(400);
      const again = await playTextFindings(page);
      const key = (f: PlayTextFinding) => `${f.kind}:${f.text}:${f.kind === 'off-frame' ? '' : f.where}`;
      const still = again.filter((f) => first.some((g) => key(g) === key(f)) && !found.has(key(f)));
      if (!still.length) continue;
      let shot = '';
      if (shots.length < 3) {
        shot = `lang-${lang}-play-${size.name}-${sec + 1}s.png`;
        await page.screenshot({ path: `${ctx.outDir}/${shot}` });
        shots.push(shot);
      }
      for (const f of still) found.set(key(f), `${playTextLine(f)} at ${sec + 1} s${shot ? ` — ${shot}` : ''}`);
    }
    const how = `${demo ? 'the demo bot playing' : 'no demo bot (host.qa({ demo })): the run untouched'}, ${sec} s${ended ? ' to the end of the run' : ''}, every visible text each second`;
    const bad = [...found.values()];
    ctx.check(S, `${lang} ${size.name}: in play (${how}) no text leaves the frame, covers a button or a touch control, or lies over another text`, bad.length === 0, bad.length ? `${bad.slice(0, 5).join('; ')}${bad.length > 5 ? ` (+${bad.length - 5} more)` : ''} — wrap or shorten it (max-width, white-space: normal), or move it clear of the controls and the other HUD texts (E_QA_HUD_OVERLAP)` : '');
  } finally {
    await context.close();
  }
}

/** What the player reads on the screen now (the game's layer and the page, not the picker's sheet) */
const screenText = (page: Page) => page.evaluate(() => (document.getElementById('ui') ?? document.body).innerText.replace(/\s+/g, ' ').trim());

/**
 * The game in its longest language (game.yaml `languages`): opened with ?lang=<code> at two sizes (languageSizes), its
 * first screen and every declared screen checked like the screens pass (text inside its box and on screen, buttons on
 * screen and big enough, no page scroll, 12 px text in the portal frame), plus no English left on the translated screen;
 * without declared screens, the first screen, play and the results. Then the language picker: on the first screen,
 * every choice ≥ minTouchPx, a choice switches the screen at once, and the choice survives a reload (the saved choice
 * beats the portal's and the browser's language). Then the demo bot plays a run in it at each size, every visible DOM
 * text sampled each second (playTextChecks): one that leaves the frame or covers a button fails. Screenshots
 * lang-<code>-<screen>-<size>.png, lang-<code>-play-<size>-<s>s.png
 */
export async function runLanguages(ctx: QaContext): Promise<void> {
  const S = 'languages';
  const langs = ctx.game.languages ?? ['en'];
  if (langs.length < 2) {
    ctx.info(S, 'languages', `the game is in English only (game.yaml languages)${ctx.game.portal ? ': W_I18N_LANGS names the languages its players speak' : ''} — not checked`);
    return;
  }
  const t0 = Date.now();
  let lang: string | null = null;
  let names: string[] = [];
  for (const [si, size] of languageSizes(ctx.quick, !!ctx.game.portal).entries()) {
    const context = await ctx.browser.newContext({
      viewport: { width: size.width, height: size.height },
      hasTouch: size.touch,
      isMobile: size.touch,
      ...(size.frame ? { deviceScaleFactor: 1 } : {}),
    });
    const page = await context.newPage();
    const errors: string[] = [];
    page.on('pageerror', (e) => errors.push(e.message));
    page.on('console', (m) => {
      if (m.type() === 'error' && !m.text().includes('favicon') && !m.text().includes(REFUSED)) errors.push(m.text());
    });
    const load = async (q = '') => {
      await page.goto(`${ctx.url}${ctx.url.includes('?') ? '&' : '?'}seed=7${q}`);
      await page.waitForFunction(() => window.__gp?.host?.qaDriver && window.__portal?.calls.some((c) => c.fn === 'loadingStop'), null, { timeout: 20000 });
      await sleep(300);
    };
    try {
      if (!lang) {
        await load();
        const lengths = await languageLengths(page);
        lang = longestLanguage(lengths);
        if (!lang) return;
        const en = lengths.en ?? 0;
        ctx.info(S, 'the longest language', `${lang}: ${lengths[lang]} characters of text, English ${en}${en ? ` (${Math.round((lengths[lang] / en - 1) * 100)}% longer)` : ''} — checked at ${languageSizes(ctx.quick, !!ctx.game.portal).map((x) => x.name).join(', ')}`);
        names = await page.evaluate(() => {
          const s = window.__gp.host.qaDriver.screens;
          return s && typeof s === 'object' ? Object.keys(s).filter((k) => typeof s[k] === 'function') : [];
        });
      }
      await load(`&lang=${encodeURIComponent(lang)}`);
      const shown = await page.evaluate(() => ({ host: window.__gp.host.lang as string, html: document.documentElement.lang }));
      ctx.check(S, `${size.name}: ?lang=${lang} opens the game in ${lang} (host.lang, <html lang>)`, shown.host === lang && shown.html === lang, JSON.stringify(shown));
      const at = (screen: string) => `${lang} "${screen}" ${size.name}`;
      const checkHere = async (screen: string) => {
        await sleep(SCREEN_SETTLE_MS);
        await page.screenshot({ path: `${ctx.outDir}/lang-${lang}-${screenFile(screen)}-${size.name}.png` });
        const left = await englishLeft(page, lang!);
        const found = await screenFindings(page, ctx, size.frame, left.map((x) => `English left: ${x}`));
        ctx.check(S, `${at(screen)}: ${found.what}, no English left`, found.bad.length === 0, found.details);
      };
      await checkHere('first-screen');
      if (names.length) {
        for (const name of names) {
          const opened = await page
            .evaluate(async (n) => {
              try {
                await window.__gp.host.qaDriver.screens[n]();
                return null;
              } catch (e) {
                return String((e as Error)?.stack ?? e).slice(0, 300);
              }
            }, name)
            .catch((e: Error) => String(e.message).slice(0, 300));
          if (opened !== null) ctx.check(S, `${at(name)}: opens (host.qa screens["${name}"]())`, false, opened);
          else await checkHere(name);
        }
      } else {
        await startRun(page);
        await sleep(800);
        await checkHere('play');
        await page.evaluate(() => window.__gp.host.qaDriver.end());
        await sleep(800);
        await checkHere('results');
      }
      // The picker: once, at the first size, on a fresh page in the longest language
      if (si === 0) await pickerChecks(ctx, page, lang, load, size.name);
      ctx.check(S, `${lang} ${size.name}: no console errors`, errors.length === 0, errors.slice(0, 3).join(' | '));
      // Then play: what the declared screens don't show (a hint, a toast), every visible text each second
      await playTextChecks(ctx, lang, size);
    } finally {
      await context.close();
    }
  }
  if (lang) ctx.info(S, 'time', `${lang}: ${names.length || 3} screens × ${languageSizes(ctx.quick, !!ctx.game.portal).length} sizes and the picker in ${((Date.now() - t0) / 1000).toFixed(1)} s`);
}

/** The language picker on the first screen: its choices, a switch without reload, and the choice saved */
async function pickerChecks(ctx: QaContext, page: Page, lang: string, load: (q?: string) => Promise<void>, size: string): Promise<void> {
  const S = 'languages';
  await load(`&lang=${encodeURIComponent(lang)}`);
  const toggle = page.locator('[data-gp=lang]:visible').first();
  const has = await toggle.isVisible().catch(() => false);
  ctx.check(S, 'first screen: a language picker (languagePicker() from @gp/core: data-gp="lang")', has, has ? '' : 'none on the first screen: add languagePicker({ host, onChange: showTitle }) to the title — players pick their language there (CrazyGames reviewers asked for it)');
  if (!has) return;
  await toggle.click();
  await sleep(250);
  const choices = await page.evaluate(() => [...document.querySelectorAll<HTMLElement>('[data-gp-lang]')].filter((e) => e.getClientRects().length).map((e) => e.dataset.gpLang!));
  await page.screenshot({ path: `${ctx.outDir}/lang-picker-${size}.png` });
  const t = await tappables(page, ctx.game.minTouchPx);
  const fit = await textFit(page);
  const want = ctx.game.languages;
  const bad = [...t.bad, ...fit.offscreen.map((x) => `text off screen: ${x}`), ...fit.clipped.map((x) => `text ${x}`), ...(fit.scroll ? ['the page scrolls'] : [])];
  ctx.check(S, `the picker offers every language (${want.length}), each choice on screen and ≥ ${ctx.game.minTouchPx} px`, bad.length === 0 && want.every((l) => choices.includes(l)), bad.length ? bad.slice(0, 4).join('; ') : `${choices.join(', ')}`);
  const before = await screenText(page);
  const next = want.find((l) => l !== lang && l !== 'en') ?? want.find((l) => l !== lang)!;
  const choice = page.locator(`[data-gp-lang="${next}"]`).first();
  if (!(await choice.isVisible().catch(() => false))) return;
  await choice.click();
  await sleep(400);
  const after = await page.evaluate(() => ({ host: window.__gp.host.lang as string, html: document.documentElement.lang, sheet: !!document.querySelector('[data-gp=lang-sheet]') }));
  const text = await screenText(page);
  ctx.check(S, `choosing ${next} switches at once: host.lang, <html lang> and the screen's text change, the sheet closes`, after.host === next && after.html === next && !after.sheet && text !== before, `${JSON.stringify(after)}; text ${text === before ? 'unchanged' : 'changed'}`);
  const left = await englishLeft(page, next);
  if (next !== 'en') ctx.check(S, `after the switch to ${next}: no English left on the screen (re-rendered)`, left.length === 0, left.slice(0, 4).join('; '));
  // Saved: a reload without ?lang keeps it (the player's choice beats the portal's and the browser's)
  await load();
  const kept = await page.evaluate(() => window.__gp.host.lang as string);
  ctx.check(S, `the choice is saved: after a reload the game is still in ${next}`, kept === next, `host.lang ${kept}`);
}

/** The sizes "desktop decides" measures the look at (the screens pass and the 1280×720 viewport) */
const DESKTOP_SIZES = new Set(['desktop-1280x720', 'desktop-821x462']);

/**
 * Desktop decides (crazygames): the portal's small desktop frame, 821×462 at devicePixelRatio 1 — the first screen, a
 * run 2 s in (the hero 1 s in) and the results, each measured for a clearly empty or flat layout. 1280×720 is measured
 * in its viewport section and the declared screens in the screens pass. Screenshots desktop-821x462-<n>-<screen>.png
 */
async function runDesktopFrame(ctx: QaContext): Promise<void> {
  if (!desktopGated(ctx)) return;
  const S = 'desktop-821x462';
  const { context, page, errors } = await openDesktop(ctx, { width: 821, height: 462 }, 1);
  try {
    const firstShot = await page.screenshot({ path: `${ctx.outDir}/${S}-1-first-screen.png` });
    await desktopLook(ctx, page, S, 'first screen', firstShot);
    await startRun(page);
    await page.evaluate(() => window.__gp.host.qaDriver.demo?.());
    await sleep(1000);
    await heroCheck(ctx, page, S);
    await sleep(1000);
    const playShot = await page.screenshot({ path: `${ctx.outDir}/${S}-2-play.png` });
    await desktopLook(ctx, page, S, 'play', playShot, { recheck: `${ctx.outDir}/${S}-2-play-again.png` });
    await page.evaluate(() => window.__gp.host.qaDriver.end());
    await sleep(800);
    const resultsShot = await page.screenshot({ path: `${ctx.outDir}/${S}-3-results.png` });
    await desktopLook(ctx, page, S, 'results', resultsShot);
    ctx.check(S, 'no errors', errors.length === 0, errors.slice(0, 3).join(' | '));
  } finally {
    await context.close();
  }
}

/** Desktop dev page with the probe, at the first screen */
async function openDesktop(ctx: QaContext, size = { width: 1280, height: 720 }, scale?: number) {
  const context = await ctx.browser.newContext({ viewport: size, ...(scale ? { deviceScaleFactor: scale } : {}) });
  await context.addInitScript(installProbe);
  const page = await context.newPage();
  const errors: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message));
  await page.goto(`${ctx.url}?seed=7`);
  await page.waitForFunction(() => window.__gp?.host?.qaDriver && window.__portal?.calls.some((c) => c.fn === 'loadingStop'), null, { timeout: 20000 });
  await sleep(400);
  return { context, page, errors };
}

/** From the first screen into a run: a click on Play, or host.qa play() */
async function startRun(page: Page): Promise<void> {
  const play = page.locator('[data-gp=play]').first();
  if (await play.isVisible().catch(() => false)) await play.click();
  else await page.evaluate(() => window.__gp.host.qaDriver.play());
  await page.waitForFunction(() => window.__portal.calls.at(-1)?.fn === 'gameplayStart', null, { timeout: 5000 }).catch(() => {});
  // A story scene after Play is skipped
  await page.locator('[data-gp=dialog-skip]:visible').first().click({ timeout: 500 }).catch(() => {});
}

/**
 * A WebGL context loss during play (a GPU reset or memory pressure on a phone), through WEBGL_lose_context: the run must
 * pause (the host's 'context' reason: no gameplay, no time) and after restoreContext() the canvas must be drawn again —
 * or the host's "reload" notice shows, when the engine can't get its context back. The engine lab saw Pixi draw nothing
 * while the run kept scoring, three score on a black screen, Kaplay never move again. Only for a canvas with WebGL.
 */
async function runContextLoss(ctx: QaContext): Promise<void> {
  const { check, info } = ctx;
  const S = 'webgl context loss';
  const { context, page, errors } = await openDesktop(ctx);
  try {
    await startRun(page);
    await sleep(1000);
    const gl = (await canvasContexts(page)).filter((c) => c.ok && /webgl/.test(c.type) && c.canvas !== '(offscreen)');
    if (!gl.length) {
      info(S, 'context loss', 'no WebGL context on a canvas in the page (Canvas 2D or DOM) — not checked');
      return;
    }
    const target = gl.find((c) => c.canvas === '#game') ?? gl[0];
    check(S, 'the WebGL canvas is the host\'s #game (the host watches it for a context loss)', target.canvas === '#game', `${target.type} on ${target.canvas}${target.canvas === '#game' ? '' : ': draw on the canvas start() gets (an engine that makes its own canvas: pass it ctx.canvas)'}`);
    const [before] = await pixelStats(page, undefined, { hideDom: true, path: `${ctx.outDir}/context-1-before.png` });
    const lost = await page.evaluate((sel) => {
      const p = window.__gpProbe;
      const a = p.asked.find((x: any) => x.ok && /webgl/.test(x.type) && (sel === '#game' ? x.canvas.id === 'game' : x.canvas.isConnected));
      const ext = a?.canvas.getContext(a.type)?.getExtension('WEBGL_lose_context');
      if (!ext) return false;
      (window as any).__gpLose = ext;
      ext.loseContext();
      return true;
    }, target.canvas);
    if (!lost) {
      info(S, 'context loss', 'WEBGL_lose_context is not available — not checked');
      return;
    }
    await sleep(400);
    const during = await page.evaluate(() => ({
      reasons: [...window.__gp.host.pauseReasons] as string[],
      last: window.__portal.calls.map((c) => c.fn).filter((f) => f.startsWith('gameplay')).at(-1) ?? null,
    }));
    check(S, 'context lost during play → the run pauses (host.pauseReasons has "context", gameplayStop)', during.reasons.includes('context') && during.last === 'gameplayStop', JSON.stringify(during));
    await page.evaluate(() => (window as any).__gpLose.restoreContext());
    await sleep(1500);
    const reload = await page.locator('[data-gp=reload]').first().isVisible().catch(() => false);
    const [after] = await pixelStats(page, undefined, { hideDom: true, path: `${ctx.outDir}/context-2-restored.png` });
    await page.screenshot({ path: `${ctx.outDir}/context-3-restored-with-ui.png` });
    const drawn = before.offBackground < 0.002 || after.offBackground >= before.offBackground * 0.5;
    const pct = (x: number) => `${(x * 100).toFixed(1)} %`;
    check(
      S,
      'context restored → the canvas is drawn again, or the "reload" notice shows',
      reload || drawn,
      reload
        ? 'the host\'s "reload" notice (no listener called preventDefault() on webglcontextlost)'
        : `drawn pixels (the canvas alone, DOM hidden): ${pct(before.offBackground)} before → ${pct(after.offBackground)} after${drawn ? '' : ': the engine must re-create its GPU state (call preventDefault() in its webglcontextlost listener, re-upload textures) and the game must draw again in host.onResume'}`,
    );
    if (before.offBackground < 0.002) info(S, 'context restored: drawn pixels', 'the canvas showed almost nothing but the background before the loss — the comparison says little');
    check(S, 'no errors around the context loss', errors.length === 0, errors.slice(0, 3).join(' | '));
  } finally {
    await context.close();
  }
}

/** Keyboard: after a click on the canvas, Tab reaches the DOM buttons — on the first screen and on the results */
async function runFocus(ctx: QaContext): Promise<void> {
  const S = 'keyboard';
  const { context, page } = await openDesktop(ctx);
  try {
    const first = await focusEscape(page);
    if (first.checked) ctx.check(S, 'first screen: after a click on the canvas, Tab reaches the buttons', first.ok, first.text);
    else ctx.info(S, 'first screen: Tab after a click on the canvas', `${first.text} — not checked`);
    await page.reload();
    await page.waitForFunction(() => window.__gp?.host?.qaDriver, null, { timeout: 20000 });
    await sleep(300);
    await startRun(page);
    await sleep(800);
    await page.evaluate(() => window.__gp.host.qaDriver.end());
    await sleep(800);
    const results = await focusEscape(page);
    if (results.checked) ctx.check(S, 'results: after a click on the canvas, Tab reaches the buttons', results.ok, results.text);
    else ctx.info(S, 'results: Tab after a click on the canvas', `${results.text} — not checked`);
  } finally {
    await context.close();
  }
}

/** What a new player meets in the first minute, as `gp qa` measures it (qa/first-minute.json; `gp review` reads it) */
export interface FirstMinute {
  /** From opening the page to a tappable Play, ms (a first visit that lands in gameplay: to gameplayStart) */
  playReadyMs: number | null;
  /** From the Play tap to the run starting (gameplayStart) with no other tap, ms (0: no Play, a first visit lands in play); null: no run within 8 s */
  playToRunMs: number | null;
  /** A player who touches nothing: the run ended after this many seconds (null: still going after IDLE_SEC) */
  idleEndSec: number | null;
  /** Most words a player can read on screen in the first seconds of the run (DOM and declared canvas text) */
  words: number;
  /** The demo bot playing: the first celebrated moment (host.happytime) and the twist, seconds after Play (to the second) */
  firstHighlightSec: number | null;
  twistSec: number | null;
  /** The demo bot's run ended after this many seconds (null: still going after DEMO_SEC) */
  demoEndSec: number | null;
  // --- Since the first-minute gates (2026-10-10): what CrazyGames' gameplay conversion sees
  /** Clicks from a fresh page to gameplay (0: it lands in play; 1: Play; 2+: a modal, a story, a controls card in between); null: none within 3 */
  clicksToGameplay: number | null;
  /** What each click was ("Play", "Skip"…) */
  clickPath: string[];
  /** From opening the page (navigation start) to gameplayStart, ms */
  loadToGameplayMs: number | null;
  /** The host's funnel in that fresh session: each step and its second (host events 'funnel') */
  funnel: { step: string; sec: number }[];
  /** On-screen touch controls at the first frame of play on a phone: declared (data-gp-touch, host.qa touchControls), and the hidden ones */
  touchControls: { declared: number; hidden: string[] } | null;
  /**
   * The naive touch bot (into play by the biggest button, then random taps and drags for 60 s at 360×800 on crazygames,
   * 30 s elsewhere): when it reached gameplay (s after load), its gameplay seconds, the run's events it caused, how long
   * it touched, and the first fail or results in that time (host.fail / host.roundEnd: what it was and when, s after the
   * bot began)
   */
  touchBot: { gameplaySec: number | null; playedSec: number; events: number; taps: number; drags: number; endedOn: string | null; sec?: number; failedAt?: { type: string; sec: number } | null; wins?: number } | null;
  /** The start's loudness: the loudest 43 ms of the host's output in the first 3 s of sound after the first touch, dBFS (null: no sound) */
  startLoudness: { maxDb: number | null; measured: boolean; note: string } | null;
  /** Frames per second in the first 30 s of play at 4× CPU slowdown (the quiet end of gp qa): the lowest sample, and all */
  fps4x: { fps: number | null; samples: number[]; mainMs: number | null } | null;
  /** The gates that failed on a crazygames build (names), empty when all passed; on other channels they are hints */
  failed: string[];
}

const IDLE_SEC = 12;
const DEMO_SEC = 45;
/**
 * The touch bot's session (s): a new player's first minute on crazygames (Frankengun: the bot that played 30 s missed a
 * first run lost at 40 s), half of it elsewhere
 */
export const TOUCH_BOT_SEC = 60;
const TOUCH_BOT_SEC_OFF_PORTAL = 30;
const touchBotSec = (ctx: QaContext) => (gated(ctx) ? TOUCH_BOT_SEC : TOUCH_BOT_SEC_OFF_PORTAL);
/** More words than this before the first action fail on crazygames (Larss: "'Play now' into a tutorial was killing conversion") */
export const FIRST_MINUTE_MAX_WORDS = 25;
/** No sound louder than this (RMS over ≈ 43 ms, dBFS) in the first 3 s of sound (Potion Logic's "deafening" boil at the start) */
export const START_LOUD_DB = -10;
/** The floor for the first 30 s of play at 4× CPU slowdown (a mid-range phone): under it the game stutters there */
export const FIRST_MINUTE_MIN_FPS_4X = 30;

/** A crazygames build: the first-minute numbers are gates (checks); elsewhere hints */
const gated = (ctx: QaContext) => ctx.game.channel.id === 'crazygames';

/** The gate: a check on crazygames, an info line elsewhere (it says so) */
function gate(ctx: QaContext, failed: string[], name: string, ok: boolean, details: string): void {
  if (gated(ctx)) {
    ctx.check('first minute', name, ok, details);
    if (!ok) failed.push(name);
  } else ctx.info('first minute', `${name} (a check on crazygames)`, `${ok ? 'yes' : 'NO'} — ${details}`);
}

/** first-minute.json: the numbers merged into what is there (the fps sample comes from the quiet end of the run) */
function writeFirstMinute(ctx: QaContext, patch: Partial<FirstMinute>): void {
  const file = join(ctx.outDir, 'first-minute.json');
  let old: Partial<FirstMinute> = {};
  try {
    old = existsSync(file) ? (JSON.parse(readFileSync(file, 'utf8')) as Partial<FirstMinute>) : {};
  } catch {
    old = {};
  }
  const failed = [...new Set([...(old.failed ?? []).filter((f) => (patch.fps4x !== undefined ? !f.startsWith('play at 4×') : f.startsWith('play at 4×'))), ...(patch.failed ?? [])])];
  writeFileSync(file, JSON.stringify({ ...old, at: new Date().toISOString(), ...patch, failed }, null, 2));
}

/** Words in the text a player sees now: visible DOM text and the canvas text the game declares (numbers don't count) */
async function wordsOnScreen(page: Page): Promise<number> {
  return page.evaluate(() => {
    const words = (t: string) => (t.match(/\p{L}{2,}/gu) ?? []).length;
    let n = words(document.body.innerText || '');
    const d = window.__gp?.host?.qaDriver;
    try {
      const rects = typeof d?.canvasUi === 'function' ? d.canvasUi() ?? [] : [];
      for (const r of rects) if (typeof r?.text === 'string') n += words(r.text);
    } catch {
      // the game's canvasUi threw: DOM text only
    }
    return n;
  });
}

const PHONE = { width: 360, height: 800 };

/** A fresh profile on a phone (a new player: no save — never QA's "returning" visit), loaded */
async function openFresh(ctx: QaContext): Promise<{ context: import('playwright').BrowserContext; page: Page; t0: number }> {
  const context = await freshBrowser(ctx).newContext({ viewport: PHONE, hasTouch: true, isMobile: true });
  await context.addInitScript(installProbe);
  const page = await context.newPage();
  // Links out (a privacy policy) open elsewhere: the bot stays on the game
  context.on('page', (p) => void (p !== page && p.close().catch(() => {})));
  const t0 = Date.now();
  await page.goto(`${ctx.url}?seed=7`);
  await page.waitForFunction(() => window.__gp?.host?.qaDriver && window.__portal?.calls.some((c) => c.fn === 'loadingStop'), null, { timeout: 20000 });
  return { context, page, t0 };
}

const gameplayAt = (page: Page): Promise<number | null> => page.evaluate(() => window.__portal.calls.find((c) => c.fn === 'gameplayStart')?.t ?? null);

/**
 * In gameplay already (one look; a waitForFunction of 100 ms timed out on a loaded machine with gameplay long started:
 * the art showcase's "no gameplay within 3 clicks" with the run 97 ms after Play, load 28 on 4 cores)
 */
const inGameplay = (page: Page): Promise<boolean> => page.evaluate(() => window.__portal.calls.some((c) => c.fn === 'gameplayStart')).catch(() => false);

async function waitGameplay(page: Page, ms: number): Promise<boolean> {
  return page
    .waitForFunction(() => window.__portal.calls.some((c) => c.fn === 'gameplayStart'), null, { timeout: ms })
    .then(() => true)
    .catch(() => false);
}

/** The biggest visible button that isn't a rewarded offer, the language picker or a link: the one a new player taps next */
async function nextButton(page: Page): Promise<string | null> {
  return page.evaluate(() => {
    const cands = [...document.querySelectorAll<HTMLElement>('[data-gp=dialog-skip], [data-gp=welcome-continue], button, [role=button]')]
      .filter((b) => {
        const r = b.getBoundingClientRect();
        return r.width > 0 && r.height > 0 && !b.closest('[data-gp-rewarded], [data-gp=lang], [data-gp=sign-in]') && getComputedStyle(b).visibility !== 'hidden';
      })
      .map((b) => ({ b, a: b.getBoundingClientRect().width * b.getBoundingClientRect().height, skip: b.dataset.gp === 'dialog-skip' }));
    cands.sort((x, y) => Number(y.skip) - Number(x.skip) || y.a - x.a);
    const pick = cands[0]?.b;
    if (!pick) return null;
    pick.dataset.gpQaNext = '1';
    return (pick.innerText || pick.getAttribute('aria-label') || pick.dataset.gp || 'button').trim().slice(0, 30);
  });
}

/** The declared touch controls right now: DOM [data-gp-touch] and host.qa touchControls() rects; the ones not visible */
async function touchControlsNow(page: Page): Promise<{ declared: number; hidden: string[] }> {
  const dom = await page.evaluate(() => {
    const out: { name: string; visible: boolean }[] = [];
    for (const el of document.querySelectorAll<HTMLElement>('[data-gp-touch]')) {
      const r = el.getBoundingClientRect();
      let op = 1;
      let hidden = false;
      for (let e: HTMLElement | null = el; e; e = e.parentElement) {
        const cs = getComputedStyle(e);
        op *= Number(cs.opacity);
        if (cs.visibility === 'hidden' || cs.display === 'none') hidden = true;
      }
      const on = r.width > 4 && r.height > 4 && r.right > 0 && r.bottom > 0 && r.left < innerWidth && r.top < innerHeight;
      out.push({ name: el.dataset.gpTouch || el.getAttribute('aria-label') || el.tagName.toLowerCase(), visible: on && !hidden && op >= 0.15 });
    }
    return out;
  });
  const rects: CanvasUiRect[] = await page.evaluate(() => {
    const d = window.__gp?.host?.qaDriver;
    try {
      return typeof d?.touchControls === 'function' ? (d.touchControls() ?? []) : [];
    } catch {
      return [];
    }
  });
  const hidden = dom.filter((d) => !d.visible).map((d) => d.name);
  if (rects.length) {
    const stats = await pixelStats(page, rects, { hideDom: true });
    rects.forEach((r, i) => {
      const on = r.w > 4 && r.h > 4 && r.x + r.w > 0 && r.y + r.h > 0 && r.x < PHONE.width && r.y < PHONE.height;
      if (!on || stats[i].varied < 0.02) hidden.push(`${r.name} (canvas)`);
    });
  }
  return { declared: dom.length + rects.length, hidden };
}

/** Listen to the host's output for 3 s from the first sound-unlocking touch: the loudest ≈ 43 ms (RMS, dBFS) */
async function listenStart(page: Page): Promise<void> {
  await page.evaluate(() => {
    const L: { max: number; samples: number; done: boolean; t0: number; ct0: number; ct1: number; an?: AnalyserNode; buf?: Float32Array<ArrayBuffer> } = { max: -Infinity, samples: 0, done: false, t0: 0, ct0: 0, ct1: 0 };
    (window as any).__gpLoud = L;
    const iv = setInterval(() => {
      const a = window.__gp?.host?.audio as { ctx: AudioContext; out: GainNode } | null;
      if (!a) return;
      if (!L.an) {
        L.an = a.ctx.createAnalyser();
        L.an.fftSize = 2048;
        a.out.connect(L.an);
        L.buf = new Float32Array(L.an.fftSize);
        L.t0 = performance.now();
        L.ct0 = a.ctx.currentTime;
      }
      L.ct1 = a.ctx.currentTime;
      if (performance.now() - L.t0 > 3000) {
        clearInterval(iv);
        L.done = true;
        return;
      }
      L.an.getFloatTimeDomainData(L.buf!);
      let s = 0;
      for (const v of L.buf!) s += v * v;
      const rms = Math.sqrt(s / L.buf!.length);
      if (rms > 0) L.max = Math.max(L.max, 20 * Math.log10(rms));
      L.samples++;
    }, 20);
  });
}

async function loudness(page: Page): Promise<FirstMinute['startLoudness']> {
  await page.waitForFunction(() => (window as any).__gpLoud?.done, null, { timeout: 6000 }).catch(() => {});
  const L = await page.evaluate(() => {
    const l = (window as any).__gpLoud;
    return l ? { max: l.max as number, samples: l.samples as number, done: !!l.done, advanced: l.ct1 - l.ct0 } : null;
  });
  if (!L) return null;
  if (!L.done) return { maxDb: null, measured: false, note: 'no host.audio within 6 s of the first touch (no sound unlocked)' };
  if (L.advanced < 1) return { maxDb: null, measured: false, note: `the AudioContext didn't run in this browser (${L.advanced.toFixed(2)} s of audio time in 3 s)` };
  return { maxDb: Number.isFinite(L.max) ? Math.round(L.max * 10) / 10 : null, measured: true, note: `${L.samples} samples` };
}

/** A seeded random source for the touch bot (mulberry32): the same taps every run */
function botRng(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/**
 * A new player on a phone who doesn't read: into play the obvious way (the biggest button, when the game doesn't land
 * there), then random taps and drags for 30 s. The game must keep them playing: 15 s of gameplay, or a run event (a
 * score, a hit, a fail, the results) — not a menu or a sheet the random touches opened and can't leave, nor a run that
 * never reacts to touch
 */
async function touchBot(ctx: QaContext): Promise<FirstMinute['touchBot']> {
  const { context, page } = await openFresh(ctx);
  try {
    for (let i = 0; i < 2 && !(await waitGameplay(page, i ? 2000 : 1500)); i++) {
      if (!(await nextButton(page))) break;
      await page.locator('[data-gp-qa-next="1"]').first().tap().catch(() => {});
      await page.evaluate(() => document.querySelectorAll('[data-gp-qa-next]').forEach((e) => e.removeAttribute('data-gp-qa-next')));
    }
    const cdp = await context.newCDPSession(page);
    const rnd = botRng(7);
    const url = page.url();
    const sec = touchBotSec(ctx);
    // The first fail or results while the bot touches: a new player's first minute ending in a loss (or a results screen)
    const from = await page.evaluate(() => {
      const w = window as any;
      const t0 = performance.now();
      w.__gpBotEnd = null;
      w.__gpBotWins = 0;
      window.__gp.events.on((e: { type: string; data?: Record<string, unknown> }) => {
        // A level won (host.roundEnd({ won: true }): Hang the Moon's night hung by random taps) is no loss — the host's
        // own firstFail funnel step reads it the same way
        if (e.type === 'round:end' && e.data?.won === true) w.__gpBotWins++;
        else if (w.__gpBotEnd === null && (e.type === 'fail' || e.type === 'round:end')) w.__gpBotEnd = { type: e.type, sec: Math.round((performance.now() - t0) / 100) / 10 };
      });
      return window.__gp.events.log.length;
    });
    let taps = 0;
    let drags = 0;
    const end = Date.now() + sec * 1000;
    while (Date.now() < end) {
      if (page.url().split('?')[0] !== url.split('?')[0]) {
        await page.goto(url).catch(() => {});
        await page.waitForFunction(() => window.__gp?.host, null, { timeout: 10000 }).catch(() => {});
      }
      const x = Math.round(12 + rnd() * (PHONE.width - 24));
      const y = Math.round(12 + rnd() * (PHONE.height - 24));
      if (rnd() < 0.3) {
        // A drag: a thumb swiping across the screen
        const x2 = Math.round(Math.max(4, Math.min(PHONE.width - 4, x + (rnd() - 0.5) * 240)));
        const y2 = Math.round(Math.max(4, Math.min(PHONE.height - 4, y + (rnd() - 0.5) * 240)));
        await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x, y }] }).catch(() => {});
        for (let i = 1; i <= 6; i++) {
          await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: x + ((x2 - x) * i) / 6, y: y + ((y2 - y) * i) / 6 }] }).catch(() => {});
          await sleep(30);
        }
        await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] }).catch(() => {});
        drags++;
      } else {
        await page.touchscreen.tap(x, y).catch(() => {});
        taps++;
      }
      await sleep(250 + Math.round(rnd() * 200));
    }
    const res = await page
      .evaluate((from) => {
        const start = window.__portal.calls.find((c) => c.fn === 'gameplayStart')?.t ?? null;
        const run = ['score', 'highlight', 'twist', 'round:end', 'target:pop', 'target:miss', 'fail', 'round:start'];
        const screens = window.__gp.events.log.filter((e: { type: string }) => e.type === 'screen');
        return {
          start,
          played: window.__gp.host.playedSec as number,
          playing: !!window.__gp.host.isPlaying,
          screen: (screens.at(-1)?.data.name as string | undefined) ?? null,
          events: window.__gp.events.log.slice(from).filter((e: { type: string }) => run.includes(e.type)).length,
          failedAt: ((window as any).__gpBotEnd ?? null) as { type: string; sec: number } | null,
          wins: Number((window as any).__gpBotWins ?? 0),
        };
      }, from)
      .catch(() => ({ start: null, played: 0, playing: false, screen: null, events: 0, failedAt: null, wins: 0 }));
    await page.screenshot({ path: join(ctx.outDir, 'first-minute-touch-bot.png') }).catch(() => {});
    return { gameplaySec: res.start === null ? null : Math.round(res.start * 10) / 10, playedSec: res.played ?? 0, events: res.events, taps, drags, endedOn: res.playing ? 'play' : res.screen, sec, failedAt: res.failedAt, wins: res.wins };
  } finally {
    await context.close();
  }
}

/**
 * The first minute (Basic Launch, 2026-10-04: 20–68 % of players played a minute; the target is 80 %+), on a phone with a
 * fresh profile — a new player: how many clicks from load to gameplay (CrazyGames: "Games should land new users in
 * gameplay immediately. If this is not feasible given the game specifics, a maximum of 1 click is allowed"); whether a
 * player who touches nothing loses within seconds; how much text before the first action; the on-screen touch controls
 * at the first frame; a naive touch bot; the start's loudness; and — the demo bot playing — when the first celebrated
 * moment and the twist come. On crazygames the first six are gates (failed checks); elsewhere hints. qa/first-minute.json
 * has the numbers (`gp review` reads them); the frame rate at 4× CPU comes at the quiet end (runFirstMinuteFps)
 */
async function runFirstMinute(ctx: QaContext): Promise<void> {
  const S = 'first minute';
  const failed: string[] = [];
  const fm: Omit<FirstMinute, 'fps4x'> = {
    playReadyMs: null,
    playToRunMs: null,
    idleEndSec: null,
    words: 0,
    firstHighlightSec: null,
    twistSec: null,
    demoEndSec: null,
    clicksToGameplay: null,
    clickPath: [],
    loadToGameplayMs: null,
    funnel: [],
    touchControls: null,
    touchBot: null,
    startLoudness: null,
    failed,
  };
  const runEnded = (page: Page, since: number) =>
    page.evaluate((since) => window.__portal.calls.some((c) => c.fn === 'gameplayStop' && c.t > since) && !window.__gp.host.paused, since);
  // A new player: load → gameplay in clicks; then they touch nothing
  {
    const { context, page, t0 } = await openFresh(ctx);
    try {
      if (await waitGameplay(page, 1500)) fm.clicksToGameplay = 0;
      else {
        const play = page.locator('[data-gp=play]').first();
        fm.playReadyMs = await play
          .waitFor({ state: 'visible', timeout: 15000 })
          .then(() => Date.now() - t0)
          .catch(() => null);
        let clicks = 0;
        if (fm.playReadyMs !== null) {
          await play.tap();
          clicks = 1;
          fm.clickPath.push('Play');
          const tapAt = Date.now();
          if (await waitGameplay(page, 8000)) fm.playToRunMs = Date.now() - tapAt;
        }
        // Not in play yet: what a new player does next — the Skip of a story, else the biggest button — up to 3 clicks
        while (!(await inGameplay(page)) && clicks < 3) {
          const label = await nextButton(page);
          if (!label) break;
          await page.locator('[data-gp-qa-next="1"]').first().tap().catch(() => {});
          await page.evaluate(() => document.querySelectorAll('[data-gp-qa-next]').forEach((e) => e.removeAttribute('data-gp-qa-next')));
          clicks++;
          fm.clickPath.push(label);
          await waitGameplay(page, 3000);
        }
        fm.clicksToGameplay = (await inGameplay(page)) ? clicks : null;
      }
      if (fm.clicksToGameplay !== null) {
        const at = await gameplayAt(page);
        fm.loadToGameplayMs = at === null ? null : Math.round(at * 1000);
        if (fm.clicksToGameplay === 0) {
          fm.playReadyMs = fm.loadToGameplayMs;
          fm.playToRunMs = 0;
        }
        // A story dialog over the run's first frame is one more click before the player plays (it must be skipped)
        await sleep(150);
        const dialog = await page.locator('[data-gp=dialog]').first().isVisible().catch(() => false);
        if (dialog) {
          fm.clicksToGameplay++;
          fm.clickPath.push('(a story dialog over the run)');
        }
        // The first frame of play: the on-screen controls must be there before the first touch (Spin Brawl's stick wasn't)
        fm.touchControls = await touchControlsNow(page);
        await page.screenshot({ path: join(ctx.outDir, 'first-minute-0s.png') }).catch(() => {});
      }
      const since = (await gameplayAt(page)) ?? (await page.evaluate(() => performance.now() / 1000));
      if (fm.clicksToGameplay !== null) {
        for (let t = 0; t < IDLE_SEC; t++) {
          await sleep(1000);
          if (t < 6) fm.words = Math.max(fm.words, await wordsOnScreen(page));
          if (t === 0) await page.screenshot({ path: join(ctx.outDir, 'first-minute-1s.png') }).catch(() => {});
          if (t === 4) await page.screenshot({ path: join(ctx.outDir, 'first-minute-5s.png') }).catch(() => {});
          if (await runEnded(page, since)) {
            fm.idleEndSec = t + 1;
            break;
          }
        }
      }
      fm.funnel = await page.evaluate(() => window.__gp.events.log.filter((e: { type: string }) => e.type === 'funnel').map((e: { data: { step: string; sec: number } }) => ({ step: e.data.step, sec: e.data.sec })));
    } finally {
      await context.close();
    }
  }
  const zero = fm.clicksToGameplay === 0;
  // The demo bot playing (when does the game first celebrate, and the twist), the touch bot, and the start's loudness
  const demoRun = async () => {
    const { context, page } = await openFresh(ctx);
    try {
      if (!zero) {
        const play = page.locator('[data-gp=play]').first();
        if (!(await play.isVisible().catch(() => false))) return;
        await play.tap();
      }
      const demo = await page.evaluate(() => {
        const d = window.__gp.host.qaDriver;
        if (typeof d.demo !== 'function') return false;
        d.demo();
        return true;
      });
      if (!demo) return;
      // Polled once a second: the events' own clock is the app's, the portal stub's is performance.now() in seconds
      const from = await page.evaluate(() => ({ n: window.__gp.events.log.length, t: performance.now() / 1000 }));
      for (let t = 0; t < DEMO_SEC; t++) {
        await sleep(1000);
        const st = await page.evaluate((from) => {
          const log: { type: string }[] = window.__gp.events.log.slice(from.n);
          return {
            hl: log.some((e) => e.type === 'highlight'),
            tw: log.some((e) => e.type === 'twist'),
            end: window.__portal.calls.some((c) => c.fn === 'gameplayStop' && c.t > from.t) && !window.__gp.host.paused,
          };
        }, from);
        if (st.hl && fm.firstHighlightSec === null) fm.firstHighlightSec = t + 1;
        if (st.tw && fm.twistSec === null) fm.twistSec = t + 1;
        if (st.end) {
          fm.demoEndSec = t + 1;
          break;
        }
        if (fm.firstHighlightSec !== null && fm.twistSec !== null && t >= 20) break;
      }
    } finally {
      await context.close();
    }
  };
  const loudRun = async () => {
    const { context, page } = await openFresh(ctx);
    try {
      await listenStart(page);
      // The player's first touch: Play, or (in play already) a tap on the middle of the screen
      const play = page.locator('[data-gp=play]').first();
      if (!zero && (await play.isVisible().catch(() => false))) await play.tap();
      else await page.touchscreen.tap(PHONE.width / 2, PHONE.height / 2);
      fm.startLoudness = await loudness(page);
    } finally {
      await context.close();
    }
  };
  await Promise.all([demoRun(), touchBot(ctx).then((r) => void (fm.touchBot = r)), loudRun()]);

  writeFirstMinute(ctx, fm);
  // --- The numbers, and the gates (checks on crazygames)
  const sec = (ms: number | null) => (ms === null ? '—' : `${(ms / 1000).toFixed(1)} s`);
  const c = fm.clicksToGameplay;
  gate(
    ctx,
    failed,
    'first visit: in gameplay within 1 click of loading (CrazyGames: "land new users in gameplay immediately… a maximum of 1 click")',
    c !== null && c <= 1,
    c === null
      ? `no gameplay within 3 clicks (${fm.clickPath.join(' → ') || 'no Play button'}): a new player must reach play in one tap`
      : `${c} click${c === 1 ? '' : 's'}${fm.clickPath.length ? ` (${fm.clickPath.join(' → ')})` : ''}, gameplay ${sec(fm.loadToGameplayMs)} after the page opened${c > 1 ? ' — a prologue, a modal or a controls card before play: move it into play (one hint at a time: hints()), or after the first run' : ''}`,
  );
  if (c === 1) ctx.info(S, 'first visit: 0 clicks is best', 'the Play button is the one click allowed — a new player (host.firstVisit) can land straight in a safe first run, with the title after it (docs/guides/first-minute.md)');
  if (c !== 0) gate(ctx, failed, 'Play starts the run within 8 s, with no other tap', fm.playToRunMs !== null, fm.playToRunMs !== null ? `${sec(fm.playToRunMs)} after the tap` : 'no run within 8 s of Play without another tap: a menu, a mode choice or a popup stands between the player and the game');
  ctx.info(S, 'a tappable Play after opening (phone)', zero ? `none needed: gameplay ${sec(fm.loadToGameplayMs)} after opening` : sec(fm.playReadyMs));
  if (c !== null)
    gate(ctx, failed, `a new player who touches nothing is still playing after ${IDLE_SEC} s`, fm.idleEndSec === null, fm.idleEndSec !== null ? `the run ends after ${fm.idleEndSec} s — a new player who is still looking loses before they start: the first seconds can't be lost (the first threat sleeps)` : `still playing after ${IDLE_SEC} s`);
  if (c !== null)
    gate(ctx, failed, `at most ${FIRST_MINUTE_MAX_WORDS} words on screen before the first action (the first 6 s of the run)`, fm.words <= FIRST_MINUTE_MAX_WORDS, fm.words ? `${fm.words} at most${fm.words > FIRST_MINUTE_MAX_WORDS ? ' — show the rule, don\'t write it: one hint of ≤ 6 words when the action is needed (hints())' : ''}` : 'none in the DOM or the declared canvas text');
  const tc = fm.touchControls;
  if (tc && tc.declared > 0) gate(ctx, failed, 'touch controls visible at the first frame of play (phone)', tc.hidden.length === 0, tc.hidden.length ? `not visible before the first touch: ${tc.hidden.join(', ')} — draw the stick and buttons from the first frame (Spin Brawl's invisible stick)` : `${tc.declared} declared, all visible`);
  else if (c !== null) ctx.info(S, 'touch controls at the first frame of play', 'none declared (data-gp-touch on DOM controls, host.qa({ touchControls }) for canvas ones) — fine for a game steered by a drag or a tap anywhere');
  const tb = fm.touchBot;
  if (tb) {
    const sec = tb.sec ?? touchBotSec(ctx);
    const plays = tb.gameplaySec !== null && (tb.playedSec >= 15 || tb.events > 0);
    // A new player's first minute must not end: a fail (host.fail) or a results screen (host.roundEnd) while the bot
    // touches fails on crazygames — before 2026-10-19 a fail counted as "a run event", a pass (Frankengun: lost at 40 s)
    const ended = tb.failedAt ?? null;
    const ok = plays && !ended;
    gate(
      ctx,
      failed,
      `a naive touch bot (random taps and drags for ${sec} s at 360×800) keeps playing: 15 s of gameplay or a run event, and no fail or results in that time`,
      ok,
      `${tb.gameplaySec !== null ? `gameplay from ${tb.gameplaySec} s, ${tb.playedSec} s of it` : 'never in gameplay'}; ${tb.taps} taps, ${tb.drags} drags; ${tb.events} run events (score, hits, fails, results)${tb.wins ? `; ${tb.wins} won (host.roundEnd({ won: true }): no loss)` : ''}${ended ? `; ${ended.type === 'fail' ? 'a fail (host.fail)' : 'the results (host.roundEnd, not won)'} ${ended.sec} s after it began` : ''}; at the end: ${tb.endedOn ?? 'not in play (no host.screen name)'}${
        ok
          ? ''
          : ended
            ? ` — a new player who touches at random loses (or the run ends) within ${sec} s: make the first run safe for its first minute (the first threats sleep, a hit only knocks back, a timer runs past a minute) — host.firstVisit says it is that player (E_QA_FIRST_RUN_LOST, first-minute-touch-bot.png)`
            : " — random touches left the game on a screen it can't get back from, or the run never reacts to touch (first-minute-touch-bot.png)"
      }`,
    );
  }
  const ld = fm.startLoudness;
  if (ld?.measured && ld.maxDb !== null) gate(ctx, failed, `the start isn't loud: nothing over ${START_LOUD_DB} dBFS in the first 3 s of sound`, ld.maxDb <= START_LOUD_DB, `loudest ${ld.maxDb} dBFS (RMS over ≈ 43 ms, the host's output)${ld.maxDb > START_LOUD_DB ? ' — soften the first sounds (Potion Logic\'s "deafening" boil at the start)' : ''}`);
  else ctx.info(S, 'the start\'s loudness (first 3 s of sound)', ld ? (ld.measured ? 'silent' : `not measured: ${ld.note}`) : 'not measured');
  // Beside the balance model's first reward, when its section ended first (otherwise it says both)
  if (ctx.notes) ctx.notes.firstHighlightSec = fm.firstHighlightSec;
  const model = ctx.notes?.modelFirstRewardSec;
  const reward = model !== undefined ? ` — the balance model's first reward: ${model === null ? 'none' : `${Math.round(model)} s of play`}` : '';
  ctx.info(S, 'the first celebrated moment (host.happytime), the demo bot playing', `${fm.firstHighlightSec !== null ? `${fm.firstHighlightSec} s after Play` : `none within ${DEMO_SEC} s (or no host.happytime calls / no demo bot)`}${reward}`);
  ctx.info(S, 'the funnel of that first visit (host events)', fm.funnel.map((f) => `${f.step} ${f.sec.toFixed(1)} s`).join(' → ') || 'none (a platform without the funnel)');
}

/**
 * The frame rate in the first 30 s of a new player's run at 4× CPU slowdown (a mid-range phone, CDP
 * Emulation.setCPUThrottlingRate), the demo bot playing when the game has one. Alone at the quiet end of the run: other
 * pages would take its frames. A gate on crazygames (under FIRST_MINUTE_MIN_FPS_4X), a hint elsewhere
 */
async function runFirstMinuteFps(ctx: QaContext): Promise<void> {
  const failed: string[] = [];
  const { context, page } = await openFresh(ctx);
  let cdp: import('playwright').CDPSession | null = null;
  const samples: FpsSample[] = [];
  try {
    if (!(await waitGameplay(page, 1500))) {
      const play = page.locator('[data-gp=play]').first();
      if (await play.isVisible().catch(() => false)) await play.tap();
      else await page.evaluate(() => window.__gp.host.qaDriver.play());
      await waitGameplay(page, 5000);
    }
    await page.locator('[data-gp=dialog-skip]:visible').first().tap({ timeout: 500 }).catch(() => {});
    await page.evaluate(() => window.__gp.host.qaDriver.demo?.());
    cdp = await context.newCDPSession(page);
    await cdp.send('Emulation.setCPUThrottlingRate', { rate: PHONE_CPU_SLOWDOWN });
    for (const at of [1000, 8000, 8000]) {
      await sleep(at);
      // A run that ended meanwhile: the next one, as a player taps Play again
      if (!(await page.evaluate(() => window.__gp.host.isPlaying && !window.__gp.host.paused))) {
        await page.evaluate(() => {
          window.__gp.host.qaDriver.play();
          window.__gp.host.qaDriver.demo?.();
        });
        await sleep(300);
      }
      samples.push(await sampleFps(page, FPS_SAMPLE_MS));
    }
  } catch {
    // No CDP (another browser): not measured
  } finally {
    await cdp?.send('Emulation.setCPUThrottlingRate', { rate: 1 }).catch(() => {});
    await cdp?.detach().catch(() => {});
    await context.close();
  }
  const ran = samples.filter((s) => s.ran !== false);
  if (!ran.length) {
    ctx.info('first minute', `play at 4× CPU slowdown, the first 30 s (a phone)`, 'not measured (no run going, or no CDP)');
    writeFirstMinute(ctx, { fps4x: { fps: null, samples: [], mainMs: null }, failed });
    return;
  }
  // The median of the samples (at 1 s, 9 s and 17 s of play): one start-up hitch (the first bakes) doesn't decide it
  const sorted = [...ran].sort((a, b) => a.fps - b.fps);
  const mid = sorted[Math.floor((sorted.length - 1) / 2)];
  let note = '';
  if (sorted[0].fps < FIRST_MINUTE_MIN_FPS_4X) {
    const load = machineLoad();
    if (load.busy) note = ` (the machine is busy: ${load.text})`;
  }
  const name = `play at 4× CPU slowdown (a mid-range phone): ≥ ${FIRST_MINUTE_MIN_FPS_4X} fps in the first 30 s`;
  const ok = mid.fps >= FIRST_MINUTE_MIN_FPS_4X;
  const text = `${mid.fps.toFixed(1)} fps (median of ${ran.map((s) => s.fps.toFixed(1)).join(' / ')})${mid.mainMs !== null ? `, main thread ${mid.mainMs.toFixed(1)} ms per frame` : ''}${note}`;
  gate(ctx, failed, name, ok, ok ? text : `${text} — it will stutter on a phone: bake, fewer particles on AutoQuality, no full-screen passes (docs/guides/art.md → Performance)`);
  writeFirstMinute(ctx, { fps4x: { fps: Math.round(mid.fps * 10) / 10, samples: ran.map((s) => Math.round(s.fps * 10) / 10), mainMs: mid.mainMs === null ? null : Math.round(mid.mainMs * 10) / 10 }, failed });
}

// --- The look: desktop layout, the hero, glyph icons, faces, magnified bitmaps, the title's choices, a 3D camera ------
// What portal reviewers and our second agents found by hand while gp qa was green (CrazyGames: "the overall quality"):
// docs/guides/code-games.md → What gp qa checks: the look

/** A crazygames build: the desktop layout and the hero are checks (desktop decides); elsewhere hints */
const desktopGated = (ctx: QaContext) => ctx.game.channel.id === 'crazygames';

/**
 * A screen at a desktop size (1280×720, 821×462): on crazygames a clearly empty or flat screen fails (FLAT_FAIL_LIMITS:
 * most of it one colour, most of it featureless, or one featureless area of 40 % of the screen); elsewhere the numbers
 * are a hint. `recheck`: a play frame is shot again 2 s later (to this path) before it fails (an act card, a fade-in)
 */
async function desktopLook(ctx: QaContext, page: Page, scope: string, screen: string, png: Buffer, opts: { recheck?: string } = {}): Promise<void> {
  let f = await flatFrameOf(page, png).catch(() => null);
  if (!f) return;
  let why = emptyLayout(f);
  if (why.length && opts.recheck) {
    await sleep(2000);
    const again = await page.screenshot({ path: opts.recheck }).catch(() => null);
    const g = again ? await flatFrameOf(page, again).catch(() => null) : null;
    if (g) {
      f = g;
      why = emptyLayout(g);
    }
  }
  const L = FLAT_FAIL_LIMITS;
  const name = `${screen}: not an empty or flat screen at a desktop size (one colour < ${L.topShare * 100} %, featureless < ${L.uniformShare * 100} %, no featureless area of ${L.emptyRect * 100} %)`;
  const nums = `top colour ${Math.round(f.topShare * 100)} % (${f.topColor}), ${Math.round(f.uniformShare * 100)} % featureless, the largest featureless area ${Math.round(f.emptyRect * 100)} %, ${f.levels}/32 lightness levels`;
  const fix =
    "a desktop screen is where CrazyGames' reviewers judge the look: fill it — a lit background with layers behind every screen (@gp/art scenery and light), the world scaled with the screen, panels sized for 1280×720 rather than a phone column in the middle (E_QA_DESKTOP_EMPTY, docs/guides/art.md)";
  if (desktopGated(ctx)) ctx.check(scope, name, why.length === 0, why.length ? `${why.join('; ')} — ${fix}` : nums);
  else if (why.length) ctx.info(scope, `${name} (a check on crazygames)`, `NO — ${why.join('; ')}`);
}

/** host.qa({ hero }) now: the rect (CSS px), null when the game says there is none now, or why it can't be read */
async function heroNow(page: Page): Promise<{ declared: boolean; rect?: { x: number; y: number; w: number; h: number } | null; error?: string; view: { width: number; height: number } }> {
  return page.evaluate(() => {
    const d = window.__gp?.host?.qaDriver;
    const view = { width: innerWidth, height: innerHeight };
    if (!d || d.hero === undefined) return { declared: false, view };
    let r: any;
    try {
      r = typeof d.hero === 'function' ? d.hero() : d.hero;
    } catch (e) {
      return { declared: true, error: `hero() threw: ${String(e)}`, view };
    }
    if (r === null || r === undefined) return { declared: true, rect: null, view };
    if (![r.x, r.y, r.w, r.h].every((v) => typeof v === 'number' && Number.isFinite(v))) return { declared: true, error: 'hero must be { x, y, w, h } in CSS px (or a function returning one, or null)', view };
    return { declared: true, rect: { x: r.x, y: r.y, w: r.w, h: r.h }, view };
  });
}

/** The hero in play at this size: ≥ HERO_MIN_SHARE of the short side — a check on crazygames, a hint elsewhere */
async function heroCheck(ctx: QaContext, page: Page, scope: string, opts: { gate?: boolean } = {}): Promise<void> {
  const h = await heroNow(page);
  const name = `play: the hero (host.qa hero) is at least ${HERO_MIN_SHARE * 100} % of the screen's short side`;
  if (!h.declared) {
    const g = ctx.game;
    const genre = gameGenre({ kit: g.kit.kit, audience: g.audience.id, money: g.money, tags: g.listing.tags });
    const required = desktopGated(ctx) && heroRequired(genre.genre, g.listing.tags);
    const how = "host.qa({ hero: () => ({ x, y, w, h }) }) names the player's object, so QA can tell a speck on a desktop screen";
    // Required (an action, shooting or arcade game on crazygames): one failure, at the size that gates it
    if (required && opts.gate)
      ctx.check(scope, `${name} — declared (required for ${genre.sub ?? genre.genre}${g.listing.tags.some((t) => /^arcade$/i.test(t)) ? ', tagged Arcade' : ''} on crazygames)`, false, `not declared — ${how}: the rejected action games' sprites were 30–40 px at 1280×720, under the 43 px the check asks (E_QA_HERO_MISSING)`);
    else if (desktopGated(ctx)) ctx.info(scope, name, `not declared — ${how} (${required ? 'E_QA_HERO_MISSING' : 'E_QA_HERO_SMALL'})`);
    return;
  }
  if (h.error) return ctx.check(scope, name, false, h.error);
  if (!h.rect) return ctx.info(scope, name, 'hero() returned null in play — not checked');
  const v = heroVerdict(h.rect, h.view);
  if (desktopGated(ctx)) ctx.check(scope, name, v.ok, v.text + (v.ok ? '' : ' (E_QA_HERO_SMALL)'));
  else ctx.info(scope, `${name} (a check on crazygames)`, `${v.ok ? 'yes' : 'NO'} — ${v.text}`);
}

/** The visible text with icon glyphs in it (emoji, ◆ ✓ ✕ ● ▶ …): text nodes, ::before / ::after content, canvasUi text */
export async function glyphIcons(page: Page): Promise<{ glyphs: string[]; text: string; where: string; platform: boolean }[]> {
  return page.evaluate(({ src, arrows }) => {
    const re = () => new RegExp(src, 'gu');
    // An arrow between two words or numbers is running text ("×1.0 → ×1.1"), not an icon (@gp/qa/glyphs)
    const inText = new RegExp(arrows, 'gu');
    const out = new Map<string, { glyphs: string[]; text: string; where: string; platform: boolean }>();
    const desc = (el: Element) => {
      const cn = (el as HTMLElement).className;
      const cls = typeof cn === 'string' && cn.trim() ? `.${cn.trim().split(/\s+/)[0]}` : '';
      const root = el.parentElement?.closest('[id]');
      return `${el.tagName.toLowerCase()}${el.id ? `#${el.id}` : cls}${root && root !== document.body ? ` in #${root.id}` : ''}`;
    };
    const visible = (el: Element) => {
      if (el.getClientRects().length === 0) return false;
      let o = 1;
      for (let p: Element | null = el; p; p = p.parentElement) {
        const st = getComputedStyle(p);
        if (st.visibility === 'hidden' || st.display === 'none') return false;
        o *= Number(st.opacity);
      }
      return o >= 0.05;
    };
    const add = (el: Element, text: string, where: string) => {
      const g = [...new Set(text.replace(inText, ' ').match(re()) ?? [])];
      if (!g.length) return;
      const t = text.replace(/\s+/g, ' ').trim();
      const key = `${where}|${t}`;
      if (!out.has(key)) out.set(key, { glyphs: g, text: t.length > 40 ? `${t.slice(0, 39)}…` : t, where, platform: !!el.closest('[id^="gp-"]') });
    };
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    for (let n = walker.nextNode(); n; n = walker.nextNode()) {
      const el = n.parentElement;
      const text = n.textContent ?? '';
      if (!el || !text.trim() || el.closest('script, style, noscript, template') || !visible(el)) continue;
      add(el, text, desc(el));
    }
    for (const el of document.body.querySelectorAll('*')) {
      for (const pseudo of ['::before', '::after']) {
        const c = getComputedStyle(el, pseudo).content;
        if (!c || c === 'none' || c === 'normal' || !/^["']/.test(c)) continue;
        if (visible(el)) add(el, c.replace(/^["']|["']$/g, ''), `${desc(el)}${pseudo}`);
      }
    }
    const d = window.__gp?.host?.qaDriver;
    try {
      for (const r of (typeof d?.canvasUi === 'function' ? d.canvasUi() : []) ?? []) if (typeof r?.text === 'string') add(document.body, r.text, `canvas "${r.name}"`);
    } catch {
      // canvasUi is checked elsewhere
    }
    return [...out.values()];
  }, { src: ICON_GLYPH_SOURCE, arrows: TEXT_ARROW_SOURCE });
}

/**
 * Icon glyphs on a screen fail, naming the element and the screen — the game's own text and what it hands the
 * platform's screens (#gp-*: a currency or reward icon as text) alike; the platform's own marks are drawn (@gp/core/icons)
 */
async function glyphCheck(ctx: QaContext, page: Page, scope: string, screen: string): Promise<void> {
  const found = await glyphIcons(page).catch(() => null);
  if (!found) return;
  const line = (f: (typeof found)[number]) => `${f.glyphs.join(' ')} in "${f.text}" (${f.where}${f.platform ? ', a platform screen: pass a drawn icon from @gp/core/icons' : ''})`;
  ctx.check(
    scope,
    `${screen}: no glyphs as icons in the visible text (emoji, ◆ ✓ ✕ ● ▶ ⚡ …)`,
    found.length === 0,
    found.length
      ? `${found.slice(0, 5).map(line).join('; ')}${found.length > 5 ? ` (+${found.length - 5} more)` : ''} — a font's symbol reads as a web page, not a game: draw the icon (an SVG or a canvas sprite in the game's style), or drop it from the text (E_QA_GLYPH_ICON)`
      : 'none',
  );
}

/** The faces the visible text renders in: the DOM text now, or (`canvas`) the canvas text drawn so far on the page (the probe) */
async function faceUses(page: Page, canvas = false): Promise<FaceUse[]> {
  const raw = await page.evaluate((canvas) => {
    const loaded: string[] = [];
    const declared: string[] = [];
    for (const f of document.fonts as unknown as Iterable<FontFace>) {
      const n = f.family.replace(/^["']|["']$/g, '').toLowerCase();
      declared.push(n);
      if (f.status === 'loaded') loaded.push(n);
    }
    const lists: Record<string, number> = {};
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    for (let n = canvas ? null : walker.nextNode(); n; n = walker.nextNode()) {
      const el = n.parentElement;
      const chars = (n.textContent ?? '').replace(/\s+/g, '').length;
      if (!el || !chars || el.closest('script, style, noscript, template') || el.getClientRects().length === 0) continue;
      const st = getComputedStyle(el);
      if (st.visibility === 'hidden' || Number(st.opacity) === 0) continue;
      lists[st.fontFamily] = (lists[st.fontFamily] ?? 0) + chars;
    }
    const cv: Record<string, number> = canvas ? Object.fromEntries((window.__gpProbe?.canvasFonts as Map<string, number> | undefined) ?? []) : {};
    return { loaded, declared, lists, cv };
  }, canvas);
  const faces = { loaded: new Set(raw.loaded), declared: new Set(raw.declared) };
  return [...Object.entries(raw.lists), ...Object.entries(raw.cv)].map(([list, chars]) => ({ ...renderingFace(list, faces), chars }));
}

/** The title's interactive choices now: DOM controls on screen and canvas buttons (host.qa canvasUi) */
async function titleChoices(page: Page): Promise<string[]> {
  return page.evaluate(() => {
    const names: string[] = [];
    for (const el of document.querySelectorAll<HTMLElement>('button, [role=button], a[href], input, select, [data-gp-touch]')) {
      const r = el.getBoundingClientRect();
      const st = getComputedStyle(el);
      if (r.width < 2 || r.height < 2 || st.visibility === 'hidden' || st.display === 'none' || (el as HTMLButtonElement).disabled) continue;
      if (r.right <= 0 || r.bottom <= 0 || r.left >= innerWidth || r.top >= innerHeight) continue;
      if (el.parentElement?.closest('button, [role=button], a[href]')) continue;
      names.push((el.innerText || el.getAttribute('aria-label') || el.dataset.gp || el.tagName.toLowerCase()).replace(/\s+/g, ' ').trim().slice(0, 20));
    }
    const d = window.__gp?.host?.qaDriver;
    try {
      for (const r of (typeof d?.canvasUi === 'function' ? d.canvasUi() : []) ?? []) if (r?.kind === 'button') names.push(`${r.name} (canvas)`);
    } catch {
      // canvasUi is checked elsewhere
    }
    return names;
  });
}

/** The camera a three game renders with: host.qa({ camera }) or the three adapter's eng.camera (host.engineCamera) */
async function cameraNow(page: Page): Promise<(CameraLike & { source: string; view: number }) | null> {
  return page.evaluate(() => {
    const host = window.__gp?.host;
    let cam: any = null;
    let source = '';
    try {
      if (typeof host?.qaDriver?.camera === 'function') {
        cam = host.qaDriver.camera();
        source = 'host.qa camera()';
      }
      if (!cam && typeof host?.engineCamera === 'function') {
        cam = host.engineCamera();
        source = "the three adapter's eng.camera";
      }
    } catch {
      cam = null;
    }
    if (!cam || typeof cam !== 'object') return null;
    const num = (v: unknown) => (typeof v === 'number' && Number.isFinite(v) ? v : undefined);
    return { source, isPerspectiveCamera: !!cam.isPerspectiveCamera, isOrthographicCamera: !!cam.isOrthographicCamera, fov: num(cam.fov), aspect: num(cam.aspect), zoom: num(cam.zoom), hfov: num(cam.hfov), view: innerWidth / innerHeight };
  });
}

/** A three game in portrait: the camera's horizontal field of view ≥ PORTRAIT_MIN_HFOV (other engines: not checked) */
async function fovCheck(ctx: QaContext, page: Page, scope: string): Promise<void> {
  const g = ctx.game.kit as { kit: string; engine?: { name: string } | null };
  if (g.engine?.name !== 'three') return;
  const vp = page.viewportSize();
  if (!vp || vp.height <= vp.width) return;
  const name = `play in portrait: the 3D camera sees at least ${PORTRAIT_MIN_HFOV}° across (horizontal field of view)`;
  const cam = await cameraNow(page);
  if (!cam) return ctx.info(scope, name, "no camera found (the three adapter's eng.camera, or host.qa({ camera: () => camera })) — not checked");
  const h = horizontalFovDeg(cam, cam.view);
  if (h === null) return ctx.info(scope, name, `${cam.source}: ${cam.isOrthographicCamera ? 'an orthographic camera' : 'no fov and aspect'} — not checked`);
  const ok = h >= PORTRAIT_MIN_HFOV - 0.05;
  ctx.check(
    scope,
    name,
    ok,
    `${h.toFixed(1)}° across (${cam.source}${cam.fov !== undefined ? `: fov ${cam.fov.toFixed(1)}° vertical, aspect ${(cam.aspect ?? cam.view).toFixed(2)}` : ''})${ok ? '' : ` — in portrait a fixed vertical fov leaves a slit to see through: widen it from the aspect, fov = 2·atan(tan(${PORTRAIT_MIN_HFOV}°/2) / aspect), on every resize (E_QA_PORTRAIT_FOV, docs/guides/three-fps.md)`}`,
  );
}

/** Bitmaps drawn magnified on this page so far (the probe): over MAG_FAIL fails, over MAG_WARN warns, with the screen and size */
async function magnifiedCheck(ctx: QaContext, page: Page, scope: string): Promise<void> {
  const list: Magnified[] = await page.evaluate(() => [...((window.__gpProbe?.mags as Map<string, Magnified> | undefined)?.values() ?? [])]).catch(() => []);
  const j = judgeMagnified(list);
  const dpr = await page.evaluate(() => devicePixelRatio).catch(() => 1);
  ctx.check(
    scope,
    `images: no bitmap drawn over ${MAG_FAIL}× its own pixels per device pixel (at devicePixelRatio ${dpr})`,
    j.fail.length === 0,
    j.fail.length
      ? `${j.fail.slice(0, 4).join('; ')}${j.fail.length > 4 ? ` (+${j.fail.length - 4} more)` : ''} — a small bitmap blown up is mush («Пиксельное месиво»): bake or paint it at the size it is drawn × devicePixelRatio (SpriteCache bakes at the density; gp art paints at the asset's size), or keep pixel art crisp (imageSmoothingEnabled = false) (E_QA_BITMAP_MAGNIFIED)`
      : list.length
        ? `${list.length} drawn over 1.05×, the largest ${Math.max(...list.map((m) => m.scale)).toFixed(2)}×`
        : 'none drawn magnified',
  );
  if (j.warn.length) ctx.info(scope, `images: drawn over ${MAG_WARN}× their own pixels (a warning: soft)`, `${j.warn.slice(0, 4).join('; ')}${j.warn.length > 4 ? ` (+${j.warn.length - 4} more)` : ''} — bake them at the drawn size × devicePixelRatio`);
}

/**
 * The results screen's primary action continues play (T1: each results screen is an exit — Hang the Moon had 14 a
 * session): the biggest button, rewarded offers aside, is the one into the next run (data-gp="again" / "next" / "play",
 * or its words), and Menu is smaller
 */
async function resultsPrimary(page: Page): Promise<{ ok: boolean; text: string } | null> {
  return page.evaluate(() => {
    const go = /^(▶\s*)?(play again|again|next( level)?|continue|retry|try again|restart|replay|one more)\b/i;
    const all = [...document.querySelectorAll<HTMLElement>('button, [role=button]')]
      .filter((b) => {
        const r = b.getBoundingClientRect();
        return r.width > 0 && r.height > 0 && getComputedStyle(b).visibility !== 'hidden' && !b.closest('[data-gp-rewarded], [data-gp=lang], [data-gp=sign-in]');
      })
      .map((b) => {
        const r = b.getBoundingClientRect();
        const text = (b.innerText || b.getAttribute('aria-label') || '').trim().split('\n')[0];
        return { text: text || b.dataset.gp || 'button', area: r.width * r.height, size: `${Math.round(r.width)}×${Math.round(r.height)}`, primary: ['again', 'next', 'play'].includes(b.dataset.gp ?? '') || go.test(text) };
      });
    if (!all.length) return null;
    const prim = all.filter((b) => b.primary).sort((a, b) => b.area - a.area)[0];
    const biggest = [...all].sort((a, b) => b.area - a.area)[0];
    if (!prim) return { ok: false, text: `no button goes on into the next run (data-gp="again" / "next"): ${all.map((b) => `"${b.text}"`).join(', ')}` };
    const rivals = all.filter((b) => b !== prim && b.area >= prim.area * 0.95);
    if (biggest !== prim && biggest.area > prim.area * 1.05) return { ok: false, text: `"${biggest.text}" ${biggest.size} is bigger than "${prim.text}" ${prim.size}: make the way into the next run the big button and Menu small (mountResults does)` };
    return { ok: true, text: `"${prim.text}" ${prim.size}${rivals.length ? ` — as big as ${rivals.map((r) => `"${r.text}"`).join(', ')}: make Menu smaller (mountResults)` : ''}` };
  });
}

// --- The calibration's checks: the title's key art, the later play frame, play text, collections, scope -------------
// docs/research/qa-calibration-2026-10.md: what the rejected games shared that no check caught, and the blind review

/** A warning (ctx.warn when the runner has it, else a note) */
const warnLine = (ctx: QaContext, scope: string, name: string, details: string) => (ctx.warn ?? ctx.info)(scope, name, details);

/**
 * The share of the screen under DOM layers painted over a page canvas: `covered` under an opaque one (a panel, a modal:
 * the layers' alphas combined ≥ PANEL_MIN_ALPHA), `dimmed` under a translucent one only. A layer is an element after the
 * canvas in the document (or positioned with a z-index) that contains no canvas, with a background colour or gradient (an
 * image background is art, not a panel), or a backdrop blur; its alpha × the opacities up the tree. Sampled on a
 * 128×72 grid. null: no canvas covers a quarter of the screen
 */
async function titleCoverage(page: Page): Promise<{ covered: number; dimmed: number } | null> {
  return page.evaluate((minAlpha) => {
    const vw = innerWidth;
    const vh = innerHeight;
    const shown = (el: Element) => {
      let o = 1;
      for (let p: Element | null = el; p; p = p.parentElement) {
        const st = getComputedStyle(p);
        if (st.display === 'none' || st.visibility === 'hidden') return 0;
        o *= Number(st.opacity);
      }
      return o;
    };
    const canvases = [...document.querySelectorAll('canvas')]
      .map((c) => ({ c, r: c.getBoundingClientRect() }))
      .filter(({ c, r }) => r.width * r.height >= vw * vh * 0.25 && shown(c) > 0.05);
    if (!canvases.length) return null;
    const alphaOf = (s: string) => {
      const m = s.match(/rgba?\(([^)]*)\)/g) ?? [];
      if (!m.length) return 0;
      const a = m.map((x) => {
        const parts = x.replace(/^rgba?\(|\)$/g, '').split(/[\s,/]+/).filter(Boolean);
        return parts[3] === undefined ? 1 : parts[3].endsWith('%') ? parseFloat(parts[3]) / 100 : parseFloat(parts[3]);
      });
      return a.reduce((n, v) => n + v, 0) / a.length;
    };
    const layers: { x0: number; y0: number; x1: number; y1: number; a: number }[] = [];
    for (const el of document.body.querySelectorAll('*')) {
      if (/^(CANVAS|IMG|SVG|VIDEO|PICTURE|SCRIPT|STYLE|svg)$/.test(el.tagName) || el.closest('svg') || el.querySelector('canvas')) continue;
      const r = el.getBoundingClientRect();
      if (r.width < 4 || r.height < 4 || r.right <= 0 || r.bottom <= 0 || r.left >= vw || r.top >= vh) continue;
      const st = getComputedStyle(el);
      const above = canvases.some(({ c }) => c.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING) || (st.position !== 'static' && Number(st.zIndex) > 0);
      if (!above) continue;
      let a = alphaOf(st.backgroundColor);
      if (st.backgroundImage && st.backgroundImage !== 'none' && !st.backgroundImage.includes('url(')) a = Math.max(a, alphaOf(st.backgroundImage));
      const bf = (st as unknown as { backdropFilter?: string }).backdropFilter ?? '';
      if (/blur\(/.test(bf) && !/blur\(0(px)?\)/.test(bf)) a = Math.max(a, 0.8);
      if (a < 0.15) continue;
      const o = shown(el);
      if (a * o < 0.15) continue;
      layers.push({ x0: r.left, y0: r.top, x1: r.right, y1: r.bottom, a: a * o });
    }
    let covered = 0;
    let dimmed = 0;
    const N = 128;
    const M = 72;
    for (let j = 0; j < M; j++)
      for (let i = 0; i < N; i++) {
        const x = ((i + 0.5) / N) * vw;
        const y = ((j + 0.5) / M) * vh;
        if (!canvases.some(({ r }) => x >= r.left && x < r.right && y >= r.top && y < r.bottom)) continue;
        let clear = 1;
        for (const l of layers) if (x >= l.x0 && x < l.x1 && y >= l.y0 && y < l.y1) clear *= 1 - Math.min(1, l.a);
        const a = 1 - clear;
        if (a >= minAlpha) covered++;
        else if (a >= 0.25) dimmed++;
      }
    return { covered: covered / (N * M), dimmed: dimmed / (N * M) };
  }, PANEL_MIN_ALPHA);
}

/** A title-like declared screen, judged like the first screen at 1280×720 */
export const TITLE_SCREEN = /^(title|title-screen|menu|main-?menu|home|start)$/i;

/**
 * The title's key art (at 1280×720): how much of it opaque DOM panels cover, and whether the canvas alone has detail (a
 * shot with the DOM hidden). Over TITLE_COVER_FAIL fails on crazygames, over TITLE_COVER_WARN warns (E_QA_TITLE_COVERED)
 */
async function titleCoverCheck(ctx: QaContext, page: Page, scope: string, screen: string): Promise<void> {
  const cov = await titleCoverage(page).catch(() => null);
  const name = `${screen}: the key art not hidden behind panels (opaque DOM over the canvas ≤ ${TITLE_COVER_WARN * 100} %; over ${TITLE_COVER_FAIL * 100} % fails on crazygames)`;
  if (!cov) return ctx.info(scope, name, 'no canvas covers a quarter of the screen — not judged');
  await domHidden(page, true);
  let detail = true;
  try {
    const bare = await page.screenshot();
    const f = await flatFrameOf(page, bare).catch(() => null);
    detail = !!f && !f.flat;
  } finally {
    await domHidden(page, false);
  }
  const v = titleCoverVerdict({ ...cov, detail }, desktopGated(ctx));
  if (v.level === 'fail') ctx.check(scope, name, false, v.text);
  else if (v.level === 'warn') warnLine(ctx, scope, `${name} — E_QA_TITLE_COVERED (a warning)`, v.text);
  else if (desktopGated(ctx)) ctx.check(scope, name, true, v.text);
  else ctx.info(scope, name, v.text);
}

/** The text a player reads now: the DOM's visible text and the canvas text drawn in the next 300 ms, with what's behind each (from `png`) */
async function playTexts(page: Page, png: Buffer): Promise<PlayText[]> {
  const dom = await page.evaluate(() => {
    const out: { text: string; px: number; where: string; color: string; alpha: number; outline: string | null; x: number; y: number; w: number; h: number }[] = [];
    const vw = innerWidth;
    const vh = innerHeight;
    const desc = (el: Element) => {
      const cn = (el as HTMLElement).className;
      const cls = typeof cn === 'string' && cn.trim() ? `.${cn.trim().split(/\s+/)[0]}` : '';
      return `${el.tagName.toLowerCase()}${el.id ? `#${el.id}` : cls}`;
    };
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    for (let n = walker.nextNode(); n && out.length < 120; n = walker.nextNode()) {
      const el = n.parentElement;
      const text = (n.textContent ?? '').replace(/\s+/g, ' ').trim();
      if (!el || !/[\p{L}\p{N}]/u.test(text) || el.closest('script, style, noscript, template, canvas')) continue;
      let o = 1;
      let hidden = false;
      for (let p: Element | null = el; p; p = p.parentElement) {
        const st = getComputedStyle(p);
        if (st.display === 'none' || st.visibility === 'hidden') hidden = true;
        o *= Number(st.opacity);
      }
      // A text fading in or out (a popup) is not judged mid-fade
      if (hidden || o < 0.5) continue;
      const range = document.createRange();
      range.selectNodeContents(n);
      const r = range.getBoundingClientRect();
      if (r.width < 1 || r.height < 1 || r.right <= 0 || r.bottom <= 0 || r.left >= vw || r.top >= vh) continue;
      const st = getComputedStyle(el);
      const stroke = parseFloat(st.getPropertyValue('-webkit-text-stroke-width')) > 0 ? st.getPropertyValue('-webkit-text-stroke-color') : null;
      // A shadow that hugs the glyphs (blur ≤ 4 px) is an outline; a soft glow is not
      const sh = st.textShadow && st.textShadow !== 'none' ? st.textShadow.match(/(rgba?\([^)]*\)|#[0-9a-f]{3,8})\s+(-?[\d.]+)px\s+(-?[\d.]+)px(?:\s+([\d.]+)px)?/i) : null;
      const shadow = sh && parseFloat(sh[4] ?? '0') <= 4 ? sh[1] : null;
      out.push({ text: text.slice(0, 60), px: parseFloat(st.fontSize), where: desc(el), color: st.color, alpha: o, outline: stroke ?? shadow, x: r.left, y: r.top, w: r.width, h: r.height });
    }
    return out;
  });
  const cv = await canvasTexts(page).catch(() => []);
  const boxes = [...dom, ...cv];
  const pixels = await boxPixels(page, png, boxes).catch(() => boxes.map(() => [] as number[]));
  const colour = (s: string | null, alpha: number): [number, number, number, number] | null => {
    const c = parseColor(s);
    return c ? [c[0], c[1], c[2], c[3] * alpha] : null;
  };
  return boxes.map((b, i): PlayText => {
    const color = colour(b.color, b.alpha);
    const isDom = i < dom.length;
    return {
      text: b.text,
      px: b.px,
      source: isDom ? 'dom' : 'canvas',
      where: isDom ? (b as (typeof dom)[number]).where : 'canvas text',
      color,
      outline: colour(b.outline, 1),
      bg: color && pixels[i]?.length ? textBackground(pixels[i], color) : null,
    };
  });
}

/** Play text at 1280×720 judged (E_QA_PLAY_TEXT): HUD numbers under 12 px fail on crazygames, small or low-contrast text warns */
function playTextVerdict(ctx: QaContext, scope: string, when: string, texts: PlayText[]): void {
  const v = judgePlayText(texts, desktopGated(ctx));
  const name = `${when}: play text readable at 1280×720 (HUD numbers ≥ ${HUD_NUMBER_MIN_PX} px; text ≥ ${PLAY_TEXT_MIN_PX} px and ≥ ${PLAY_TEXT_MIN_CONTRAST}:1 against what's behind it)`;
  const fix = " — reviewers judge on a desktop: HUD numbers of 16 px or more in the game's face, a plate or an outline behind text over the scene (a stroke, a hard shadow), never a pale text on a pale sky (E_QA_PLAY_TEXT)";
  const list = (l: string[]) => `${l.slice(0, 5).join('; ')}${l.length > 5 ? ` (+${l.length - 5} more)` : ''}`;
  if (!v.judged) return ctx.info(scope, name, 'no text in play (DOM or canvas) — not judged');
  if (desktopGated(ctx)) ctx.check(scope, name, v.fail.length === 0, v.fail.length ? list(v.fail) + fix : `${v.judged} texts`);
  const all = [...(desktopGated(ctx) ? [] : v.fail), ...v.warn];
  if (all.length) warnLine(ctx, scope, `${name} — E_QA_PLAY_TEXT (a warning)`, list(all) + fix);
  else if (!desktopGated(ctx)) ctx.info(scope, name, `${v.judged} texts, all readable`);
}

/**
 * The look at 1280×720 beyond the first frames: the title's key art (E_QA_TITLE_COVERED), the play text 2 s into a demo
 * run, and the later play frame — ≥ LATER_PLAY_SEC s in, still in play — measured for an empty or flat screen like the
 * first (E_QA_DESKTOP_EMPTY) and its text again. Screenshot desktop-1280x720-5-play-later.png
 */
async function runDesktopLook(ctx: QaContext): Promise<void> {
  const S = 'desktop-look';
  const { context, page, errors } = await openDesktop(ctx);
  try {
    await titleCoverCheck(ctx, page, S, 'first screen');
    const endsBefore = await roundEnds(page);
    await startRun(page);
    const t0 = Date.now();
    await page.evaluate(() => window.__gp.host.qaDriver.demo?.());
    await sleep(2000);
    const early = await page.screenshot();
    const texts = await playTexts(page, early);
    const playing = async () => (await lastGameplay(page)) === 'gameplayStart' && (await roundEnds(page)) === endsBefore;
    const later = `play ${LATER_PLAY_SEC} s in: not an empty or flat screen`;
    if (!(await playing())) {
      playTextVerdict(ctx, S, 'play 2 s in', texts);
      return ctx.info(S, later, 'the run ended (or paused) within 2 s — not measured');
    }
    await sleep(Math.max(0, LATER_PLAY_SEC * 1000 - (Date.now() - t0)));
    if (!(await playing())) {
      playTextVerdict(ctx, S, 'play 2 s in', texts);
      const demo = await page.evaluate(() => typeof window.__gp.host.qaDriver.demo === 'function');
      return ctx.info(S, later, `the run ended before ${LATER_PLAY_SEC} s${demo ? ' with the demo bot' : ' (no demo bot: host.qa({ demo }) keeps a run going)'} — not measured`);
    }
    const shot = await page.screenshot({ path: `${ctx.outDir}/desktop-1280x720-5-play-later.png` });
    texts.push(...(await playTexts(page, shot)));
    playTextVerdict(ctx, S, `play (2 s and ${LATER_PLAY_SEC} s in)`, texts);
    await desktopLook(ctx, page, S, `play ${LATER_PLAY_SEC} s in`, shot, { recheck: `${ctx.outDir}/desktop-1280x720-5-play-later-again.png` });
    ctx.check(S, 'no errors', errors.length === 0, errors.slice(0, 3).join(' | '));
  } finally {
    await context.close();
  }
}

/**
 * The biggest group of alike items on screen (≥ 6 visible siblings of one tag and first class, each 24 px to a quarter
 * of the screen): each item's text and its images (img, canvas, svg, a url() background) ≥ 16 px a side, two at most
 */
async function collectionItems(page: Page): Promise<{ text: string; images: { x: number; y: number; w: number; h: number }[] }[]> {
  return page.evaluate(() => {
    const vw = innerWidth;
    const vh = innerHeight;
    const visible = (el: Element) => {
      const r = el.getBoundingClientRect();
      if (r.width < 16 || r.height < 16 || r.right <= 0 || r.bottom <= 0 || r.left >= vw || r.top >= vh) return null;
      for (let p: Element | null = el; p; p = p.parentElement) {
        const st = getComputedStyle(p);
        if (st.display === 'none' || st.visibility === 'hidden' || Number(st.opacity) < 0.05) return null;
      }
      return r;
    };
    let best: Element[] = [];
    for (const parent of document.body.querySelectorAll('*')) {
      if (parent.children.length < 6) continue;
      const groups = new Map<string, Element[]>();
      for (const k of parent.children) {
        const r = visible(k);
        if (!r || r.width < 24 || r.height < 24 || r.width * r.height > vw * vh * 0.25) continue;
        const cn = (k as HTMLElement).className;
        const sig = `${k.tagName}|${typeof cn === 'string' ? (cn.trim().split(/\s+/)[0] ?? '') : ''}`;
        groups.set(sig, [...(groups.get(sig) ?? []), k]);
      }
      for (const g of groups.values()) if (g.length > best.length) best = g;
    }
    if (best.length < 6) return [];
    return best.slice(0, 60).map((item) => {
      const images: { x: number; y: number; w: number; h: number }[] = [];
      for (const el of [item, ...item.querySelectorAll('*')]) {
        if (images.length >= 2) break;
        const tag = el.tagName.toUpperCase();
        const isImg = tag === 'IMG' || tag === 'CANVAS' || tag === 'SVG' || getComputedStyle(el).backgroundImage.includes('url(');
        // An svg counts once (its own box), not its parts
        if (!isImg || (tag !== 'SVG' && el.closest('svg'))) continue;
        const r = visible(el);
        if (r) images.push({ x: r.left, y: r.top, w: r.width, h: r.height });
      }
      return { text: ((item as HTMLElement).innerText ?? '').replace(/\s+/g, ' ').trim().slice(0, 60), images };
    });
  });
}

/** A declared screen's collection on a fresh save: mostly "???", silhouettes or empty slots warns (W_META_SILHOUETTES) */
async function silhouetteCheck(ctx: QaContext, page: Page, scope: string, screen: string, png: Buffer): Promise<void> {
  const items = await collectionItems(page).catch(() => []);
  if (!items.length) return;
  const px = await boxPixels(page, png, items.flatMap((i) => i.images), 32).catch(() => null);
  if (!px) return;
  let k = 0;
  const judged = items.map((i) => {
    const imgs = i.images.map(() => px[k++]);
    return { text: i.text, placeholderImage: imgs.length ? imgs.every((p) => isPlaceholderImage(p)) : null };
  });
  const v = silhouettesVerdict(judged);
  const name = `${screen}: a collection shows more than placeholders on a fresh save`;
  if (v.warn) warnLine(ctx, scope, `${name} — W_META_SILHOUETTES (a warning)`, v.text);
  else ctx.info(scope, name, v.text);
}

/**
 * Canvas UI in the portal's small frames (821×462, 800×450 at devicePixelRatio 1): its text ≥ 12 px. The rects (title,
 * and 1.5 s into a run, as the production frames run takes its shots) go to ctx.canvasUi: the production run checks they
 * have pixels drawn in the upload
 */
async function runCanvasUiFrames(ctx: QaContext): Promise<void> {
  const S = 'canvas UI, portal frames';
  for (const f of PORTAL_FRAMES) {
    const { context, page } = await openDesktop(ctx, { width: f.width, height: f.height }, 1);
    try {
      const title = await canvasUi(page, ctx.game.minTouchPx, MIN_TEXT_PX);
      if (!title) return; // the game declares no canvas UI
      const play = page.locator('[data-gp=play]').first();
      if (await play.isVisible().catch(() => false)) await play.click();
      else await page.mouse.click(f.width / 2, f.height / 2);
      await sleep(1500);
      const inPlay = (await canvasUi(page, ctx.game.minTouchPx, MIN_TEXT_PX))!;
      ctx.canvasUi[`${f.name}:title`] = title.rects;
      ctx.canvasUi[`${f.name}:play`] = inPlay.rects;
      const bad = [...title.bad.map((b) => `first screen: ${b}`), ...inPlay.bad.map((b) => `play: ${b}`)];
      ctx.check(S, `${f.name}: canvas text ≥ ${MIN_TEXT_PX} px, buttons on screen and ≥ ${ctx.game.minTouchPx} px (first screen and play)`, bad.length === 0, bad.slice(0, 4).join('; ') || `${title.rects.length} + ${inPlay.rects.length} rects`);
    } finally {
      await context.close();
    }
  }
}

export const suite: QaSuite = {
  kit: 'code',
  prod: {
    async play(page) {
      const el = page.locator('[data-gp=play]').first();
      if (await el.isVisible().catch(() => false)) await el.tap();
      else {
        const vp = page.viewportSize()!;
        await page.touchscreen.tap(vp.width / 2, vp.height / 2);
      }
    },
  },
  sections: true,
  needs: { production: ['canvas-ui-frames'] },
  async run(ctx) {
    // In parallel (ctx.jobs > 1) the frame rate and the twist wait for quiet(): other pages would take their frames
    const parallel = (ctx.jobs ?? 1) > 1;
    // The longest first (the pool takes them in this order, and the report lists them so)
    const sections: QaSection[] = [
      ...viewports(ctx).map((vp) => ({ name: vp.name, run: (c: QaContext) => runViewport(c, vp, { fps: !parallel }) })),
      // The feel section plays the longest (the virtual clock, frame by frame): it starts early
      { name: 'feel', run: runFeel },
      { name: 'ads', run: runAds },
      { name: 'screens', run: runScreens },
      { name: 'canvas-ui-frames', run: runCanvasUiFrames },
      { name: 'desktop-821x462', run: runDesktopFrame },
      { name: 'desktop-look', run: runDesktopLook },
      ...(ctx.extra ?? []),
      { name: 'languages', run: runLanguages },
      { name: 'ads-nav', run: runAdsNav },
      ...(parallel ? [] : [{ name: 'twist', run: runTwist }]),
      { name: 'context-loss', run: runContextLoss },
      { name: 'focus', run: runFocus },
      { name: 'sound', run: runSound },
      { name: 'first-minute', run: runFirstMinute },
      ...(parallel ? [] : [{ name: 'first-minute fps', run: runFirstMinuteFps }]),
    ];
    await runSections(asReturning(ctx), sections);
  },
  async quiet(ctx) {
    await runSections(asReturning(ctx), [...viewports(ctx).map((vp) => ({ name: `fps ${vp.name}`, run: (c: QaContext) => runFps(c, vp) })), { name: 'twist', run: runTwist }, { name: 'first-minute fps', run: runFirstMinuteFps }], 1);
  },
};

function viewports(ctx: QaContext): (typeof VIEWPORTS)[number][] {
  return ctx.quick ? VIEWPORTS.slice(0, 1) : [...VIEWPORTS];
}

/** The frame rate at one screen size, alone on the machine: into a run as runViewport goes (Play, the steering test), then fpsCheck */
async function runFps(ctx: QaContext, vp: (typeof VIEWPORTS)[number]): Promise<void> {
  const context = await ctx.browser.newContext({ viewport: { width: vp.width, height: vp.height }, hasTouch: vp.touch, isMobile: vp.touch });
  await context.addInitScript(installProbe);
  const page = await context.newPage();
  try {
    await page.goto(`${ctx.url}?seed=7`);
    await page.waitForFunction(() => window.__gp?.host && window.__portal?.calls.some((c) => c.fn === 'loadingStop'), null, { timeout: 20000 });
    await sleep(500);
    // No host.qa play/end: the viewport's section already failed on it
    if (!(await page.evaluate(() => typeof window.__gp.host.qaDriver?.play === 'function'))) return;
    if (await page.locator('[data-gp=play]').first().isVisible().catch(() => false)) await tapSelector(page, '[data-gp=play]', vp.touch);
    else await page.evaluate(() => window.__gp.host.qaDriver.play());
    await page.waitForFunction(() => window.__portal.calls.at(-1)?.fn === 'gameplayStart', null, { timeout: 5000 }).catch(() => {});
    await sleep(300);
    await page.locator('[data-gp=dialog-skip]:visible').first().click({ timeout: 500 }).catch(() => {});
    const endsBefore = await roundEnds(page);
    await page.keyboard.down('KeyD');
    await sleep(400);
    await page.keyboard.up('KeyD');
    await page.waitForFunction((n) => window.__gp.events.count('round:end') > n, endsBefore, { timeout: 1200 }).catch(() => {});
    if ((await roundEnds(page)) > endsBefore) {
      await page.evaluate(() => window.__gp.host.qaDriver.play());
      await page.waitForFunction(() => window.__portal.calls.at(-1)?.fn === 'gameplayStart', null, { timeout: 5000 }).catch(() => {});
    }
    await sleep(300);
    await fpsCheck(ctx, page, vp.name);
    if (vp.touch) await phoneFpsHint(ctx, page, vp.name);
  } finally {
    await context.close();
  }
}
