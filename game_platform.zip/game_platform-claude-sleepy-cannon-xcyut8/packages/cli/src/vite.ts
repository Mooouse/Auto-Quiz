// Dev server and web build of a game, through Vite's API.

import { existsSync, readdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { build, createServer, preview, type InlineConfig, type PreviewServer, type ViteDevServer } from 'vite';
import { gameDependencies, viteCacheDir, wasmPackages } from './deps.ts';
import { PLAYER_DIR, ROOT, type GameLocation } from './paths.ts';
import { gpGame, type BuildPortal } from './vite-plugin.ts';

/**
 * `@gp/<pkg>` and its subpaths straight to the platform's sources, from each package's `exports`. So a game with its own
 * code builds wherever it lives — in games/, docs/examples/ or its own repository next to the platform — without
 * node_modules links (a game repo only links node_modules for its type checker).
 */
export function gpAliases(): { find: RegExp; replacement: string }[] {
  const out: { find: RegExp; replacement: string }[] = [];
  const pkgs = join(ROOT, 'packages');
  for (const dir of readdirSync(pkgs)) {
    const file = join(pkgs, dir, 'package.json');
    if (!existsSync(file)) continue;
    const pkg = JSON.parse(readFileSync(file, 'utf8')) as { name?: string; exports?: Record<string, string> };
    if (!pkg.name?.startsWith('@gp/') || !pkg.exports) continue;
    for (const [sub, target] of Object.entries(pkg.exports)) {
      const id = sub === '.' ? pkg.name : `${pkg.name}/${sub.replace(/^\.\//, '')}`;
      out.push({ find: new RegExp(`^${id.replace(/[/.]/g, '\\$&')}$`), replacement: join(pkgs, dir, target) });
    }
  }
  return out;
}

function config(loc: GameLocation, mode: 'dev' | 'release', opts: { draftTexts?: boolean; portal?: BuildPortal; frozen?: boolean } = {}): InlineConfig {
  const deps = gameDependencies(loc);
  return {
    root: PLAYER_DIR,
    configFile: false,
    // The dependency pre-bundle of this game (its own engine included) lives in the game folder, not in the platform's
    // packages/player/node_modules/.vite, which every game on a platform checkout would share (and race for)
    cacheDir: viteCacheDir(loc),
    // wasm-bindgen packages are served as they are: a pre-bundle would split their glue from their .wasm (deps.ts)
    optimizeDeps: { exclude: wasmPackages(loc) },
    resolve: { alias: gpAliases() },
    // Relative paths: works inside Capacitor and in a web portal's subfolder
    base: './',
    logLevel: 'warn',
    plugins: [gpGame(loc, mode, opts)],
    // build.target comes from the plugin: it depends on the channel's platform (BUILD_TARGETS in vite-plugin.ts)
    build: { outDir: join(loc.dir, 'dist'), emptyOutDir: true, sourcemap: false },
    // The game's folder may be outside the platform repository (a game repo next to it)
    server: { host: true, fs: { allow: [ROOT, loc.dir, ...(deps && deps.dir !== loc.dir ? [deps.dir] : [])] } },
  };
}

/**
 * `draftTexts` only for `gp dev` (checkGame): QA, covers and video start it without, so they refuse untranslated texts.
 * `frozen` for them too: no file watcher, no HMR — an edit during the run never reloads the page under test, and every
 * page load gets the game as it was first served (vite-plugin.ts); `gp dev` keeps both
 */
export async function startDev(loc: GameLocation, port?: number, opts: { draftTexts?: boolean; portal?: BuildPortal; frozen?: boolean } = {}): Promise<ViteDevServer> {
  const c = config(loc, 'dev', opts);
  const frozen = opts.frozen ? { watch: null, hmr: false } : {};
  const server = await createServer({ ...c, server: { ...c.server, port, strictPort: port !== undefined, ...frozen } });
  await server.listen();
  return server;
}

export interface BuildOptions {
  /** One JS bundle (no lazy chunks), one stylesheet, every imported asset inlined: to be folded into one index.html */
  singleFile?: boolean;
  /** Build for this portal's SDK instead of the channel's (gp build --target playgama), or for none (--target idos) */
  portal?: BuildPortal;
  /** An E2E build (test hooks) that still talks to the real portal SDK: gp playgama-check serves a fake one in its place */
  realPortal?: boolean;
}

export async function buildWeb(loc: GameLocation, mode: 'dev' | 'release', e2e = false, outDir = join(loc.dir, 'dist'), opts: BuildOptions = {}): Promise<string> {
  // One process may build and then start a dev server (gp qa): Vite's build sets NODE_ENV=production, which
  // would turn the dev server into a production one (real portal SDK instead of the stub). Restore both.
  const env = { e2e: process.env.VITE_E2E, node: process.env.NODE_ENV, real: process.env.VITE_REAL_PORTAL };
  process.env.VITE_E2E = e2e ? '1' : '';
  process.env.VITE_REAL_PORTAL = opts.realPortal ? '1' : '';
  try {
    const c = config(loc, mode, { portal: opts.portal });
    // E2E builds (device tests) keep names readable for the DevTools-driven test
    const single = opts.singleFile
      ? {
          modulePreload: false,
          cssCodeSplit: false,
          assetsInlineLimit: Number.MAX_SAFE_INTEGER,
          rolldownOptions: { output: { codeSplitting: false } },
          // One file is one chunk by design: the size and load budget (`gp build --target <portal>`) is the real check
          chunkSizeWarningLimit: Number.MAX_SAFE_INTEGER,
          // A sourcemap next to the bundle (not referenced by it, not in the upload): the size report's bytes per npm package
          sourcemap: 'hidden' as const,
        }
      : {};
    await build({ ...c, mode: 'production', build: { ...c.build, ...single, outDir, minify: e2e ? false : undefined } });
  } finally {
    for (const [k, v] of [['VITE_E2E', env.e2e], ['NODE_ENV', env.node], ['VITE_REAL_PORTAL', env.real]] as const) {
      if (v === undefined) delete process.env[k];
      else process.env[k] = v;
    }
  }
  return outDir;
}

/** Serve a finished build as a portal would: static files, nothing else */
export async function servePreview(loc: GameLocation, dir: string): Promise<PreviewServer> {
  // preview() sets NODE_ENV=production for the whole process too (see buildWeb)
  const node = process.env.NODE_ENV;
  try {
    return await preview({ ...config(loc, 'dev'), build: { outDir: dir }, preview: { host: '127.0.0.1', port: 0 } });
  } finally {
    if (node === undefined) delete process.env.NODE_ENV;
    else process.env.NODE_ENV = node;
  }
}
