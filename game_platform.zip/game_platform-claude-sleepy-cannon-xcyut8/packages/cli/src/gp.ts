#!/usr/bin/env node
// gp — the command line of the platform. `gp help` lists commands; every command has --json where it makes sense.

import { appendFileSync, cpSync, existsSync, mkdirSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { dirname, join, relative, resolve } from 'node:path';
import { parseDocument } from 'yaml';
import { CATALOG, CHANNELS, ENGINES, GAME_SCHEMA, GENERAL_BLOCKS, GENRE_BLOCKS, GENRE_IDS, GENRE_INFO, PHYSICS, SUBGENRE_INFO, UNSUPPORTED_ENGINES, blocksFor, catalogEntries, expectationsFor, explain, genreRows, genreTopic, loadYaml, type GameSpecInput } from '@gp/spec';
import type { Command } from './commands.ts';
import { editorSchemas, guideDocs, referenceDocs } from './docs.ts';
import { checkGame, DRAFT_TEXT_CODES, formatIssues, loadPublisher } from './game.ts';
import { DOCS_REFERENCE_DIR, GAMES_DIR, ROOT, SCHEMA_FILE, listExamples, listGames, locateGame, shown } from './paths.ts';

const out = (s = '') => process.stdout.write(s + '\n');
/** Keep one-line { a: 1 } maps and [1, 2] lists as the author wrote them */
const YAML_OUT = { lineWidth: 0, flowCollectionPadding: false } as const;

const commands: Command[] = [
  {
    name: 'validate',
    usage: 'validate [game] [--all] [--release] [--json]',
    description:
      'Check game.yaml: schema, references, audience and channel rules, and the story file when `story.file` declares one (against its depth: word counts, scene length, play before story, barks, shop and ad lines, children\'s voicing). Every issue has a code, a line, and a fix; hints (info) need no fix. `--all`: every game in games/ and every folder example (docs/examples/<name>/game.yaml). `--release` also requires real ad IDs and filled-in publisher data. Exit code 1 on errors.',
    async run(args, flags) {
      const mode = flags.release ? 'release' : 'dev';
      // --all: the games in games/ and the folder examples (docs/examples/<name>/game.yaml: Balloon Pop, code, art)
      const games = flags.all
        ? [...listGames().map((g) => locateGame(g)), ...listExamples().map((e) => ({ id: e.gameId ?? e.id, dir: e.dir, file: e.file }))]
        : [locateGame(args[0])];
      let failed = 0;
      const json: unknown[] = [];
      for (const loc of games) {
        const r = checkGame(loc, mode);
        if (!r.ok) failed++;
        if (flags.json) json.push({ game: loc.id, ok: r.ok, issues: r.issues });
        else {
          if (r.issues.length) out(formatIssues(loc, r.issues));
          const errs = r.issues.filter((i) => i.severity === 'error').length;
          const infos = r.issues.filter((i) => i.severity === 'info').length;
          out(`${r.ok ? '✓' : '✗'} ${loc.id}: ${errs} error(s), ${r.issues.length - errs - infos} warning(s)${infos ? `, ${infos} hint(s)` : ''}${mode === 'release' ? ' [release]' : ''}`);
        }
      }
      // The publisher's recorded results (the money model's calibration) are checked with every game
      if (flags.all) {
        const { loadResults, formatResultIssues } = await import('./forecast.ts');
        const res = loadResults();
        if (res.issues.some((i) => i.severity === 'error')) {
          failed++;
          if (!flags.json) for (const l of formatResultIssues(res.issues)) out(l);
        }
        if (!flags.json && existsSync(res.file)) out(`${res.issues.some((i) => i.severity === 'error') ? '✗' : '✓'} publisher/results.yaml: ${res.results.length} recorded result(s)`);
      }
      if (flags.json) out(JSON.stringify(flags.all ? json : json[0], null, 2));
      return failed ? 1 : 0;
    },
  },
  {
    name: 'explain',
    usage: 'explain <topic>',
    description: 'Explain an error code (E_…), a game.yaml field (round.goal), a profile (ages-2-5, android-families) or a catalog entry (sky-balloons, animals-en).',
    async run(args) {
      const topic = args[0];
      if (!topic) {
        out('Usage: gp explain <topic>. Topics: error codes, fields (e.g. round.trajectory), audience, channel, catalog ids.');
        return 1;
      }
      const text = explain(topic);
      if (!text) {
        out(`Nothing known about "${topic}". Try: gp catalog, gp explain audience, gp explain channel, or a field path like round.goal.`);
        return 1;
      }
      out(text);
      return 0;
    },
  },
  {
    name: 'catalog',
    usage: 'catalog [kind] [--json] · catalog genres · catalog blocks [--genre <g>]',
    description:
      "List building blocks: kits, mechanics, trajectories, themes, content packs, sticker packs. `genres`: the genres (money.genre) and their sub-genres — CrazyGames' average play and D1, what their players expect (the must-haves `gp validate` hints about: I_GENRE_EXPECTS) and the blocks only that genre uses (W_GENRE_BLOCK elsewhere); docs/guides/genres.md. `blocks`: the runtime blocks a code game imports (@gp/core, @gp/art, @gp/physics) and the genres they fit; `--genre <g>` only those that fit g (a genre or a sub-genre), its own first.",
    async run(args, flags) {
      const kind = args[0];
      if (kind === 'genres') {
        const rows = genreRows();
        if (flags.json) out(JSON.stringify({ genres: GENRE_INFO, subgenres: SUBGENRE_INFO, rows }, (_k, v) => (v instanceof RegExp ? String(v) : v), 2));
        else {
          out(`${'genre'.padEnd(14)} ${'name'.padEnd(28)} ${'min'.padEnd(8)} ${'D1'.padEnd(6)} ${'must-haves'.padEnd(30)} only here`);
          for (const r of rows) out(`${r.id.padEnd(14)} ${r.name.padEnd(28)} ${r.minutes.padEnd(8)} ${r.d1.padEnd(6)} ${(r.expects || '—').padEnd(30)} ${r.only}`);
          out('\nmoney.genre takes a genre or a sub-genre (benchmarked as its genre, ″). One genre: gp explain genre.<id> · its blocks: gp catalog blocks --genre <id>');
        }
        return 0;
      }
      if (kind === 'blocks') {
        const g = typeof flags.genre === 'string' ? genreTopic(flags.genre) : null;
        if (typeof flags.genre === 'string' && !g) {
          out(`--genre ${flags.genre}: not a genre. Genres: ${GENRE_IDS.join(', ')}`);
          return 1;
        }
        const blocks = g ? blocksFor(g.genre.id, g.sub?.id ?? null) : Object.values(GENRE_BLOCKS);
        const fits = (name: string) => [...Object.values(GENRE_INFO).filter((x) => x.blocks.includes(name)).map((x) => x.id), ...Object.values(SUBGENRE_INFO).filter((x) => x.blocks.includes(name)).map((x) => x.id)];
        const rows = blocks.map((b) => ({ ...b, genres: GENERAL_BLOCKS.includes(b.name) ? ['every genre'] : fits(b.name) }));
        if (flags.json) out(JSON.stringify(rows, null, 2));
        else {
          if (g) out(`Blocks for ${g.sub ? `${g.sub.id} (${g.genre.id})` : g.genre.id} — its own first, then those of every genre:\n`);
          for (const b of rows) out(`${b.name.padEnd(17)} ${b.from.padEnd(15)} ${b.what}${b.only ? ` [${b.only.join('/')} only]` : ''}${g ? '' : ` — ${b.genres.join(', ') || '—'}`}`);
          if (g) {
            const not = Object.values(GENRE_BLOCKS).filter((b) => b.only && !b.only.includes(g.genre.id));
            if (not.length) out(`\nNot for ${g.genre.id} (W_GENRE_BLOCK): ${not.map((b) => `${b.name} (${b.only!.join('/')})`).join(', ')}`);
          }
        }
        return 0;
      }
      if (kind && !(kind in CATALOG)) {
        out(`Unknown kind "${kind}". Kinds: ${Object.keys(CATALOG).join(', ')}, genres, blocks`);
        return 1;
      }
      const entries = catalogEntries().filter((e) => !kind || e.kind === kind);
      if (flags.json) out(JSON.stringify(entries, null, 2));
      else {
        for (const e of entries) out(`${e.kind.padEnd(10)} ${e.id.padEnd(18)} ${e.description}`);
        if (!kind) out('\nA code game: pick the genre (money.genre), then `gp catalog genres` says what its players expect and `gp catalog blocks --genre <g>` which blocks fit it.');
      }
      return 0;
    },
  },
  {
    name: 'new',
    usage: 'new <id> [--from <game>] [--title "Title"]',
    description:
      'Create games/<id>/game.yaml (games/ is made on demand) from an existing game (default: balloon-pop, the kids kit\'s example in docs/examples/kids) with a new id, appId, save key and privacy URL. Then change what makes the game its own: Google Play bans near-identical apps.',
    async run(args, flags) {
      const id = args[0];
      if (!id || !/^[a-z][a-z0-9-]{1,39}$/.test(id)) {
        out('Usage: gp new <id> — id in kebab-case, e.g. catch-a-star');
        return 1;
      }
      const dir = join(GAMES_DIR, id);
      if (existsSync(dir)) {
        out(`games/${id} already exists`);
        return 1;
      }
      const from = locateGame(String(flags.from ?? 'balloon-pop'));
      const doc = parseDocument(readFileSync(from.file, 'utf8'));
      const site = loadPublisher().developer?.website;
      const website = site && /^https:\/\//.test(site) ? site.replace(/\/$/, '') : 'https://example.com';
      if (website === 'https://example.com') out('Note: publisher/publisher.yaml has no developer.website — privacyPolicyUrl set to example.com, change it.');
      const code = doc.get('kit') === 'code';
      const android = CHANNELS[String(doc.get('channel'))]?.platform === 'android';
      doc.set('id', id);
      doc.set('title', typeof flags.title === 'string' ? flags.title : `TODO: title of ${id}`);
      doc.delete('saveKey');
      // The source game's concept and listing are its own: a new game writes its own (E_CONCEPT refuses a TODO)
      if (doc.has('concept'))
        doc.set('concept', { pitch: 'TODO: one sentence — what the player does and why it is fun', closest: ['TODO: the closest live game', 'TODO: the second', 'TODO: the third'], different: 'TODO: what the player DOES here that none of them has — a rule, an input or a goal' });
      // … and so is the money design: decided again with the new concept (E_MONEY refuses the TODO)
      if (doc.has('money')) doc.set('money', { genre: 'TODO: the genre', session: { minutes: 12, breaks: 4, breaksAt: 'TODO: where the natural breaks are' }, returns: { kind: 'meta', what: 'TODO: why a player comes back tomorrow' } });
      if (doc.has('listing')) doc.set('listing', { description: 'TODO: what the game is (genre and its twist), what the player does and why it is fun — then a short list of features. At least 150 characters, and it must match the covers and the video.', controls: 'TODO: Mouse: … · Keyboard: … · Touch: …', orientation: 'both' });
      if (!code && android) {
        const prefix = String(loadPublisher().developer?.appIdPrefix ?? 'com.example').replace(/\.$/, '');
        doc.set('appId', `${prefix}.${id.replace(/-/g, '')}`);
        doc.set('privacyPolicyUrl', `${website}/${id}/privacy-policy.html`);
        doc.setIn(['monetization', 'ads', 'appId'], 'auto');
        doc.setIn(['monetization', 'ads', 'interstitial'], 'auto');
      }
      doc.commentBefore = ` yaml-language-server: $schema=../../packages/spec/schema/game.${String(doc.get('kit') ?? 'kids')}.schema.json\n "${id}" — created with \`gp new ${id} --from ${from.id}\`. ${code ? 'Replace the code with your game (docs/guides/code-games.md).' : 'Make it its own game: mechanic or trajectory, content, theme, stickers, texts.'}`;
      mkdirSync(dir, { recursive: true });
      writeFileSync(join(dir, 'game.yaml'), doc.toString(YAML_OUT));
      // A code game's folder is its code: copy it too (not the build output, QA results or zips)
      const copied: string[] = [];
      if (code)
        for (const e of readdirSync(from.dir)) {
          if (e === 'game.yaml' || e === 'qa' || e === 'dist' || e === 'upload' || e === 'store' || e === 'submission' || e === 'node_modules' || e.endsWith('.zip')) continue;
          cpSync(join(from.dir, e), join(dir, e), { recursive: true });
          copied.push(e);
        }
      out(`Created games/${id}/game.yaml${copied.length ? ` and ${copied.join(', ')}` : ''} (from ${from.id}).`);
      out('Next: edit it → gp validate ' + id + ' → gp dev ' + id + ' → gp qa ' + id);
      return 0;
    },
  },
  {
    name: 'init',
    usage: 'init <dir> --id <game-id> --title "<Title>" [--engine canvas|pixi|phaser|three] [--physics]',
    description:
      "A new game repository from the platform's template (templates/game-repo): scripts to connect it to the platform, the type checker and tests, and a game skeleton that already does what every portal game must (screens, host lifecycle, a PLACEHOLDER progression with its balance report, a rewarded Continue done right, the cover frame, a demo bot for the video, a pure simulation with a balance bot and tests, the look drawn with @gp/art in art.ts: docs/guides/art.md) around a PLACEHOLDER mechanic you replace. Also docs/concept.md (the originality check) and REPORT.md. Its concept and its money design are TODO (`gp validate` refuses them: E_CONCEPT, E_MONEY) and so is its listing (a W_LISTING warning); `gp submission` refuses both, and the placeholder. `--engine` (default canvas: Canvas 2D, no package): pixi, phaser or three — the skeleton draws through that engine's adapter (@gp/core/engines/<name>: view.ts), games/<id>/package.json pins the version the adapter supports, scripts/setup.sh installs it into the game folder, and game.yaml says `engine: { name, version }` (docs/guides/code-games.md#engines). `--physics` (with --engine canvas, the default, or pixi; `--physics=rapier2d-deterministic` for the same floats on every machine): the PLACEHOLDER mechanic on Rapier 2D through the physics block @gp/physics — a ball bouncing off a platform, stepped by sim.ts on the adapter's fixed step, a fresh world at every run, the same physics in the balance bot — @dimforge/rapier2d-compat pinned in games/<id>/package.json, game.yaml `engine: { name, physics: { name, version } }` and the portal budget raised on purpose (`budget: { gzipKB: 1500 }`: Rapier is ≈ 1.3 MB gzipped) (docs/guides/code-games.md#physics).",
    async run(args, flags) {
      const target = args[0];
      const id = typeof flags.id === 'string' ? flags.id : '';
      if (!target || !/^[a-z][a-z0-9]*(-[a-z0-9]+)*$/.test(id) || id.length > 40) {
        out('Usage: gp init <dir> --id <game-id> --title "<Title>" [--engine canvas|pixi|phaser|three] [--physics]   (id: kebab-case, e.g. cloud-herder)');
        return 1;
      }
      const engineId = typeof flags.engine === 'string' ? flags.engine.trim().toLowerCase() : 'canvas';
      const engine = ENGINES[engineId];
      if (!engine) {
        out(UNSUPPORTED_ENGINES[engineId] ?? `--engine ${engineId}: no adapter for it on the platform.`);
        out(`Engines: ${Object.values(ENGINES).map((e) => `${e.id} (${e.range})`).join(' · ')}`);
        return 1;
      }
      // --physics (Rapier 2D, the default library) or --physics=<library>
      const physicsId = flags.physics === true ? 'rapier2d' : typeof flags.physics === 'string' ? flags.physics.trim().toLowerCase() : null;
      const physics = physicsId ? PHYSICS[physicsId] : null;
      if (physicsId && !physics) {
        out(`--physics=${physicsId}: the physics block runs ${Object.keys(PHYSICS).join(' or ')} (docs/guides/code-games.md#physics).`);
        return 1;
      }
      if (physics && engine.id !== 'canvas' && engine.id !== 'pixi') {
        out(`--physics: the skeleton draws its physics with Canvas 2D or Pixi (--engine canvas or pixi). ${engine.id === 'phaser' ? 'Phaser has its own Arcade physics; ' : ''}the block itself (@gp/physics) steps on any adapter's onStep — docs/guides/code-games.md#physics.`);
        return 1;
      }
      const dir = resolve(process.cwd(), target);
      if (existsSync(dir) && !statSync(dir).isDirectory()) {
        out(`${target} is a file, not a folder`);
        return 1;
      }
      if (existsSync(dir) && readdirSync(dir).filter((e) => e !== '.git').length) {
        out(`${target} is not empty: gp init only creates a new repository (a game inside the platform: gp new).`);
        return 1;
      }
      const title = typeof flags.title === 'string' ? flags.title : id.split('-').map((x) => x[0].toUpperCase() + x.slice(1)).join(' ');
      const tpl = join(ROOT, 'templates', 'game-repo');
      const files: string[] = [];
      const engineName = { canvas: 'Canvas 2D', pixi: 'PixiJS', phaser: 'Phaser', three: 'three.js' }[engine.id] ?? engine.id;
      const copyFile = (src: string, dst: string) => {
        // The title in code and YAML goes in as a quoted literal (an apostrophe or a quote must not break them)
        let text = readFileSync(src, 'utf8').replace(/__ID__/g, id).replace(/__ENGINE_ID__/g, engine.id).replace(/__ENGINE__/g, engineName);
        if (/\.(ts|mjs)$/.test(src)) text = text.replace(/'__TITLE__'/g, () => JSON.stringify(title));
        if (/\.ya?ml$/.test(src)) text = text.replace(/"__TITLE__"/g, () => JSON.stringify(title));
        text = text.replace(/__TITLE__/g, () => title);
        writeFileSync(dst, text, { mode: statSync(src).mode });
        if (!files.includes(relative(dir, dst))) files.push(relative(dir, dst));
      };
      const copy = (from: string, to: string) => {
        for (const e of readdirSync(from)) {
          const src = join(from, e);
          // The engine variants of the skeleton are applied below, not copied
          if (from === tpl && (e === 'engines' || e === 'physics')) continue;
          const dst = join(to, e.replace(/__ID__/g, id));
          if (statSync(src).isDirectory()) {
            mkdirSync(dst, { recursive: true });
            copy(src, dst);
          } else copyFile(src, dst);
        }
      };
      mkdirSync(dir, { recursive: true });
      copy(tpl, dir);
      initEngine(join(dir, 'games', id), id, engine, (name, to) => copyFile(join(tpl, 'engines', name), to));
      if (physics) initPhysics(join(dir, 'games', id), id, engine, physics, (name, to) => copyFile(join(tpl, name), to));
      if (engine.package || physics) files.push(join('games', id, 'package.json'));
      out(`✓ ${target}: ${files.length} files — games/${id}/ (a skeleton around a PLACEHOLDER mechanic, drawn with ${engineName}${engine.package ? ` ${engine.tested}` : ''}${engine.package || physics ? ` through @gp/core/engines/${engine.id}` : ''}${physics ? `, its physics on ${physics.package} ${physics.tested} through @gp/physics` : ''}), docs/concept.md, scripts/, README.md, CLAUDE.md`);
      const pinned = [...(engine.package ? [`${engine.package} ${engine.tested}`] : []), ...(physics ? [`${physics.package} ${physics.tested}`] : [])];
      if (pinned.length) out(`  ${pinned.join(' and ')} ${pinned.length > 1 ? 'are' : 'is'} pinned in games/${id}/package.json: scripts/setup.sh installs ${pinned.length > 1 ? 'them' : 'it'} into games/${id}/node_modules`);
      if (physics) out(`  Physics costs ≈ ${physics.gzipKB.toLocaleString('en-US')} KB gzipped: game.yaml raises the portal budget on purpose (budget: { gzipKB: 1500 }) — keep it only if physics is the mechanic`);
      out('Next:');
      out(`  1. docs/concept.md: search the portal for your genre and theme, then write concept and money in games/${id}/game.yaml — money.genre first: scripts/gp.sh catalog genres says what its players expect and which blocks fit (scripts/gp.sh forecast: what it can earn)`);
      out(`  2. scripts/setup.sh → scripts/gp.sh validate → replace the PLACEHOLDER mechanic (sim.ts, data.ts, main.ts) and progression (the shape your genre needs: docs/guides/upgrades.md; scripts/gp.sh balance)`);
      out('  3. scripts/gp.sh qa → scripts/gp.sh review (a second agent writes quality.md) → scripts/gp.sh submission → REPORT.md, and send the owner the submission files');
      return 0;
    },
  },
  {
    name: 'dev',
    usage: 'dev [game] [--port 5173] [--stop]',
    description: 'Run the game in the browser with test ads and a stub purchase. Editing game.yaml reloads the page; errors show in the page overlay and here. A code game\'s folder is watched whole (a file replaced by an editor or a tool — written elsewhere and renamed over it, or deleted and written again — is still seen; its outputs qa/, dist/, upload/, store/, submission/ are not watched), and every page load re-reads a game file whose mtime changed since it was served. Unfinished translations (E_I18N_MISSING, E_I18N_EMPTY) are warnings here: the game shows English for them, so it can be played while they are written; gp qa, build and submission refuse them. It prints its pid; `--stop` stops the game\'s running `gp dev` (from another shell, or after it was started in the background) — never `pkill -f vite`: in a cloud session that kills your own shell, whose command line has the word in it.',
    async run(args, flags) {
      const loc = locateGame(args[0]);
      const { clearDevRecord, readDevRecord, stopDev, writeDevRecord } = await import('./dev-pid.ts');
      if (flags.stop) {
        const stopped = await stopDev(loc.dir);
        out(stopped ? `${loc.id}: stopped gp dev (pid ${stopped.pid}, ${stopped.url})` : `${loc.id}: no gp dev is running for this game`);
        return 0;
      }
      const running = readDevRecord(loc.dir);
      if (running) {
        out(`${loc.id}: gp dev already runs (pid ${running.pid}): ${running.url} — gp dev --stop to stop it`);
        return 1;
      }
      // Unfinished translations don't stop a dev run (the game shows English there); everything else does
      const r = checkGame(loc, 'dev', { draftTexts: true });
      if (!r.ok) {
        out(formatIssues(loc, r.issues));
        return 1;
      }
      const drafts = r.issues.filter((i) => DRAFT_TEXT_CODES.includes(i.code));
      if (drafts.length) out(formatIssues(loc, drafts));
      const { startDev } = await import('./vite.ts');
      const server = await startDev(loc, flags.port ? Number(flags.port) : undefined, { draftTexts: true });
      out(`${loc.id}: ${server.resolvedUrls?.local[0] ?? 'http://localhost:5173/'}`);
      for (const u of server.resolvedUrls?.network ?? []) out(`  on the network: ${u}`);
      const url = server.resolvedUrls?.local[0] ?? 'http://localhost:5173/';
      writeDevRecord(loc.dir, { pid: process.pid, url });
      const bye = () => {
        clearDevRecord(loc.dir);
        void server.close().finally(() => process.exit(0));
      };
      process.once('SIGINT', bye);
      process.once('SIGTERM', bye);
      process.once('exit', () => clearDevRecord(loc.dir));
      out(`\n${loc.id}: test hooks on (window.__app, window.__gp), ?seed=<n> for a repeatable run.`);
      out(`${loc.id}: pid ${process.pid} — stop it with Ctrl+C or \`gp dev --stop\` (never \`pkill -f vite\`: it kills your own shell too).`);
      return await new Promise<number>(() => {});
    },
  },
  {
    name: 'build',
    usage: 'build [game] [--target web|android|crazygames|playgama|idos] [--release] [--e2e]',
    description:
      'Web build into games/<id>/dist. `--target crazygames` writes the upload instead: the production build folded into ONE self-contained games/<id>/upload/index.html (the CrazyGames form takes files, not archives), checked for the portal limits, test code and the SDK adapter. It prints the size and load budget: the upload raw and gzipped, each npm package\'s share (from the sourcemap), the estimated time to a tappable Play on a slow phone (1.6 Mbps, 150 ms RTT, 4× CPU), a warning above the channel\'s budget (CrazyGames: 400 KB gzipped, 3 s; game.yaml `budget: { gzipKB }` raises it on purpose), a failure above the hard limit (20 MB); the numbers go to upload/size.json for `gp forecast`. `--target android` also generates games/<id>/android (Capacitor project from the spec: appId, name, colors, AdMob App ID, version, theme icon) and syncs the web build into it; Gradle runs in CI. `--target playgama` (docs/guides/publishing-playgama.md) and `--target idos` (docs/guides/publishing-idosgames.md) write the same one-file upload for that portal into upload-<target>/ with its zip: Playgama Bridge instead of the CrazyGames SDK, or for iDos Games no portal SDK at all (a plain web build without ads). `--release` uses the real ad IDs and fails if anything is still a test ID or TODO. `--e2e` keeps test hooks (device tests).',
    async run(args, flags) {
      const loc = locateGame(args[0]);
      const mode = flags.release ? 'release' : 'dev';
      const r = checkGame(loc, mode);
      if (!r.ok || !r.game) {
        out(formatIssues(loc, r.issues));
        return 1;
      }
      const ch = CHANNELS[r.game.channel.id];
      if (flags.target === 'playgama' || flags.target === 'idos') {
        const target = flags.target;
        if (!ch.portal) {
          out(`--target ${target} is for a portal game (channel: crazygames); now: ${ch.id}`);
          return 1;
        }
        const { buildPortal } = await import('./portal-build.ts');
        const pkg = await buildPortal(loc, r.game, mode, target);
        for (const p of pkg.problems) out(`✗ ${p}`);
        if (pkg.problems.length) {
          out(`✗ ${loc.id}: nothing written to upload-${target}/`);
          return 1;
        }
        const kb = (pkg.bytes / 1024).toFixed(0);
        const what = target === 'playgama'
          ? `index.html + playgama-bridge-config.json, ${kb} KB (the same game, Playgama Bridge instead of the CrazyGames SDK)`
          : `index.html, ${kb} KB (the same game without a portal SDK: no ads, saves in the browser)`;
        out(`✓ ${loc.id}: ${shown(join(pkg.dir, `${r.game.id}-${target}.zip`))} — ${what}`);
        const { sizeLines } = await import('./size.ts');
        for (const l of sizeLines(pkg.size, ch.webLimits?.maxInitialMB)) out(l);
        out(target === 'playgama'
          ? '  Upload the zip: developer.playgama.com → your game → build (or the Playgama MCP server). Then pick the platforms. docs/guides/publishing-playgama.md'
          : '  Upload the zip to the game\'s Title (the iDos Games MCP server: begin_build_upload → curl -T → finish_build_upload). docs/guides/publishing-idosgames.md');
        return 0;
      }
      if (flags.target === 'crazygames' || (flags.target && flags.target === ch.portal)) {
        if (ch.portal !== flags.target) {
          out(`--target ${flags.target} needs channel: ${flags.target} in game.yaml (now: ${ch.id})`);
          return 1;
        }
        const { buildPortal } = await import('./portal-build.ts');
        const pkg = await buildPortal(loc, r.game, mode);
        for (const p of pkg.problems) out(`✗ ${p}`);
        out(`${pkg.problems.length ? '✗' : '✓'} ${loc.id}: ${pkg.problems.length ? 'nothing written to upload/' : shown(pkg.file)} — one file, ${(pkg.bytes / 1024).toFixed(0)} KB (limit ${ch.webLimits?.maxInitialMB} MB)`);
        const { sizeLines } = await import('./size.ts');
        for (const l of sizeLines(pkg.size, ch.webLimits?.maxInitialMB)) out(l);
        if (!pkg.problems.length) {
          out(`  The numbers: ${shown(join(pkg.dir, 'size.json'))} (gp forecast reads them; not part of the upload)`);
          out('  Upload that one file (the form takes files, not archives): developer.crazygames.com → Submit a game.');
          out('  `gp qa` plays this very file against a fake SDK; covers and videos: `gp covers`, `gp video`. Checklist: docs/guides/publishing-crazygames.md');
        }
        return pkg.problems.length ? 1 : 0;
      }
      const { buildWeb } = await import('./vite.ts');
      const dist = await buildWeb(loc, mode, !!flags.e2e);
      out(`✓ ${loc.id}: ${shown(dist)} (${mode}${flags.e2e ? ', e2e' : ''})`);
      if (mode === 'dev' && r.game.ads?.admob) out('  dev build: Google test ad IDs, fine for testing; for a store release use --release (after gp admob provision).');
      if (flags.target === 'android') {
        const { buildAndroid } = await import('./android.ts');
        const dir = buildAndroid(loc, r.game);
        out(`✓ ${loc.id}: ${shown(dir)} — next: cd ${shown(dir)} && ./gradlew assembleDebug bundleRelease (needs the Android SDK; CI does it)`);
      } else if (flags.target && flags.target !== 'web') {
        out(`Unknown target "${flags.target}". Targets: web, android, crazygames, playgama, idos`);
        return 1;
      }
      return 0;
    },
  },
  {
    name: 'covers',
    usage: 'covers [game] [--out <dir>] [--variants <1-3>] [--check]',
    description:
      "Store and portal graphics from the game itself, checked at the size players see them (docs/guides/covers.md): the channel's cover sizes (CrazyGames 1920×1080, 800×1200, 800×800; Google Play feature graphic 1024×500) into games/<id>/store/. A code game with a cover hook — host.qa({ cover: { scene, hero, front, title } }) — draws only the key art in layers; the platform lays out each size, lights the hero's rim, darkens behind the title, adds a vignette and letters the title (big, outlined, extruded, fitted to its zone). Without a hook: the game's own `?cover` frame (body[data-cover=ready]), else the first screen. Then the click-through check scores every cover at 200 px wide (title width, letter size and contrast, hero vs. background, colourfulness, value contrast, near-black and flat area, detail) — a warning under 70, never a failure — into store/cover-check.md, with cover-preview-200.png (the thumbnails in colour and grayscale) and cover-thumbnail-200x112.png. `--variants 3`: three compositions (hero / action / close-up) for A/B tests, the extra ones in store/variants/<name>/. `--check`: only score the covers already rendered.",
    async run(args, flags) {
      const loc = locateGame(args[0]);
      const dir = typeof flags.out === 'string' ? flags.out : join(loc.dir, 'store');
      const { checkCovers, renderCovers, CHECK_FILE } = await import('./covers.ts');
      const { formatVerdict } = await import('./cover-check.ts');
      const report = (scores: { file: string; verdict: Parameters<typeof formatVerdict>[1] }[]) => {
        for (const s of scores) out(formatVerdict(shown(s.file), s.verdict).join('\n'));
      };
      if (flags.check) {
        const res = await checkCovers(dir);
        report(res.scores);
        for (const p of res.previews) out(`  Look at ${shown(p)}: the covers at the portal's size (bottom row: grayscale).`);
        out(`  The report: ${shown(join(dir, CHECK_FILE))}`);
        return 0;
      }
      const r = checkGame(loc, 'dev');
      if (!r.ok || !r.game) {
        out(formatIssues(loc, r.issues));
        return 1;
      }
      const variants = flags.variants === undefined ? 1 : flags.variants === true ? 3 : Number(flags.variants);
      if (!Number.isInteger(variants) || variants < 1 || variants > 3) {
        out('--variants takes 1, 2 or 3');
        return 1;
      }
      const res = await renderCovers(loc, r.game, dir, { variants });
      for (const f of res.files) out(`✓ ${shown(f)}`);
      if (res.mode === 'frame') out('  The game\'s own ?cover frame was used. A cover hook lets the platform letter the title, light the hero and score it all: host.qa({ cover }) — docs/guides/covers.md.');
      if (res.mode === 'first-screen') out('  No cover hook and no ?cover frame — the first screen was used. A code game draws its key art in host.qa({ cover }): docs/guides/covers.md.');
      for (const n of res.notes) out(`  ${n}`);
      report(res.scores);
      for (const p of res.previews) out(`  Look at ${shown(p)}: can you tell what the game is in half a second? (bottom row: grayscale)`);
      out(`  The report: ${shown(join(dir, CHECK_FILE))}${variants > 1 ? ' — the alternatives are in store/variants/: swapping a cover on CrazyGames is in docs/guides/covers.md#ab-testing-covers' : ''}`);
      return 0;
    },
  },
  {
    name: 'art',
    usage: 'art [game] [--only <id,id>] [--force] [--style] [--record] [--check] [--provider gemini|svg|mock] | art import <dir> [game] [--cleanup <file>] [--size <px>] [--kind sprite|ui|icon|background|tile|keyart] [--tolerance <n>] [--recolor] [--force]',
    description:
      "Raster art for a code game from an image model, made at build time and bundled (docs/guides/art.md#5-generated-art-gp-art). game.yaml `art` gives the style and the assets (id, kind sprite|background|tile|ui|icon|keyart, prompt, size, a sprite's `frames`: one pose each, painted from the sprite). First a style board (assets/style.webp), then every missing asset asked for in that style with the board as a reference: sprites on a chroma key cut out to transparency, trimmed and fitted; backgrounds cropped to fill; all WebP in games/<id>/assets/, with assets/index.ts (import { ART } — load with loadImages from @gp/art/assets) and assets/provenance.yaml (model, full prompt, hash, date), which gp validate checks. The raw model outputs stay in qa/art-raw/. `--only` / `--force` remake assets, `--style` a new board, `--record` takes the hashes of files edited by hand, `--check` only checks. Needs GEMINI_API_KEY in the environment or a network secret (header x-goog-api-key for generativelanguage.googleapis.com) (provider gemini, the default); `--provider svg` renders the game's own cartoon SVGs (art/<id>.svg, art/<id>-<n>.svg for frames: drawn by the game's agent; no key, no cost; a changed drawing is rendered again); `--provider mock` draws seeded placeholders with no network. Prints the estimated cost first. `import <dir>`: finished pictures the owner supplies (PNG, JPEG or WebP in <dir>, e.g. painted cars, side view, on a plain studio background) made into assets the same way, no key and no network (docs/guides/art.md#51-importing-finished-pictures-gp-art-import): the plain background flooded away from the borders with a colour tolerance and a soft alpha edge (its colour taken out of the edge), trimmed, fitted into the size (`--size`, default 512 for a sprite) and saved as WebP; ids from the file names (slugified), written into game.yaml `art.assets` as `source: import` and into provenance.yaml as `source: owner` with the original's name, sha256 and the date, which gp validate checks; gp art never regenerates them. `<dir>/cleanup.json` (or `--cleanup`) overrides per picture (its file name or id) over `defaults`: id, kind, size, tolerance, drift, key (the backdrop's colour), crop [x, y, w, h], erase (rectangles made transparent), patch (rectangles painted over from around them: an emblem), split.wheels ([cx, cy, r] circles cut out as <id>-wheel-N sprites, the body keeping the arches) and recolor (an <id>-paint mask of the body's dominant hue, to tint for paint variants; `--recolor` for every picture); parts carry `part: { of, at }`, exported as PARTS in assets/index.ts. An unchanged picture with unchanged settings is kept (`--force` imports again). Look at qa/art-import.png: every cut-out on a checkerboard and put back together.",
    async run(args, flags) {
      const art = await import('./art.ts');
      const report = (loc: ReturnType<typeof locateGame>) => {
        const rows = art.artSummary(loc);
        for (const r of rows) out(`  ${r.file.padEnd(28)} ${r.kind.padEnd(10)} ${`${r.size[0]}×${r.size[1]}`.padEnd(10)} ${(r.bytes / 1024).toFixed(1)} KB`);
        if (rows.length) out(`  ${rows.length} file(s), ${(rows.reduce((s, r) => s + r.bytes, 0) / 1024).toFixed(0)} KB (the style board isn't bundled unless imported)`);
        const issues = art.artChecks(loc);
        if (issues.length) out(formatIssues(loc, issues));
        return issues.some((i) => i.severity === 'error') ? 1 : 0;
      };
      if (args[0] === 'import') {
        const [, dir, game] = args;
        if (!dir) {
          out('Usage: gp art import <dir> [game] [--cleanup <file>] [--size <px>] [--kind sprite] [--tolerance <n>] [--recolor] [--force]');
          return 1;
        }
        const loc = locateGame(game);
        const kinds = ['sprite', 'ui', 'icon', 'background', 'tile', 'keyart'];
        if (typeof flags.kind === 'string' && !kinds.includes(flags.kind)) {
          out(`--kind is one of ${kinds.join(', ')}`);
          return 1;
        }
        const num = (k: string) => (typeof flags[k] === 'string' && Number(flags[k]) > 0 ? Number(flags[k]) : undefined);
        const { importArt } = await import('./art-import.ts');
        try {
          const res = await importArt(loc, dir, { cleanup: typeof flags.cleanup === 'string' ? flags.cleanup : undefined, size: num('size'), tolerance: num('tolerance'), kind: typeof flags.kind === 'string' ? (flags.kind as import('./art.ts').ArtKind) : undefined, recolor: !!flags.recolor, force: !!flags.force, log: (s) => out(`  ${s}`) });
          for (const f of res.made) out(`✓ ${f}`);
          for (const f of res.removed) out(`- ${f} (no longer in cleanup.json)`);
          for (const w of res.warnings) out(`⚠ ${w}`);
          if (res.kept.length) out(`  kept ${res.kept.length} unchanged (--force to import again)`);
          if (res.preview) out(`  Look at ${shown(res.preview)}: clean edges (no halo, no leftover backdrop or shadow), nothing cut off, the parts back in place.`);
        } catch (e) {
          out(`✗ ${(e as Error).message}`);
          return 1;
        }
        return report(loc);
      }
      const loc = locateGame(args[0]);
      const spec = art.artSpec(loc);
      if (!spec) {
        out(`${loc.id}: game.yaml has no \`art\` section with assets — gp explain art (docs/guides/art.md#5-generated-art-gp-art); the owner's own pictures: gp art import <dir> ${loc.id}`);
        return 1;
      }
      if (flags.check) return report(loc);
      if (flags.record) {
        const changed = art.recordArt(loc);
        out(changed.length ? `✓ recorded ${changed.length} edited file(s): ${changed.join(', ')}` : '✓ nothing changed by hand');
        return report(loc);
      }
      const only = typeof flags.only === 'string' ? flags.only.split(',').map((s) => s.trim()).filter(Boolean) : undefined;
      const unknown = (only ?? []).filter((id) => !spec.assets.some((a) => a.id === id && !art.imported(a)));
      if (unknown.length) {
        out(`Unknown asset id(s): ${unknown.join(', ')}. game.yaml art.assets has: ${spec.assets.filter((a) => !art.imported(a)).map((a) => a.id).join(', ')} (imported pictures are remade with gp art import)`);
        return 1;
      }
      const provider = typeof flags.provider === 'string' ? flags.provider : undefined;
      const model = spec.model ?? art.DEFAULT_IMAGE_MODEL;
      const todo = spec.assets.filter((a) => !art.imported(a)).reduce((n, a) => n + (flags.force || only?.includes(a.id) ? art.assetFiles(a, art.extOf(spec)).length : art.assetFiles(a, art.extOf(spec)).filter((f) => !existsSync(join(art.assetsDir(loc), f))).length), 0) + (spec.assets.some((a) => !art.imported(a)) && (flags.style || !existsSync(join(art.assetsDir(loc), art.STYLE_FILE))) ? 1 : 0);
      const pname = provider ?? process.env.GP_ART_PROVIDER ?? 'gemini';
      out(pname === 'gemini' ? `${loc.id}: ${todo} image(s) to make with ${model} — about $${(todo * (art.IMAGE_PRICE_USD[model] ?? 0.05)).toFixed(2)}` : `${loc.id}: up to ${todo} image(s) from ${pname === 'svg' ? `the game's own drawings (${art.ART_SRC_DIR}/<id>.svg), no key, no cost` : 'the mock provider (no network, placeholders)'}`);
      try {
        const res = await art.generateArt(loc, { provider, only, force: !!flags.force, style: !!flags.style, log: (s) => out(`  ${s}`) });
        for (const f of res.made) out(`✓ ${f}`);
        for (const w of res.warnings) out(`⚠ ${w}`);
        if (res.kept.length) out(`  kept ${res.kept.length} existing (--only <id> or --force to remake)`);
      } catch (e) {
        out(`✗ ${(e as Error).message}`);
        return 1;
      }
      out('  Look at every image at the size it is drawn, next to the others: one style, clean edges, no text or watermark (docs/guides/art.md#5-generated-art-gp-art).');
      return report(loc);
    },
  },
  {
    name: 'assets',
    usage: 'assets get <url> [game] | assets sheet <image> [game] [--grid 32] | assets compare <image> [game] [--factor 2] [--models a.pth,b.pth] | assets upscale <image> [game] [--method xbrz] [--factor 2] [--out <file>]',
    description:
      "Find and take existing images instead of making new ones (docs/guides/art.md § 5, «Existing assets»). `get` downloads an image or a pack (a zip is unpacked) into the game's assets-src/ and lists every image with its size. `sheet` numbers the cells of a sprite sheet on a grid and writes qa/sheet-<name>.png to look at, with each cell's [x, y, w, h] for game.yaml. Then an art asset takes it: `{ id: skeleton, kind: sprite, from: assets-src/…png, cut: [x, y, w, h], size: 32 }` — gp art cuts, mirrors (`flip`), trims and fits it, and with `technique: pixel` snaps every pixel to the game's palette. `compare` runs every pixel-art scaler on one image (nearest, Scale2x/EPX, xBR, xBRZ, and ESRGAN models with --models when GP_PYTHON has spandrel) and writes qa/upscale-<name>.png side by side; `upscale` writes one (<name>@<factor>x.png), back in whole pixels in the game's palette with the small details kept — the same as an art asset's `upscale: { method, factor }`.",
    async run(args, flags) {
      const [sub, target, game] = args;
      if (!['get', 'sheet', 'compare', 'upscale'].includes(sub ?? '')) {
        out('Usage: gp assets get <url> [game] | sheet <image> [game] [--grid 32] | compare <image> [game] [--factor 2] | upscale <image> [game] [--method xbrz] [--factor 2]');
        return 1;
      }
      const loc = locateGame(game);
      const art = await import('./art.ts');
      const { listImages, sheetImage } = await import('./assets.ts');
      if (sub === 'get') {
        if (!target) { out('gp assets get <url> [game]'); return 1; }
        try {
          const files = await listImages(loc, await art.localSource(loc, target));
          for (const f of files) out(`  ${f.file.padEnd(60)} ${f.w}×${f.h}`);
          out(`✓ ${files.length} image(s) in ${art.ASSETS_SRC_DIR}/ — a sheet? gp assets sheet <image> --grid <cell px>; then an art asset with \`from:\` (and \`cut:\`)`);
          return 0;
        } catch (e) {
          out(`✗ ${(e as Error).message}`);
          return 1;
        }
      }
      if ((sub === 'compare' || sub === 'upscale') && target) {
        const { compareUpscalers, upscaleFile } = await import('./assets.ts');
        const factor = Number(flags.factor ?? 2);
        const palette = art.artSpec(loc)?.palette;
        try {
          if (sub === 'compare') {
            const models = typeof flags.models === 'string' ? flags.models.split(',').filter(Boolean) : [];
            out(`✓ ${shown(await compareUpscalers(loc, target, factor, models, palette))} — every scaler at the same size; pick the one that keeps the design`);
          } else {
            const method = String(flags.method ?? 'xbrz') as import('./upscale.ts').UpscaleMethod;
            out(`✓ ${shown(await upscaleFile(loc, target, { method, factor, palette, keepDetails: !flags['no-details'] }, typeof flags.out === 'string' ? flags.out : undefined))}`);
          }
          return 0;
        } catch (e) {
          out(`✗ ${(e as Error).message}`);
          return 1;
        }
      }
      if (!target) { out('gp assets sheet <image> [game] --grid 32'); return 1; }
      const grid = String(flags.grid ?? '32').split('x').map(Number);
      const res = await sheetImage(loc, target, { w: grid[0]!, h: grid[1] ?? grid[0]!, margin: Number(flags.margin ?? 0), gap: Number(flags.gap ?? 0) });
      out(`✓ ${res.cols}×${res.rows} cells of ${grid[0]}×${grid[1] ?? grid[0]} — ${shown(res.file)} (each cell numbered; cell n is cut: [x, y, w, h] = ${res.example})`);
      return 0;
    },
  },
  {
    name: 'video',
    usage: 'video [game] [--frames] [--script <file.mjs>] [--out <dir>] [--only landscape|portrait] [--sound] [--max <seconds>]',
    description:
      "The portal's preview videos, filmed from the game in the dev build on a virtual clock (smooth 30 fps on any machine): 15 s, H.264, no sound, opening on the ?cover frame — CrazyGames 1920×1080 (a laptop's layout) and 1080×1920 (a phone's). What is filmed: games/<id>/video.mjs (or --script), a module whose default export gets { page, step, sec, tap, until, visible }; Without one, Play is tapped and the game's host.qa({ demo }) bot plays. Needs ffmpeg with libx264 (FFMPEG=…, or `pip install imageio-ffmpeg`). Every run also writes a contact sheet beside each video, store/<video>-frames.png: a frame a second and the end card, each with its time, the cover, the end card and any frame showing the Play button marked — composed in the browser from the recorder's own frames, no ffmpeg; look at it to check what the video shows. `--frames`: the contact sheets only (no video, no ffmpeg needed) — for a container without ffmpeg or H.264. Not for the portal: `--sound` records the game's own sound on the same clock (an AAC track; the game's AudioContext plays one frame of audio per filmed frame, so it stays in step) and `--max <seconds>` films longer (1–600; your video.mjs gets it as `v.length`) — a gameplay video for the owner, written as gameplay-<size>.mp4 (with its contact sheet) beside the previews, which it never replaces (the portal wants 15–20 s and no sound; `--max 15`…`20` without `--sound` is still a preview).",
    async run(args, flags) {
      const loc = locateGame(args[0]);
      const r = checkGame(loc, 'dev');
      if (!r.ok || !r.game) {
        out(formatIssues(loc, r.issues));
        return 1;
      }
      const { renderVideos } = await import('./video.ts');
      const only = flags.only === 'landscape' || flags.only === 'portrait' ? flags.only : undefined;
      const max = flags.max === undefined ? undefined : Number(flags.max);
      if (max !== undefined && !(max >= 1 && max <= 600)) { out('gp video --max <seconds>: a length from 1 to 600'); return 1; }
      const res = await renderVideos(loc, r.game, { outDir: typeof flags.out === 'string' ? flags.out : undefined, script: typeof flags.script === 'string' ? flags.script : undefined, only, frames: !!flags.frames, sound: !!flags.sound, max });
      for (const f of res.files) out(`✓ ${shown(f)}`);
      for (const f of res.sheets) out(`✓ ${shown(f)} (contact sheet: a frame a second — look at it)`);
      if (flags.frames) out('  --frames: the contact sheets only; the videos themselves need ffmpeg with libx264 (gp video without --frames).');
      for (const p of res.problems) out(`✗ ${p}`);
      out(`  ${res.scripted ? 'Filmed by the game\'s video script.' : 'Default scenario (Play, then host.qa demo()).'} Watch it: the first seconds must show what makes the game different.`);
      return res.problems.length ? 1 : 0;
    },
  },
  {
    name: 'uniqueness',
    usage: 'uniqueness [game]',
    description:
      "How unique the game is, from every stage: the concept (about play, not looks; no live genre + theme match; the portal search written down), the code (the mechanic is the game's own, not the template's or the example's) and play (the declared concept.twist happens early — from the last `gp qa`), and a little the story (an own premise and characters). A score out of 100 (70+ passes `gp submission`), what to change in the GAME, and ready portal searches. Written to games/<id>/qa/uniqueness.md. Run it after every big change.",
    async run(args) {
      const loc = locateGame(args[0]);
      const r = checkGame(loc, 'dev');
      if (!r.game) {
        out(formatIssues(loc, r.issues));
        out(`✗ ${loc.id}: uniqueness 0/100 — fix the errors above first (the concept is written before anything else: docs/guides/uniqueness.md)`);
        return 1;
      }
      const { uniquenessReport, UNIQUE_ENOUGH } = await import('./uniqueness.ts');
      const rep = uniquenessReport(loc, r.game, r.issues);
      mkdirSync(join(loc.dir, 'qa'), { recursive: true });
      writeFileSync(join(loc.dir, 'qa', 'uniqueness.md'), rep.markdown);
      out(rep.markdown);
      out(`${rep.score >= UNIQUE_ENOUGH && !rep.gate ? '✓' : '✗'} ${loc.id}: uniqueness ${rep.score}/100 — ${rep.verdict}. ${shown(join(loc.dir, 'qa', 'uniqueness.md'))}`);
      return rep.score >= UNIQUE_ENOUGH && !rep.gate ? 0 : 1;
    },
  },
  {
    name: 'name',
    usage: 'name [game] [--genre <g>] [--words "throne,dread"] · name --title "Spin Brawl" --genre io',
    description:
      "Scores a title and suggests others (docs/guides/naming.md). A portal title is read before the game is seen — in the search box, on tag pages, under a 200 px thumbnail — so it needs a HOOK (a common word the genre's hits made famous: brawl, clash, defense, merge, idle, drift; never the hit's name) and a word of its own, 2–3 words, ≤ 24 characters, no one-word coined compound. The score is out of 100 (hook 40, own word 25, length 15, word count 10, not coined 10); `gp validate` warns when a portal game's title has no hook of its genre (W_TITLE_HOOK). For a game: its title, genre (money.genre or listing.tags) and own words (the title's and concept's nouns, or --words); a game already on the portal gets 'keep the name + a genre subtitle' options too.",
    async run(args, flags) {
      const { GENRES, GENRE_IDS, GENRE_PHRASES, SUBGENRES, SUBGENRE_PHRASES, genreOf, moneyGenre, scoreTitle, suggestTitles, hooksFor } = await import('@gp/spec');
      let title = typeof flags.title === 'string' ? flags.title : '';
      let genre = typeof flags.genre === 'string' ? flags.genre : '';
      let words = typeof flags.words === 'string' ? flags.words.split(',') : [];
      if (!title) {
        const loc = locateGame(args[0]);
        const r = checkGame(loc, 'dev');
        if (!r.game) {
          out(formatIssues(loc, r.issues));
          return 1;
        }
        title = r.game.title;
        if (!genre) genre = (r.game as { money?: { genre?: string } }).money?.genre ?? genreOf(r.game.kit.kit, r.game.audience.id, r.game.listing.tags).genre;
        if (!words.length) words = [title, r.game.concept?.pitch ?? ''].join(' ').split(/[^A-Za-z]+/).filter((w) => w.length >= 4);
      }
      const named = moneyGenre(genre);
      if (!named) {
        out(`✗ --genre must be one of: ${GENRE_IDS.join(', ')}`);
        return 1;
      }
      const g: (typeof GENRES)[number] = named;
      // A sub-genre (deckbuilder, roguelite) names its own hooks first
      const sub = genre in SUBGENRES ? (genre as keyof typeof SUBGENRES) : null;
      const label = sub ?? g;
      if (!words.length) words = title.split(/[^A-Za-z]+/);
      const s = scoreTitle(title, g, sub);
      out(`${s.score >= 70 ? '✓' : '✗'} "${title}" (${label}${sub ? `, benchmarked as ${g}` : ''}): ${s.score}/100`);
      for (const x of s.hooks) out(`  hook "${x.word}" — ${x.fits ? `a ${g} word` : 'from another genre'} (${x.evokes})`);
      for (const i of s.issues) out(`  · ${i}`);
      out(`\nHooks for ${label}: ${hooksFor(g, sub).map((k) => k.word).join(', ')}`);
      if (((sub && SUBGENRE_PHRASES[sub]) || GENRE_PHRASES[g]).length) {
        out('\nKeep the name, add the genre (a game already on the portal):');
        for (const t of suggestTitles(g, [], { base: title.split(':')[0], n: 3, sub })) out(`  ${String(t.score).padStart(3)}  ${t.title}`);
      }
      out('\nNew titles from its own words:');
      for (const t of suggestTitles(g, words, { base: undefined, n: 10, sub })) out(`  ${String(t.score).padStart(3)}  ${t.title}`);
      out('\nThen: search each on the portal (site:crazygames.com "<title>") — a live game with the same name is a no; and never a hit\'s name (E_TITLE_GENERIC).');
      return s.score >= 70 ? 0 : 1;
    },
  },
  {
    name: 'forecast',
    usage:
      'forecast [game] [--out <file>] [--json] [--resubmission after-stop|after-rejection|none] · forecast --idea --channel crazygames --genre idle [--session 15] [--breaks 4] [--rewarded revive,x2] [--meta 60] [--return daily] [--pitch "…"] [--unique 80] [--mb 5] [--load 2.5] · forecast --results',
    description:
      "What the game can earn, as estimates with the confidence of every input (ranges, never one number): its channel's path (CrazyGames: QA review → Basic Launch, 7–21 days without ads → Full Launch; Google Play: review → organic installs), P(approval) (the review odds × `gp uniqueness`), P(Full Launch) (the design against the Basic Launch gates), revenue per month in months 1–3 (pessimistic / median / optimistic), the expected value (probability-weighted) and the three biggest levers. Midgame ads are the design's natural breaks run through the channel's ad policy; rewarded views come from its offers; children get none. A game: reads the `money` section, the code (rewarded placements, host.adBreak), balance(), the upload and `gp uniqueness`; writes games/<id>/qa/forecast.md (`--out` elsewhere). A game the portal judged before is a resubmission: its latest record in publisher/results.yaml (Basic Launch stopped, or rejected) caps P(approval) at the recorded resubmissions of its kind (3 of 4 after a stop were rejected) — `--resubmission` says it when the file doesn't (`none`: a new submission). `--idea`: step 1, before any code, from a few numbers (`--pitch` is checked against the taken concepts). `--results`: publisher/results.yaml — the recorded outcomes, checked, and how the model compares with them (from 3 results of a kind it narrows its ranges). The inputs are one table: MONEY_TABLE in packages/spec/src/money.ts.",
    async run(args, flags) {
      const f = await import('./forecast.ts');
      const { ideaDesign, calibrate, forecast, levers, CHANNELS: CH } = await import('@gp/spec');
      const write = (file: string, text: string) => {
        mkdirSync(dirname(file), { recursive: true });
        writeFileSync(file, text);
      };
      if (flags.results) {
        const r = f.loadResults();
        for (const l of f.formatResultIssues(r.issues)) out(l);
        if (r.issues.some((i) => i.severity === 'error')) {
          out(`✗ ${shown(r.file)}: fix the errors above`);
          return 1;
        }
        out(`# Recorded results — ${shown(r.file)} (${r.results.length})\n`);
        for (const ch of [...new Set(r.results.map((x) => x.channel))]) out(calibrate(r.results, ch).markdown);
        if (!r.results.length) out('No results recorded yet: add one per game when the portal or store answers (the format: docs/guides/game-design.md → Design for money → Calibration).');
        out(`✓ ${shown(r.file)}: ${r.results.length} result(s), schema ok`);
        return 0;
      }
      if (flags.idea) {
        const n = (k: string) => (typeof flags[k] === 'string' && flags[k] !== '' ? Number(flags[k]) : undefined);
        const bad = ['session', 'breaks', 'meta', 'unique', 'mb', 'load'].filter((k) => n(k) !== undefined && !Number.isFinite(n(k)));
        if (bad.length) {
          out(`--${bad.join(', --')}: a number, please`);
          return 1;
        }
        const channel = typeof flags.channel === 'string' ? flags.channel : 'crazygames';
        const { design, issues } = ideaDesign({
          channel,
          genre: typeof flags.genre === 'string' ? flags.genre : undefined,
          audience: typeof flags.audience === 'string' ? flags.audience : undefined,
          sessionMin: n('session'),
          breaks: n('breaks'),
          rewarded: typeof flags.rewarded === 'string' ? flags.rewarded.split(',').map((s) => s.trim()) : [],
          metaMin: n('meta') ?? null,
          returns: typeof flags.return === 'string' ? flags.return : undefined,
          uploadMB: n('mb') ?? null,
          loadSec: n('load') ?? null,
          pitch: typeof flags.pitch === 'string' ? flags.pitch : undefined,
          unique: n('unique'),
        });
        for (const i of issues) out(`✗ ${i}`);
        if (issues.length) return 1;
        const { results } = f.loadResults();
        const cal = calibrate(results, channel);
        const fc = forecast(design, cal.calibration);
        const lv = levers(design, cal.calibration);
        const title = typeof flags.title === 'string' ? flags.title : `Idea: ${design.genre} on ${CH[channel]?.title ?? channel}`;
        if (flags.json) {
          out(JSON.stringify({ design, forecast: fc, levers: lv }, null, 2));
          return 0;
        }
        const md = f.forecastMarkdown(title, design, fc, lv, cal, { idea: true, full: !!flags.out });
        out(md);
        if (typeof flags.out === 'string') {
          const file = resolve(process.cwd(), flags.out);
          write(file, f.forecastMarkdown(title, design, fc, lv, cal, { idea: true }));
          out(`✓ ${shown(file)}`);
        }
        out(f.forecastLine(fc));
        // What the genre's players expect, before the idea is chosen (the blocks: gp catalog blocks --genre)
        const gt = genreTopic(typeof flags.genre === 'string' ? flags.genre : design.genre);
        const must = gt ? expectationsFor(gt.genre.id, gt.sub?.id ?? null) : [];
        if (gt && must.length) out(`${gt.sub?.name ?? gt.genre.name} players expect: ${must.map((e) => e.what).join('; ')} — gp explain genre.${gt.sub?.id ?? gt.genre.id}`);
        return 0;
      }
      const loc = locateGame(args[0]);
      const r = checkGame(loc, 'dev');
      if (!r.game) {
        out(formatIssues(loc, r.issues));
        out(`✗ ${loc.id}: fix the errors above first — or forecast the idea: gp forecast --idea --channel … --genre …`);
        return 1;
      }
      const money = r.issues.filter((i) => /^[EW]_MONEY/.test(i.code));
      if (money.length) out(formatIssues(loc, money) + '\n');
      const rs = typeof flags.resubmission === 'string' ? ({ stopped: 'after-stop', rejected: 'after-rejection' } as Record<string, string>)[flags.resubmission] ?? flags.resubmission : undefined;
      if (rs !== undefined && !['after-stop', 'after-rejection', 'none'].includes(rs)) {
        out(`--resubmission ${rs}: after-stop, after-rejection or none`);
        return 1;
      }
      const g = await f.gameForecast(loc, r.game, r.issues, { resubmission: rs as 'after-stop' | 'after-rejection' | 'none' | undefined });
      if (flags.json) {
        out(JSON.stringify({ game: loc.id, design: g.design, forecast: g.forecast, levers: g.levers, calibration: { notes: g.calibration.calibration.notes, comparisons: g.calibration.comparisons } }, null, 2));
        return 0;
      }
      const md = f.forecastMarkdown(r.game.title, g.design, g.forecast, g.levers, g.calibration, { balance: g.balance, id: loc.id });
      const file = typeof flags.out === 'string' ? resolve(process.cwd(), flags.out) : join(loc.dir, 'qa', 'forecast.md');
      write(file, md);
      out(f.forecastMarkdown(r.game.title, g.design, g.forecast, g.levers, g.calibration, { balance: g.balance, id: loc.id, full: false }));
      out(`${f.forecastLine(g.forecast)}\n✓ ${loc.id}: ${shown(file)} (with every assumption)`);
      return 0;
    },
  },
  {
    name: 'story',
    usage: 'story [game] [--depth none|premise|barks|chapters|branching] [--genre action|idle|puzzle|choices] [--write] [--force] [--out <file>] [--json] · story [game] --strings',
    description:
      "How much story the game needs, and why: the recommended depth from its audience, channel, kit and genre (the table in docs/guides/story.md), and what this kind of game supports. A game that needs none is told so and nothing else. With `--write` (or when game.yaml declares a depth whose file doesn't exist yet) it forms a starting story file for the depth from the concept: bark lists with the Bag and cooldown wiring (barks), a StoryDef of 6 short chapters unlocked by progress with a first-action premise (chapters), plus a flag and 2 endings (branching); a premise goes into game.yaml. It never overwrites a file without `--force`; `--out` writes the file elsewhere and leaves game.yaml alone. Then it lists what to correct: the `gp validate` story checks as a to-do list. `--strings`: the story file's lines, choices and barks into strings/en.yaml as `story.<line id>`, `story.<line id>.<choice id>` and `bark.<event>.<n>` keys (the old ones replaced), so `gp translate` lists them for every language; the game shows them with `new StoryRunner(…, { i18n: host.i18n })` and `barkText(host.i18n, event, i, line)`, and `gp validate` keeps the two in step (W_STORY_STRINGS).",
    async run(args, flags) {
      const loc = locateGame(args[0]);
      const loaded = loadYaml(readFileSync(loc.file, 'utf8'));
      if (loaded.issues.length || !loaded.data || typeof loaded.data !== 'object') {
        out(formatIssues(loc, loaded.issues));
        return 1;
      }
      const { storyCommand, writeStoryStrings } = await import('./story.ts');
      if (flags.strings) {
        const spec = loaded.data as GameSpecInput;
        const file = spec.story?.file ?? 'story.ts';
        const r = writeStoryStrings(loc, file, (f, text) => {
          mkdirSync(dirname(f), { recursive: true });
          writeFileSync(f, text);
        });
        if ('error' in r) {
          out(`✗ ${r.error}`);
          return 1;
        }
        out(`✓ ${shown(r.file)}: ${r.keys} story text(s) as story.* and bark.* keys. Then: gp translate --write (the other languages), and show them through host.i18n — new StoryRunner(story, scene, state, progress, { i18n: host.i18n }), barkText(host.i18n, event, i, line).`);
        return 0;
      }
      const res = storyCommand(
        loc,
        loaded.data as GameSpecInput,
        { depth: typeof flags.depth === 'string' ? flags.depth : undefined, genre: typeof flags.genre === 'string' ? flags.genre : undefined, write: !!flags.write, force: !!flags.force, out: typeof flags.out === 'string' ? resolve(process.cwd(), flags.out) : undefined },
        (file, text) => {
          mkdirSync(dirname(file), { recursive: true });
          writeFileSync(file, text);
        },
      );
      if (res.section) {
        const doc = parseDocument(readFileSync(loc.file, 'utf8'));
        doc.set('story', doc.createNode(res.section, { flow: true }));
        writeFileSync(loc.file, doc.toString(YAML_OUT));
      }
      if (flags.json) out(JSON.stringify(res.json, null, 2));
      else for (const l of res.lines) out(l);
      return res.code;
    },
  },
  {
    name: 'translate',
    usage: 'translate [game] [--lang <code>] [--write [--accept]] [--check] [--json]',
    description:
      "The game in every language of game.yaml `languages` (docs/guides/i18n.md). There is no translation service: the game's own agent translates, and this command gives it the work and checks the result. Without flags it writes qa/translate-brief.md — the rules (keep every {param}, the plural forms each language needs, UI text within ~30% of English, the glossary's names untranslated, the platform's tone), and per language the keys still missing as YAML to fill, with the English beside each, and the listing (description, controls) for the store page. `--write` appends those missing keys, empty, to each strings/<code>.yaml (creating it), so the agent fills the quotes in place, and records in strings/<code>.sources.json the English each written translation was made from (a hash per key): when the English of a key changes and its translation doesn't, `--check` and `gp validate` warn W_I18N_STALE and the brief lists the key with the new English; a translation redone is recorded at the next `--write`, and `--write --accept` takes the stale ones as they are (a game without the file gets no warning until its first `--write`); `--lang de` limits the brief (and `--write --accept`) to one language. `--check` runs the checks of `gp validate` on the texts and prints a table per language: keys done, the listing, the characters beyond ASCII (what a pixel font must draw); it exits 1 while anything is missing or wrong. The kit's and the platform's own texts are translated already (13 languages).",
    async run(args, flags) {
      const loc = locateGame(args[0]);
      const loaded = loadYaml(readFileSync(loc.file, 'utf8'));
      if (loaded.issues.length || !loaded.data || typeof loaded.data !== 'object') {
        out(formatIssues(loc, loaded.issues));
        return 1;
      }
      const spec = loaded.data as GameSpecInput;
      const { i18nChecks, i18nGameOf, recordSources, translateBrief, translateStatus, writeMissing } = await import('./i18n.ts');
      const game = i18nGameOf(spec);
      if (game.languages.length < 2) {
        out(`${loc.id} is in English only. Declare its languages in game.yaml first — a portal game: languages: [en, es, pt-BR, fr, de, ru, tr, it, pl, id] — then run gp translate again (docs/guides/i18n.md).`);
        return 1;
      }
      if (flags.write) {
        const done = writeMissing(loc, game, spec as unknown as Record<string, unknown>, (file, text) => {
          mkdirSync(dirname(file), { recursive: true });
          writeFileSync(file, text);
        });
        out(done.length ? done.map((d) => `+ ${d}`).join('\n') : 'Nothing to add: every language has every key.');
        // The English each translation was made from, so a changed English shows as stale (W_I18N_STALE)
        const recorded = recordSources(loc, game, spec as unknown as Record<string, unknown>, (file, text) => writeFileSync(file, text), { accept: !!flags.accept, lang: typeof flags.lang === 'string' ? flags.lang : undefined });
        for (const d of recorded) out(`✓ ${d}`);
      } else if (flags.accept) {
        out('✗ --accept goes with --write: gp translate --write --accept');
        return 1;
      }
      if (flags.check || flags.json) {
        const issues = i18nChecks(loc, game, spec as unknown as Record<string, unknown>);
        const { rows } = translateStatus(loc, game, spec as unknown as Record<string, unknown>);
        const errors = issues.filter((i) => i.severity === 'error');
        if (flags.json) {
          out(JSON.stringify({ game: loc.id, languages: rows, issues }, null, 2));
          return errors.length || rows.some((r) => r.missing.length) ? 1 : 0;
        }
        out(`| Language | Keys | Listing | Characters beyond ASCII (a pixel font needs them) |`);
        out(`|---|---|---|---|`);
        const list = (xs: string[]) => `${xs.slice(0, 4).join(', ')}${xs.length > 4 ? ', …' : ''}`;
        for (const r of rows) out(`| ${r.lang} ${r.name} | ${r.done}/${r.total}${r.missing.length ? ` (missing: ${list(r.missing)})` : ''}${r.stale.length ? ` (stale: ${list(r.stale)})` : ''} | ${r.listing ? '✓' : '✗'} | ${r.charset || '—'} |`);
        if (issues.length) out(`\n${formatIssues(loc, issues)}`);
        const ok = !errors.length && rows.every((r) => !r.missing.length);
        out(`${ok ? '✓' : '✗'} ${loc.id}: ${game.languages.length} languages, ${errors.length} error(s), ${issues.length - errors.length} warning(s)`);
        return ok ? 0 : 1;
      }
      const lang = typeof flags.lang === 'string' ? flags.lang : undefined;
      const brief = translateBrief(loc, game, spec as unknown as Record<string, unknown>, lang);
      const file = join(loc.dir, 'qa', 'translate-brief.md');
      mkdirSync(dirname(file), { recursive: true });
      writeFileSync(file, brief);
      const { rows } = translateStatus(loc, game, spec as unknown as Record<string, unknown>);
      for (const r of rows) if (r.lang !== 'en') out(`${r.missing.length || !r.listing ? '✗' : r.stale.length ? '⚠' : '✓'} ${r.lang.padEnd(6)} ${r.name.padEnd(20)} ${r.done}/${r.total} keys${r.listing ? '' : ', listing missing'}${r.stale.length ? `, ${r.stale.length} stale` : ''}`);
      out(`Brief: ${shown(file)} — translate what it lists into strings/<code>.yaml (\`gp translate --write\` adds the keys, empty), then gp translate --check.`);
      return 0;
    },
  },
  {
    name: 'balance',
    usage: 'balance [game] [--csv] [--json]',
    description:
      "The progression curve from the game's own balance bot and its balance model, against the channel's targets. The model (`balanceModel()`: the economy as tables — stages with difficulty, reward and minutes; purchases with cost and power; @gp/core/balance-model) is walked in expected values in milliseconds: power ÷ difficulty on arrival at every stage, attempts, farming, when each purchase comes; checks for walls, grind, stretches that play themselves, dominant and dead purchases, the first session (the first reward within a minute, a new thing every 3 min of the first 10, big rewards apart, hard streaks, jumps in a stage's time, a reward timeline) and the session's end (what the player has at money.session.minutes, the next goal ≥ 60 % reached, a meta of 2+ sessions) — those fail only when game.yaml declares `balance.anchor`, else they warn; `--csv` also writes the tables as CSV for Google Sheets or Excel (qa/balance-stages.csv, balance-items.csv). The bot: `balance()` from bot.ts (or balance.ts) returning a BalanceReport — fresh vs fully progressed power, a cheapest-first and a best-value buyer's campaign (first purchase, each new thing, the end of the meta), purchases that change nothing (docs/guides/upgrades.md#3-the-balance-report). The decisions too, when the bot reports them: the skill ladder (runs per skill — naive, average, skilled: the win rate, the winning run's length, how far naive falls behind; game.yaml `balance.difficulty` sets the targets, which then fail), the pick rate of every offered option (choiceLog(): over 60 % dominant, under 5 % dead weight), how alike the runs' final builds are, and whether the hard stages are short — tables in qa/balance.md, `--csv` adds qa/balance-picks.csv. Fails only on a clearly broken curve (never a first purchase, everything bought in minutes, progress that weakens, a trap, a dead purchase); `gp qa` runs it too. Written to games/<id>/qa/balance.md.",
    async run(args, flags) {
      const loc = locateGame(args[0]);
      const r = checkGame(loc, 'dev');
      // The curve doesn't wait for the concept: a game.yaml with errors still says its channel
      const channel = r.game?.channel.id ?? String(parseDocument(readFileSync(loc.file, 'utf8')).get('channel') ?? 'crazygames');
      const title = r.game?.title ?? loc.id;
      const { balanceDesign, runBalance } = await import('./balance.ts');
      const run = await runBalance(loc, channel, { design: balanceDesign(r.game ?? null, r.game ? null : parseDocument(readFileSync(loc.file, 'utf8')).toJSON()) });
      if (!run) {
        out(`${loc.id}: no balance() or balanceModel() export in bot.ts or balance.ts — nothing to check. The contract: docs/guides/upgrades.md#3-the-balance-report`);
        return 1;
      }
      const ok = run.verdict.ok && !run.model?.failed;
      if (flags.json) {
        out(JSON.stringify({ game: loc.id, file: run.file, source: run.source, report: run.report, rows: run.verdict.rows, model: run.model ? { checks: run.model.checks, cheap: run.model.cheap, careful: run.model.careful, growth: run.model.growth } : undefined, ok }, null, 2));
        return ok ? 0 : 1;
      }
      const qaDir = join(loc.dir, 'qa');
      mkdirSync(qaDir, { recursive: true });
      let csvNote = '';
      if (run.model && flags.csv) {
        const { modelCsv } = await import('@gp/core/balance-model');
        const csv = modelCsv(run.model);
        writeFileSync(join(qaDir, 'balance-stages.csv'), csv.stages);
        writeFileSync(join(qaDir, 'balance-items.csv'), csv.items);
        csvNote = `\nThe model's tables as CSV, to open in Google Sheets or Excel: ${shown(join(qaDir, 'balance-stages.csv'))}, ${shown(join(qaDir, 'balance-items.csv'))}.\n`;
      }
      const { decisionsMarkdown, pickRatesCsv } = await import('@gp/core/balance');
      if (flags.csv && run.report.choices?.length) {
        writeFileSync(join(qaDir, 'balance-picks.csv'), pickRatesCsv(run.report));
        csvNote += `\nThe pick rates as CSV: ${shown(join(qaDir, 'balance-picks.csv'))}.\n`;
      }
      const decisions = decisionsMarkdown(run.report, channel);
      const from = run.source === 'model' ? `\`balanceModel()\` alone (no bot yet: the curve above is the model's)` : run.model ? '`balance()` (the bot) and `balanceModel()`' : '`balance()`';
      const md = `# ${title} — balance (${channel})\n\n${run.verdict.markdown}\nFrom ${from} in ${shown(run.file)} (${run.seconds.toFixed(1)} s).\n${decisions ? `\n${decisions}` : ''}${run.model ? `\n${run.model.markdown}` : ''}${csvNote}`;
      writeFileSync(join(qaDir, 'balance.md'), md);
      out(md);
      const failed = run.verdict.failed + (run.model?.failed ?? 0);
      const warned = run.verdict.warned + (run.model?.warned ?? 0);
      out(`${ok ? '✓' : '✗'} ${loc.id}: balance ${failed} failed, ${warned} warning(s). ${shown(join(qaDir, 'balance.md'))}`);
      return ok ? 0 : 1;
    },
  },
  {
    name: 'preview',
    usage: 'preview [game] --to <dir>',
    description:
      "Publishes the portal upload for reviewers: builds it (as `gp build --target crazygames`) and copies it to <dir>/<id>/index.html, with the wide cover (games/<id>/store/) as cover.png, then updates <dir>/games.json, the front page <dir>/index.html and .nojekyll. <dir> is a checkout of the previews repository (GitHub Pages: a stable link per game); committing and pushing it is yours. Outside CrazyGames the SDK reports 'disabled', so the preview plays as a plain web build, without ads.",
    async run(args, flags) {
      const loc = locateGame(args[0]);
      if (typeof flags.to !== 'string') {
        out('Usage: gp preview [game] --to <dir> (a checkout of the previews repository)');
        return 1;
      }
      const r = checkGame(loc, 'dev');
      if (!r.ok || !r.game) {
        out(formatIssues(loc, r.issues));
        return 1;
      }
      if (!r.game.portal) {
        out(`${loc.id}: channel ${r.game.channel.id} has no portal build to preview`);
        return 1;
      }
      const { execFileSync } = await import('node:child_process');
      let commit: string | undefined;
      try {
        commit = execFileSync('git', ['-C', loc.dir, 'rev-parse', 'HEAD'], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim();
      } catch {}
      const { publishPreview } = await import('./preview.ts');
      const res = await publishPreview(loc, r.game, resolve(flags.to), commit);
      for (const p of res.problems) out(`✗ ${p}`);
      out(res.ok ? `✓ ${loc.id}: ${shown(join(resolve(flags.to), res.url))} (${res.entry?.gzipKB} KB gzipped) — commit and push the previews checkout` : `✗ ${loc.id}: nothing published`);
      if (res.renamed?.length) out(`  The old link${res.renamed.length > 1 ? 's' : ''} ${res.renamed.map((r) => r + '/').join(', ')} now redirect${res.renamed.length > 1 ? '' : 's'} to ${res.url}`);
      return res.ok ? 0 : 1;
    },
  },
  {
    name: 'retire',
    usage: 'retire <game>',
    description:
      "Take a replaced game out of its repository: `git rm -r` of games/<id> (it stays in the git history, so nothing is lost), so `scripts/gp.sh` finds one game again. Only a game named explicitly, only in a git checkout, and only when the folder has no uncommitted changes (they would be lost). Commit afterwards. For a game that never went to the portal — a released game keeps its folder (its appId and saveKey).",
    async run(args) {
      if (!args[0]) {
        out('Usage: gp retire <game> — name the game to take out (never implied from the current folder)');
        return 1;
      }
      const loc = locateGame(args[0]);
      const { execFileSync } = await import('node:child_process');
      const git = (...a: string[]) => execFileSync('git', ['-C', loc.dir, ...a], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }).trim();
      try {
        git('rev-parse', '--show-toplevel');
      } catch {
        out(`✗ ${loc.id}: ${shown(loc.dir)} is not in a git checkout — nothing to retire safely`);
        return 1;
      }
      const dirty = git('status', '--porcelain', '--', '.');
      if (dirty) {
        out(`✗ ${loc.id}: uncommitted changes in its folder would be lost — commit or drop them first:\n${dirty}`);
        return 1;
      }
      git('rm', '-r', '-q', '--', '.');
      out(`✓ ${loc.id}: ${shown(loc.dir)} removed from the repository (git history keeps it). Commit: git commit -m "Retire ${loc.id}"`);
      return 0;
    },
  },
  {
    name: 'rename',
    usage: 'rename <game> <new-id>',
    description:
      "Give a renamed game an id that says its current name: the folder games/<old> becomes games/<new-id> (`git mv` in a checkout), game.yaml's `id` changes, and `saveKey` is pinned to the old default so the players keep their saves (appId never changes). Its preview link, upload and submission zip then carry the new name; the next `gp preview` moves the old preview to the new link and leaves a redirect behind. Prints the files outside the game folder that still name the old id (scripts, tests, CI) — update them, then `gp validate` and commit. Only with no uncommitted changes in the game folder.",
    async run(args) {
      if (!args[0] || !args[1]) {
        out('Usage: gp rename <game> <new-id> — e.g. gp rename echoflies firefly-rush');
        return 1;
      }
      const loc = locateGame(args[0]);
      const { renameGame } = await import('./rename.ts');
      const r = renameGame(loc.dir, args[1]);
      if (!r.ok) {
        out(`✗ ${loc.id}: ${r.problems.join('; ')}`);
        return 1;
      }
      out(`✓ ${loc.id} → ${args[1]}: ${shown(r.dir!)}${r.git ? ' (git mv)' : ''}`);
      if (r.pinnedSaveKey) out(`  saveKey pinned to "${r.pinnedSaveKey}": players keep their saves`);
      if (r.mentions.length) out(`  Still naming "${loc.id}" (update them):\n${r.mentions.map((m) => '    ' + m).join('\n')}`);
      out(`  Next: gp validate ${args[1]}, commit; gp preview moves the old preview link to the new one.`);
      return 0;
    },
  },
  {
    name: 'playgama-check',
    usage: 'playgama-check <game>',
    description:
      "Playgama's certification, before the owner runs it in Playgama's QA Tool: the game plays as its Playgama build against a recording fake Bridge and the demo bot plays. Checks: the Bridge initialized first, saves through Bridge storage in one call, game_ready, gameplay_started/stopped, an interstitial at a natural break within 90 s, a rewarded ad closed early gives nothing, pause_state_changed and audio_state_changed obeyed, no localStorage, no external resources. Writes games/<id>/qa/playgama-check.md. Run it before handing a Playgama zip over (docs/guides/publishing-playgama.md).",
    async run(args) {
      if (!args[0]) {
        out('Usage: gp playgama-check <game>');
        return 1;
      }
      const loc = locateGame(args[0]);
      const { playgamaCheck } = await import('./playgama-check.ts');
      const r = await playgamaCheck(loc);
      for (const c of r.checks) out(`${c.ok ? '✓' : '✗'} ${c.name}${c.detail ? ` — ${c.detail}` : ''}`);
      const bad = r.checks.filter((c) => !c.ok).length;
      out(bad ? `✗ ${loc.id}: ${bad} Playgama check(s) fail — fix them before the QA Tool (${shown(r.file)})` : `✓ ${loc.id}: ready for Playgama's QA Tool (${shown(r.file)})`);
      return bad ? 1 : 0;
    },
  },
  {
    name: 'lessons',
    usage: 'lessons',
    description:
      "What the people who judged our games told them off for — reviewers, the owner, a contest jury: every remark verbatim, grouped into lessons, each with how a reviewer spots the flaw in play, the usual fix with the platform's tools and what gp already measures of it (packages/cli/src/lessons.ts). Read it when you design a game and plan a patch; `gp review` hands the same lessons to the second agent, who marks a plain flaw [blocking].",
    async run() {
      const { lessonsMarkdown } = await import('./lessons.ts');
      out(lessonsMarkdown());
      return 0;
    },
  },
  {
    name: 'review',
    usage: 'review [game] [--check] [--no-capture] [--first-look]',
    description:
      "The quality review before the submission, by a second agent: writes games/<id>/qa/review-brief.md, the reviewer's whole task — CrazyGames' quality requirements as a checklist (each with its source line in docs/research/crazygames-requirements-2026-09.md and what `gp qa` already checks of it), what the platform knows about the game (concept, money design, story, `gp uniqueness`, `gp forecast`, the size and load budget, the last QA run, the QA screenshots, covers and preview videos to look at), and the traits of the games the portal has answered for (publisher/results.yaml), as data. It also builds games/<id>/qa/review-sheet.png: the game's own title, two moments of play (captured at 1280×720 from a fresh save: the dev build on a virtual clock, ?seed=1, the demo bot) and a meta screen, and its cover, beside 3 approved and 2 rejected shots of our own games (publisher/reference/index.yaml); the reviewer plays the desktop first, then the phone, and scores each screen 1–5 for \"would it sit on CrazyGames' front page next to these\". The reviewer writes games/<id>/quality.md: a `## Scores` list (`- title: 4/5 — <why>`, play-1, play-2, meta) and a `## Findings` list of `- [blocking] <what> → <change>` and `- [nice] <what> → <change>`; a score below 3 must be a [blocking] finding that names the screen. The sheet's last row is our other games' title screens (publisher/reference, and every game of a previews checkout — GP_PREVIEWS, else game-previews beside the platform — captured once into .gp/looks/), and the brief warns when the game's title, results or language screen is very close to one of them (a colour histogram and a layout edge map). `gp submission` refuses to complete while quality.md is missing, malformed (on CrazyGames: no scores, or a score below 3 that no [blocking] finding names; a blind first look of keep playing ≤ 2 or no goal that no [blocking] finding names) or has a [blocking] finding, and copies it into submission/ when it passes; on CrazyGames it also needs qa/first-look.md. Run it after `gp qa` (the brief lists that run's screenshots). `--first-look`: only the blind first contact — six frames of a fresh run's first 30 s (0, 3, 8, 15, 22, 30 s at 1280×720) as qa/first-look.png and qa/first-look-brief.md, with no text of ours, for an agent who knows nothing about the game; it writes qa/first-look.md (goal, controls, hook, keep playing 1–5). `--no-capture`: the sheet from the last `gp qa`'s screenshots only (no dev server). `--check`: only check quality.md and the first look (exit 1 when they would stop the submission).",
    async run(args, flags) {
      const loc = locateGame(args[0]);
      const r = checkGame(loc, 'dev');
      if (!r.ok || !r.game) {
        out(formatIssues(loc, r.issues));
        return 1;
      }
      if (!r.game.portal) {
        out(`${loc.id}: channel ${r.game.channel.id} has no portal quality review (CrazyGames only for now)`);
        return 1;
      }
      if (flags['first-look']) {
        const { captureFirstLook, composeStrip, firstLookBrief, FIRST_LOOK_BRIEF, FIRST_LOOK_FILE } = await import('./first-look.ts');
        const { frames, problems } = await captureFirstLook(loc);
        let strip: string | null = null;
        try {
          strip = await composeStrip(loc, frames);
        } catch (e) {
          problems.push(`the strip was not composed: ${String((e as Error).message).split('\n')[0]}`);
        }
        const brief = join(loc.dir, 'qa', FIRST_LOOK_BRIEF);
        const answer = join(loc.dir, 'qa', FIRST_LOOK_FILE);
        writeFileSync(brief, firstLookBrief(frames.map((f) => ({ t: f.t, file: resolve(f.file) })), strip && resolve(strip), resolve(answer), problems));
        out(`✓ ${loc.id}: ${shown(brief)} and ${strip ? shown(strip) : 'the frames'} — give the brief, and nothing else, to an agent who knows nothing about the game; it writes ${shown(answer)}`);
        for (const p of problems) out(`  · ${p}`);
        return 0;
      }
      const { niceLookHints, qualityGate, reviewBrief, reviewFacts, BRIEF_FILE } = await import('./review.ts');
      const gate = qualityGate(loc, r.game);
      for (const p of gate.report?.problems ?? []) out(`✗ ${shown(gate.file)}:${p.line}  ${p.message}`);
      for (const b of gate.report?.blocking ?? []) out(`✗ ${shown(gate.file)}:${b.line}  [blocking] ${b.what} → ${b.change}`);
      if (flags.check) {
        out(`${gate.ok ? '✓' : '✗'} ${loc.id}: quality review — ${gate.detail}`);
        return gate.ok ? 0 : 1;
      }
      for (const h of gate.report ? niceLookHints(gate.report) : []) out(`· ${shown(gate.file)}:${h.line}  [nice] about the look of the first screen or play? On CrazyGames that is [blocking]: "${h.what.slice(0, 100)}"`);
      // The sheet first: the brief lists the QA folder's pictures, the sheet's among them
      const { buildReviewSheet } = await import('./review-sheet.ts');
      const sheet = await buildReviewSheet(loc, r.game, { capture: !flags['no-capture'] });
      const facts = { ...(await reviewFacts(loc, r.game, r.issues)), sheet };
      const file = join(loc.dir, 'qa', BRIEF_FILE);
      mkdirSync(dirname(file), { recursive: true });
      writeFileSync(file, reviewBrief(loc, r.game, facts, new Date().toISOString().slice(0, 10)));
      out(`✓ ${loc.id}: ${shown(file)} — give it to a second agent (a reviewer who didn't make the game); it plays the game and writes ${shown(gate.file)}`);
      out(`${sheet.file ? '✓' : '✗'} review sheet: ${sheet.file ? shown(sheet.file) : 'not composed'} — ${sheet.cells.filter((c) => c.file).map((c) => c.id).join(', ') || 'no frames'} beside ${sheet.approved.length} approved and ${sheet.rejected.length} rejected references`);
      for (const p of sheet.problems) out(`  · ${p}`);
      const same = sheet.sameness;
      if (same?.compared) out(`${same.veryClose.length ? '⚠' : '✓'} sameness: ${same.screens.map((x) => x.screen).join(', ') || 'no screens'} against ${same.compared} shots of ${same.games} other games — ${same.veryClose.length ? same.veryClose.slice(0, 3).map((m) => `${m.screen} very close to ${m.other.title}'s ${m.other.screen} (colour ${m.sim.colour}, layout ${m.sim.layout})`).join('; ') : 'none very close'}`);
      if (!facts.qa) out(`  No QA results yet: run gp qa ${loc.id} first, then gp review again (the brief lists its screenshots).`);
      out(`${gate.ok ? '✓' : '·'} quality.md now: ${gate.detail}`);
      return 0;
    },
  },
  {
    name: 'submission',
    usage: 'submission [game] [--full] [--reuse-media]',
    description:
      "Everything the portal's submission form asks for, built and checked, in games/<id>/submission/: index.html (the one-file upload), the three covers, the two preview videos, listing.md (description, controls and the form's answers, from game.yaml `listing`), and for the owner uniqueness.md, forecast.md (what the game can earn and how sure that is: `gp forecast`; a code game without a `money` section is refused) and quality.md (the second agent's quality review: `gp review`; refused while it is missing, malformed or has a [blocking] finding). An update (CHANGELOG.md with more than one version) also needs games/<id>/patch-notes.md: what changed for players, in English, at most 2000 characters (copied as patch-notes.md; refused while missing or longer). This folder is what a game maker hands over at the end, with one zip beside it: games/<id>/<id>-<version>-submission.zip (the whole folder) for a new game, <id>-<version>-update.zip (index.html, listing.md, patch-notes.md) for an update. `--full`: a game with an update history that must be submitted anew (a rejected game resubmitted, a new listing): the whole folder and the full submission zip, no patch notes asked for; it warns with the odds of a resubmission (P(approval) and the recorded resubmissions: 3 of 4 after a Basic Launch stop were rejected). `--reuse-media`: keep the covers and videos already in games/<id>/store/ while they are newer than the game's code (older ones are rendered again); with `--full`, keep them as they are — nothing is rendered again, only what is missing (a note names the old ones to look at).",
    async run(args, flags) {
      const loc = locateGame(args[0]);
      const r = checkGame(loc, 'dev');
      if (!r.ok || !r.game) {
        out(formatIssues(loc, r.issues));
        return 1;
      }
      if (!r.game.portal) {
        out(`${loc.id}: channel ${r.game.channel.id} has no portal submission (CrazyGames only for now)`);
        return 1;
      }
      const { buildSubmission } = await import('./submission.ts');
      const res = await buildSubmission(loc, r.game, { reuseMedia: !!flags['reuse-media'], full: !!flags.full });
      const w = Math.max(...res.files.map((f) => f.field.length));
      for (const f of res.files) out(`${f.ok ? '✓' : '✗'} ${f.field.padEnd(w)}  ${f.file ?? '—'}  ${f.detail}`);
      out(res.ok ? `\n✓ ${loc.id}: ${shown(res.dir)}/ is complete. Send the owner ${shown(res.handover!.file)} (${res.handover!.names.join(', ')}); test in the portal's Preview before Submit.` : `\n✗ ${loc.id}: the submission is incomplete — fix the ✗ lines`);
      return res.ok ? 0 : 1;
    },
  },
  {
    name: 'android',
    usage: 'android check-manifest [game] <merged AndroidManifest.xml>',
    description:
      "Check an Android build's merged manifest against the channel: only allowlisted permissions (android-families: no AD_ID, no Privacy Sandbox, nothing an SDK added unnoticed), targetSdkVersion at the Google Play minimum. Exit code 1 on problems.",
    async run(args) {
      if (args[0] !== 'check-manifest' || args.length < 2) {
        out('Usage: gp android check-manifest [game] <path to merged AndroidManifest.xml>');
        return 1;
      }
      const loc = locateGame(args.length > 2 ? args[1] : undefined);
      const r = checkGame(loc, 'dev');
      if (!r.game) {
        out(formatIssues(loc, r.issues));
        return 1;
      }
      const { checkAndroidManifest } = await import('./android.ts');
      const res = checkAndroidManifest(r.game, args[args.length - 1]);
      out(res.report);
      for (const p of res.problems) out(`✗ ${p}`);
      out(res.problems.length ? `✗ ${loc.id}: manifest check failed` : `✓ ${loc.id}: manifest matches channel ${r.game.channel.id}`);
      return res.problems.length ? 1 : 0;
    },
  },
  {
    name: 'qa',
    usage: 'qa [game] [--quick] [--failed] [--jobs <n>] [--bot] [--headed]',
    description:
      "Automated QA in a headless browser: the kit's own check suite on its screen sizes (every kit: layout, touch sizes, rounds, ads rules, saves, performance, console errors; kids also multitouch, rotation, purchase, parent gate; code: the host contract, failed ads, the shop and dialog when present, and the balance report the game's bot exports). A game on a portal is also checked as its upload (the one-file production build, `gp build --target crazygames`) with the portal SDK faked (SDK call order, gameplay events, cloud save, no test hooks). Report and screenshots in games/<id>/qa/; at the end one line of the money forecast (`gp forecast`: never a failure). `--quick`: one screen size, for iterating (the full run is what counts). `--failed` (code games): re-run only the sections that failed in the last run and keep the rest — for iterating on a fix; after a `--quick` run it re-runs them quick (one screen size), after a full run full; the gate is a full run. `--jobs <n>`: sections at once (default GP_QA_JOBS, else one fewer than the CPUs, at most 3; the frame rate and the timed twist always run last, alone). `--headed`: watch it in a browser window (one section at a time). The balance: at a launch the bot's `balance()` and the `balanceModel()` both run and are compared; in an update (CHANGELOG.md with 2+ versions) the model alone, when the game has one — `--bot` runs the bot too.",
    async run(args, flags) {
      const loc = locateGame(args[0]);
      const r = checkGame(loc, 'dev');
      if (!r.ok || !r.game) {
        out(formatIssues(loc, r.issues));
        return 1;
      }
      const { runQa } = await import('@gp/qa');
      const { startDev, servePreview } = await import('./vite.ts');
      // A game on a portal is also checked as it will be uploaded: the production build with the real SDK adapter
      // Built before the dev server starts: files written later would make it reload the page under test
      let prod: Awaited<ReturnType<typeof servePreview>> | null = null;
      if (r.game.portal) {
        const { buildPortal } = await import('./portal-build.ts');
        const pkg = await buildPortal(loc, r.game);
        for (const p of pkg.problems) out(`✗ upload: ${p}`);
        if (pkg.problems.length) return 1;
        prod = await servePreview(loc, pkg.dir);
      }
      // Frozen: a file written while QA runs (the next edit) doesn't reload the page under test (vite.ts startDev)
      const server = await startDev(loc, undefined, { frozen: true });
      const url = server.resolvedUrls?.local[0] ?? 'http://localhost:5173/';
      try {
        const prodUrl = prod?.resolvedUrls?.local[0];
        // A code game's progression curve, from its own balance bot (a warning when it exports no balance())
        const game = r.game;
        const { balanceDesign, balanceQa } = await import('./balance.ts');
        // The run is kept: the forecast line below reads the same report as forecast.md (gp forecast)
        let balanceRun: Awaited<ReturnType<typeof balanceQa>> | undefined;
        const after =
          game.kit.kit === 'code'
            ? async (ctx: Parameters<typeof balanceQa>[2]) => {
                // An update (CHANGELOG.md with 2+ versions) is a patch: the model alone, unless --bot
                const { isUpdate } = await import('./submission.ts');
                balanceRun = await balanceQa(loc, game.channel.id, ctx, { worker: true, patch: isUpdate(loc.dir) && !flags.bot, design: balanceDesign(game) });
              }
            : undefined;
        const jobs = flags.jobs === undefined || flags.jobs === true ? undefined : Number(flags.jobs);
        if (jobs !== undefined && !(Number.isInteger(jobs) && jobs >= 1)) {
          out(`✗ --jobs takes a whole number ≥ 1, not "${String(flags.jobs)}"`);
          return 1;
        }
        let res: Awaited<ReturnType<typeof runQa>>;
        try {
          res = await runQa({ url, game, outDir: join(loc.dir, 'qa'), headed: !!flags.headed, quick: !!flags.quick, prodUrl, after, jobs, failed: !!flags.failed });
        } catch (e) {
          // --failed refuses what it can't re-run in part (no full run before it, the platform changed): say so
          if (!flags.failed) throw e;
          out(`✗ ${(e as Error).message}`);
          return 1;
        }
        out(`\n${res.failed ? '✗' : '✓'} ${loc.id}: ${res.passed} passed, ${res.failed} failed. Report: ${shown(res.report)}`);
        // The money forecast: never a QA failure, but in view at every QA run (docs/guides/game-design.md → Design for money)
        try {
          const { gameForecast, forecastLine } = await import('./forecast.ts');
          out(forecastLine((await gameForecast(loc, game, r.issues, { balanceRun })).forecast));
        } catch (e) {
          out(`money: no forecast (${(e as Error).message.split('\n')[0]})`);
        }
        return res.failed ? 1 : 0;
      } finally {
        await server.close();
        await prod?.close();
      }
    },
  },
  {
    name: 'admob',
    usage: 'admob provision [game] [--app-id <id>] [--interstitial <id>]',
    description:
      "Fill in the game's AdMob App ID and interstitial ad unit ID. With the IDs: checks them against publisher.yaml and writes them into game.yaml. Without: prints the exact AdMob steps and names to use.",
    async run(args, flags) {
      if (args[0] !== 'provision') {
        out('Usage: gp admob provision [game] [--app-id ca-app-pub-…~…] [--interstitial ca-app-pub-…/…]');
        return 1;
      }
      const loc = locateGame(args[1]);
      const doc = parseDocument(readFileSync(loc.file, 'utf8'));
      const title = String(doc.get('title'));
      const pub = loadPublisher().admob?.publisherId ?? '(publisher/publisher.yaml: admob.publisherId)';
      if (typeof flags['app-id'] !== 'string' && typeof flags.interstitial !== 'string') {
        out(`AdMob (https://admob.google.com), account ${pub}:`);
        out(`  1. Apps → Add app → Android → "Is the app listed on a supported app store?" No → name: "${title}" → App ID`);
        out(`  2. That app → Ad units → Add → Interstitial → name: "${loc.id}-interstitial" → ad unit ID`);
        out(`  3. gp admob provision ${loc.id} --app-id <App ID> --interstitial <ad unit ID>`);
        out('After the game is on Google Play: AdMob → Apps → Link your app (the IDs stay the same).');
        out('Dev builds always use Google test IDs; only `gp build --release` uses these.');
        return 0;
      }
      if (typeof flags['app-id'] === 'string') doc.setIn(['monetization', 'ads', 'appId'], flags['app-id']);
      if (typeof flags.interstitial === 'string') doc.setIn(['monetization', 'ads', 'interstitial'], flags.interstitial);
      const before = readFileSync(loc.file, 'utf8');
      writeFileSync(loc.file, doc.toString(YAML_OUT));
      const r = checkGame(loc, 'dev');
      const idIssues = r.issues.filter((i) => i.path[0] === 'monetization');
      if (idIssues.length) {
        writeFileSync(loc.file, before);
        out(formatIssues(loc, idIssues));
        out('game.yaml left unchanged.');
        return 1;
      }
      out(`✓ ${loc.id}: AdMob IDs written to game.yaml`);
      return 0;
    },
  },
  {
    name: 'schema',
    usage: 'schema',
    description: 'Write packages/spec/schema/game.schema.json — JSON Schema of game.yaml for editor autocompletion (VS Code YAML extension picks it up from the first line of game.yaml).',
    async run() {
      mkdirSync(join(ROOT, 'packages/spec/schema'), { recursive: true });
      writeFileSync(SCHEMA_FILE, JSON.stringify({ $schema: 'http://json-schema.org/draft-07/schema#', ...GAME_SCHEMA }, null, 2) + '\n');
      out(`✓ ${shown(SCHEMA_FILE)}`);
      return 0;
    },
  },
  {
    name: 'docs',
    usage: 'docs [--check]',
    description: 'Regenerate docs/reference/*.md (game.yaml fields, catalog, profiles, errors, CLI), docs/guides/genres.md (the genre registry) and the editor schema. `--check` only verifies they are up to date (CI).',
    async run(_args, flags) {
      const files: Record<string, string> = Object.fromEntries(Object.entries(referenceDocs(commands)).map(([k, v]) => [join(DOCS_REFERENCE_DIR, k), v]));
      for (const [name, text] of Object.entries(guideDocs())) files[join(ROOT, 'docs/guides', name)] = text;
      files[SCHEMA_FILE] = JSON.stringify({ $schema: 'http://json-schema.org/draft-07/schema#', ...GAME_SCHEMA }, null, 2) + '\n';
      for (const [name, text] of Object.entries(editorSchemas())) files[join(ROOT, 'packages/spec/schema', name)] = text;
      let stale = 0;
      for (const [file, text] of Object.entries(files)) {
        const cur = existsSync(file) ? readFileSync(file, 'utf8') : '';
        if (cur === text) continue;
        stale++;
        if (flags.check) out(`out of date: ${shown(file)}`);
        else {
          mkdirSync(join(file, '..'), { recursive: true });
          writeFileSync(file, text);
          out(`✓ ${shown(file)}`);
        }
      }
      if (flags.check && stale) out('Run `npm run gp -- docs` and commit the result.');
      if (!stale) out('Reference docs are up to date.');
      return flags.check && stale ? 1 : 0;
    },
  },
  {
    name: 'doctor',
    usage: 'doctor',
    description: 'Check the environment: Node version, dependencies, a browser for QA, the Android toolchain (optional: CI builds Android).',
    async run() {
      let bad = 0;
      const ok = (cond: boolean, what: string, hint: string) => {
        out(`${cond ? '✓' : '✗'} ${what}${cond ? '' : ` — ${hint}`}`);
        if (!cond) bad++;
      };
      const [maj, min] = process.versions.node.split('.').map(Number);
      ok(maj > 22 || (maj === 22 && min >= 18), `Node ${process.versions.node}`, 'Node 22.18+ is needed (runs .ts directly)');
      ok(existsSync(join(ROOT, 'node_modules/vite')), 'dependencies installed', 'run npm install');
      let browser = false;
      try {
        const { chromium } = await import('playwright');
        browser = existsSync(chromium.executablePath());
      } catch {
        browser = false;
      }
      ok(browser, 'Chromium for gp qa', 'npx playwright install chromium');
      // Nimbus Drift's container had no ffmpeg: gp video and gp submission need one that encodes H.264
      const { findFfmpeg } = await import('./video.ts');
      const ffmpeg = findFfmpeg();
      out(`${ffmpeg ? '✓' : '·'} ffmpeg with libx264${ffmpeg ? '' : ' — not found (gp video, gp submission): pip install imageio-ffmpeg, or FFMPEG=/path/to/ffmpeg'}`);
      const sdk = !!(process.env.ANDROID_HOME || process.env.ANDROID_SDK_ROOT);
      out(`${sdk ? '✓' : '·'} Android SDK${sdk ? '' : ' — not found (optional: Android builds run in GitHub Actions)'}`);
      return bad ? 1 : 0;
    },
  },
];

function help(): void {
  out('gp — make games on the platform\n');
  for (const c of commands) out(`  gp ${c.usage}\n      ${c.description}\n`);
  out('Docs: AGENTS.md (start here), docs/tutorial.md, docs/reference/.');
}

function parse(argv: string[]): { args: string[]; flags: Record<string, string | boolean> } {
  const args: string[] = [];
  const flags: Record<string, string | boolean> = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const [k, v] = a.slice(2).split('=', 2);
      if (v !== undefined) flags[k] = v;
      else if (argv[i + 1] && !argv[i + 1].startsWith('--') && ['from', 'title', 'port', 'app-id', 'interstitial', 'target', 'out', 'script', 'only', 'id', 'depth', 'genre', 'channel', 'audience', 'session', 'breaks', 'rewarded', 'meta', 'return', 'pitch', 'unique', 'mb', 'load', 'engine', 'to', 'words', 'variants', 'jobs', 'provider', 'resubmission', 'factor', 'models', 'method', 'grid', 'margin', 'gap', 'cleanup', 'size', 'kind', 'tolerance', 'max'].includes(k)) flags[k] = argv[++i];
      else flags[k] = true;
    } else args.push(a);
  }
  return { args, flags };
}

const [name, ...rest] = process.argv.slice(2);
const cmd = commands.find((c) => c.name === name);
if (!cmd) {
  help();
  process.exit(name && name !== 'help' ? 1 : 0);
}
if (rest.includes('--help') || rest.includes('-h')) {
  out(`gp ${cmd.usage}\n\n${cmd.description}`);
  process.exit(0);
}
const t0 = Date.now();
try {
  const { args, flags } = parse(rest);
  process.exitCode = await cmd.run(args, flags);
} catch (e) {
  out(`gp ${name}: ${(e as Error).message}`);
  process.exitCode = 1;
} finally {
  logRun(name, rest, Number(process.exitCode ?? 0), Date.now() - t0);
}

/**
 * Local run log (.gp/runs.jsonl, not committed): one line per command — the raw data for the platform metrics
 * (time from brief to green QA, validate iterations). Nothing leaves the machine.
 */
function logRun(command: string, argv: string[], exit: number, ms: number): void {
  if (command === 'dev' || process.env.GP_NO_LOG) return;
  try {
    mkdirSync(join(ROOT, '.gp'), { recursive: true });
    appendFileSync(join(ROOT, '.gp/runs.jsonl'), JSON.stringify({ t: new Date().toISOString(), command, argv, exit, ms }) + '\n');
  } catch {
    // the log is a convenience; never fail a command because of it
  }
}

/**
 * `gp init --engine <name>`: the engine variant of the skeleton. Canvas 2D is the template as it is (no package); for
 * an engine with a package, main.ts becomes the shared engine skeleton (templates/game-repo/engines/main.ts: the same
 * screens, the loop through the adapter), view.ts the engine's drawing (engines/<name>/view.ts), package.json pins the
 * tested version, and game.yaml names the engine — `gp validate` checks the three agree with the installed package.
 */
function initEngine(gameDir: string, id: string, engine: (typeof ENGINES)[string], copyFile: (templateFile: string, to: string) => void): void {
  const yamlFile = join(gameDir, 'game.yaml');
  const line = engine.package ? `engine: { name: ${engine.id}, version: ${engine.tested} }` : `engine: { name: ${engine.id} }`;
  const comment = `# The engine and its adapter (@gp/core/engines/${engine.id}); ${engine.package ? `the version pinned in package.json (gp validate checks both)` : 'Canvas 2D needs no package'} — docs/guides/code-games.md#engines`;
  const yaml = readFileSync(yamlFile, 'utf8');
  const lines = yaml.split('\n');
  const at = lines.findIndex((l) => /^background:/.test(l));
  lines.splice(at >= 0 ? at + 1 : lines.findIndex((l) => /^kit:/.test(l)) + 1, 0, comment, line);
  writeFileSync(yamlFile, lines.join('\n'));
  if (!engine.package) return;
  copyFile('main.ts', join(gameDir, 'main.ts'));
  // The Canvas skeleton's look (art.ts, @gp/art on Canvas 2D) doesn't apply: the engine draws in view.ts
  rmSync(join(gameDir, 'art.ts'), { force: true });
  copyFile(join(engine.id, 'view.ts'), join(gameDir, 'view.ts'));
  const pkg: Record<string, unknown> = {
    name: id,
    private: true,
    description: `The game's own npm dependencies: ${engine.package}, installed into this folder (scripts/setup.sh). Upgrade it only within ${engine.range}, here and in game.yaml engine.version together`,
    dependencies: { [engine.package]: engine.tested },
  };
  // three ships no types of its own
  if (engine.id === 'three') pkg.devDependencies = { '@types/three': engine.tested!.replace(/\.\d+$/, '.0') };
  writeFileSync(join(gameDir, 'package.json'), JSON.stringify(pkg, null, 2) + '\n');
}

/**
 * `gp init --physics`: the skeleton's PLACEHOLDER mechanic on Rapier 2D through the physics block (@gp/physics). After
 * initEngine: main.ts is the engine skeleton (for Canvas 2D too: the physics steps on the adapter's fixed step), view.ts
 * draws the platform and the ball (templates/game-repo/physics/<engine>/view.ts), sim.ts is the physics sim
 * (physics/sim.ts: a fresh world at every run), main.ts, bot.ts and sim.test.ts await its WebAssembly first, the
 * -compat package is pinned in package.json, game.yaml names it and raises the portal budget. Each edit of a shared
 * template file must find its anchor: a template change that moves one fails here (and in init.test.ts), not silently.
 */
function initPhysics(gameDir: string, id: string, engine: (typeof ENGINES)[string], physics: (typeof PHYSICS)[string], copyFile: (templateFile: string, to: string) => void): void {
  const edit = (file: string, ...pairs: [string, string][]) => {
    const f = join(gameDir, file);
    let text = readFileSync(f, 'utf8');
    for (const [from, to] of pairs) {
      if (!text.includes(from)) throw new Error(`gp init --physics: templates/game-repo changed — "${from.split('\n')[0]}" is no longer in ${file}`);
      text = text.replace(from, () => to);
    }
    writeFileSync(f, text);
  };
  if (!engine.package) copyFile(join('engines', 'main.ts'), join(gameDir, 'main.ts'));
  rmSync(join(gameDir, 'art.ts'), { force: true });
  copyFile(join('physics', engine.id, 'view.ts'), join(gameDir, 'view.ts'));
  copyFile(join('physics', 'sim.ts'), join(gameDir, 'sim.ts'));
  if (physics.package !== '@dimforge/rapier2d-compat') edit('sim.ts', ["from '@dimforge/rapier2d-compat'", `from '${physics.package}'`]);
  edit(
    'main.ts',
    ["import { newRun, step, tap, type RunState } from './sim.ts';", "import { loadPhysics, newRun, step, tap, type RunState } from './sim.ts';"],
    ['  const eng = await createView(ctx, () => {', "  // Rapier's WebAssembly and the world first (without WebAssembly this throws: the player's \"can't run\" screen)\n  await loadPhysics();\n  const eng = await createView(ctx, () => {"],
  );
  edit(
    'bot.ts',
    ["import { DT, newRun, step, tap, type Rand, type Tuning } from './sim.ts';", "import { DT, loadPhysics, newRun, step, tap, type Rand, type Tuning } from './sim.ts';"],
    ['export function balance(): BalanceReport {\n', "export async function balance(): Promise<BalanceReport> {\n  // The bot plays the page's physics: Rapier's WebAssembly first (the -compat build loads in Node)\n  await loadPhysics();\n"],
  );
  edit(
    'sim.test.ts',
    ["import { describe, expect, it } from 'vitest';", "import { beforeAll, describe, expect, it } from 'vitest';"],
    ["import { newRun, step, tap } from './sim.ts';\n", "import { loadPhysics, newRun, step, tap } from './sim.ts';\n\n// Rapier's WebAssembly, once for the file (the -compat build loads in Node)\nbeforeAll(loadPhysics);\n"],
    ["  it('the balance report meets the channel\\'s targets', () => {\n    const v = evaluateBalance(balance(), 'crazygames');", "  it('the balance report meets the channel\\'s targets', async () => {\n    const v = evaluateBalance(await balance(), 'crazygames');"],
  );
  const yamlFile = join(gameDir, 'game.yaml');
  const lines = readFileSync(yamlFile, 'utf8').split('\n');
  const at = lines.findIndex((l) => /^engine:/.test(l));
  lines[at] = lines[at].replace(/ }$/, `, physics: { name: ${physics.id}, version: ${physics.tested} } }`);
  lines.splice(
    at + 1,
    0,
    `# Rapier is ≈ ${physics.gzipKB.toLocaleString('en-US')} KB gzipped, over the portal's 400 KB: the budget raised on purpose (gp build warns above it, gp forecast counts the`,
    '# longer load). Keep physics only where it is the mechanic — docs/guides/code-games.md#physics',
    'budget: { gzipKB: 1500 }',
  );
  writeFileSync(yamlFile, lines.join('\n'));
  const pkgFile = join(gameDir, 'package.json');
  const pkg = (existsSync(pkgFile) ? JSON.parse(readFileSync(pkgFile, 'utf8')) : { name: id, private: true }) as { description?: string; dependencies?: Record<string, string> };
  pkg.description = `The game's own npm dependencies, installed into this folder (scripts/setup.sh). Upgrade only within what the platform supports (${[...(engine.package ? [engine.range] : []), physics.range].join('; ')}), here and in game.yaml engine${engine.package ? '.version and engine' : ''}.physics.version together`;
  pkg.dependencies = { ...(pkg.dependencies ?? {}), [physics.package]: physics.tested };
  writeFileSync(pkgFile, JSON.stringify(pkg, null, 2) + '\n');
}
