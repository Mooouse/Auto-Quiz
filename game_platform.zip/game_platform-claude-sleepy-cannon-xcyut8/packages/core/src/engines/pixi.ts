// PixiJS 8 through the engine contract: the renderer only (no Application, no Ticker loop of Pixi's own), the
// adapter's fixed-step loop. Pixi is the game's own npm dependency; pass the three pieces the adapter uses:
//
//   import { autoDetectRenderer, Container, Graphics, Rectangle, Ticker } from 'pixi.js';
//   const eng = await pixiAdapter(host, canvas, { autoDetectRenderer, Container, Ticker }, { background: '#101826' });
//   const dot = eng.texture(new Graphics().circle(6, 6, 6).fill(0xffffff), { frame: new Rectangle(0, 0, 12, 12) });
//   eng.stage.addChild(…); eng.onStep((dt) => …); eng.onFrame(() => …); eng.setRunning(true);
//
// What it does for you (each one found by hand in the engine lab, games/lab-pixi/NOTES.md):
// - Ticker.system stopped: a bare renderer still runs Pixi's own requestAnimationFrame loop (its GC scheduler) at 60
//   callbacks/s on menus; the adapter updates it from its own frames only;
// - skipExtensionImports: no EventSystem (pointer listeners and touch-action on #game) and no AccessibilitySystem (a
//   DOM overlay on Tab): input is the game's (MoveInput); pass `init: { skipExtensionImports: false }` to have Pixi's;
// - WebGL (2, else 1), then Pixi's Canvas renderer, and a second attempt on Canvas alone when Pixi's probe says WebGL
//   works but #game is refused a context; neither → an Error the player shows as "can't run";
// - no MSAA on the main context (software WebGL paid ~40 % for it), the canvas's CSS left to the platform;
// - a lost and restored WebGL context: Pixi re-uploads what has a CPU copy, but generated textures come back EMPTY —
//   make them with eng.texture() and the adapter draws them again on the restore, before the redraw.
//
// Pictures from the engine's own drawing (a DOM thumbnail, the cover's key art): eng.snapshot(w, h, (root) => root.addChild(…))
// → a 2D canvas; fitRect(bounds, rect) scales and places a subject inside a rectangle. A quality level's render scale:
// eng.setRenderScale(0.75) (@gp/core/quality).

import type { GameHost } from '../host';
import { createDriver, devWarn, windowSize, type Engine, type EngineOptions } from './driver';

export type { Engine, EngineAudio, EngineOptions, EngineSize } from './driver';

/** The part of a Pixi 8 renderer the adapter uses (structural: @gp/core doesn't depend on pixi.js) */
export interface PixiRendererLike {
  readonly name?: string;
  render(what: object): void;
  resize(width: number, height: number, resolution?: number): void;
  generateTexture(options: object): unknown;
  /** For snapshot() (every Pixi 8 renderer has it) */
  readonly extract?: { canvas(options: object): unknown };
}

/** The pieces of `pixi.js` the adapter needs: `{ autoDetectRenderer, Container, Ticker }` */
export interface PixiModule<R extends PixiRendererLike, C> {
  autoDetectRenderer(options: object): Promise<R>;
  Container: new () => C;
  Ticker: { readonly system: { autoStart: boolean; stop(): unknown; update(time?: number): void } };
  /** For snapshot()'s frame (optional: a plain rectangle with Pixi's copyTo is made otherwise) */
  Rectangle?: new (x: number, y: number, width: number, height: number) => object;
}

export interface PixiSnapshotOptions {
  /** Pixels per unit of the picture (default 1: w×h px) */
  resolution?: number;
  /** The background (a CSS colour or 0xRRGGBB); default transparent */
  background?: string | number;
}

export interface PixiOptions extends EngineOptions {
  /** The clear colour (a CSS colour or 0xRRGGBB) */
  background?: string | number;
  /** Renderer order (default ['webgl', 'canvas'], then 'canvas' alone; WebGPU is left out: it changes nothing here and isn't everywhere) */
  preference?: string | string[];
  /** More options for autoDetectRenderer (they win over the adapter's, except canvas, size and resolution) */
  init?: Record<string, unknown>;
}

export interface PixiTextureOptions {
  /** The region to draw; give one at (0, 0) — a texture is redrawn after a context restore with the identity transform */
  frame?: { x: number; y: number; width: number; height: number };
  /** Default: the DPR cap (2), so it is sharp at any capped DPR */
  resolution?: number;
  /** Smooth edges (only where the renderer can: WebGL2 and Canvas; WebGL1 warns and ignores it). Default true */
  antialias?: boolean;
}

export interface PixiEngine<R extends PixiRendererLike, C> extends Engine {
  readonly renderer: R;
  /** The root container the adapter renders every frame */
  readonly stage: C;
  /** 1 or 2 when drawing with WebGL, null on Pixi's Canvas renderer */
  readonly webgl: 1 | 2 | null;
  /** renderer.generateTexture of a Graphics (or any container), remembered so a context restore draws it again */
  texture<T = ReturnType<R['generateTexture']>>(target: object, opts?: PixiTextureOptions): T;
  /** After a context restore, once Pixi and the adapter rebuilt their GPU state (before the redraw): re-create what else you made on the GPU */
  onRestore(fn: () => void): () => void;
  /**
   * Draw something off screen into a new 2D canvas of w×h (a DOM thumbnail, the cover's art): `build` fills a fresh root
   * container (its region 0,0 → w,h is the picture). Add new display objects to it, not ones on the stage (Pixi would move
   * them); they stay yours to destroy, the root is destroyed. `.toDataURL('image/png')` for an <img>, cached
   */
  snapshot(w: number, h: number, build: (root: C) => void, opts?: PixiSnapshotOptions): HTMLCanvasElement;
}

/**
 * Scale and place a subject (its local bounds: container.getLocalBounds()) to fill `rect` with `padding` (a share of the
 * rectangle each side, default 0.06): set `scale` and `x, y` on the container. Any 2D engine: Pixi, Phaser, Canvas 2D
 */
export function fitRect(bounds: { x: number; y: number; width: number; height: number }, rect: { x: number; y: number; w: number; h: number }, padding = 0.06): { scale: number; x: number; y: number } {
  const pad = 1 - 2 * Math.max(0, Math.min(0.4, padding));
  const scale = Math.min((rect.w * pad) / Math.max(1e-6, bounds.width), (rect.h * pad) / Math.max(1e-6, bounds.height));
  return { scale, x: rect.x + rect.w / 2 - (bounds.x + bounds.width / 2) * scale, y: rect.y + rect.h / 2 - (bounds.y + bounds.height / 2) * scale };
}

/** Pixi 8's renderer on #game, created stopped. Rejects with a readable Error when there is no renderer at all */
export async function pixiAdapter<R extends PixiRendererLike, C>(host: GameHost, canvas: HTMLCanvasElement, pixi: PixiModule<R, C>, opts: PixiOptions = {}): Promise<PixiEngine<R, C>> {
  const s0 = windowSize(opts.dprMax ?? 2, opts.renderScale ?? 1);
  const base = {
    antialias: false,
    skipExtensionImports: true,
    ...(opts.background !== undefined ? { background: opts.background } : {}),
    ...opts.init,
    canvas,
    width: s0.width,
    height: s0.height,
    resolution: s0.dpr,
    // The platform's CSS sizes #game; Pixi sets only the drawing buffer
    autoDensity: false,
  };
  const attempts: (string | string[])[] = opts.preference ? [opts.preference] : [['webgl', 'canvas'], 'canvas'];
  let renderer: R | null = null;
  const errors: string[] = [];
  for (const preference of attempts) {
    try {
      renderer = await pixi.autoDetectRenderer({ ...base, preference });
      break;
    } catch (e) {
      errors.push(`${[preference].flat().join(' → ')}: ${e instanceof Error ? e.message : String(e)}`);
    }
  }
  if (!renderer) throw new Error(`no WebGL and no Canvas 2D renderer (Pixi: ${errors.join('; ')})`);
  const r = renderer;
  // A bare renderer still starts Ticker.system (its scheduler's listener): Pixi's own rAF loop. The adapter's frames drive it
  pixi.Ticker.system.autoStart = false;
  pixi.Ticker.system.stop();
  const gl = (r as { gl?: unknown }).gl;
  const webgl: 1 | 2 | null = gl ? (typeof WebGL2RenderingContext !== 'undefined' && gl instanceof WebGL2RenderingContext ? 2 : 1) : null;
  const stage = new pixi.Container();
  const generated: { target: object; texture: unknown }[] = [];
  const restoreFns: (() => void)[] = [];

  // Added after Pixi's own listener (made in init): Pixi has re-created its GL state when this runs. The host's onResume
  // comes after every listener, and the driver redraws there
  const onRestored = () => {
    for (const g of generated) r.render({ container: g.target, target: g.texture, clear: true, clearColor: [0, 0, 0, 0] });
    for (const fn of restoreFns) fn();
  };
  const d = createDriver(host, canvas, opts, (drv) => {
    const render = () => r.render(stage as object);
    const loop = drv.loop({ render, beforeFrame: (ts) => pixi.Ticker.system.update(ts) });
    return {
      start: loop.start,
      stop: loop.stop,
      render,
      resize: (s) => r.resize(s.width, s.height, s.dpr),
      webgl: true,
      // After destroy() a restore must not draw into textures the game may have destroyed with its renderer
      destroy: () => canvas.removeEventListener('webglcontextrestored', onRestored),
    };
  });
  canvas.addEventListener('webglcontextrestored', onRestored);

  return Object.assign(d.engine, {
    renderer: r,
    stage,
    webgl,
    texture<T>(target: object, o: PixiTextureOptions = {}): T {
      const f = o.frame;
      if (f && (f.x !== 0 || f.y !== 0)) devWarn('pixi-frame', `pixiAdapter.texture(): a frame at (${f.x}, ${f.y}) is redrawn at (0, 0) after a WebGL context restore — draw the shape from (0, 0)`);
      // Antialiased render textures need WebGL2 (WebGL1 warns on every one) or the Canvas renderer
      const antialias = (o.antialias ?? true) && webgl !== 1;
      const texture = r.generateTexture({ target, ...(f ? { frame: f } : {}), resolution: o.resolution ?? opts.dprMax ?? 2, antialias });
      generated.push({ target, texture });
      return texture as T;
    },
    snapshot(w: number, h: number, build: (root: C) => void, o: PixiSnapshotOptions = {}): HTMLCanvasElement {
      if (!r.extract) throw new Error('pixiAdapter.snapshot(): the renderer has no extract system');
      const root = new pixi.Container();
      build(root);
      const W = Math.max(1, Math.round(w));
      const H = Math.max(1, Math.round(h));
      // Pixi copies the frame with Rectangle#copyTo
      const frame = pixi.Rectangle
        ? new pixi.Rectangle(0, 0, W, H)
        : { x: 0, y: 0, width: W, height: H, copyTo: (t: { x: number; y: number; width: number; height: number }) => Object.assign(t, { x: 0, y: 0, width: W, height: H }) };
      try {
        return r.extract.canvas({ target: root, frame, resolution: o.resolution ?? 1, clearColor: o.background ?? [0, 0, 0, 0], antialias: webgl !== 1 }) as HTMLCanvasElement;
      } finally {
        (root as { removeChildren?(): unknown; destroy?(): unknown }).removeChildren?.();
        (root as { destroy?(): unknown }).destroy?.();
      }
    },
    onRestore(fn: () => void) {
      restoreFns.push(fn);
      return () => {
        const i = restoreFns.indexOf(fn);
        if (i >= 0) restoreFns.splice(i, 1);
      };
    },
  });
}
