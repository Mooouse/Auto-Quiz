import { describe, expect, it } from 'vitest';
import { curve, walkModel, type BalanceModel } from '../src/balance-model.ts';
import { PRESTIGE_GENRES, Prestige, prestigeModel } from '../src/prestige.ts';

interface Save {
  coins: number;
  garages: number;
  lifetime: number;
  prestige: { points: number; earned: number; count: number };
  settings: { sound: boolean };
}
const DEFAULTS: Save = { coins: 0, garages: 1, lifetime: 0, prestige: { points: 0, earned: 0, count: 0 }, settings: { sound: true } };
const make = () =>
  new Prestige<Save>({ needs: (s) => s.garages >= 5, gain: Prestige.root(1e6), perPoint: 0.5, keeps: ['prestige', 'lifetime', 'settings'] });

describe('Prestige', () => {
  it('stars = floor(sqrt(lifetime / unit)); the cube root needs 8× for 2×', () => {
    const g = Prestige.root(1e6);
    expect([0, 999_999, 1e6, 4e6, 8.99e6, 9e6, 1e8].map(g)).toEqual([0, 0, 1, 2, 2, 3, 10]);
    const c = Prestige.root(1e12, 3);
    expect([1e12, 8e12, 27e12].map(c)).toEqual([1, 2, 3]);
    expect(() => Prestige.root(0)).toThrow();
  });

  it('the condition, the points a reset gives (all lives counted, minus those gained), the multiplier', () => {
    const P = make();
    const save = structuredClone(DEFAULTS);
    save.lifetime = 9e6;
    expect(P.next(save.lifetime, save.prestige)).toBe(3);
    expect(P.can(save, save.lifetime, save.prestige)).toBe(false); // not the fifth garage yet
    save.garages = 5;
    expect(P.can(save, save.lifetime, save.prestige)).toBe(true);
    const done = P.prestige(save, save.lifetime, save.prestige)!;
    expect(done).toEqual({ save: { points: 3, earned: 3, count: 1 }, gained: 3 });
    expect(P.multiplier(done.save)).toBe(2.5);
    // The same lifetime again gives nothing: a reset right after a reset is refused
    expect(P.next(9e6, done.save)).toBe(0);
    expect(P.prestige({ ...save, prestige: done.save }, 9e6, done.save)).toBeNull();
    expect(P.next(16e6, done.save)).toBe(1);
  });

  it('reset() names every key but keeps; restart() gives the defaults back and keeps the rest', () => {
    const P = make();
    const save: Save = { coins: 500, garages: 6, lifetime: 9e6, prestige: { points: 3, earned: 3, count: 1 }, settings: { sound: false } };
    expect(P.reset(save).sort()).toEqual(['coins', 'garages']);
    const next = P.restart(save, DEFAULTS);
    expect(next).toEqual({ coins: 0, garages: 1, lifetime: 9e6, prestige: { points: 3, earned: 3, count: 1 }, settings: { sound: false } });
    expect(next.prestige).toBe(save.prestige);
    next.coins = 5;
    expect(DEFAULTS.coins).toBe(0); // the defaults are copied, never shared
    expect(() => new Prestige({ needs: () => true, gain: () => 1, keeps: [] })).toThrow(/keeps/);
  });

  it('sanitize: non-negative integers, never more points held than earned', () => {
    const P = make();
    expect(P.sanitize(undefined)).toEqual({ points: 0, earned: 0, count: 0 });
    expect(P.sanitize({ points: 4.7, earned: 2, count: -1 })).toEqual({ points: 4, earned: 4, count: 0 });
    expect(P.sanitize({ points: 1, earned: 5, count: 2 })).toEqual({ points: 1, earned: 5, count: 2 });
  });

  it('lives() and multiplierAfter(): the multiplier of the second, third … life for the balance model', () => {
    const P = make();
    expect(P.multiplierAfter(0, 4e6)).toBe(1);
    // Each life earns 4M at ×1: lifetime 4M → 2 stars, 8M → 2 (floor sqrt 8 = 2) + 0, 12M → 3 …
    const flat = P.lives(3, 4e6);
    expect(flat.map((l) => [l.lifetime, l.gained, l.points, l.multiplier])).toEqual([
      [4e6, 2, 2, 1],
      [8e6, 0, 2, 2],
      [12e6, 1, 3, 2],
    ]);
    // A life that earns in proportion to its multiplier
    const scaled = P.lives(2, (_life, m) => 4e6 * m);
    expect(scaled[1]).toMatchObject({ multiplier: 2, earned: 8e6, lifetime: 12e6, points: 3 });
    expect(P.multiplierAfter(2, (_l, m) => 4e6 * m)).toBe(2.5);
    expect(PRESTIGE_GENRES).toEqual(['idle']);
  });

  it('prestigeModel(): the second life of the balance model runs faster', () => {
    const d = curve.geometric(8, 10, 1.35);
    const r = curve.geometric(8, 20, 1.25);
    const items = curve.geometric(12, 15, 1.4).map((cost, l) => ({ id: `lv-${l + 1}`, cost, mult: 1.2, ...(l ? { requires: `lv-${l}` } : {}) }));
    const model: BalanceModel = { start: { power: 11 }, stages: d.map((difficulty, i) => ({ id: `s${i + 1}`, difficulty, reward: r[i], minutes: 1 })), items };
    const P = make();
    const mult = P.multiplierAfter(1, 4e6);
    const first = walkModel(model, 'cheapest');
    const second = walkModel(prestigeModel(model, mult), 'cheapest');
    expect(second.stages.at(-1)!.clearedMin!).toBeLessThan(first.stages.at(-1)!.clearedMin!);
    expect(prestigeModel(model, 2, 'power').start.power).toBe(22);
    expect(prestigeModel(model, 2).stages[0].reward).toBe(40);
    expect(model.stages[0].reward).toBe(20); // the original tables are untouched
  });
});
