// What every scene of the kit gets.

import type { App, Scene, Theme } from '@gp/core';
import type { ScoreResult, TapScoreConfig } from '@gp/blocks';
import type { CasualConfig } from './index.meta.ts';

export interface CasualContext {
  readonly app: App;
  readonly theme: Theme;
  readonly title: string;
  readonly casual: CasualConfig;
  readonly round: TapScoreConfig;
  titleScene(): Scene;
  play(): Scene;
  result(r: ScoreResult, newBest: boolean): Scene;
}
