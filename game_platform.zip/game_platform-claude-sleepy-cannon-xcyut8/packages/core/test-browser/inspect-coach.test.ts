// Browser test of the inspect plates (inspect), the coach's hand (coachHand, hints' `hand`) and the one-card queue
// (cards): a held finger opens a plate above it and the lift is not a tap; a short tap is; a mouse hovers; the hand
// shows the gesture between two elements (still with reduced motion) and goes with its hint; the title's cards open one
// at a time. `npm run test:browser` (Playwright's Chromium).
import type { Page } from 'playwright';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { metaLog, SIZES, startFixture, type Fixture } from './meta-helpers';

let fx: Fixture;
beforeAll(async () => {
  fx = await startFixture();
}, 60000);
afterAll(async () => fx?.close());

/** A finger down at (x, y), held `ms`, moved by (dx, dy) on the way, then lifted (CDP touch events: real pointer events) */
async function touch(page: Page, x: number, y: number, ms: number, dx = 0, dy = 0) {
  const cdp = await page.context().newCDPSession(page);
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x, y }] });
  if (dx || dy) {
    await page.waitForTimeout(60);
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: x + dx, y: y + dy }] });
  }
  await page.waitForTimeout(ms);
  const open = await page.locator('[data-gp=plate]').count();
  const box = open ? await page.locator('[data-gp=plate]').boundingBox() : null;
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
  await page.waitForTimeout(50);
  return { open, box };
}

describe('inspect', () => {
  it('a finger held 380 ms opens the plate above it; the lift is not a tap (the game never hears it)', async () => {
    const page = await fx.open('screen=inspect');
    const { open, box } = await touch(page, 100, 260, 500);
    expect(open).toBe(1);
    expect(box!.y + box!.height).toBeLessThan(260); // above the finger
    expect(await page.locator('[data-gp=plate]').count()).toBe(0); // gone with the lift
    const log = await metaLog(page);
    expect(log.filter((l) => l.startsWith('tap:') || l.startsWith('game-'))).toEqual([]);
    await page.close();
  });

  it("a short tap is the game's (onTap and its own listeners); the first one on a thing hints 'Hold to read' once", async () => {
    const page = await fx.open('screen=inspect');
    const short = await touch(page, 100, 260, 60);
    expect(short.open).toBe(0);
    const log = await metaLog(page);
    expect(log).toContain('tap:70,60');
    expect(log).toContain('game-up');
    await page.waitForSelector('[data-gp=hint][data-hint=gp-inspect-hold]');
    expect(await page.innerText('[data-gp=hint]')).toBe('Hold to read');
    // Holding (learning it) takes the hint away
    await touch(page, 100, 260, 500);
    expect(await page.evaluate(() => (window as unknown as { __meta: { tips: { seen(id: string): boolean } } }).__meta.tips.seen('gp-inspect-hold'))).toBe(true);
    await page.close();
  });

  it('a finger that moves is a drag: no plate; nothing there: no plate; the plate stays inside the screen', async () => {
    const page = await fx.open('screen=inspect');
    expect((await touch(page, 100, 260, 500, 30, 0)).open).toBe(0);
    expect((await touch(page, 250, 300, 500)).open).toBe(0);
    const edge = await touch(page, 33, 470, 500);
    expect(edge.open).toBe(1);
    expect(edge.box!.x).toBeGreaterThanOrEqual(8);
    expect(edge.box!.x + edge.box!.width).toBeLessThanOrEqual(SIZES[0].width - 8);
    await page.close();
  });

  it('a mouse: the plate after a rest, gone when it moves off the thing', async () => {
    const page = await fx.open('screen=inspect', SIZES[1]);
    await page.mouse.move(100, 260);
    await page.mouse.move(101, 261);
    await page.waitForSelector('[data-gp=plate]', { timeout: 2000 });
    expect(await page.innerText('[data-gp=plate] b')).toBe('Ember bone');
    expect(await page.getAttribute('[data-gp=plate]', 'data-kind')).toBe('rare');
    await page.mouse.move(250, 300);
    expect(await page.locator('[data-gp=plate]').count()).toBe(0);
    await page.close();
  });
});

describe('coachHand', () => {
  const hand = (page: Page) =>
    page.evaluate(() => {
      const l = document.getElementById('gp-coach');
      const line = l?.querySelector('line');
      return {
        on: !!l && !l.hidden,
        pe: l ? getComputedStyle(l).pointerEvents : '',
        drawn: !!l?.querySelector('svg[data-mark=hand]'),
        anims: document.getAnimations().length,
        still: l?.dataset.still !== undefined,
        line: line ? [line.getAttribute('x1'), line.getAttribute('y1'), line.getAttribute('x2'), line.getAttribute('y2')].map(Number) : null,
      };
    });

  it('shows a drag between two elements: a drawn hand on a path, moving, no pointer events', async () => {
    const page = await fx.open('screen=coach&gesture=drag');
    const h = await hand(page);
    expect(h).toMatchObject({ on: true, pe: 'none', drawn: true, still: false });
    expect(h.anims).toBeGreaterThan(0);
    expect(h.line).toEqual([70, 590, 270, 670]); // the centres of #a and #b
    const t0 = await page.evaluate(() => getComputedStyle(document.querySelector('#gp-coach .gp-ch-hand')!).transform);
    await page.waitForTimeout(700);
    const t1 = await page.evaluate(() => getComputedStyle(document.querySelector('#gp-coach .gp-ch-hand')!).transform);
    expect(t1).not.toBe(t0);
    await page.close();
  });

  it('with reduced motion: a still hand at the start and the arrow to the end, no animation', async () => {
    const page = await fx.open('screen=coach&gesture=swipe', SIZES[0], { reducedMotion: 'reduce' });
    const h = await hand(page);
    expect(h).toMatchObject({ on: true, still: true, anims: 0 });
    expect(await page.locator('#gp-coach polygon').count()).toBe(1);
    await page.close();
  });

  it("comes and goes with its hint (hints' hand), hidden behind a modal", async () => {
    const page = await fx.open('screen=coach&gesture=tap&via=hints');
    await page.waitForSelector('#gp-coach:not([hidden])');
    expect(await page.innerText('[data-gp=hint]')).toBe('Drag onto its twin');
    await page.evaluate(() => {
      const d = document.createElement('div');
      d.setAttribute('aria-modal', 'true');
      d.id = 'modal';
      d.style.cssText = 'position:fixed;inset:20px;background:#000';
      document.body.append(d);
    });
    await page.waitForSelector('#gp-coach[hidden]', { state: 'attached', timeout: 2000 });
    await page.evaluate(() => document.getElementById('modal')!.remove());
    await page.waitForSelector('#gp-coach:not([hidden])', { timeout: 2000 });
    await page.evaluate(() => (window as unknown as { __meta: { tips: { done(id: string): void } } }).__meta.tips.done('merge'));
    expect(await page.locator('#gp-coach').count()).toBe(0);
    await page.close();
  });
});

describe('cards (one card at a time)', () => {
  const modals = (page: Page) => page.evaluate(() => [...document.querySelectorAll('[aria-modal=true]')].filter((e) => e.getBoundingClientRect().width > 0).map((e) => e.id));

  it('the welcome card first (priority), then the week, then the goals — never two at once; a card with nothing is skipped', async () => {
    const page = await fx.open('screen=cards');
    expect(await modals(page)).toEqual(['gp-welcome']);
    expect(await page.evaluate(() => (window as unknown as { __meta: { cards: { current: string; waiting: string[] } } }).__meta.cards.waiting)).toEqual(['nothing', 'streak', 'goals']);
    await page.tap('[data-gp=welcome-close]');
    await page.waitForSelector('#gp-streak');
    expect(await modals(page)).toEqual(['gp-streak']);
    await page.tap('[data-gp=streak-claim]');
    await page.tap('[data-gp=streak-close]');
    await page.waitForSelector('#gp-goals');
    expect(await modals(page)).toEqual(['gp-goals']);
    const screens = (await metaLog(page)).filter((l) => l.startsWith('screen:'));
    expect(screens).toEqual(['screen:welcome', 'screen:streak', 'screen:goals']);
    await page.close();
  });

  it('held (a run is on): nothing more opens until it is let go', async () => {
    const page = await fx.open('screen=cards');
    await page.evaluate(() => (window as unknown as { __meta: { cards: { hold(on: boolean): void } } }).__meta.cards.hold(true));
    await page.tap('[data-gp=welcome-close]');
    await page.waitForTimeout(700);
    expect(await modals(page)).toEqual([]);
    await page.evaluate(() => (window as unknown as { __meta: { cards: { hold(on: boolean): void } } }).__meta.cards.hold(false));
    await page.waitForSelector('#gp-streak', { timeout: 2000 });
    await page.close();
  });
});
