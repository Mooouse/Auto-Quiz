// createSfx on real WebAudio (an OfflineAudioContext the test reads sample by sample): every recipe sounds and rings
// out, a burst of stacked booms never clips (the effects' limiter), a file decodes from a data: URL with its rate as its
// pitch, and a sound to the listener's right is in the right channel. Runs with `npm run test:browser`.

import { fileURLToPath } from 'node:url';
import { chromium, type Browser, type Page } from 'playwright';
import { createServer, type ViteDevServer } from 'vite';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

let server: ViteDevServer;
let browser: Browser;
let page: Page;

beforeAll(async () => {
  server = await createServer({ root: fileURLToPath(new URL('./sfx-fixture', import.meta.url)), configFile: false, logLevel: 'error', server: { port: 0 } });
  await server.listen();
  browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  page = await browser.newPage();
  await page.goto(server.resolvedUrls!.local[0]);
  await page.waitForFunction(() => '__sfx' in window);
}, 60000);

afterAll(async () => {
  await browser?.close();
  await server?.close();
});

type Stats = { peak: number; lastLoud: number; zcPerSec: number; balance: number };
const call = <T>(fn: string, arg?: number) => page.evaluate(([f, a]) => (window as unknown as { __sfx: Record<string, (x?: number) => Promise<unknown>> }).__sfx[f as string](a as number | undefined), [fn, arg] as const) as Promise<T>;

describe('createSfx on real WebAudio', () => {
  it('every recipe and material is heard, stays under −3 dBFS and rings out within 2 s', { timeout: 30000 }, async () => {
    const r = await call<Record<string, { peak: number; lastLoud: number }>>('recipes');
    for (const [k, v] of Object.entries(r)) {
      expect(v.peak, `${k} audible`).toBeGreaterThan(0.01);
      expect(v.peak, `${k} not too loud`).toBeLessThan(0.71);
      expect(v.lastLoud, `${k} rings out`).toBeLessThan(2);
    }
    expect(Object.keys(r)).toHaveLength(15);
  });
  it('a burst of stacked booms is limited: no sample reaches 0.99', { timeout: 30000 }, async () => {
    const b = await call<Stats>('burst');
    expect(b.peak).toBeGreaterThan(0.3);
    expect(b.peak).toBeLessThan(0.99);
  });
  it('a file decodes from a data: URL; its rate is its pitch', { timeout: 30000 }, async () => {
    const one = await call<Stats>('file', 1);
    const two = await call<Stats>('file', 2);
    expect(one.peak).toBeGreaterThan(0.2);
    expect(one.zcPerSec).toBeGreaterThan(800);
    expect(one.zcPerSec).toBeLessThan(960);
    expect(two.zcPerSec / one.zcPerSec).toBeCloseTo(2, 1);
    // Twice as fast: over in half the time
    expect(two.lastLoud).toBeLessThan(one.lastLoud * 0.6);
  });
  it('a sound to the listener\'s right plays mostly in the right channel', { timeout: 30000 }, async () => {
    const p = await call<Stats>('pan');
    expect(p.balance).toBeGreaterThan(4);
  });
});
