// What Playgama's QA Tool sees. Its recorder films and screenshots the page's FIRST <canvas> (Bridge 2.3:
// document.querySelector('canvas')), not the page: a game whose menus, result screen and ad buttons are DOM (#ui) is
// filmed without them. Candle Crypt's "×2 gems" result screen and its "Ad not finished — no reward" were invisible to
// it; it saw the dungeon before the ad and the dungeon after, and reported "Reward was granted despite the ad being
// closed before completion" (2026-10-10).
//
// So once the QA Tool asks for a recording or a screenshot, the portal puts a mirror canvas first in the document. Each
// frame it copies every visible canvas of the page and paints the DOM over them in document order: boxes, borders,
// text, images. A sketch, not the browser's render (no z-index, gradients, shadows, clipping or pseudo-elements), but
// every screen, button and message is there. Nothing runs for players: only a recorder message installs it.

/** The recorder actions of the Bridge's QA Tool channel ({ type: 'recorder', action }) */
const RECORDER_ACTIONS = new Set(['start_capture', 'take_screenshot']);
/** At most this many mirror frames a second (the recorder films 30) */
const MIRROR_FPS = 30;

export const RECORDER_MIRROR_ID = 'gp-recorder';

/**
 * Installs the mirror on the first recorder message from the QA Tool. Registered in the capture phase, so it runs
 * before the Bridge's own listener and the Bridge's querySelector('canvas') already finds the mirror. Returns the
 * unsubscribe.
 */
export function watchRecorder(win: Window | undefined = typeof window === 'undefined' ? undefined : window): () => void {
  if (!win?.addEventListener) return () => {};
  const onMessage = (e: MessageEvent) => {
    const m = e.data as { type?: unknown; action?: unknown } | null;
    if (!m || typeof m !== 'object' || m.type !== 'recorder' || !RECORDER_ACTIONS.has(String(m.action))) return;
    installRecorderMirror(win.document);
  };
  win.addEventListener('message', onMessage, { capture: true });
  return () => win.removeEventListener('message', onMessage, { capture: true });
}

/** The mirror canvas, first in the document and drawn every frame from then on (idempotent) */
export function installRecorderMirror(doc: Document = document): HTMLCanvasElement {
  const existing = doc.getElementById(RECORDER_MIRROR_ID);
  if (existing instanceof HTMLCanvasElement) return existing;
  const mirror = doc.createElement('canvas');
  mirror.id = RECORDER_MIRROR_ID;
  mirror.setAttribute('aria-hidden', 'true');
  // In the layout (a canvas out of it may give the recorder no frames), under everything, never tapped
  mirror.style.cssText = 'position:fixed;left:0;top:0;width:100%;height:100%;opacity:0;pointer-events:none;z-index:-2147483647';
  doc.body.prepend(mirror);
  const ctx = mirror.getContext('2d');
  if (!ctx) return mirror;
  const win = doc.defaultView ?? window;
  let last = 0;
  const frame = (t: number) => {
    win.requestAnimationFrame(frame);
    if (t - last < 1000 / MIRROR_FPS - 2 || doc.hidden) return;
    last = t;
    try {
      drawPage(ctx, mirror, doc);
    } catch (e) {
      console.warn('[gp] recorder mirror', e);
    }
  };
  // Drawn once now: a screenshot asked for right away gets the page, not a blank canvas
  drawPage(ctx, mirror, doc);
  win.requestAnimationFrame(frame);
  return mirror;
}

/** The page as the player sees it, sketched onto the mirror */
export function drawPage(ctx: CanvasRenderingContext2D, mirror: HTMLCanvasElement, doc: Document): void {
  const win = doc.defaultView ?? window;
  const w = Math.max(1, Math.round(win.innerWidth));
  const h = Math.max(1, Math.round(win.innerHeight));
  if (mirror.width !== w || mirror.height !== h) {
    mirror.width = w;
    mirror.height = h;
  }
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.globalAlpha = 1;
  ctx.fillStyle = paint(win.getComputedStyle(doc.body).backgroundColor) ?? paint(win.getComputedStyle(doc.documentElement).backgroundColor) ?? '#000';
  ctx.fillRect(0, 0, w, h);
  walk(ctx, doc.body, 1, mirror, w, h);
}

function walk(ctx: CanvasRenderingContext2D, el: Element, parentAlpha: number, mirror: HTMLCanvasElement, vw: number, vh: number): void {
  for (const node of el.childNodes) {
    if (node.nodeType === 3) {
      drawText(ctx, node as Text, el, parentAlpha, vw, vh);
      continue;
    }
    if (node.nodeType !== 1 || node === mirror) continue;
    const child = node as Element;
    const tag = child.tagName;
    if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'TEMPLATE' || tag === 'NOSCRIPT') continue;
    const cs = getComputedStyle(child);
    if (cs.display === 'none') continue;
    const alpha = parentAlpha * (Number(cs.opacity) || 0);
    if (alpha <= 0.01) continue;
    const visible = cs.visibility === 'visible';
    const r = child.getBoundingClientRect();
    const onScreen = r.width > 0 && r.height > 0 && r.right > 0 && r.bottom > 0 && r.left < vw && r.top < vh;
    if (visible && onScreen) {
      ctx.globalAlpha = alpha;
      if (tag === 'CANVAS') drawImageEl(ctx, child as HTMLCanvasElement, r);
      else if (tag === 'IMG') drawImageEl(ctx, child as HTMLImageElement, r);
      else drawBox(ctx, cs, r);
    }
    if (tag !== 'CANVAS' && tag !== 'IMG' && tag !== 'svg') walk(ctx, child, alpha, mirror, vw, vh);
  }
}

function drawImageEl(ctx: CanvasRenderingContext2D, el: HTMLCanvasElement | HTMLImageElement, r: DOMRect): void {
  if (el instanceof HTMLImageElement) {
    if (!el.complete || !el.naturalWidth) return;
    // An image from another origin would taint the mirror: the recorder's toDataURL would throw
    const src = el.currentSrc || el.src;
    if (!src.startsWith('data:') && !src.startsWith('blob:') && new URL(src, location.href).origin !== location.origin) return;
  } else if (!el.width || !el.height) return;
  try {
    ctx.drawImage(el, r.left, r.top, r.width, r.height);
  } catch {
    // a canvas that can't be read (a lost WebGL context): skip it this frame
  }
}

function drawBox(ctx: CanvasRenderingContext2D, cs: CSSStyleDeclaration, r: DOMRect): void {
  // A gradient's first colour stands for the gradient
  const fill = paint(cs.backgroundColor) ?? (cs.backgroundImage.includes('gradient') ? paint(cs.backgroundImage.match(/rgba?\([^)]*\)|#[0-9a-f]{3,8}/i)?.[0] ?? '') : null);
  const bw = parseFloat(cs.borderTopWidth) || 0;
  const border = bw > 0 && cs.borderTopStyle !== 'none' ? paint(cs.borderTopColor) : null;
  if (!fill && !border) return;
  const radius = Math.min(parseFloat(cs.borderTopLeftRadius) || 0, r.width / 2, r.height / 2);
  ctx.beginPath();
  if (radius > 0) ctx.roundRect(r.left, r.top, r.width, r.height, radius);
  else ctx.rect(r.left, r.top, r.width, r.height);
  if (fill) {
    ctx.fillStyle = fill;
    ctx.fill();
  }
  if (border) {
    ctx.beginPath();
    if (radius > 0) ctx.roundRect(r.left + bw / 2, r.top + bw / 2, r.width - bw, r.height - bw, Math.max(0, radius - bw / 2));
    else ctx.rect(r.left + bw / 2, r.top + bw / 2, r.width - bw, r.height - bw);
    ctx.lineWidth = bw;
    ctx.strokeStyle = border;
    ctx.stroke();
  }
}

function drawText(ctx: CanvasRenderingContext2D, node: Text, parent: Element, alpha: number, vw: number, vh: number): void {
  const raw = node.data;
  if (!raw.trim()) return;
  const cs = getComputedStyle(parent);
  if (cs.visibility !== 'visible' || alpha <= 0.01) return;
  const color = paint(cs.color);
  if (!color) return;
  const range = document.createRange();
  range.selectNodeContents(node);
  const rects = [...range.getClientRects()].filter((q) => q.width > 0 && q.height > 0 && q.right > 0 && q.bottom > 0 && q.left < vw && q.top < vh);
  range.detach();
  if (!rects.length) return;
  let text = raw.replace(/\s+/g, ' ').trim();
  if (cs.textTransform === 'uppercase') text = text.toUpperCase();
  else if (cs.textTransform === 'lowercase') text = text.toLowerCase();
  ctx.globalAlpha = alpha;
  ctx.fillStyle = color;
  ctx.font = `${cs.fontStyle} ${cs.fontWeight} ${cs.fontSize} ${cs.fontFamily}`;
  ctx.letterSpacing = cs.letterSpacing === 'normal' ? '0px' : cs.letterSpacing;
  ctx.textAlign = 'left';
  ctx.textBaseline = 'middle';
  if (rects.length === 1) {
    const q = rects[0]!;
    ctx.fillText(text, q.left, q.top + q.height / 2, q.width + 2);
    return;
  }
  // A wrapped text node: one rect per line; fill the lines word by word as the browser did
  const words = text.split(' ');
  let i = 0;
  for (const q of rects) {
    let line = '';
    while (i < words.length) {
      const next = line ? `${line} ${words[i]}` : words[i]!;
      if (line && ctx.measureText(next).width > q.width + 2) break;
      line = next;
      i++;
    }
    if (line) ctx.fillText(line, q.left, q.top + q.height / 2, q.width + 2);
  }
}

/** A CSS colour worth painting (not transparent), or null */
function paint(c: string): string | null {
  if (!c || c === 'transparent') return null;
  const m = c.match(/^rgba\(([^)]*)\)$/);
  if (m) {
    const a = Number(m[1]!.split(',')[3]);
    if (!(a > 0.01)) return null;
  }
  return c;
}
