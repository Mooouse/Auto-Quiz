// Phaser 4 through the engine contract: one Phaser.Game on #game, Phaser's own loop (TimeStep) put to sleep and woken
// by the adapter. Use Phaser where the game needs its physics, particles, tweens and scenes: it is the heaviest engine
// (engine lab: 362 KB gzipped, ≈ 3.3 s to a tappable Play on a slow phone, 8× Canvas 2D).
//
//   import Phaser from 'phaser';
//   class Play extends Phaser.Scene { create() { … } }
//   const eng = phaserAdapter(host, canvas, Phaser, { scene: Play, physics: { default: 'arcade', arcade: { fps: 60 } } });
//   await eng.ready;                       // the scenes active at boot have run create()
//   eng.onStep((dt) => …);                 // Arcade's fixed step (WORLD_STEP; without Arcade: the adapter's `step`)
//   this.physics.add.overlap(a, b, eng.guard(onHit));   // no callbacks after a hit ended the run
//   eng.sound()?.play('hit');              // Phaser's sound manager on the host's AudioContext, or eng.audio.play(buffer)
//   eng.setRunning(true);
//
// What it does for you (each one found in Phaser's sources by the engine lab, games/lab-phaser/NOTES.md):
// - starts stopped: Game#start always starts the loop after the scenes' create(): the adapter sleeps it before its first
//   frame, and a create() that throws rejects instead of leaving the game half-booted;
// - Phaser never pauses, resumes or resizes itself: its HIDDEN/VISIBLE/BLUR/FOCUS handlers removed, window.onblur /
//   onfocus put back, the Scale Manager's window listeners stopped, no autoFocus, the canvas's CSS left to the platform
//   (game size = CSS × DPR, every scene's main camera zoomed by the DPR: the world is in CSS px);
// - stops inside a step: Arcade's catch-up loop emptied (its private World._elapsed), scenes paused, the loop asleep;
// - resumes without a jump: loop.resetDelta() before wake(), fps.panicMax 0 (else 4 s at half speed after every resume at
//   30 fps), every scene's tween clock (Date.now) moved past the time it stood still;
// - audio: noAudio at boot (Phaser would make its own AudioContext), sound() makes a WebAudioSoundManager on the host's
//   context wired into host.audio.out once the context runs, with its per-frame resume and its unlock listeners off;
// - host.rng seeds Phaser's RND; Phaser's {min, max} ranges, GetRandom, Between… call Math.random with no hook: a dev
//   build warns once when Math.random runs during play (use functions: `speed: () => host.rng.range(40, 160)`,
//   `frame: '__BASE'` on an emitter of a single-frame texture);
// - no MSAA (12–15 fps on software WebGL), WebGL when a probe gets a context (Phaser.AUTO can't take a canvas), else
//   Phaser's Canvas renderer; a context loss is Phaser's to rebuild, the adapter redraws after it.

import type { GameHost } from '../host';
import { createDriver, devWarn, windowSize, type DriverImpl, type Engine, type EngineOptions, type EngineSize } from './driver';

export type { Engine, EngineAudio, EngineOptions, EngineSize } from './driver';

type Fn = (...args: never[]) => unknown;
interface Emitter {
  on(event: string, fn: Fn, ctx?: unknown): unknown;
  once(event: string, fn: Fn, ctx?: unknown): unknown;
  removeAllListeners(event?: string): unknown;
}
/** What the adapter touches inside a Phaser.Scene (structural: @gp/core doesn't depend on phaser) */
interface SceneInternals {
  sys: { pause(): unknown; resume(): unknown; isActive(): boolean; settings: { status: number; active?: boolean }; events: Emitter };
  cameras?: { main?: { setOrigin(x: number, y: number): unknown; setZoom(z: number): unknown } };
  tweens?: { prevTime: number; startTime: number };
  physics?: { world?: Emitter & { _elapsed?: number } };
}
/** What the adapter touches inside a Phaser.Game */
interface GameInternals {
  events: Emitter;
  loop: { sleep(): unknown; wake(seamless?: boolean): unknown; resetDelta(): unknown };
  scale: { stopListeners(): unknown; resize(width: number, height: number): unknown };
  renderer: { preRender(): unknown; postRender(): unknown } | null;
  scene: { scenes: SceneInternals[]; render(renderer: unknown): unknown };
  config: { audio: { context?: AudioContext } };
}
interface SoundManagerInternals {
  masterVolumeNode: AudioNode;
  pauseOnBlur: boolean;
  gameLostFocus: boolean;
}

/** The parts of the `phaser` module the adapter uses: pass the module itself (`import Phaser from 'phaser'`) */
export interface PhaserModule<G, SM> {
  Game: new (...config: never[]) => G;
  WEBGL: number;
  CANVAS: number;
  Scale: { NONE: number };
  Core: { Events: { HIDDEN: string; VISIBLE: string; BLUR: string; FOCUS: string; PRE_STEP: string; STEP: string; PRE_RENDER: string; POST_RENDER: string } };
  Physics: { Arcade: { Events: { WORLD_STEP: string } } };
  Sound: { WebAudioSoundManager: new (game: G) => SM };
}

export interface PhaserOptions extends EngineOptions {
  /** The game's scene class(es); the first is started at boot, as in Phaser's own config */
  scene: SceneClass | SceneClass[];
  /** Phaser's physics config, e.g. `{ default: 'arcade', arcade: { fps: 60 } }` (default: none) */
  physics?: Record<string, unknown>;
  /** The clear colour (a CSS colour) */
  background?: string;
  /** 'canvas' forces Phaser's Canvas renderer (default: WebGL where a probe gets a context) */
  renderer?: 'auto' | 'canvas';
  /**
   * More Phaser GameConfig (input, render, pixelArt…): the adapter's own keys win (canvas, parent, scale, audio,
   * fps.panicMax, autoFocus, banner; callbacks.postBoot runs before the adapter's). Input is off by default (MoveInput, DOM)
   */
  config?: Record<string, unknown>;
}

// A Phaser.Scene subclass (its constructor takes Phaser's scene config)
type SceneClass = abstract new (...args: never[]) => object;

export interface PhaserEngine<G, SM> extends Engine {
  readonly game: G;
  /** Resolves once the scenes active at boot have run create() (renderOnce draws them then); rejects if one threw */
  readonly ready: Promise<void>;
  /** WebGL or Canvas, as Phaser runs */
  readonly renderType: 'webgl' | 'canvas';
  /**
   * Phaser's WebAudioSoundManager on the host's AudioContext, its output into host.audio.out; null while sound can't
   * start (before the first tap, an ad, a hidden tab). Add buffers to a scene's `cache.audio`, then `sound()?.play(key)`
   */
  sound(): SM | null;
}

/** Phaser.AUTO can't be given our canvas ("Must set explicit renderType"): probe WebGL as Phaser does */
function webglAvailable(): boolean {
  try {
    const gl = document.createElement('canvas').getContext('webgl');
    gl?.getExtension('WEBGL_lose_context')?.loseContext();
    return !!gl;
  } catch {
    return false;
  }
}

/**
 * Phaser on #game, created stopped. Returns at once (the scenes' create() runs during boot and may use the engine:
 * onStep, guard, sound); `ready` resolves once the scenes active at boot have run create() and rejects if one threw.
 * Throws a readable Error when Phaser can't start (the player shows "can't run")
 */
export function phaserAdapter<G, SM>(host: GameHost, canvas: HTMLCanvasElement, Phaser: PhaserModule<G, SM>, opts: PhaserOptions): PhaserEngine<G, SM> {
  const P = Phaser;
  const E = P.Core.Events;
  const s0 = windowSize(opts.dprMax ?? 2, opts.renderScale ?? 1);
  let fail: (e: unknown) => void = () => {};
  let booted: () => void = () => {};
  const boot = new Promise<void>((res, rej) => {
    booted = res;
    fail = rej;
  });
  // A create() that throws (Phaser calls it from its boot callback and doesn't catch): reject, don't run half a game
  const guardScene = (Cls: SceneClass): SceneClass => {
    const C = Cls as unknown as new (...a: unknown[]) => { create?(...a: unknown[]): unknown };
    return class extends C {
      create(...a: unknown[]): unknown {
        try {
          return super.create?.(...a);
        } catch (e) {
          fail(e);
          return undefined;
        }
      }
    } as unknown as SceneClass;
  };
  const scenes = [opts.scene].flat().map(guardScene);
  const renderType: 'webgl' | 'canvas' = opts.renderer !== 'canvas' && webglAvailable() ? 'webgl' : 'canvas';
  const prevBlur = window.onblur;
  const prevFocus = window.onfocus;
  const user = opts.config ?? {};
  const userCallbacks = (user.callbacks ?? {}) as { preBoot?: (g: G) => void; postBoot?: (g: G) => void };
  const config = {
    seed: [String(host.rng.random())],
    input: { keyboard: false, mouse: false, touch: false, gamepad: false },
    // MSAA off: 12–15 fps on software WebGL with it, 52–60 without
    render: { antialiasGL: false },
    ...(opts.physics ? { physics: opts.physics } : {}),
    ...(opts.background !== undefined ? { backgroundColor: opts.background } : {}),
    ...user,
    type: renderType === 'webgl' ? P.WEBGL : P.CANVAS,
    canvas,
    parent: null,
    // The game size is the drawing buffer; the platform's CSS sizes the canvas (Scale Manager zoom wrote stale inline sizes)
    scale: { mode: P.Scale.NONE, width: Math.round(s0.width * s0.dpr), height: Math.round(s0.height * s0.dpr) },
    banner: false,
    autoFocus: false,
    // Phaser would make its own AudioContext at boot (the host has none before the first tap) and unlock listeners
    audio: { noAudio: true },
    // No 120-frame clamp to 1/60 s after every start and resume (half speed for 4 s at 30 fps)
    fps: { ...(user.fps as object | undefined), panicMax: 0 },
    scene: scenes,
    callbacks: {
      ...userCallbacks,
      postBoot(g: G) {
        userCallbacks.postBoot?.(g);
        // Game#start runs postBoot, then starts the loop and the visibility handler: undo both right after, before the
        // loop's first frame (a rAF away)
        queueMicrotask(afterStart);
      },
    },
  };

  let game: G;
  try {
    game = new P.Game(config as never);
  } catch (e) {
    throw new Error(`Phaser could not start (${e instanceof Error ? e.message : String(e)})`);
  }
  const g = game as unknown as GameInternals;
  let sound: SM | null = null;
  const paused: SceneInternals[] = [];
  const silence = () => {
    for (const ev of [E.HIDDEN, E.VISIBLE, E.BLUR, E.FOCUS]) g.events.removeAllListeners(ev);
  };
  const worlds = () => g.scene.scenes.map((s) => s.physics?.world).filter((w): w is NonNullable<typeof w> => !!w);
  const cameras = (s: EngineSize) => {
    for (const sc of g.scene.scenes) {
      const cam = sc.cameras?.main;
      if (!cam) continue;
      cam.setOrigin(0, 0);
      cam.setZoom(s.dpr);
    }
  };

  let started = false;
  /** The fixed-step accumulator when no scene has Arcade physics */
  let acc = 0;
  let inFrame = false;
  let randomCalls = 0;
  const realRandom = Math.random;

  let part!: DriverImpl;
  const d = createDriver(host, canvas, opts, () => (part = {
    start() {
      // Before boot (setRunning(true) before `ready`): afterStart starts it
      if (!started) return;
      // The tween clock is Date.now: skip the time we stood still
      const now = Date.now();
      for (const sc of g.scene.scenes) {
        const tm = sc.tweens;
        if (!tm || typeof tm.prevTime !== 'number') continue;
        const gap = now - tm.prevTime;
        tm.prevTime += gap;
        tm.startTime += gap;
      }
      for (const sc of paused.splice(0)) sc.sys.resume();
      // Without resetDelta the first frame after wake() gets the whole pause as its delta
      g.loop.resetDelta();
      acc = 0;
      g.loop.wake();
    },
    stop() {
      if (!started) return;
      for (const sc of g.scene.scenes)
        if (sc.sys.isActive()) {
          sc.sys.pause();
          paused.push(sc);
        }
      g.loop.sleep();
      // Called from inside an Arcade step (a hit ends the run): its catch-up loop would go on stepping this frame
      for (const w of worlds()) if (typeof w._elapsed === 'number') w._elapsed = 0;
      inFrame = false;
    },
    canRender: () => started,
    render() {
      const r = g.renderer;
      if (!r) return;
      r.preRender();
      g.scene.render(r);
      r.postRender();
    },
    resize(s) {
      // Before boot (the driver's first call): the config has the size
      if (!started) return;
      g.scale.resize(Math.round(s.width * s.dpr), Math.round(s.height * s.dpr));
      cameras(s);
    },
    webgl: renderType === 'webgl',
    destroy() {
      if (import.meta.env.DEV) Math.random = realRandom;
    },
  }));

  function afterStart(): void {
    started = true;
    g.loop.sleep();
    silence();
    g.scale.stopListeners();
    window.onblur = prevBlur;
    window.onfocus = prevFocus;
    cameras(d.engine.size);
    // Standing still until a run starts
    for (const sc of g.scene.scenes)
      if (sc.sys.isActive()) {
        sc.sys.pause();
        paused.push(sc);
      }
    // The steps: Arcade's fixed step when a scene has Arcade physics, else one per frame
    const ws = worlds();
    if (ws.length) ws[0].on(P.Physics.Arcade.Events.WORLD_STEP, ((dt: number) => d.on && d.step(dt)) as Fn);
    else
      g.events.on(E.STEP, ((_t: number, delta: number) => {
        if (!d.on) return;
        const dt = Math.min(d.opts.maxDt, Math.max(0, delta / 1000));
        const step = d.opts.step;
        if (step <= 0) return d.step(dt);
        // The adapter's fixed step from Phaser's frame deltas (as the other adapters); a step may stop the run
        acc += dt;
        while (d.on && acc >= step) {
          acc -= step;
          d.step(step);
        }
      }) as Fn);
    g.events.on(E.PRE_STEP, (() => (inFrame = d.on)) as Fn);
    g.events.on(E.PRE_RENDER, (() => d.on && d.frame()) as Fn);
    g.events.on(E.POST_RENDER, (() => (inFrame = false)) as Fn);
    if (!ws.some((w) => typeof w._elapsed === 'number') && ws.length) devWarn('phaser-elapsed', "Phaser's Arcade World._elapsed is gone: setRunning(false) inside a step can't stop the frame's remaining steps (check @gp/core/engines/phaser after the upgrade)");
    if (import.meta.env.DEV)
      Math.random = function random() {
        if (inFrame && randomCalls++ === 0)
          devWarn('phaser-random', `Math.random ran during play: Phaser's {min, max} ranges, GetRandom and Between ignore host.rng (runs won't repeat with ?seed). Use functions with host.rng (\`speed: () => host.rng.range(40, 160)\`) and \`frame: '__BASE'\` on emitters. First call: ${new Error().stack?.split('\n').slice(2, 5).join(' ← ')}`);
        return realRandom();
      };
    // Scenes still loading their files create later: ready when every scene active at boot has run create()
    // (Phaser's scene status: PENDING 0 — not started; INIT 1 … CREATING 4 — started, not created yet; RUNNING 5)
    const pending = g.scene.scenes.filter((sc) => sc.sys.settings.status >= 1 && sc.sys.settings.status < 5);
    let left = pending.length;
    if (!left) booted();
    for (const sc of pending)
      sc.sys.events.once('create', (() => {
        if (--left === 0) booted();
      }) as Fn);
    // A run already on (setRunning(true) before boot ended): start now
    if (d.on) part.start();
  }

  return Object.assign(d.engine, {
      game,
      renderType,
      ready: boot,
      sound(): SM | null {
        const a = d.engine.audio.live();
        // Never on a suspended context: a manager made on one is "locked" and adds body listeners that resume() the
        // host's context on the next tap, paused or not
        if (!a) return null;
        if (sound) return sound;
        g.config.audio.context = a.ctx;
        sound = new P.Sound.WebAudioSoundManager(game);
        const sm = sound as unknown as SoundManagerInternals;
        sm.masterVolumeNode.disconnect();
        sm.masterVolumeNode.connect(a.out);
        // It suspends the context on blur and resumes it every frame it finds it suspended: the host owns the context
        sm.pauseOnBlur = false;
        sm.gameLostFocus = true;
        silence();
        return sound;
      },
    });
}
