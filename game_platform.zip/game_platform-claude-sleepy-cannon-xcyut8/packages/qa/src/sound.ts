// What `gp qa` hears (the code kit's sound section): pure measures over a session the meter recorded (audio-tap.ts
// audioMeter) and the sounds the probe saw start. Reviewers never heard our games and judged them flat; the owner heard
// a deafening start, a hiss under the music, the same hit a hundred times. QA can't judge taste, but it can measure:
//   - feedback: the share of the player's actions (taps, keys, UI clicks) answered by an effect within ANSWER_SEC, and of
//     the game's moments (a celebrated moment, a fail, the round's end);
//   - the balance: the effects' loudness against the music's and the ambience's (LUFS-ish: BS.1770's K-weighting and gating);
//   - clipping: samples at ≥ 0.99 in the mix (the one failure, with a silent game);
//   - long silences in play; the same sound exactly (pitch, length, level) many times in a row.

/** One row per render quantum: [frame, mix kss, peak, clipped, zc, sfx kss, peak, clipped, zc, bed kss, peak, clipped, zc] */
export type MeterRow = number[];

/** Samples per row (a render quantum) */
export const QUANTUM = 128;
/** An effect within this many seconds of an action answers it */
export const ANSWER_SEC = 0.15;
/** Under this share of a kind of action answered: a warning */
export const MIN_ANSWERED = 0.5;
/** The effects' loudness minus the music's (LU): under the low end they drown, over the high end the music is lost */
export const BALANCE_LU = { low: -3, high: 18 } as const;
/** Silence: a 100 ms stretch under this (LUFS-ish); this long in play is a warning */
export const SILENCE_LUFS = -60;
export const SILENCE_SEC = 5;
/** The same sound this many times in a row (no pitch, length or level change): a warning */
export const REPEAT_STREAK = 6;
/** More clipped samples than this in the mix fail */
export const CLIP_MAX = 10;
/** A session whose loudest quantum stays under this (dBFS) is silent: a failure */
export const SILENT_DBFS = -60;
/** The mix's loudness in play outside this range (LUFS-ish): a warning (portals play at the player's own volume) */
export const MIX_LUFS = { low: -34, high: -12 } as const;

export interface SoundSession {
  rate: number;
  rows: MeterRow[];
  /** The mixer's buses metered apart */
  buses: { sfx: boolean; bed: boolean };
  /** Each effect source's start, context seconds (sources not on the music or ambience bus) */
  effects: number[];
  /** The player's actions QA made, context seconds: taps on the game, keys, clicks on its UI */
  actions: { t: number; kind: 'tap' | 'key' | 'ui' }[];
  /** The game's moments (host events), context seconds */
  moments: { t: number; kind: string }[];
  /** Stretches of play (gameplay on, not paused), context seconds */
  play: [number, number][];
}

export interface Answered {
  n: number;
  hit: number;
}

export interface Fingerprint {
  t: number;
  /** The loudest quantum, dB */
  level: number;
  /** Until 30 dB under its peak, s */
  len: number;
  /** Zero crossings per sample around its peak (a pitch proxy) */
  zcr: number;
}

export interface SoundReport {
  /** Seconds of context time the meter heard */
  heardSec: number;
  peakDbfs: number | null;
  silent: boolean;
  clipped: { samples: number; firstSec: number | null };
  /** The mix's integrated loudness in play */
  mixLufs: number | null;
  /** The effects' and the beds' integrated loudness in play (null: not metered apart, or nothing there) */
  sfxLufs: number | null;
  bedLufs: number | null;
  answered: Record<'tap' | 'key' | 'ui', Answered>;
  moments: Record<string, Answered>;
  longestSilence: { sec: number; atSec: number | null };
  repeats: { streak: number; atSec: number | null; sound: Fingerprint | null };
  effects: number;
}

const dbOf = (ms: number) => (ms > 0 ? 10 * Math.log10(ms) : -Infinity);
/** LUFS from a mean square summed over the channels (BS.1770: −0.691 + 10 log10) */
const lufsOf = (z: number) => -0.691 + dbOf(z);
const round1 = (v: number) => Math.round(v * 10) / 10;

/** The rows inside the windows (context seconds) */
function inWindows(rows: MeterRow[], rate: number, windows: [number, number][]): MeterRow[] {
  return rows.filter((r) => windows.some(([a, b]) => r[0] / rate >= a && r[0] / rate < b));
}

/**
 * Integrated loudness of one input (0 mix, 1 effects, 2 beds) over the rows, BS.1770-style: 400 ms blocks every 100 ms,
 * an absolute gate at −70 and a relative one 10 LU under the gated mean. null: nothing above the gate
 */
export function integratedLufs(rows: MeterRow[], rate: number, input: 0 | 1 | 2): number | null {
  const per = Math.max(1, Math.round((0.1 * rate) / QUANTUM));
  const col = 1 + input * 4;
  // 100 ms sub-blocks of consecutive rows (a gap in the frames starts a new run)
  const subs: { e: number; n: number; frame: number }[] = [];
  for (let i = 0; i < rows.length; i += per) {
    const chunk = rows.slice(i, i + per);
    subs.push({ e: chunk.reduce((s, r) => s + r[col], 0), n: chunk.length * QUANTUM, frame: chunk[0][0] });
  }
  const blocks: number[] = [];
  for (let i = 0; i + 4 <= subs.length; i++) {
    const four = subs.slice(i, i + 4);
    // Contiguous only: four sub-blocks spanning ≈ 400 ms of the context's time
    if ((four[3].frame - four[0].frame) / rate > 0.45) continue;
    blocks.push(four.reduce((s, b) => s + b.e, 0) / four.reduce((s, b) => s + b.n, 0));
  }
  const abs = blocks.filter((z) => lufsOf(z) > -70);
  if (!abs.length) return null;
  const rel = lufsOf(abs.reduce((a, b) => a + b, 0) / abs.length) - 10;
  const gated = abs.filter((z) => lufsOf(z) > rel);
  return round1(lufsOf(gated.reduce((a, b) => a + b, 0) / gated.length));
}

/** The longest stretch of play under SILENCE_LUFS, in 100 ms steps */
export function longestSilence(rows: MeterRow[], rate: number, play: [number, number][]): { sec: number; atSec: number | null } {
  const per = Math.max(1, Math.round((0.1 * rate) / QUANTUM));
  let best = { sec: 0, atSec: null as number | null };
  for (const [a, b] of play) {
    const rs = rows.filter((r) => r[0] / rate >= a && r[0] / rate < b);
    let run = 0;
    let from: number | null = null;
    for (let i = 0; i < rs.length; i += per) {
      const chunk = rs.slice(i, i + per);
      const z = chunk.reduce((s, r) => s + r[1], 0) / (chunk.length * QUANTUM);
      const gap = i > 0 && (chunk[0][0] - rs[i - 1][0]) / rate > 0.05;
      if (lufsOf(z) < SILENCE_LUFS && !gap) {
        if (from === null) from = chunk[0][0] / rate;
        run += (chunk.length * QUANTUM) / rate;
        if (run > best.sec) best = { sec: round1(run), atSec: round1(from) };
      } else {
        run = 0;
        from = null;
      }
    }
  }
  return best;
}

/** How many of `at` have an effect starting within [t + lo, t + hi] */
export function answeredBy(at: number[], effects: number[], lo: number, hi: number): Answered {
  const sorted = [...effects].sort((a, b) => a - b);
  let hit = 0;
  for (const t of at) {
    // Binary search for the first effect ≥ t + lo
    let l = 0;
    let r = sorted.length;
    while (l < r) {
      const m = (l + r) >> 1;
      if (sorted[m] < t + lo) l = m + 1;
      else r = m;
    }
    if (l < sorted.length && sorted[l] <= t + hi) hit++;
  }
  return { n: at.length, hit };
}

/** Effect sources starting together (within 15 ms) are one sound */
export function soundEvents(effects: number[], gap = 0.015): number[] {
  const out: number[] = [];
  for (const t of [...effects].sort((a, b) => a - b)) if (!out.length || t - out[out.length - 1] > gap) out.push(t);
  return out;
}

/** Each sound's fingerprint from the meter (the effects bus when it is metered apart, else the mix) */
export function fingerprints(events: number[], rows: MeterRow[], rate: number, input: 0 | 1): Fingerprint[] {
  const col = 1 + input * 4;
  const frames = rows.map((r) => r[0]);
  const at = (f: number) => {
    let l = 0;
    let r = frames.length;
    while (l < r) {
      const m = (l + r) >> 1;
      if (frames[m] < f) l = m + 1;
      else r = m;
    }
    return l;
  };
  const out: Fingerprint[] = [];
  events.forEach((t, k) => {
    const end = Math.min(events[k + 1] ?? Infinity, t + 0.4);
    const i0 = at(t * rate - QUANTUM / 2);
    const i1 = at(end * rate);
    const rs = rows.slice(i0, Math.max(i0 + 1, i1));
    if (!rs.length) return;
    const peak = Math.max(...rs.map((r) => r[col]));
    if (peak <= 0) return;
    let last = 0;
    rs.forEach((r, i) => {
      if (r[col] >= peak * 1e-3) last = i;
    });
    let zc = 0;
    let n = 0;
    for (const r of rs)
      if (r[col] >= peak * 0.1) {
        zc += r[col + 3];
        n += QUANTUM;
      }
    out.push({ t, level: round1(dbOf(peak / QUANTUM)), len: ((last + 1) * QUANTUM) / rate, zcr: n ? zc / n : 0 });
  });
  return out;
}

const same = (a: Fingerprint, b: Fingerprint) => Math.abs(a.level - b.level) <= 0.5 && Math.abs(a.len - b.len) <= 0.006 && Math.abs(a.zcr - b.zcr) <= Math.max(1e-4, a.zcr * 0.015);
const alike = (a: Fingerprint, b: Fingerprint) => Math.abs(a.level - b.level) <= 6 && Math.abs(a.len - b.len) <= Math.max(0.02, a.len * 0.4) && Math.abs(a.zcr - b.zcr) <= Math.max(2e-3, a.zcr * 0.25);

/** The longest run of one sound played exactly alike, each to the one before it (sounds of other kinds may come between) */
export function exactRepeats(fps: Fingerprint[]): SoundReport['repeats'] {
  const groups: { last: Fingerprint; streak: number; from: number }[] = [];
  let best: SoundReport['repeats'] = { streak: fps.length ? 1 : 0, atSec: fps[0] ? round1(fps[0].t) : null, sound: fps[0] ?? null };
  for (const f of fps) {
    const g = groups.find((x) => alike(x.last, f));
    if (!g) {
      groups.push({ last: f, streak: 1, from: f.t });
      continue;
    }
    if (same(g.last, f)) g.streak++;
    else {
      g.streak = 1;
      g.from = f.t;
    }
    g.last = f;
    if (g.streak > best.streak) best = { streak: g.streak, atSec: round1(g.from), sound: f };
  }
  return best;
}

/** Everything the section reports, from one session */
export function analyzeSound(s: SoundSession): SoundReport {
  const { rate, rows } = s;
  const heardSec = rate && rows.length ? round1((rows.length * QUANTUM) / rate) : 0;
  const peak = rows.reduce((m, r) => Math.max(m, r[2]), 0);
  const clippedRows = rows.filter((r) => r[3] > 0);
  const play = inWindows(rows, rate, s.play);
  const kinds = ['tap', 'key', 'ui'] as const;
  const answered = Object.fromEntries(kinds.map((k) => [k, answeredBy(s.actions.filter((a) => a.kind === k).map((a) => a.t), s.effects, -0.01, ANSWER_SEC)])) as SoundReport['answered'];
  const moments: Record<string, Answered> = {};
  for (const kind of [...new Set(s.moments.map((m) => m.kind))])
    moments[kind] = answeredBy(s.moments.filter((m) => m.kind === kind).map((m) => m.t), s.effects, -ANSWER_SEC, ANSWER_SEC);
  const events = soundEvents(s.effects);
  return {
    heardSec,
    peakDbfs: peak > 0 ? round1(20 * Math.log10(peak)) : null,
    silent: !(peak > 10 ** (SILENT_DBFS / 20)),
    clipped: { samples: clippedRows.reduce((n, r) => n + r[3], 0), firstSec: clippedRows[0] ? round1(clippedRows[0][0] / rate) : null },
    mixLufs: integratedLufs(play, rate, 0),
    sfxLufs: s.buses.sfx ? integratedLufs(play, rate, 1) : null,
    bedLufs: s.buses.bed ? integratedLufs(play, rate, 2) : null,
    answered,
    moments,
    longestSilence: longestSilence(rows, rate, s.play),
    repeats: exactRepeats(fingerprints(events, rows, rate, s.buses.sfx ? 1 : 0)),
    effects: events.length,
  };
}

export interface SoundVerdict {
  /** Checks: fail only on clipping or a silent game */
  checks: { name: string; ok: boolean; details: string }[];
  warnings: { name: string; details: string }[];
  infos: { name: string; details: string }[];
}

const pct = (a: Answered) => (a.n ? `${a.hit}/${a.n} (${Math.round((100 * a.hit) / a.n)} %)` : 'none');

/** The report's lines: warnings first (what to fix), then the two checks, then the numbers */
export function soundVerdict(r: SoundReport, o: { musicDeclared?: boolean } = {}): SoundVerdict {
  const v: SoundVerdict = { checks: [], warnings: [], infos: [] };
  v.checks.push({
    name: 'sound: the game makes a sound (title, play, results)',
    ok: !r.silent,
    details: r.silent ? `nothing over ${SILENT_DBFS} dBFS in ${r.heardSec} s of the host's output — effects and music through host.audio.out (@gp/core/sound: createSfx, createMusic)` : `loudest ${r.peakDbfs} dBFS in ${r.heardSec} s`,
  });
  v.checks.push({
    name: `sound: no clipping (samples at ≥ 0.99 in the mix: at most ${CLIP_MAX})`,
    ok: r.clipped.samples <= CLIP_MAX,
    details: r.clipped.samples ? `${r.clipped.samples} clipped samples, first at ${r.clipped.firstSec} s${r.clipped.samples > CLIP_MAX ? ' — lower the effects (createSfx vol, SFX_MAX_VOICES), duck under big hits, cap the voices of a burst' : ''}` : 'none',
  });
  // Feedback: the game's main control (taps or keys, whichever it answers more), and the UI
  const main = (['tap', 'key'] as const).map((k) => ({ k, a: r.answered[k] })).filter((x) => x.a.n > 0);
  const share = (a: Answered) => (a.n ? a.hit / a.n : 1);
  const best = main.sort((x, y) => share(y.a) - share(x.a))[0];
  if (best && share(best.a) < MIN_ANSWERED)
    v.warnings.push({
      name: `sound: player actions answered by a sound within ${ANSWER_SEC * 1000} ms`,
      details: `taps ${pct(r.answered.tap)}, keys ${pct(r.answered.key)} — an action that makes no sound feels flat (reviewers' "simple and dull"): a short effect on every press, pick, hit and denied move (createSfx, sfxRecipe('click' | 'hit' | 'deny')); a steering game's moves may stay quiet, its hits and pickups not`,
    });
  if (r.answered.ui.n && share(r.answered.ui) < MIN_ANSWERED)
    v.warnings.push({ name: 'sound: button clicks answered by a sound', details: `${pct(r.answered.ui)} — a click on Play, Again or a menu button with no sound: sfx.play('click')` });
  for (const [kind, a] of Object.entries(r.moments))
    if (a.n && share(a) < MIN_ANSWERED)
      v.warnings.push({
        name: `sound: the game's "${kind}" moments come with a sound`,
        details: `${pct(a)} within ${ANSWER_SEC * 1000} ms — ${kind === 'highlight' ? 'a celebrated moment (host.happytime) needs its fanfare' : kind === 'fail' ? 'a loss needs its sound (soft, never harsh)' : kind === 'round:end' ? 'the results need their jingle or a land (ScoreSequencer)' : 'give it a sound'}`,
      });
  if (r.sfxLufs !== null && r.bedLufs !== null) {
    const d = round1(r.sfxLufs - r.bedLufs);
    if (d < BALANCE_LU.low) v.warnings.push({ name: 'sound: effects over the music', details: `effects ${r.sfxLufs} LUFS, music and ambience ${r.bedLufs} LUFS (${d} LU): the effects drown — raise them or lower the music (the mixer's defaults keep music ≈ 4 dB under)` });
    else if (d > BALANCE_LU.high) v.warnings.push({ name: 'sound: the music heard under the effects', details: `effects ${r.sfxLufs} LUFS, music and ambience ${r.bedLufs} LUFS (+${d} LU): the music is lost under them — lower the effects` });
    else v.infos.push({ name: 'sound: effects against the music', details: `effects ${r.sfxLufs} LUFS, music and ambience ${r.bedLufs} LUFS (${d >= 0 ? '+' : ''}${d} LU; between ${BALANCE_LU.low} and +${BALANCE_LU.high} is fine)` });
  } else
    v.infos.push({
      name: 'sound: effects against the music',
      details: r.sfxLufs === null && r.bedLufs === null ? 'not measured apart: the game plays without createMixer (or nothing played on its buses)' : `only ${r.bedLufs === null ? 'effects' : 'music'} played on the mixer's buses in play${o.musicDeclared === false ? ' (the game says it has no music)' : ''}`,
    });
  if (r.longestSilence.sec >= SILENCE_SEC)
    v.warnings.push({ name: `sound: no silence of ${SILENCE_SEC} s or more in play`, details: `${r.longestSilence.sec} s of silence from ${r.longestSilence.atSec} s — music or an ambience bed under the play (createMusic, createAmbience)` });
  if (r.repeats.streak >= REPEAT_STREAK)
    v.warnings.push({
      name: `sound: no sound repeats exactly ${REPEAT_STREAK} times in a row`,
      details: `one sound ${r.repeats.streak}× in a row from ${r.repeats.atSec} s with the same pitch, length and level (${r.repeats.sound?.level} dB, ${Math.round((r.repeats.sound?.len ?? 0) * 1000)} ms) — vary it: createSfx varies the pitch ±6 % by itself, a combo's rate climbs (ScoreSequencer's pitch)`,
    });
  if (r.mixLufs !== null && (r.mixLufs > MIX_LUFS.high || r.mixLufs < MIX_LUFS.low))
    v.warnings.push({ name: 'sound: the mix in play is neither too loud nor too quiet', details: `${r.mixLufs} LUFS (between ${MIX_LUFS.low} and ${MIX_LUFS.high})` });
  v.infos.push({
    name: 'sound: what QA heard',
    details: `${r.heardSec} s; in play ${r.mixLufs ?? '—'} LUFS, peak ${r.peakDbfs ?? '—'} dBFS; ${r.effects} effects; answered within ${ANSWER_SEC * 1000} ms: taps ${pct(r.answered.tap)}, keys ${pct(r.answered.key)}, buttons ${pct(r.answered.ui)}${Object.entries(r.moments).map(([k, a]) => `, ${k} ${pct(a)}`).join('')}; longest silence in play ${r.longestSilence.sec} s; longest exact repeat ${r.repeats.streak}×`,
  });
  return v;
}
