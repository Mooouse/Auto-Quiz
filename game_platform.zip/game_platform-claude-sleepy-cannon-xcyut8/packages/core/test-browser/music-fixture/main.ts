// Test page for the music's start (packages/core/test-browser/music-start.test.ts): a real AudioContext, a host like
// GameHost's (audio null until the first tap, or there but suspended), the music asked to play at load — before the
// player's first tap — and an analyser on the host's output to measure how loud it really is.
import { createMixer, createMusic, createSceneMusic, musicTheme } from '../../src/sound';

const q = new URLSearchParams(location.search);
const kind = q.get('kind') ?? 'scene';
// 'late': host.audio is null until the first tap (GameHost's way); 'suspended': the context is there but suspended
const when = q.get('when') ?? 'late';
const ctx = new AudioContext();
// A page's context before the player's first gesture is suspended (the autoplay policy): this one is too, whatever the
// test browser's own policy
await ctx.suspend();
const out = ctx.createGain();
const an = ctx.createAnalyser();
an.fftSize = 2048;
out.connect(an).connect(ctx.destination);
let tapped = when === 'suspended';
const pauseFns: (() => void)[] = [];
const resumeFns: (() => void)[] = [];
const host = {
  paused: false,
  portalMuted: false,
  get audio() {
    return tapped ? { ctx, out } : null;
  },
  onPause: (f: () => void) => pauseFns.push(f),
  onResume: (f: () => void) => resumeFns.push(f),
};
const mixer = createMixer(host);
const scene = kind === 'scene' ? createSceneMusic(mixer) : null;
const themes = kind === 'scene' ? null : createMusic(mixer, { act: musicTheme('heroic', 5) });
// Asked at load: the title's music, before any tap
if (scene) scene.scene('fight');
else themes!.play('act');

document.getElementById('tap')!.addEventListener('click', () => {
  tapped = true;
  void ctx.resume();
});

const buf = new Float32Array(an.fftSize);
const w = window as unknown as Record<string, unknown>;
/** The output's RMS over `sec` seconds of the context's clock */
w.__rms = (sec: number) =>
  new Promise<number>((resolve) => {
    let sum = 0;
    let n = 0;
    const t0 = ctx.currentTime;
    const id = setInterval(() => {
      an.getFloatTimeDomainData(buf);
      for (const v of buf) sum += v * v;
      n += buf.length;
      if (ctx.currentTime - t0 >= sec) {
        clearInterval(id);
        resolve(Math.sqrt(sum / Math.max(1, n)));
      }
    }, 40);
  });
w.__state = () => ctx.state;
/** The host's pause and resume, as GameHost does them: suspend the context, tell the listeners */
w.__pause = async () => {
  host.paused = true;
  await ctx.suspend();
  pauseFns.forEach((f) => f());
};
w.__resume = async () => {
  host.paused = false;
  await ctx.resume();
  resumeFns.forEach((f) => f());
};
