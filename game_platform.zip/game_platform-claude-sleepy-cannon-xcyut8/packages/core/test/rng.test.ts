import { describe, expect, it } from 'vitest';
import { Bag, rng, seedRandom, seededRng } from '../src/rng.ts';
import { RunChoices } from '../src/progression.ts';

describe('rng', () => {
  it('a seed makes runs repeatable', () => {
    seedRandom(42);
    const a = [rng.random(), rng.random(), rng.int(10)];
    seedRandom(42);
    expect([rng.random(), rng.random(), rng.int(10)]).toEqual(a);
    seedRandom(null);
  });
});

describe('Bag', () => {
  it('every value once per refill, never twice in a row (also across refills)', () => {
    seedRandom(7);
    const bag = new Bag(5);
    const seq = Array.from({ length: 500 }, () => bag.next());
    for (let i = 0; i < 500; i += 5) expect([...seq.slice(i, i + 5)].sort()).toEqual([0, 1, 2, 3, 4]);
    for (let i = 1; i < seq.length; i++) expect(seq[i]).not.toBe(seq[i - 1]);
    seedRandom(null);
  });
});

describe('seededRng', () => {
  /** The mulberry32 eight games pasted (Echoflies bot.ts, Starsilk level.ts, Dread Throne bot.ts, Candle Crypt gen.ts …) */
  function pasted(seed: number): () => number {
    let a = seed >>> 0;
    return () => {
      a = (a + 0x6d2b79f5) >>> 0;
      let t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  it("gives the games' own sequence, so their pinned numbers stay", () => {
    for (const seed of [0, 1, 42, 20261001, 0xffffffff]) {
      const ours = seededRng(seed);
      const theirs = pasted(seed);
      for (let i = 0; i < 50; i++) expect(i % 2 ? ours() : ours.random()).toBe(theirs());
    }
  });

  it('range, int and pick draw from the same sequence', () => {
    const r = seededRng(9);
    const p = pasted(9);
    expect(r.range(2, 4)).toBe(2 + p() * 2);
    expect(r.int(10)).toBe((p() * 10) | 0);
    expect(r.pick(['a', 'b', 'c'])).toBe(['a', 'b', 'c'][(p() * 3) | 0]);
  });

  it("is independent of the run's rng and of other sources", () => {
    seedRandom(5);
    const before = [rng.random(), rng.random()];
    seedRandom(5);
    const a = seededRng(1);
    const b = seededRng(1);
    a();
    a();
    expect([rng.random(), rng.random()]).toEqual(before);
    expect(b()).toBe(pasted(1)());
    seedRandom(null);
  });

  it('the progression blocks take it as their Rand', () => {
    const choices = new RunChoices([{ id: 'a' }, { id: 'b' }, { id: 'c' }, { id: 'd' }], { size: 2 });
    const st = choices.start();
    expect(choices.draw(st, seededRng(3))).toEqual(choices.draw(st, seededRng(3)));
  });

  it('state() resumes the same sequence (what the table blocks save mid-run)', () => {
    const r = seededRng(20261019);
    r();
    r.int(6);
    const saved = r.state();
    const ahead = [r(), r(), r.int(100)];
    const resumed = seededRng(saved);
    expect([resumed(), resumed(), resumed.int(100)]).toEqual(ahead);
    expect(Number.isInteger(saved) && saved >= 0 && saved < 2 ** 32).toBe(true);
  });
});
