// The engines a `kit: code` game may draw with, each through its adapter in @gp/core/engines/<name>, and the versions
// the adapters support. game.yaml `engine: { name, version }` names one; `gp validate` checks it here (supported, the
// version in range) and in the CLI (the game's package.json pins that version, and that version is installed).
// The verdicts and the numbers come from the engine lab (QmaCyber/game12, docs/engine-lab.md): the same small arcade
// game in six engines, measured on the platform.

/** One supported engine */
export interface EngineInfo {
  id: string;
  /** The npm package the game installs (games/<id>/package.json); null: none (Canvas 2D is the browser's) */
  package: string | null;
  /** What the adapter supports: the major version (three: 0.<minor>, r<minor>) */
  supported: { major: number; minMinor?: number; maxMinor?: number } | null;
  /** The version the engine lab measured and `gp init --engine` pins */
  tested: string | null;
  /** The supported range, as people read it */
  range: string;
  /** The adapter's import path */
  adapter: string;
  /** When to pick it (the lab's verdict) */
  when: string;
  /** What the browser must have (gp validate's hint) */
  needs: 'nothing' | 'webgl2' | null;
}

export const ENGINES: Record<string, EngineInfo> = {
  canvas: {
    id: 'canvas',
    package: null,
    supported: null,
    tested: null,
    range: 'the browser’s Canvas 2D (no package)',
    adapter: '@gp/core/engines/canvas',
    when: 'The default: most portal games. 16 KB gzipped and 0.4 s to a tappable Play on a slow phone in the lab, plays everywhere; fastest at 200 sprites on a throttled phone (47 fps). You write particles, tweens and collisions yourself.',
    needs: 'nothing',
  },
  pixi: {
    id: 'pixi',
    package: 'pixi.js',
    supported: { major: 8 },
    tested: '8.21.0',
    range: 'pixi.js 8.x (tested 8.21.0)',
    adapter: '@gp/core/engines/pixi',
    when: 'Many sprites: its ParticleContainer held 58 fps at 2,000 sprites on the desktop and 19/15 on a throttled phone, where Canvas 2D fell to 9/6. 174 KB gzipped, ≈ 1.9 s to Play on a slow phone. WebGL2 → WebGL1 → Canvas: plays everywhere.',
    needs: null,
  },
  phaser: {
    id: 'phaser',
    package: 'phaser',
    supported: { major: 4 },
    tested: '4.2.1',
    range: 'phaser 4.x (tested 4.2.1)',
    adapter: '@gp/core/engines/phaser',
    when: 'Only when the game needs Phaser’s physics (Arcade), particles, tweens and scenes: the heaviest engine — 362 KB gzipped, ≈ 3.3 s to Play on a slow phone (8× Canvas 2D). WebGL or Canvas: plays everywhere.',
    needs: null,
  },
  three: {
    id: 'three',
    package: 'three',
    supported: { major: 0, minMinor: 163, maxMinor: 199 },
    tested: '0.186.1',
    range: 'three r163–r199, 0.163.x–0.199.x (tested 0.186.1)',
    adapter: '@gp/core/engines/three',
    when: 'Only where 3D is the point: 151 KB gzipped, ≈ 1.6 s to Play, but WebGL2 only (r163+ has no WebGL1 and no Canvas renderer) — players on old or blocklisted GPUs get "can’t run". For flat 2D use Canvas 2D or Pixi.',
    needs: 'webgl2',
  },
};

/** Engines the platform measured and decided not to support, and why (gp validate: E_ENGINE_UNSUPPORTED) */
export const UNSUPPORTED_ENGINES: Record<string, string> = {
  kaplay:
    'Kaplay is not supported: its loop can’t be stopped and restarted, it always makes its own AudioContext, it has no WebGL fallback and can’t recover a lost WebGL context, and in the engine lab it needed 6 private internals to obey the host and was the slowest variant (the only gp qa failure: 49 fps at 1280×720). Use Canvas 2D (small) or Pixi (many sprites).',
  rapier:
    'Rapier is a physics library, not an engine: draw with Canvas 2D or Pixi (engine.name) and add the physics beside it — `engine: { name: canvas, physics: { name: rapier2d, version: 0.21.0 } }`, through the physics block @gp/physics (gp init --physics). It costs ≈ 1.3 MB gzipped.',
};
for (const id of ['rapier2d', 'rapier2d-deterministic', 'rapier2d-compat']) UNSUPPORTED_ENGINES[id] = UNSUPPORTED_ENGINES.rapier;

/**
 * A physics library the physics block (@gp/physics) runs, named by game.yaml `engine.physics: { name, version }`. Like an
 * engine it is the game's own npm dependency, pinned in games/<id>/package.json; `gp validate` checks the range here and
 * the pin in the CLI.
 */
export interface PhysicsInfo {
  id: string;
  /** The npm package the game installs: the -compat build (its .wasm inside the JS, an explicit init()) */
  package: string;
  supported: { major: number; minMinor?: number; maxMinor?: number };
  /** The version the block's browser test runs (packages/core/test-browser/engines-real) and `gp init --physics` pins */
  tested: string;
  range: string;
  /** When to pick it */
  when: string;
  /** What it adds to a portal upload, gzipped (KB; measured on the one-file build) */
  gzipKB: number;
}

// Rapier is 0.x: under semver any minor may change its API, so the block supports the minor its browser test runs. The plain builds (@dimforge/rapier2d) import their .wasm as an ES module: they don't load
// in Node at all (balance bots, unit tests: no `main`, extensionless imports, a .wasm import), they need a top-level
// await in the page (a failing WebAssembly is then a module that never loads, not a readable error), and the one-file
// upload is no smaller (the engine lab: 1,314 KB gzipped against the compat build's 1,304 KB). The compat build embeds
// the same .wasm as base64 and initialises it with an explicit `await RAPIER.init()`, which the block does.
export const PHYSICS: Record<string, PhysicsInfo> = {
  rapier2d: {
    id: 'rapier2d',
    package: '@dimforge/rapier2d-compat',
    supported: { major: 0, minMinor: 21, maxMinor: 21 },
    tested: '0.21.0',
    range: '@dimforge/rapier2d-compat 0.21.x (tested 0.21.0)',
    when: 'Physics as the mechanic (stacking, piles, ragdolls, joints): Rapier 2D through @gp/physics. The same floats on the same machine and build (gp qa demo bots, balance()). ≈ 1.3 MB gzipped (3.4 MB raw), needs WebAssembly.',
    gzipKB: 1250,
  },
  'rapier2d-deterministic': {
    id: 'rapier2d-deterministic',
    package: '@dimforge/rapier2d-deterministic-compat',
    supported: { major: 0, minMinor: 21, maxMinor: 21 },
    tested: '0.21.0',
    range: '@dimforge/rapier2d-deterministic-compat 0.21.x (tested 0.21.0)',
    when: 'The same, and the same floats on every machine (Rapier’s cross-platform determinism): a shared daily seed, replays, a leaderboard of physics outcomes. +12 KB gzipped, about as fast.',
    gzipKB: 1262,
  },
};

/** Rapier packages a game may have pinned instead of the one its engine.physics names, and what to do */
export const PHYSICS_PACKAGES_INSTEAD: Record<string, string> = {
  '@dimforge/rapier2d': 'the plain build imports its .wasm as an ES module: it doesn’t load in Node (balance(), unit tests) and needs a top-level await — pin the -compat build (the same .wasm, an explicit init(); no bigger in the upload)',
  '@dimforge/rapier2d-simd': 'the SIMD builds need wasm simd128 (no Safari before 16.4) — pin @dimforge/rapier2d-compat',
  '@dimforge/rapier2d-simd-compat': 'the SIMD builds need wasm simd128 (no Safari before 16.4) — pin @dimforge/rapier2d-compat',
  '@dimforge/rapier2d-deterministic': 'the plain build imports its .wasm as an ES module — pin @dimforge/rapier2d-deterministic-compat',
};

/** An exact version x.y.z (a pin, no range) */
export function parseVersion(v: string): { major: number; minor: number; patch: number } | null {
  const m = /^(\d+)\.(\d+)\.(\d+)$/.exec(v.trim());
  return m ? { major: Number(m[1]), minor: Number(m[2]), patch: Number(m[3]) } : null;
}

/** Whether the adapter (or the physics block) supports this exact version of the package */
export function engineSupports(e: Pick<EngineInfo, 'supported'>, version: string): boolean {
  const s = e.supported;
  const v = parseVersion(version);
  if (!s || !v) return false;
  if (v.major !== s.major) return false;
  if (s.minMinor !== undefined && v.minor < s.minMinor) return false;
  if (s.maxMinor !== undefined && v.minor > s.maxMinor) return false;
  return true;
}
