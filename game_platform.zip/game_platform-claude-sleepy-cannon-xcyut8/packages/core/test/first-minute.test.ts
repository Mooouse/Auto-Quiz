// The first-minute blocks that run without a page: visits (welcome back), the deferred portal (C7), the results goal.
import { describe, expect, it } from 'vitest';
import { recordVisit } from '../src/daily.ts';
import { deferPortal, type Portal } from '../src/portal.ts';
import { goalFromSnapshot } from '../src/results-ui.ts';
import type { KeyValueStore } from '../src/save.ts';

describe('recordVisit', () => {
  it('a first visit, then the same day (no welcome back), then a new day (welcome back, the days counted)', () => {
    const first = recordVisit(undefined, '2026-10-10');
    expect(first).toEqual({ log: { first: '2026-10-10', last: '2026-10-10', days: 1 }, firstVisit: true, newDay: false, daysAway: 0 });
    const again = recordVisit(first.log, '2026-10-10');
    expect(again.firstVisit).toBe(false);
    expect(again.newDay).toBe(false);
    expect(again.log.days).toBe(1);
    const tomorrow = recordVisit(again.log, '2026-10-11');
    expect(tomorrow).toMatchObject({ newDay: true, daysAway: 1, log: { first: '2026-10-10', last: '2026-10-11', days: 2 } });
    expect(recordVisit(tomorrow.log, '2026-11-01').daysAway).toBe(21);
  });

  it('a broken log is a first visit; a clock set back never gives negative days', () => {
    expect(recordVisit({ last: 'yesterday' }, '2026-10-10').firstVisit).toBe(true);
    expect(recordVisit('nope', '2026-10-10').firstVisit).toBe(true);
    const back = recordVisit({ first: '2026-10-10', last: '2026-10-12', days: 3 }, '2026-10-11');
    expect(back).toMatchObject({ newDay: false, daysAway: 0, log: { last: '2026-10-12', days: 3 } });
  });
});

/** A fake portal: records the calls, its SDK store and readiness controlled by the test */
function fakePortal(remote: Map<string, string> | null) {
  const calls: string[] = [];
  const mute: ((m: boolean) => void)[] = [];
  const portal: Portal = {
    name: 'fake',
    init: async () => {},
    loadingStart: () => void calls.push('loadingStart'),
    loadingStop: () => void calls.push('loadingStop'),
    gameplayStart: () => void calls.push('gameplayStart'),
    gameplayStop: () => void calls.push('gameplayStop'),
    happytime: () => void calls.push('happytime'),
    adProvider: () => null,
    storage: () => (remote ? { getItem: (k) => remote.get(k) ?? null, setItem: (k, v) => void remote.set(k, v) } : null),
    muted: () => true,
    onMuteChange: (fn) => void mute.push(fn),
    locale: () => 'de-DE',
  };
  return { portal, calls, mute };
}

function memory(): KeyValueStore & { map: Map<string, string> } {
  const map = new Map<string, string>();
  return { map, getItem: (k) => map.get(k) ?? null, setItem: (k, v) => void map.set(k, v) };
}

function later() {
  let resolve!: () => void;
  const promise = new Promise<void>((r) => (resolve = r));
  return { promise, resolve };
}

describe('deferPortal (the game starts before a slow SDK)', () => {
  it('queues the lifecycle calls and plays them in order once the SDK is ready', async () => {
    const f = fakePortal(new Map());
    const init = later();
    const p = deferPortal(f.portal, init.promise, ['save'], memory);
    p.loadingStart();
    p.loadingStop();
    p.gameplayStart();
    expect(f.calls).toEqual([]);
    expect(p.ready).toBe(false);
    expect(p.locale()).toBeNull();
    expect(p.muted()).toBe(false);
    init.resolve();
    await p.whenReady;
    expect(f.calls).toEqual(['loadingStart', 'loadingStop', 'gameplayStart']);
    p.gameplayStop();
    expect(f.calls.at(-1)).toBe('gameplayStop');
    expect(p.locale()).toBe('de-DE');
  });

  it("a mute listener registered early hears the portal's mute state once the SDK is ready", async () => {
    const f = fakePortal(null);
    const init = later();
    const p = deferPortal(f.portal, init.promise, ['save'], memory);
    const heard: boolean[] = [];
    p.onMuteChange((m) => heard.push(m));
    init.resolve();
    await p.whenReady;
    expect(heard).toEqual([true]);
    expect(f.mute.length).toBe(1);
  });

  it("a new player's saves made while the SDK loaded reach the SDK's empty store, and later saves go there", async () => {
    const remote = new Map<string, string>();
    const local = memory();
    const init = later();
    const p = deferPortal(fakePortal(remote).portal, init.promise, ['save', 'save.run'], () => local);
    const kv = p.storage()!;
    expect(kv.getItem('save')).toBeNull();
    kv.setItem('save', '{"best":3}');
    expect(local.map.get('save')).toBe('{"best":3}');
    init.resolve();
    await p.whenReady;
    expect(remote.get('save')).toBe('{"best":3}');
    kv.setItem('save', '{"best":5}');
    expect(remote.get('save')).toBe('{"best":5}');
    expect(kv.getItem('save')).toBe('{"best":5}');
  });

  it("never overwrites a cloud save that was there before: the session stays local", async () => {
    const remote = new Map([['save', '{"best":99}']]);
    const local = memory();
    const init = later();
    const p = deferPortal(fakePortal(remote).portal, init.promise, ['save'], () => local);
    p.storage()!.setItem('save', '{"best":1}');
    init.resolve();
    await p.whenReady;
    p.storage()!.setItem('save', '{"best":2}');
    expect(remote.get('save')).toBe('{"best":99}');
    expect(local.map.get('save')).toBe('{"best":2}');
  });

  it('with nothing written before the SDK came, its store is used (a returning player keeps the cloud save)', async () => {
    const remote = new Map([['save', '{"best":99}']]);
    const init = later();
    const p = deferPortal(fakePortal(remote).portal, init.promise, ['save'], memory);
    init.resolve();
    await p.whenReady;
    expect(p.storage()!.getItem('save')).toBe('{"best":99}');
  });
});

describe('goalFromSnapshot', () => {
  it("the balance model's session-end goal in the player's words, the share clamped", () => {
    expect(goalFromSnapshot({ goal: { id: 'lithium', kind: 'item', share: 0.82 } }, (id) => id.toUpperCase())).toEqual({ label: 'LITHIUM', progress: 0.82 });
    expect(goalFromSnapshot({ goal: { id: 'x', kind: 'stage', share: 1.4 } }, (id) => id)!.progress).toBe(1);
    expect(goalFromSnapshot({ goal: null }, (id) => id)).toBeNull();
    expect(goalFromSnapshot(null, (id) => id)).toBeNull();
  });
});
