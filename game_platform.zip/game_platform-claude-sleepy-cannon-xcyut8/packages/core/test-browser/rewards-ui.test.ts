// Browser test of the rewards hub (mountRewardsHub): one screen at every size on every tab, gifts taken, the wheel's
// prize shown only when it stops and paid once (a reload mid-spin keeps it), the ad spin only after the free one, the
// amounts on the slices, the day's offers with the free one, currency for an ad, the boost's time in the header.
// `npm run test:browser` (Playwright's Chromium).
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { layoutOf, metaLog, SIZES, startFixture, type Fixture } from './meta-helpers';

let fx: Fixture;
beforeAll(async () => {
  fx = await startFixture();
}, 60000);
afterAll(async () => fx?.close());

const prizes = async (page: import('playwright').Page) => (await metaLog(page)).filter((l) => l.startsWith('prize:'));

describe('mountRewardsHub', () => {
  it('fits one screen at every size on every tab, every button ≥ 48 px under the game\'s CSS', async () => {
    for (const viewport of SIZES)
      for (const tab of ['gifts', 'wheel', 'offers']) {
        const page = await fx.open(`screen=rewards&tab=${tab}&boost=1`, viewport);
        expect(await layoutOf(page, 'gp-rewards'), `${tab} ${viewport.width}×${viewport.height}`).toEqual([]);
        if (tab === 'wheel') {
          const box = await page.locator('[data-gp=rewards-wheel] svg').boundingBox();
          expect(box!.height, `the wheel at ${viewport.width}×${viewport.height}`).toBeGreaterThanOrEqual(viewport.height < 500 ? 150 : 260);
        }
        expect((page as unknown as { errors: string[] }).errors).toEqual([]);
        await page.close();
      }
  }, 90000);

  it('gifts: the reached ones taken once, a countdown on the next, the boost in the header', async () => {
    const page = await fx.open('screen=rewards&boost=1', SIZES[1]);
    expect(await page.locator('[data-gp=rewards-gift][data-state=ready]').count()).toBe(2);
    expect(await page.innerText('[data-gp=rewards-gift-next]')).toBe('Next gift after 2:40 of play');
    expect(await page.innerText('[data-gp=rewards-boost]')).toBe('×2 · 12:34');
    await page.locator('[data-gp=rewards-take]').first().tap();
    expect(await page.getAttribute('[data-gp-gift="0"]', 'data-state')).toBe('taken');
    expect(await prizes(page)).toEqual(['prize:gift:{"coins":100}']);
    await page.close();
  });

  it('the wheel: amounts on the slices; the prize shows only when it stops, paid once; then the extra spin for an ad', async () => {
    const page = await fx.open('screen=rewards&tab=wheel&rand=0.4', SIZES[0]);
    const labels = await page.locator('[data-gp=rewards-slice-label]').evaluateAll((es) => es.map((e) => e.textContent));
    expect(labels).toEqual(['120', '5', '300', '×2 10m', '800', '20', '2000', '50']);
    // Before the free spin: no ad spin offered
    expect(await page.locator('[data-gp^=rewards-ad-]').count()).toBe(0);
    await page.tap('[data-gp=rewards-spin-free]');
    // Turning: nothing said, nothing paid yet (but decided and saved)
    expect(await page.innerText('[data-gp=rewards-won]')).toBe('');
    expect(await prizes(page)).toEqual([]);
    const pending = await page.evaluate(() => (window as unknown as { __meta: { wheel: { log: { pending: unknown } } } }).__meta.wheel.log.pending);
    expect(pending).not.toBeNull();
    await page.waitForFunction(() => document.querySelector('[data-gp=rewards-won]')?.textContent !== '', null, { timeout: 5000 });
    const won = await page.innerText('[data-gp=rewards-won]');
    expect(won).toMatch(/^You won: /);
    expect(await prizes(page)).toHaveLength(1);
    // The slice under the pointer is the prize: the wheel turned onto it
    const under = await page.evaluate(() => {
      const g = document.querySelector<SVGGElement>('.gp-rw-wheel')!;
      const deg = Number(/rotate\((-?[\d.]+)deg\)/.exec(g.style.transform)![1]);
      const n = 8;
      return ((Math.round((-deg / 360) * n) % n) + n) % n;
    });
    const slice = JSON.parse((await prizes(page))[0].slice('prize:wheel:'.length));
    const SL = [{ coins: 120 }, { gems: 5 }, { coins: 300 }, { boost: 600 }, { coins: 800 }, { gems: 20 }, { coins: 2000 }, { gems: 50 }];
    expect(SL[under]).toEqual(slice);
    // Now the extra spin for an ad
    await page.waitForSelector('[data-gp="rewards-ad-wheel-spin"]');
    expect(await page.innerText('[data-gp="rewards-ad-wheel-spin"]')).toBe('Extra spin');
    expect(await page.locator('[data-gp="rewards-ad-wheel-spin"] svg[data-mark=play]').count()).toBe(1);
    expect(await page.locator('[data-gp=rewards-spin-free]').count()).toBe(0);
    await page.tap('[data-gp="rewards-ad-wheel-spin"]');
    await page.waitForFunction(() => (window as unknown as { __meta: { log: string[] } }).__meta.log.filter((l) => l.startsWith('prize:')).length === 2, null, { timeout: 5000 });
    expect((await metaLog(page)).filter((l) => l.startsWith('ad:'))).toEqual(['ad:wheel-spin']);
    expect(await page.innerText('.gp-rw-line')).toBe('A free spin again tomorrow');
    await page.close();
  });

  it('a prize spun before a reload: the wheel stands on it and pays it at once, once', async () => {
    const page = await fx.open('screen=rewards&tab=wheel&pending=1&rand=0.9', SIZES[0]);
    expect(await page.innerText('[data-gp=rewards-won]')).toMatch(/^You won: /);
    expect(await prizes(page)).toHaveLength(1);
    expect(await page.evaluate(() => (window as unknown as { __meta: { wheel: { log: { pending: unknown } } } }).__meta.wheel.log.pending)).toBeNull();
    await page.close();
  });

  it('with reduced motion the wheel stops at once; a paid spin takes the currency', async () => {
    const page = await fx.open('screen=rewards&tab=wheel&freeUsed=1&ads=none', SIZES[1], { reducedMotion: 'reduce' });
    expect(await page.locator('[data-gp^=rewards-ad-]').count()).toBe(0); // no ads: no ad spin
    await page.tap('[data-gp=rewards-spin-paid]');
    await page.waitForFunction(() => document.querySelector('[data-gp=rewards-won]')?.textContent !== '', null, { timeout: 1000 });
    expect(await page.evaluate(() => (window as unknown as { __meta: { gems(): number } }).__meta.gems())).toBe(20);
    expect(await page.innerText('[data-gp=rewards-wallet]')).toBe('20');
    await page.close();
  });

  it("offers: today's offers with the first free, bought once; currency for an ad", async () => {
    const page = await fx.open('screen=rewards&tab=offers', SIZES[1]);
    const free = page.locator('[data-gp=rewards-offer][data-state=ready]');
    expect(await free.count()).toBe(1);
    const id = await free.getAttribute('data-gp-offer');
    await free.locator('[data-gp=rewards-buy]').tap();
    expect(await page.getAttribute(`[data-gp-offer="${id}"]`, 'data-state')).toBe('taken');
    expect(await page.locator('[data-gp=rewards-offer][data-state=ready]').count()).toBe(0);
    await page.tap('[data-gp-offer=boost] [data-gp=rewards-buy]');
    expect(await page.innerText('[data-gp=rewards-wallet]')).toBe('5');
    await page.tap('[data-gp="rewards-ad-free-currency"]');
    await page.waitForFunction(() => (window as unknown as { __meta: { log: string[] } }).__meta.log.some((l) => l.startsWith('prize:ad')), null, { timeout: 3000 });
    expect(await prizes(page)).toEqual([`prize:offer:${id}:${JSON.stringify({ coins: (await page.evaluate((i) => (window as unknown as { __meta: { offers: { state(): { offers: { id: string; basePrice: number }[] } } } }).__meta.offers.state().offers.find((o) => o.id === i)!.basePrice, id)) * 40 })}`, 'prize:offer:boost:{"boost":900}', 'prize:ad:{"gems":10}']);
    await page.close();
  });

  it("the platform's words in the player's language", async () => {
    const page = await fx.open('screen=rewards&tab=wheel&lang=de', SIZES[1]);
    expect(await page.innerText('#gp-rewards h2')).toBe('Belohnungen');
    expect(await page.innerText('[data-gp=rewards-spin-free]')).toBe('Gratis drehen');
    expect(await layoutOf(page, 'gp-rewards')).toEqual([]);
    await page.close();
  });
});
