// Browser test of the code kit's language pass (qa/suite.ts runLanguages) on the platform's code game skeleton (ten
// languages): its longest language at the two sizes with every screen and the picker → pass; with the picker hidden, with
// English left on a translated screen and with a squeezed layout → fail, naming what; a hint that runs off the screen
// only in play → the play sampler fails it, with the text and a screenshot. Runs with `npm run test:browser`.

import { existsSync } from 'node:fs';
import { join } from 'node:path';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { englishLeft, languageSizes, longestLanguage, playTextFindings, runLanguages } from '../qa/suite.ts';
import { startSkeleton, type Skeleton } from './skeleton.ts';

let sk: Skeleton;

beforeAll(async () => {
  sk = await startSkeleton();
}, 120000);

afterAll(async () => {
  await sk?.close();
});

describe('QA: the languages', () => {
  it('two sizes (a phone, the portal frame or a phone on its side), one with --quick; the longest language other than English', () => {
    expect(languageSizes(false, true).map((s) => s.name)).toEqual(['phone-portrait-360x800', 'mobile-800x450']);
    expect(languageSizes(false, false).map((s) => s.name)).toEqual(['phone-portrait-360x800', 'phone-landscape-800x360']);
    expect(languageSizes(true, true)).toHaveLength(1);
    expect(longestLanguage({ en: 900, de: 120, ru: 130, es: 110 })).toBe('ru');
    expect(longestLanguage({ en: 100 })).toBeNull();
  });

  it("the skeleton in its longest language: every screen at both sizes, no English left, the picker switches and remembers", async () => {
    const { ctx, checks, infos } = sk.qa();
    await runLanguages(ctx);
    const failed = checks.filter((c) => !c.ok);
    expect(failed, JSON.stringify(failed, null, 1)).toEqual([]);
    const lang = infos.find((i) => i.name === 'the longest language')!.details.split(':')[0];
    expect(sk.game.languages).toContain(lang);
    for (const s of ['first-screen', 'title', 'targets', 'paused', 'so-close', 'results'])
      for (const size of languageSizes(false, true)) {
        expect(checks.some((c) => c.name.startsWith(`${lang} "${s}" ${size.name}:`)), `${s} ${size.name}`).toBe(true);
        expect(existsSync(join(ctx.outDir, `lang-${lang}-${s}-${size.name}.png`))).toBe(true);
      }
    expect(checks.map((c) => c.name)).toEqual(expect.arrayContaining([expect.stringMatching(/^the picker offers every language \(10\)/), expect.stringMatching(/^the choice is saved/)]));
    // In play at both sizes, the demo bot playing
    for (const size of languageSizes(false, true)) expect(checks.some((c) => c.name.startsWith(`${lang} ${size.name}: in play (the demo bot playing`)), size.name).toBe(true);
    console.log(`languages: ${infos.find((i) => i.name === 'time')!.details}`);
  }, 120000);

  it('no picker on the first screen — fails, saying what to add', async () => {
    const hide = () => {
      document.addEventListener('DOMContentLoaded', () => {
        const st = document.createElement('style');
        st.textContent = '[data-gp=lang] { display: none !important; }';
        document.head.append(st);
      });
    };
    const { ctx, checks } = sk.qa({ quick: true, init: hide });
    await runLanguages(ctx);
    const c = checks.find((x) => x.name.startsWith('first screen: a language picker'))!;
    expect(c.ok).toBe(false);
    expect(c.details).toContain('languagePicker({ host');
  }, 60000);

  it('English left on a translated screen (a hard-coded text, or a parameter text) — found, with its key', async () => {
    const context = await sk.browser.newContext({ viewport: { width: 360, height: 800 } });
    const page = await context.newPage();
    await page.goto(`${sk.url}?lang=de`);
    await page.waitForFunction(() => (window as any).__gp?.host?.qaDriver);
    expect(await englishLeft(page, 'de')).toEqual([]);
    await page.evaluate(() => {
      for (const t of ['Play again', 'Score: 120', 'Spielen', 'OK']) document.body.append(Object.assign(document.createElement('div'), { textContent: t }));
    });
    expect(await englishLeft(page, 'de')).toEqual(['"Play again" (English of gp.playAgain)', '"Score: 120" (English of score)']);
    await context.close();
  }, 60000);

  it('a hint that runs off the screen only in play — the declared screens pass, the play sampler fails it with a screenshot', async () => {
    const hint = () => {
      // In play only, after 3 s of it (a later tip: the first screen, in play at a first visit, doesn't show it yet): a
      // one-line hint pinned to the right half, too long for a phone in any language
      let since = 0;
      setInterval(() => {
        const w = window as any;
        const playing = w.__portal?.calls.at(-1)?.fn === 'gameplayStart';
        since = playing ? since || Date.now() : 0;
        const el = document.getElementById('qa-hint');
        if (playing && Date.now() - since > 3000 && !el) document.body.append(Object.assign(document.createElement('div'), { id: 'qa-hint', textContent: 'Wische nach links und rechts, um den Keimen auszuweichen', style: 'position:fixed;left:200px;top:120px;white-space:nowrap;font:16px sans-serif;z-index:9' }));
        if (!playing && el) el.remove();
      }, 100);
    };
    const { ctx, checks } = sk.qa({ quick: true, init: hint });
    await runLanguages(ctx);
    const play = checks.find((c) => / in play \(/.test(c.name))!;
    expect(play.ok).toBe(false);
    expect(play.details).toMatch(/"Wische nach links und rechts, um den[^"]*…" leaves the frame \(200,\d+–\d+,\d+ in 360×800\) at \d+ s — lang-\w+-play-phone-portrait-360x800-\d+s\.png/);
    const shot = /(lang-\S+\.png)/.exec(play.details)![1];
    expect(existsSync(join(ctx.outDir, shot))).toBe(true);
    // The declared screens didn't show it
    expect(checks.filter((c) => !c.ok && c !== play), JSON.stringify(checks.filter((c) => !c.ok && c !== play))).toEqual([]);
  }, 90000);

  it('playTextFindings: off the frame, over or under a button; not a button\'s own label, an overlay over the button, a panel to scroll or a clipped box', async () => {
    const context = await sk.browser.newContext({ viewport: { width: 360, height: 640 } });
    const page = await context.newPage();
    const at = async (html: string) => {
      await page.setContent(`<style>body{margin:0;font:16px sans-serif} button{position:fixed;left:20px;top:300px;width:120px;height:48px}</style>${html}`);
      return playTextFindings(page);
    };
    expect(await at('<button>Pause</button><div style="position:fixed;left:10px;top:10px">Hello</div>')).toEqual([]);
    expect(await at('<div style="position:fixed;left:300px;top:10px;white-space:nowrap">A long hint that goes on</div>')).toEqual([{ kind: 'off-frame', text: 'A long hint that goes on', where: expect.stringMatching(/^300,\d+–\d+,\d+ in 360×640$/) }]);
    // A hint drawn over the button (pointer-events: none or not), and one under it
    expect(await at('<button>Pause</button><div style="position:fixed;left:30px;top:310px;pointer-events:none;z-index:2">Tap to jump</div>')).toEqual([{ kind: 'over-button', text: 'Tap to jump', where: 'Pause' }]);
    expect(await at('<div style="position:fixed;left:30px;top:310px">Tap to jump</div><button style="z-index:2">Pause</button>')).toEqual([{ kind: 'over-button', text: 'Tap to jump', where: 'Pause' }]);
    // A full-screen overlay (a dialog) the text is on hides the button under it; a hidden button is no button
    expect(await at('<button>Pause</button><div style="position:fixed;inset:0;background:#000;z-index:3"><p style="position:absolute;left:30px;top:300px;margin:0;color:#fff">Paused</p></div>')).toEqual([]);
    expect(await at('<button style="visibility:hidden">Pause</button><div style="position:fixed;left:30px;top:310px">Tap to jump</div>')).toEqual([]);
    // Inside a panel the player can scroll, or cut by a box inside the frame (a ticker): not off the frame
    expect(await at('<div style="position:fixed;left:0;top:0;width:200px;height:100px;overflow:auto"><div style="width:600px;white-space:nowrap">A wide row inside a scrolling panel</div></div>')).toEqual([]);
    expect(await at('<div style="position:fixed;left:0;top:0;width:200px;overflow:hidden"><div style="white-space:nowrap">A ticker clipped by its own box, longer than the screen is wide</div></div>')).toEqual([]);
    await context.close();
  }, 60000);

  it('a layout that cuts the longer texts off — fails in the longest language', async () => {
    const squeeze = () => {
      document.addEventListener('DOMContentLoaded', () => {
        const st = document.createElement('style');
        st.textContent = '#ui button { width: 90px !important; min-width: 0 !important; white-space: nowrap; overflow: hidden; }';
        document.head.append(st);
      });
    };
    const { ctx, checks } = sk.qa({ quick: true, init: squeeze });
    await runLanguages(ctx);
    const bad = checks.filter((c) => !c.ok && / "title" /.test(c.name));
    expect(bad.length).toBeGreaterThan(0);
    expect(bad[0].details).toMatch(/cut off by button/);
  }, 60000);
});
