import { describe, expect, it } from 'vitest';
import { MAX_READING_SEC, readableText, readingSec } from '../src/reading.ts';

describe('readingSec: 2 s to notice + 20 characters a second (Netflix adult subtitles, Brysbaert 2019), at most 8 s', () => {
  it('a short phrase needs a little over the noticing time', () => {
    expect(readingSec('Tap the target!')).toBeCloseTo(2 + 15 / 20, 5);
  });
  it("Echoflies' hint after the playtest: ≈ 5 s", () => {
    expect(readingSec('Your echo flies the dotted path again — catch what it misses.')).toBeCloseTo(2 + 61 / 20, 5);
  });
  it('spacing does not count; a wall of text is capped', () => {
    expect(readingSec('  a   b \n c ')).toBe(readingSec('a b c'));
    expect(readableText('  a   b \n c ')).toBe('a b c');
    expect(readingSec('x'.repeat(500))).toBe(MAX_READING_SEC);
  });
  it('characters, not UTF-16 units: an emoji is one', () => {
    expect(readingSec('🔥')).toBe(readingSec('x'));
  });
});
