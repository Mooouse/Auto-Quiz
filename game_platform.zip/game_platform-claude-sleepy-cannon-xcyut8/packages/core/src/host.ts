// GameHost: what a game with its own code (kit: code) gets from the platform. The game brings the mechanics,
// screens and art; the host keeps the channel's rules that are easy to get wrong by hand:
// - the portal lifecycle (loading, gameplayStart/Stop deduplicated, stopped on a hidden tab and during ads, happytime);
// - midgame ads only at natural breaks and within the channel's limits; rewarded ads only after the player's tap;
// - sound through the host's AudioContext, which is suspended while an ad plays or the tab is hidden;
// - a WebGL context loss on the game's canvas pauses the game until the context is back (a "reload" screen if it never is);
// - saves in the portal's cloud storage (localStorage elsewhere), shaped by the game's defaults;
// - a seeded random source (?seed= in dev builds) and events for QA;
// - the game's texts in the player's language (host.t, host.i18n): the saved choice, else the portal's, else the
//   browser's, else English — and the platform's own texts (notices, the rewarded button, shop, dialogue) with them;
// - the first minute (docs/guides/first-minute.md): `firstVisit` (no save yet: land in a safe first run, no title gate),
//   the funnel's steps on the event bus ('funnel': boot → loaded → title → firstInput → gameplayStart → play15/30/60 →
//   firstFail → firstResults, and exit with the last screen on pagehide), and a run saved for a reload (saveRun/loadRun).

import { AdManager, createAdProvider, type AdsOptions } from './ads';
import { EventBus, type GameEventType } from './events';
import { byLanguage, createI18n, detectLanguage, type I18n, type Params, type Strings } from './i18n.ts';
import { PLATFORM_STRINGS } from './i18n-platform.ts';
import { showNotice } from './notice';
import type { Portal } from './portal';
import { rng } from './rng';
import { loadJson, mergeShape, type KeyValueStore } from './save';

/** The first-minute funnel's steps, in the order a new player meets them (docs/guides/first-minute.md) */
export const FUNNEL_STEPS = ['boot', 'loaded', 'title', 'firstInput', 'gameplayStart', 'play15', 'play30', 'play60', 'firstFail', 'firstResults', 'exit'] as const;
export type FunnelStep = (typeof FUNNEL_STEPS)[number];
/** Seconds of gameplay at which the funnel's play15 / play30 / play60 come (CrazyGames' conversion counts the minute) */
const PLAY_MARKS = [15, 30, 60] as const;

export interface HostOptions {
  /** Where the save lives; never change it after release */
  saveKey: string;
  /** Smallest touch target for the audience, CSS px */
  minTouchPx: number;
  locale: string;
  ads: AdsOptions | null;
  portal: Portal | null;
  keepEventLog: boolean;
  /** The game's canvas (#game): a WebGL context loss on it pauses the game ('context'). The player passes it */
  canvas?: HTMLCanvasElement | null;
  /** The game's title, for the "reload" screen */
  title?: string;
  /** The game's texts per language (games/<id>/strings/<lang>.yaml; the player passes them) */
  strings?: Strings;
  /** The game's languages (game.yaml `languages`; default English only) */
  languages?: readonly string[];
  /**
   * The player calls loaded() when the game's start() is done: until then the portal hears no gameplayStart (a first
   * visit that starts its run inside start() still reports init → loadingStart → loadingStop → gameplayStart). Off when
   * a page makes the host itself (tests): gameplay goes to the portal at once
   */
  holdGameplayUntilLoaded?: boolean;
}

/** What `gp qa` needs to drive a game with its own code (register it in dev builds with `host.qa(...)`) */
export interface QaDriver {
  /** From the first screen into gameplay, as a player would (e.g. click Play) */
  play(): void | Promise<void>;
  /** End the current run right now, straight to the results screen (no "Continue" offers) */
  end(): void | Promise<void>;
  /** Optional: lose the current run the way a player does, so offers such as a rewarded "Continue" appear */
  lose?(): void | Promise<void>;
  /** Optional: give the player this much of the shop currency (dev builds only), so QA can buy in the shop */
  grant?(amount: number): void;
  /** Optional: a bot plays the run that has just started (`gp video` films it for the portal's preview videos) */
  demo?(): void;
  /**
   * Optional: what the game draws ON THE CANVAS right now that a player reads or taps (a score, a canvas button), in CSS
   * px of the viewport. `gp qa` checks it like the DOM: on screen at every size, buttons ≥ minTouchPx with no DOM on top,
   * text ≥ 12 px in the portal's small frames, and drawn in the upload. Return [] on screens with none
   */
  canvasUi?(): CanvasUiRect[];
  /**
   * Optional: the title screen animates on purpose (an attract loop), so `gp qa` allows a running loop there. Never on
   * the pause screen or during an ad: there nothing may run
   */
  idleAnimation?: boolean;
  /**
   * Optional: every screen of the game QA can't reach by itself (a journal, a character sheet, a map, a settings panel,
   * the boss card), by name: each function opens that screen right now, from whatever screen the previous one left, with
   * content a player would see there (a full inventory, a long name). `gp qa` opens each at every size and checks it like
   * the first screen: buttons on screen and ≥ minTouchPx, text inside its box and on screen, no page scroll, canvas UI,
   * Tab after a click on the canvas, text ≥ 12 px in the portal's small frames — screenshots `screen-<name>-<size>.png`.
   * Names: kebab-case ('journal', 'char-sheet')
   */
  screens?: Record<string, () => void | Promise<void>>;
  /**
   * Optional: the on-screen touch controls the game DRAWS ON THE CANVAS (a stick, jump and fire buttons), CSS px of the
   * viewport, as they are right now. `gp qa` checks they are visible at the first frame of play on a phone (Spin Brawl's
   * stick appeared only after the first touch). DOM controls need none of this: mark them `data-gp-touch`
   */
  touchControls?(): CanvasUiRect[];
  /**
   * Optional: where the player's object is on screen right now — the ship, the hero, the cell — in CSS px of the
   * viewport (a rect, or a function returning one; null when there is none, e.g. on a menu). `gp qa` checks it in play
   * at every size: on a portal its size (√(w·h)) must be at least 6 % of the screen's short side — on a desktop screen
   * a hero drawn at its phone size is a speck in an empty field (desktop decides)
   */
  hero?: { x: number; y: number; w: number; h: number } | (() => { x: number; y: number; w: number; h: number } | null);
  /**
   * Optional: the camera a 3D game renders with (three's PerspectiveCamera, or `{ hfov }` in degrees), when it isn't
   * the three adapter's `eng.camera` (that one QA finds by itself). `gp qa` checks its horizontal field of view in
   * portrait: at least 60°
   */
  camera?(): unknown;
  /**
   * Optional: the cover's key art (`gp covers`, docs/guides/covers.md). The game draws the picture — the world, its
   * hero big, one action moment — and the platform draws the title, the rim light, the vignette and scores the result
   * at the size players see it (200 px wide). Called once per cover size and composition, on fresh layers
   */
  cover?: CoverArt;
  /**
   * Optional: a digest of the game's state right now (a string or a number: the score, a hash of the positions). `gp qa`
   * plays the same seeded demo for 10 s at 60 Hz and at 144 Hz (its feel section) and compares the two: a game whose
   * simulation follows the frame rate plays differently on a 144 Hz monitor (CrazyGames: "consistently across… 144 Hz").
   * Round what drifts in the last digits (positions to 1 px); without it QA compares the last `score` event, or skips
   */
  digest?(): string | number;
}

/** A cover's composition: where the platform puts the title and where the hero belongs (`gp covers --variants`) */
export type CoverVariant = 'hero' | 'action' | 'closeup';

/** A box in CSS px of the cover */
export interface CoverRect {
  x: number;
  y: number;
  w: number;
  h: number;
}

/** What the platform tells the cover hook: the cover's size, the composition and its zones (CSS px of the cover) */
export interface CoverLayout {
  w: number;
  h: number;
  shape: 'landscape' | 'portrait' | 'square';
  variant: CoverVariant;
  /** Where the hero goes, big: fill this box (bleeding past the cover's edge is fine; small is not) */
  hero: CoverRect;
  /** Where the title will be: keep it calm (no bright detail, no second subject) */
  title: CoverRect;
  /** Where the action moment goes (the explosion, the hit, the catch): next to the hero, away from the title */
  focus: { x: number; y: number };
  /** A size unit: the cover's shorter side / 1080 (1 for the 1920×1080 cover) */
  unit: number;
  /** The light direction (rad, screen space) the platform's rim light comes from: shade the hero to match */
  light: number;
}

/** How the platform letters the title on the cover (every field has a default: docs/guides/covers.md) */
export interface CoverTitleStyle {
  /** The words on the cover (default: the game's title). Keep it to 1–3 words */
  text?: string;
  /** A CSS font family the page has loaded (a FontFace the game ships); default: the platform's display face */
  font?: string;
  /** CSS font weight (default 400 for the platform's face, 900 for a family of your own) */
  weight?: number | string;
  /** The letters' fill, top to bottom: 2–3 colours, light to saturated */
  fill?: string[];
  /** The thick outline: a very dark shade of the hero's colour, never pure black */
  outline?: string;
  /** The block under the letters (3D depth); default: a darker outline */
  extrude?: string;
  /** The glow around the title */
  glow?: string;
  /** Tilt in radians (default -0.05: a slight upward lean) */
  tilt?: number;
  /** Arc: how far the middle of a line rises, in em (default 0.06; 0 = straight) */
  arc?: number;
  /** Upper case (default true for the platform's face) */
  upper?: boolean;
}

/** The cover's key art, drawn by the game in layers on transparent canvases of the cover's size (CSS px) */
export interface CoverArt {
  /** The world behind the hero, filling the whole cover: no empty dark areas, saturated, one light */
  scene(g: CanvasRenderingContext2D, layout: CoverLayout): void | Promise<void>;
  /** The hero and what it is doing, on its own layer: the platform gives it a rim light and a halo and measures it */
  hero?(g: CanvasRenderingContext2D, layout: CoverLayout): void | Promise<void>;
  /** In front of everything but the title: sparks, debris, motion */
  front?(g: CanvasRenderingContext2D, layout: CoverLayout): void | Promise<void>;
  title?: CoverTitleStyle;
  /** The rim light's colour (default: the title's glow) */
  rim?: string;
}

/** Something drawn on the canvas that a player reads or taps (host.qa({ canvasUi })), CSS px of the viewport */
export interface CanvasUiRect {
  /** For the report: 'score', 'jump' */
  name: string;
  /** 'button': tapped (≥ minTouchPx, no DOM element on top); 'text': read (≥ 12 px in the portal's small frames) */
  kind: 'text' | 'button';
  x: number;
  y: number;
  w: number;
  h: number;
  /** The font size it is drawn at, CSS px (text without it is judged by its height) */
  fontPx?: number;
  /** The words drawn there: `gp qa` looks for concept.twist.explained in them (a canvas-drawn explanation of the twist) */
  text?: string;
}

/**
 * Why the host paused the game: the tab is hidden, an ad is playing, or the WebGL context of the game's canvas is lost
 * (a GPU reset or memory pressure on a phone: nothing can be drawn until the browser gives it back)
 */
export type PauseReason = 'hidden' | 'ad' | 'context';

export class GameHost {
  readonly events: EventBus;
  readonly ads: AdManager;
  readonly minTouchPx: number;
  readonly locale: string;
  /** Seeded in dev builds with ?seed=<n>: use it for all game randomness to make runs repeatable */
  readonly rng = rng;
  /** Set by the game in dev builds; `gp qa` uses it */
  qaDriver: QaDriver | null = null;
  /** The camera an engine adapter renders with (the three adapter sets it): `gp qa` reads its field of view in portrait */
  engineCamera: (() => unknown) | null = null;
  /**
   * No save yet when the game started: a new player. Land them in a safe first run (no title, no Play gate — CrazyGames:
   * "land new users in gameplay immediately… a maximum of 1 click"), show the title after it, on pause or as an overlay
   * that fades on the first input. Read it once, at start. Dev and E2E builds: `?visit=first` / `?visit=returning`
   */
  readonly firstVisit: boolean;
  /**
   * The game's texts and the platform's in the player's language (docs/guides/i18n.md): `host.t(key, params)` is
   * `host.i18n.t`; `i18n.number(n)` formats a number, `i18n.languages` lists the game's languages
   */
  readonly i18n: I18n;

  private readonly portal: Portal | null;
  private readonly store: () => KeyValueStore;
  private readonly holdGameplay: boolean;
  /** Dev and E2E builds: the event log and host.seen are kept for QA */
  private readonly keepLog: boolean;
  private loadedDone = false;
  private readonly funnelDone = new Set<FunnelStep>();
  private lastScreen: string | null = null;
  /** Gameplay seconds before the current stretch, and when the current stretch began (performance.now ms) */
  private playedMs = 0;
  private playingSince: number | null = null;
  private playTimer: ReturnType<typeof setTimeout> | null = null;
  private readonly saveKey: string;
  private readonly t0 = performance.now();
  private wantPlaying = false;
  private playing = false;
  private readonly pauses = new Set<PauseReason>();
  private readonly pauseFns: ((reason: PauseReason, reasons: ReadonlySet<PauseReason>) => void)[] = [];
  /** The WebGL context of the game's canvas is lost right now */
  private contextLost = false;
  private readonly resumeFns: (() => void)[] = [];
  private lastInputSec: number | null = null;
  private audioCtx: AudioContext | null = null;
  private audioOut: GainNode | null = null;
  /** Between the game's output and the speakers: silent while the portal's mute setting is on */
  private portalGain: GainNode | null = null;
  private portalMute = false;

  constructor(opts: HostOptions) {
    this.minTouchPx = opts.minTouchPx;
    this.locale = opts.locale;
    this.portal = opts.portal;
    this.saveKey = opts.saveKey;
    const portalStore = this.portal?.storage() ?? null;
    this.store = () => portalStore ?? localStorage;
    this.events = new EventBus(() => (performance.now() - this.t0) / 1000, opts.keepEventLog);
    this.keepLog = opts.keepEventLog;
    this.holdGameplay = !!opts.holdGameplayUntilLoaded;
    this.firstVisit = this.readFirstVisit();
    this.funnel('boot', { firstVisit: this.firstVisit });
    this.i18n = this.makeI18n(opts);
    const policy = opts.ads?.policy ?? {
      noAdsAfterLaunchSec: Infinity,
      firstAdAfterRound: Infinity,
      everyRounds: Infinity,
      minIntervalSec: Infinity,
      maxAdWaitSec: 0,
      testAdCloseSec: 0,
    };
    this.ads = new AdManager(
      createAdProvider(opts.ads, this.portal?.adProvider() ?? null),
      policy,
      () => false,
      {
        onStart: () => {
          this.pause('ad');
          this.events.emit('ad:start');
        },
        onEnd: (shown) => {
          // A rewarded ad that gave nothing doesn't resume the run on the portal's side: the game says when play goes on
          // (Playgama's certification reads a gameplay_started right after an early-closed rewarded ad as a reward given)
          if (this.rewardedShowing && !shown) this.wantPlaying = false;
          this.resume('ad');
          this.events.emit('ad:end', { shown });
        },
        onPending: (p) => this.setAdInert(p),
      },
      undefined,
      opts.ads?.rewarded ?? false,
    );
    // Only the player's own input counts for rewarded ads; the first one also unlocks audio
    const input = (e: Event) => {
      if (!e.isTrusted) return;
      this.lastInputSec = performance.now() / 1000;
      this.unlockAudio();
      this.funnel('firstInput', { kind: e.type === 'keydown' ? 'key' : 'pointer', screen: this.isPlaying ? 'play' : this.lastScreen });
    };
    window.addEventListener('pointerdown', input, { capture: true });
    window.addEventListener('keydown', input, { capture: true });
    // The tab hidden, or the platform pausing the game (Playgama Bridge): one 'hidden' reason, cleared when neither holds
    let platformPaused = false;
    const hidden = () => (document.hidden || platformPaused ? this.pause('hidden') : this.resume('hidden'));
    document.addEventListener('visibilitychange', hidden);
    this.portal?.onPause?.((p) => {
      platformPaused = p;
      hidden();
    });
    if (opts.canvas) this.watchContext(opts.canvas, opts.title ?? document.title);
    // The funnel's last step: where the player left (the last screen, the gameplay seconds). pagehide, not unload: it
    // fires on mobile tab switches and bfcache too; the first one counts
    window.addEventListener('pagehide', () => this.funnel('exit', { screen: this.isPlaying ? 'play' : this.lastScreen, playedSec: this.playedSec, reached: this.lastFunnelStep() }));
    this.events.on((e) => {
      if (e.type === 'highlight') this.portal?.happytime();
    });
    this.portalMute = this.portal?.muted() ?? false;
    this.portal?.onMuteChange((m) => {
      this.portalMute = m;
      if (this.portalGain) this.portalGain.gain.value = m ? 0 : 1;
    });
    void this.ads.init();
  }

  // --- Languages ---------------------------------------------------------------------------------

  /** Where the player's own language choice is saved: next to the game's save, in the same storage */
  private get langKey(): string {
    return `${this.saveKey}.lang`;
  }

  private makeI18n(opts: HostOptions): I18n {
    const languages = opts.languages?.length ? [...opts.languages] : ['en'];
    const test = import.meta.env.DEV || import.meta.env.VITE_E2E === '1';
    // ?lang=<code> in dev and E2E builds: gp qa opens the game in its longest language
    const forced = test ? new URLSearchParams(location.search).get('lang') : null;
    let saved: string | null = null;
    try {
      saved = this.store().getItem(this.langKey);
    } catch {
      saved = null;
    }
    const browser = typeof navigator === 'undefined' ? [] : [...(navigator.languages ?? []), navigator.language];
    const lang = detectLanguage([forced, saved, this.portal?.locale() ?? null, ...browser], languages);
    const i18n = createI18n({
      strings: [byLanguage(PLATFORM_STRINGS), opts.strings ?? {}],
      languages,
      lang,
      onMissing: test ? (key, l) => console.warn(`[i18n] "${key}" has no ${l} text: English is shown (gp validate lists the missing keys)`) : undefined,
    });
    document.documentElement.lang = i18n.lang;
    i18n.onChange((l) => {
      document.documentElement.lang = l;
      try {
        this.store().setItem(this.langKey, l);
      } catch (e) {
        console.warn('[save]', e);
      }
      this.events.emit('language', { lang: l });
    });
    return i18n;
  }

  /** The game's text for `key` in the player's language, with its {params} (numbers formatted, plurals by `n`) */
  t(key: string, params?: Params): string {
    return this.i18n.t(key, params);
  }

  /** The current language's code ("de", "pt-BR") */
  get lang(): string {
    return this.i18n.lang;
  }

  /**
   * The player chose a language (your picker; languagePicker() calls it): switch, save the choice (it beats the portal's
   * and the browser's from now on) and call the onLanguage listeners. false when the game doesn't have it
   */
  setLanguage(code: string): boolean {
    return this.i18n.setLanguage(code);
  }

  /** After every switch of language: re-render the screen you are on (DOM and canvas text). Returns the unsubscribe */
  onLanguage(fn: (lang: string) => void): () => void {
    return this.i18n.onChange(fn);
  }

  // --- Lifecycle ---------------------------------------------------------------------------------

  /**
   * The player is (or is no longer) playing: a run is going on and not paused by the game.
   * Call it on run start, on the game's own pause/resume, on death/results and in menus. Repeats are fine.
   * The host holds it back while the tab is hidden or an ad plays and restores it afterwards.
   */
  gameplay(on: boolean): void {
    this.wantPlaying = on;
    this.syncPlaying();
    // Playgama's certification asks its tester to trigger an interstitial, and a tester doesn't play to a game's first
    // natural break: on Playgama the first Play of a session is one (the policy's limits still apply: PLAYGAMA_AD_POLICY).
    // Held back like gameplayStart until loading is done (a first visit starts its run inside start())
    if (on && !this.firstPlayBreak && this.portal?.name === 'playgama' && (!this.holdGameplay || this.loadedDone)) {
      this.firstPlayBreak = true;
      void this.ads.naturalBreak();
    }
  }

  /**
   * The player calls it when the game's start() is done: the portal's loadingStop, the funnel's 'loaded', and a run that
   * start() began (a first visit) reaches the portal now. Once; a game never calls it
   */
  loaded(): void {
    if (this.loadedDone) return;
    this.loadedDone = true;
    this.portal?.loadingStop();
    this.funnel('loaded');
    if (this.wantPlaying) this.gameplay(true);
  }

  // --- The first minute --------------------------------------------------------------------------

  /** In dev and E2E builds `?visit=first|returning` (or QA's window.__gpVisit) plays a new or a returning player */
  private readFirstVisit(): boolean {
    if (import.meta.env.DEV || import.meta.env.VITE_E2E === '1') {
      const forced = new URLSearchParams(location.search).get('visit') ?? (window as unknown as { __gpVisit?: string }).__gpVisit ?? null;
      if (forced === 'first') return true;
      if (forced === 'returning') return false;
    }
    try {
      return !this.store().getItem(this.saveKey);
    } catch {
      return true;
    }
  }

  /**
   * The game shows a screen now: 'title', 'results', 'shop', 'map' … (mountResults and welcomeBack say it themselves).
   * The funnel's 'title' comes from it, and 'exit' names the last screen the player saw. Repeats are fine
   */
  screen(name: string): void {
    this.lastScreen = name;
    this.events.emit('screen', { name });
    if (name === 'title') this.funnel('title');
  }

  /**
   * The player failed: died, lost the level, ran out of time — call it at the moment, before any Continue offer (the
   * funnel's 'firstFail': a new player who fails before a minute of play mostly leaves). host.roundEnd({ lost: true })
   * counts too
   */
  fail(data: Record<string, unknown> = {}): void {
    this.events.emit('fail', data);
    this.funnel('firstFail', data);
  }

  /** Seconds of gameplay this session (the host's gameplay state: not paused, not on a menu) */
  get playedSec(): number {
    const now = this.playingSince === null ? 0 : performance.now() - this.playingSince;
    return Math.round((this.playedMs + now) / 100) / 10;
  }

  /**
   * The player meets something new: an enemy, an item, a card, a place, a boss (`kind` 'enemy', `id` 'bat'). Call it
   * every time — only the first sighting of each id counts. `gp qa` (its feel section) plays a long demo run and counts
   * the distinct ids at 2, 5 and 10 minutes of play, and warns when nothing new appears for over 90 s (judges' most
   * frequent remark: "no variety"). Kept in dev and E2E builds only; a no-op in production
   */
  seen(kind: string, id: string | number): void {
    if (!this.keepLog) return;
    const key = `${kind}\u0000${id}`;
    if (this.seenIds.has(key)) return;
    this.seenIds.add(key);
    this.seenLog.push({ kind, id: String(id), playedSec: this.playedSec, t: performance.now() });
  }

  /** The first sightings so far (host.seen), in order: what `gp qa` reads. Empty in production */
  readonly seenLog: { kind: string; id: string; playedSec: number; t: number }[] = [];
  private readonly seenIds = new Set<string>();

  /** The funnel steps this session has reached so far */
  get funnelSteps(): ReadonlySet<FunnelStep> {
    return new Set(this.funnelDone);
  }

  private lastFunnelStep(): FunnelStep | null {
    let last: FunnelStep | null = null;
    for (const s of FUNNEL_STEPS) if (s !== 'exit' && this.funnelDone.has(s)) last = s;
    return last;
  }

  /** A funnel step, once a session: on the event bus (QA, the game's own analytics) and to the portal if it takes them */
  private funnel(step: FunnelStep, data: Record<string, unknown> = {}): void {
    if (this.funnelDone.has(step)) return;
    this.funnelDone.add(step);
    const e = { step, sec: Math.round(performance.now() / 10) / 100, ...data };
    this.events.emit('funnel', e);
    try {
      this.portal?.funnel?.(step, e);
    } catch (err) {
      console.warn('[funnel]', err);
    }
  }

  /** The gameplay clock for play15/30/60: runs while the host's gameplay state is on */
  private trackPlay(on: boolean): void {
    const now = performance.now();
    if (on) {
      if (this.playingSince === null) this.playingSince = now;
    } else if (this.playingSince !== null) {
      this.playedMs += now - this.playingSince;
      this.playingSince = null;
    }
    if (this.playTimer) clearTimeout(this.playTimer);
    this.playTimer = null;
    if (!on || this.playingSince === null) return;
    const next = PLAY_MARKS.find((m) => !this.funnelDone.has(`play${m}`));
    if (next === undefined) return;
    const left = next * 1000 - this.playedMs - (now - this.playingSince);
    this.playTimer = setTimeout(() => {
      this.funnel(`play${next}`);
      this.trackPlay(true);
    }, Math.max(0, left));
  }

  // --- A run saved for a reload ------------------------------------------------------------------

  /** Where the run in progress is saved: next to the game's save, in the same storage (the portal's cloud save) */
  get runKey(): string {
    return `${this.saveKey}.run`;
  }

  /**
   * Save the run in progress, so a reload (or tomorrow's visit) goes on where the player left: on every important
   * change — a move, a room cleared, a wave survived — never every frame. Through the host's storage: CrazyGames' and
   * Playgama's cloud saves keep it too. Never throws
   */
  saveRun(data: unknown): void {
    try {
      this.store().setItem(this.runKey, JSON.stringify({ at: Date.now(), data }));
    } catch (e) {
      console.warn('[save]', e);
    }
  }

  /**
   * The saved run shaped like `defaults` (mergeShape: an old or broken one gets defaults where it doesn't fit), or null
   * when there is none, it was cleared, or it is older than `maxAgeHours`
   */
  loadRun<T>(defaults: T, opts: { maxAgeHours?: number } = {}): T | null {
    try {
      const raw = this.store().getItem(this.runKey);
      if (!raw) return null;
      const r = JSON.parse(raw) as { at?: unknown; data?: unknown };
      if (!r || typeof r !== 'object' || r.data === undefined || r.data === null) return null;
      if (opts.maxAgeHours !== undefined && typeof r.at === 'number' && Date.now() - r.at > opts.maxAgeHours * 3600_000) return null;
      return mergeShape(defaults, r.data);
    } catch {
      return null;
    }
  }

  /** The run is over (results, give up): a reload starts fresh */
  clearRun(): void {
    try {
      if (this.store().getItem(this.runKey)) this.store().setItem(this.runKey, '');
    } catch (e) {
      console.warn('[save]', e);
    }
  }

  private firstPlayBreak = false;
  private rewardedShowing = false;

  /**
   * The game's twist just happened — the moment that makes it its own (`concept.twist.event` in game.yaml). Call it every
   * time it happens; `gp qa` lets the demo bot play and checks a new player meets it within `concept.twist.within` seconds.
   */
  twist(event = 'twist'): void {
    this.events.emit('twist', { event });
  }

  /** A moment worth celebrating (stage cleared, new best) */
  happytime(): void {
    this.events.emit('highlight');
  }

  /**
   * The tab is hidden, an ad is playing or the WebGL context is lost: stop time and sound (the host already suspended its
   * audio). Don't step a run while it is true: a run your Resume button or a reward restarts now stands still until onResume
   */
  get paused(): boolean {
    return this.pauses.size > 0;
  }

  /** Why the game is paused now (empty when it isn't): a copy */
  get pauseReasons(): ReadonlySet<PauseReason> {
    return new Set(this.pauses);
  }

  /**
   * Called once for EACH new reason, with all the reasons now in force: a tab hidden while an ad plays calls it with
   * 'ad' and then with 'hidden'. So it can be called again before onResume: make it idempotent (stop the clock, show the
   * pause screen). 'hidden' and 'context' are the moments to show your pause screen
   */
  onPause(fn: (reason: PauseReason, reasons: ReadonlySet<PauseReason>) => void): void {
    this.pauseFns.push(fn);
  }

  /**
   * Called once when the last reason is cleared (the tab is back AND the ad is over AND the context is back): go on, and
   * redraw if your loop stood still (after a context loss the canvas is blank until you draw; the engine has already
   * re-created its GPU state). host.adPending is already false here
   */
  onResume(fn: () => void): void {
    this.resumeFns.push(fn);
  }

  private pause(reason: PauseReason): void {
    if (this.pauses.has(reason)) return;
    const was = this.paused;
    this.pauses.add(reason);
    if (!was) {
      void this.audioCtx?.suspend();
      this.syncPlaying();
    }
    const reasons = this.pauseReasons;
    for (const f of this.pauseFns) f(reason, reasons);
  }

  private resume(reason: PauseReason): void {
    if (!this.pauses.delete(reason) || this.paused) return;
    void this.audioCtx?.resume();
    this.syncPlaying();
    for (const f of this.resumeFns) f();
  }

  /**
   * A WebGL context loss on the game's canvas, for every engine (the engine lab: Pixi drew nothing while the run kept
   * scoring, three scored on a black screen, Kaplay never moved again). The engine's own listeners may come before or
   * after these (an engine made at Play is made after the host), so the host looks at the event once its dispatch is over:
   * - lost → paused ('context') at once; the context comes back only if a listener called preventDefault() (engines that
   *   can rebuild do) — if none did, it never will, and the player sees a "reload" screen;
   * - restored → after every listener (the engine re-creates its GPU state in its own), 'context' is cleared and
   *   onResume lets the game redraw.
   */
  private watchContext(canvas: HTMLCanvasElement, title: string): void {
    canvas.addEventListener('webglcontextlost', (e) => {
      this.contextLost = true;
      this.events.emit('context:lost');
      this.pause('context');
      setTimeout(() => {
        if (!this.contextLost || e.defaultPrevented) return;
        this.events.emit('context:gone');
        showNotice(this.i18n.t('gp.graphicsLost', { title }), 'reload');
      }, 0);
    });
    canvas.addEventListener('webglcontextrestored', () => {
      if (!this.contextLost) return;
      this.contextLost = false;
      setTimeout(() => {
        if (this.contextLost) return; // lost again meanwhile
        this.events.emit('context:restored');
        this.resume('context');
      }, 0);
    });
  }

  private syncPlaying(): void {
    const on = this.wantPlaying && !this.paused && (!this.holdGameplay || this.loadedDone);
    if (on === this.playing) return;
    this.playing = on;
    this.trackPlay(on);
    if (on) this.funnel('gameplayStart', { firstVisit: this.firstVisit, afterInput: this.lastInputSec !== null });
    if (!this.portal) return;
    if (on) this.portal.gameplayStart();
    else this.portal.gameplayStop();
  }

  // --- Ads ---------------------------------------------------------------------------------------

  /** A run (round, level) is over. Counts for the ad limits and tells QA; call it once per run */
  roundEnd(result: Record<string, unknown> = {}): void {
    this.gameplay(false);
    this.ads.countRound();
    this.events.emit('round:end', result);
    if (result.lost === true || result.won === false || result.fail === true) this.funnel('firstFail', result);
    this.funnel('firstResults', result);
  }

  /**
   * A natural break chosen by the player: "Play again", "Next level", back to the menu. Shows a midgame ad if the
   * channel's limits allow it (never in the first minute or the first run) and resolves when it's over.
   * Never call it during play or on a timer. While another ad is pending it does nothing.
   */
  async adBreak(): Promise<void> {
    this.gameplay(false);
    await this.ads.naturalBreak();
  }

  /**
   * The player's account on the portal (Playgama: sign-in through the Bridge): `supported` false elsewhere. A game shows
   * a sign-in button only when supported && !authorized — `signInButton()` does that, and on Playgama the host puts one
   * on the menus by itself unless the game placed its own.
   */
  get account(): { supported: boolean; authorized: boolean; name: string | null } {
    return this.portal?.account?.() ?? { supported: false, authorized: false, name: null };
  }

  /**
   * Sign in on the portal, from the player's tap. Resolves true when signed in; the page then reloads so the saves come
   * from the account (pass `{ reload: false }` to reload them yourself). Never required to play.
   */
  async signIn(o: { reload?: boolean } = {}): Promise<boolean> {
    if (!this.portal?.signIn) return false;
    const ok = await this.portal.signIn();
    if (ok) {
      this.events.emit('account:signed-in');
      if (o.reload !== false) location.reload();
    }
    return ok;
  }

  /** Whether the run is going on (the portal's gameplay state): menus show a sign-in, play doesn't */
  get isPlaying(): boolean {
    return this.playing;
  }

  /** The player muted the game in the portal's settings: `host.audio` is silent already; mute your own sounds too */
  get portalMuted(): boolean {
    return this.portalMute;
  }

  /**
   * An ad is on its way or on screen: other ad requests are refused until it's over. The UI roots (inertDuringAds) are
   * inert meanwhile, so nothing under it can be tapped; a reward that arrives late must still check the run is on
   * (rewardedOffer() does)
   */
  get adPending(): boolean {
    return this.ads.adPending;
  }

  private readonly inertRoots = new Set<HTMLElement>();
  /** The roots made inert by the pending ad (a root the game had made inert itself is left alone) */
  private inertSet: HTMLElement[] = [];

  /**
   * While an ad (midgame or rewarded) is pending — from the request, before the portal's overlay covers the page, to its
   * end — these elements are `inert`: no tap, click, key or focus reaches the game's buttons under it (Frankengun's "No
   * thanks" clicked under a loading revive ad ended the run, and the late reward revived it: a softlock). The player
   * registers the UI layer (#ui) and the canvas; register a screen you put elsewhere (on document.body). Returns the
   * unregister
   */
  inertDuringAds(...roots: HTMLElement[]): () => void {
    for (const r of roots) this.inertRoots.add(r);
    if (this.ads.adPending) this.setAdInert(true);
    return () => {
      for (const r of roots) {
        this.inertRoots.delete(r);
        const i = this.inertSet.indexOf(r);
        if (i >= 0) {
          r.inert = false;
          this.inertSet.splice(i, 1);
        }
      }
    };
  }

  private setAdInert(on: boolean): void {
    if (on) {
      for (const r of this.inertRoots) {
        if (r.inert || this.inertSet.includes(r)) continue;
        r.inert = true;
        this.inertSet.push(r);
      }
    } else {
      for (const r of this.inertSet) r.inert = false;
      this.inertSet = [];
    }
  }

  /**
   * Rewarded ads can be offered now: show the "watch an ad" buttons only when true. Read it each time a screen with such
   * a button opens: it turns false for the rest of the session when ads are off (CrazyGames' Basic Launch, where
   * monetization is off; an ad blocker) or after two failed ads in a row. `rewardedButton()` does all of this.
   */
  get rewardedAvailable(): boolean {
    return this.ads.rewardedAvailable;
  }

  /**
   * A rewarded ad the player chose. Call it right from the button's tap handler. true — watched to the end: give
   * the reward now; false — no reward (failed or not available). Then say so on the button ("No ad available right now")
   * and leave the player's other choices as they were: a failed ad must never end the run or decide for the player.
   * An ad without the player's tap is refused, and so is a second one while an ad is pending (a double click gets one
   * ad and one reward).
   */
  async rewarded(placement: string): Promise<boolean> {
    this.rewardedShowing = true;
    let ok = false;
    try {
      ok = await this.ads.rewarded(this.lastInputSec, placement);
    } finally {
      this.rewardedShowing = false;
    }
    this.events.emit('ad:rewarded', { placement, ok });
    return ok;
  }

  // --- Save --------------------------------------------------------------------------------------

  /** The saved data shaped like `defaults` (see mergeShape): what doesn't fit gets the default */
  load<T>(defaults: T): T {
    return loadJson(this.saveKey, defaults, this.store);
  }

  /** Save now: after a run, a purchase in the game's shop, a settings change. Never throws */
  save(data: unknown): void {
    try {
      this.store().setItem(this.saveKey, JSON.stringify(data));
    } catch (e) {
      console.warn('[save]', e);
    }
  }

  // --- Audio -------------------------------------------------------------------------------------

  /**
   * The game's audio output: connect every sound to it. null until the player's first tap or key (browsers block
   * audio before one). The host suspends it while an ad plays or the tab is hidden — a portal rule.
   */
  get audio(): { ctx: AudioContext; out: GainNode } | null {
    return this.audioCtx && this.audioOut ? { ctx: this.audioCtx, out: this.audioOut } : null;
  }

  private unlockAudio(): void {
    if (this.audioCtx) {
      if (this.audioCtx.state === 'suspended' && !this.paused) void this.audioCtx.resume();
      return;
    }
    try {
      const AC = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.audioCtx = new AC();
      this.audioOut = this.audioCtx.createGain();
      this.portalGain = this.audioCtx.createGain();
      this.portalGain.gain.value = this.portalMute ? 0 : 1;
      this.audioOut.connect(this.portalGain).connect(this.audioCtx.destination);
      if (this.paused) void this.audioCtx.suspend();
    } catch {
      this.audioCtx = null;
    }
  }

  // --- QA ----------------------------------------------------------------------------------------

  /** Let `gp qa` drive the game (only has an effect in dev and E2E builds, where QA runs) */
  qa(driver: QaDriver): void {
    this.qaDriver = driver;
  }

  /** Report something for QA and analytics (e.g. 'score') */
  emit(type: GameEventType, data: Record<string, unknown> = {}): void {
    this.events.emit(type, data);
  }
}

/** What the game knows about itself (from game.yaml) */
export interface GameInfo {
  id: string;
  title: string;
  locale: string;
  audience: string;
  channel: string;
}

/** The argument of a code game's `export default function start(...)` */
export interface GameContext {
  host: GameHost;
  /** A full-window canvas (#game) — draw on it, or ignore it and use `ui` */
  canvas: HTMLCanvasElement;
  /** An empty full-window layer (#ui) for DOM screens: menus, HUD, shop */
  ui: HTMLElement;
  game: GameInfo;
}

/** A code game's entry module: `export default function start(ctx: GameContext)`; loading ends when it resolves */
export type StartGame = (ctx: GameContext) => void | Promise<void>;
