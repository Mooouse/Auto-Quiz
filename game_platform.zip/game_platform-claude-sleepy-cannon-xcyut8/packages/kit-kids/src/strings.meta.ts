// The kids kit's texts in every language the platform knows (pure data: Node checks it, the player picks one). They
// are the grown-ups' texts — the parent gate and the settings behind it — so they follow the device's language; what
// the child hears (praise, content words) stays in the game's `locale`, the language its voice speaks.

import type { StringTable } from '@gp/core/i18n';

export const KIDS_STRINGS: StringTable = {
  gatePrompt: {
    en: 'For grown-ups. Tap the numbers:',
    es: 'Para adultos. Toca los números:',
    'pt-BR': 'Para adultos. Toque nos números:',
    fr: 'Pour les adultes. Touchez les nombres :',
    de: 'Für Erwachsene. Tippe die Zahlen:',
    ru: 'Для взрослых. Нажмите числа:',
    tr: 'Yetişkinler için. Sayılara dokunun:',
    it: 'Per gli adulti. Tocca i numeri:',
    pl: 'Dla dorosłych. Dotknij liczb:',
    id: 'Untuk orang dewasa. Ketuk angkanya:',
    ja: '大人の方へ。数字をタップ：',
    ko: '어른용입니다. 숫자를 누르세요:',
    'zh-CN': '家长专用。请点击数字：',
  },
  parents: { en: 'For parents', es: 'Para padres', 'pt-BR': 'Para os pais', fr: 'Pour les parents', de: 'Für Eltern', ru: 'Для родителей', tr: 'Ebeveynler için', it: 'Per i genitori', pl: 'Dla rodziców', id: 'Untuk orang tua', ja: '保護者の方へ', ko: '보호자용', 'zh-CN': '家长专区' },
  sound: { en: 'Sounds', es: 'Sonidos', 'pt-BR': 'Sons', fr: 'Sons', de: 'Töne', ru: 'Звуки', tr: 'Sesler', it: 'Suoni', pl: 'Dźwięki', id: 'Efek suara', ja: '効果音', ko: '효과음', 'zh-CN': '音效' },
  voice: { en: 'Voice', es: 'Voz', 'pt-BR': 'Voz', fr: 'Voix', de: 'Stimme', ru: 'Голос', tr: 'Seslendirme', it: 'Voce', pl: 'Głos', id: 'Suara', ja: '音声', ko: '음성', 'zh-CN': '语音' },
  on: { en: 'on', es: 'sí', 'pt-BR': 'ligado', fr: 'oui', de: 'an', ru: 'вкл.', tr: 'açık', it: 'sì', pl: 'wł.', id: 'nyala', ja: 'オン', ko: '켜짐', 'zh-CN': '开' },
  off: { en: 'off', es: 'no', 'pt-BR': 'desligado', fr: 'non', de: 'aus', ru: 'выкл.', tr: 'kapalı', it: 'no', pl: 'wył.', id: 'mati', ja: 'オフ', ko: '꺼짐', 'zh-CN': '关' },
  removeAds: { en: 'Remove ads', es: 'Quitar anuncios', 'pt-BR': 'Remover anúncios', fr: 'Supprimer les pubs', de: 'Werbung entfernen', ru: 'Убрать рекламу', tr: 'Reklamları kaldır', it: 'Rimuovi pubblicità', pl: 'Usuń reklamy', id: 'Hapus iklan', ja: '広告を削除', ko: '광고 제거', 'zh-CN': '去除广告' },
  adsRemoved: { en: 'Ads removed', es: 'Anuncios quitados', 'pt-BR': 'Anúncios removidos', fr: 'Pubs supprimées', de: 'Werbung entfernt', ru: 'Реклама убрана', tr: 'Reklamlar kaldırıldı', it: 'Pubblicità rimossa', pl: 'Reklamy usunięte', id: 'Iklan dihapus', ja: '広告を削除しました', ko: '광고 제거됨', 'zh-CN': '已去除广告' },
  restore: { en: 'Restore purchases', es: 'Restaurar compras', 'pt-BR': 'Restaurar compras', fr: 'Restaurer les achats', de: 'Käufe wiederherstellen', ru: 'Восстановить покупки', tr: 'Satın alımları geri yükle', it: 'Ripristina acquisti', pl: 'Przywróć zakupy', id: 'Pulihkan pembelian', ja: '購入を復元', ko: '구매 복원', 'zh-CN': '恢复购买' },
  restored: { en: 'Purchase restored', es: 'Compra restaurada', 'pt-BR': 'Compra restaurada', fr: 'Achat restauré', de: 'Kauf wiederhergestellt', ru: 'Покупка восстановлена', tr: 'Satın alım geri yüklendi', it: 'Acquisto ripristinato', pl: 'Zakup przywrócony', id: 'Pembelian dipulihkan', ja: '購入を復元しました', ko: '구매가 복원되었습니다', 'zh-CN': '已恢复购买' },
  nothingToRestore: { en: 'No purchases found', es: 'No se encontraron compras', 'pt-BR': 'Nenhuma compra encontrada', fr: 'Aucun achat trouvé', de: 'Keine Käufe gefunden', ru: 'Покупки не найдены', tr: 'Satın alım bulunamadı', it: 'Nessun acquisto trovato', pl: 'Nie znaleziono zakupów', id: 'Tidak ada pembelian', ja: '購入が見つかりません', ko: '구매 내역이 없습니다', 'zh-CN': '未找到购买记录' },
  purchaseFailed: { en: 'Purchase failed', es: 'La compra falló', 'pt-BR': 'A compra falhou', fr: "L'achat a échoué", de: 'Kauf fehlgeschlagen', ru: 'Покупка не удалась', tr: 'Satın alma başarısız', it: 'Acquisto non riuscito', pl: 'Zakup nieudany', id: 'Pembelian gagal', ja: '購入に失敗しました', ko: '구매 실패', 'zh-CN': '购买失败' },
  purchasePending: { en: 'Payment is pending', es: 'Pago pendiente', 'pt-BR': 'Pagamento pendente', fr: 'Paiement en attente', de: 'Zahlung ausstehend', ru: 'Платёж в обработке', tr: 'Ödeme bekleniyor', it: 'Pagamento in sospeso', pl: 'Płatność oczekuje', id: 'Pembayaran tertunda', ja: '支払い保留中', ko: '결제 대기 중', 'zh-CN': '付款处理中' },
  storeUnavailable: { en: "Can't reach Google Play", es: 'Sin conexión con Google Play', 'pt-BR': 'Sem acesso ao Google Play', fr: 'Google Play injoignable', de: 'Google Play nicht erreichbar', ru: 'Нет связи с Google Play', tr: "Google Play'e ulaşılamıyor", it: 'Google Play non raggiungibile', pl: 'Brak połączenia z Google Play', id: 'Google Play tidak terjangkau', ja: 'Google Play に接続できません', ko: 'Google Play에 연결할 수 없음', 'zh-CN': '无法连接 Google Play' },
  privacy: { en: 'Privacy policy', es: 'Política de privacidad', 'pt-BR': 'Política de privacidade', fr: 'Confidentialité', de: 'Datenschutz', ru: 'Конфиденциальность', tr: 'Gizlilik politikası', it: 'Privacy', pl: 'Polityka prywatności', id: 'Kebijakan privasi', ja: 'プライバシーポリシー', ko: '개인정보 처리방침', 'zh-CN': '隐私政策' },
  back: { en: 'Back', es: 'Volver', 'pt-BR': 'Voltar', fr: 'Retour', de: 'Zurück', ru: 'Назад', tr: 'Geri', it: 'Indietro', pl: 'Wstecz', id: 'Kembali', ja: '戻る', ko: '뒤로', 'zh-CN': '返回' },
  testOnly: { en: 'test', es: 'prueba', 'pt-BR': 'teste', fr: 'test', de: 'Test', ru: 'тест', tr: 'test', it: 'test', pl: 'test', id: 'uji', ja: 'テスト', ko: '테스트', 'zh-CN': '测试' },
};

/** Number words 0–10 for the parent gate's task ("seven, two, five"), per language */
export const KIDS_NUMBER_WORDS: Record<string, readonly string[]> = {
  en: ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten'],
  es: ['cero', 'uno', 'dos', 'tres', 'cuatro', 'cinco', 'seis', 'siete', 'ocho', 'nueve', 'diez'],
  'pt-BR': ['zero', 'um', 'dois', 'três', 'quatro', 'cinco', 'seis', 'sete', 'oito', 'nove', 'dez'],
  fr: ['zéro', 'un', 'deux', 'trois', 'quatre', 'cinq', 'six', 'sept', 'huit', 'neuf', 'dix'],
  de: ['null', 'eins', 'zwei', 'drei', 'vier', 'fünf', 'sechs', 'sieben', 'acht', 'neun', 'zehn'],
  ru: ['ноль', 'один', 'два', 'три', 'четыре', 'пять', 'шесть', 'семь', 'восемь', 'девять', 'десять'],
  tr: ['sıfır', 'bir', 'iki', 'üç', 'dört', 'beş', 'altı', 'yedi', 'sekiz', 'dokuz', 'on'],
  it: ['zero', 'uno', 'due', 'tre', 'quattro', 'cinque', 'sei', 'sette', 'otto', 'nove', 'dieci'],
  pl: ['zero', 'jeden', 'dwa', 'trzy', 'cztery', 'pięć', 'sześć', 'siedem', 'osiem', 'dziewięć', 'dziesięć'],
  id: ['nol', 'satu', 'dua', 'tiga', 'empat', 'lima', 'enam', 'tujuh', 'delapan', 'sembilan', 'sepuluh'],
  ja: ['れい', 'いち', 'に', 'さん', 'よん', 'ご', 'ろく', 'なな', 'はち', 'きゅう', 'じゅう'],
  ko: ['영', '일', '이', '삼', '사', '오', '육', '칠', '팔', '구', '십'],
  'zh-CN': ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九', '十'],
};
