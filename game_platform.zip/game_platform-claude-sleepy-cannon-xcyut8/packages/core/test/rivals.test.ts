import { describe, expect, it } from 'vitest';
import { worldClock } from '../src/clock.ts';
import { rivalNameProblem, rivals } from '../src/rivals.ts';

const day = (d: number, h = 12) => Date.UTC(2026, 9, d, h);
const CAST = [
  { id: 'maple', name: 'Maple', skill: 0.8 },
  { id: 'bram', name: 'Old Bram', skill: 0.4 },
  { id: 'nia', name: "Ni'a", skill: 0.6 },
];

describe('rivals', () => {
  it('named characters, always marked as NPC rivals; a seeded routine per day, the same for everyone', () => {
    let t = day(19);
    const mk = () => rivals({ salt: 'raccoons', cast: CAST, now: () => t, behave: (r, rng) => ({ wakes: 4 + rng.int(4), traps: rng() < r.skill }) });
    const a = mk();
    const list = a.list();
    expect(list.map((r) => [r.id, r.npc, r.kind])).toEqual([
      ['maple', true, 'rival'],
      ['bram', true, 'rival'],
      ['nia', true, 'rival'],
    ]);
    expect(a.get('maple')).toEqual(mk().get('maple'));
    expect(a.period()).toBe('2026-10-19');
    const routines = new Set<string>();
    for (let d = 1; d <= 15; d++) {
      t = day(d);
      routines.add(JSON.stringify(a.get('maple').behaviour));
    }
    expect(routines.size).toBeGreaterThan(2);
  });

  it('scores in a range by skill, seeded per day; the board puts the player among them, labelled', () => {
    const r = rivals({ salt: 'raccoons', cast: CAST, now: () => day(19), spread: 0.1 });
    const maple = r.score('maple', [200, 600]);
    expect(maple).toBe(r.score('maple', [200, 600]));
    expect(maple).toBeGreaterThanOrEqual(200 + 400 * 0.6);
    expect(maple).toBeLessThanOrEqual(200 + 400 * 0.9 + 1);
    expect(r.score('bram', [200, 600])).toBeLessThan(maple);
    expect(r.score('maple', [200, 600], { key: '2026-10-18' })).not.toBe(maple);
    const board = r.board({ score: 450, name: 'You' }, [200, 600]);
    expect(board).toHaveLength(4);
    expect(board.filter((e) => e.you)).toEqual([{ id: 'you', name: 'You', score: 450, npc: false, you: true }]);
    expect(board.filter((e) => !e.you).every((e) => e.npc)).toBe(true);
    for (let i = 1; i < board.length; i++) expect(board[i - 1].score).toBeGreaterThanOrEqual(board[i].score);
    // Lower is better (a time)
    const times = r.board({ score: 50 }, [40, 120], { better: 'low' });
    for (let i = 1; i < times.length; i++) expect(times[i - 1].score).toBeLessThanOrEqual(times[i].score);
  });

  it('on the world clock: routines per slot', () => {
    let t = day(19, 18);
    const clock = worldClock({ salt: 'raccoons', every: '1h', now: () => t });
    const r = rivals({ salt: 'raccoons', cast: CAST, clock, behave: (_r, rng) => rng.int(1000) });
    expect(r.period()).toBe('2026-10-19#18');
    const a = r.get('nia').behaviour;
    t += 3600_000;
    expect(r.period()).toBe('2026-10-19#19');
    expect(r.get('nia').behaviour).not.toBe(a);
  });

  it('never a username: names that pass for real players are refused', () => {
    expect(rivalNameProblem('Maple')).toBeNull();
    expect(rivalNameProblem('Old Bram')).toBeNull();
    expect(rivalNameProblem('Zoë-Anne')).toBeNull();
    for (const bad of ['xX_Pro99', 'maple123', 'ninja@home', 'Player 2', 'Guest', 'A'])
      expect(rivalNameProblem(bad), bad).not.toBeNull();
    expect(() => rivals({ salt: 'g', cast: [{ id: 'x', name: 'Sniper_42', skill: 0.5 }] })).toThrow(/username/);
    expect(() => rivals({ salt: 'g', cast: [{ id: 'x', name: 'Maple', skill: 2 }] })).toThrow(/skill/);
    expect(() => rivals({ salt: 'g', cast: [] })).toThrow(/cast/);
  });
});
