// gp dev serves the game's files as they are on disk: a file replaced (a temporary file renamed over it, or deleted and
// written again) is still seen, and a page load re-reads a served file whose mtime changed even when no watcher saw it.
// The game is a copy of the code example outside the platform, as in a `gp init` repository.

import { cpSync, mkdtempSync, renameSync, rmSync, unlinkSync, utimesSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import type { ViteDevServer } from 'vite';
import { ROOT, type GameLocation } from '../src/paths.ts';
import { devFreshness, isGameOutput, isGameSource } from '../src/vite-plugin.ts';
import { startDev } from '../src/vite.ts';

const tmp = mkdtempSync(join(tmpdir(), 'gp-dev-'));
const dir = join(tmp, 'games', 'demo');
const loc: GameLocation = { id: 'demo', dir, file: join(dir, 'game.yaml') };
const data = join(dir, 'data.ts');
let server: ViteDevServer;
let base = '';
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const get = async (u: string) => (await fetch(base + u)).text();
const served = () => get(`/@fs${data}`);
/** Wait until the served data.ts has this marker (the watcher's event is asynchronous), or give up */
async function until(marker: string, ms = 3000): Promise<boolean> {
  for (const t0 = Date.now(); Date.now() - t0 < ms; await sleep(50)) if ((await served()).includes(marker)) return true;
  return false;
}

beforeAll(async () => {
  cpSync(join(ROOT, 'docs/examples/code'), dir, { recursive: true, filter: (f) => !/[\\/](upload|dist|qa|node_modules|store|submission)$/.test(f) });
  writeFileSync(data, 'export const DATA = { v: 0 };\n');
  // main.ts imports data.ts, as a game's data table
  const main = join(dir, 'main.ts');
  const { readFileSync } = await import('node:fs');
  writeFileSync(main, `import { DATA } from './data.ts';\nvoid DATA;\n${readFileSync(main, 'utf8')}`);
  server = await startDev(loc, 0);
  base = server.resolvedUrls!.local[0].replace(/\/$/, '');
  await get('/');
  expect(await served()).toContain('v: 0');
}, 60_000);
afterAll(async () => {
  await server?.close();
  rmSync(tmp, { recursive: true, force: true });
});

describe('gp dev: the game files as they are on disk', () => {
  it('a file replaced again and again (rename over it, delete and write) is served fresh, without a page load', { timeout: 30_000 }, async () => {
    const ways: [string, (s: string) => Promise<void> | void][] = [
      ['rename', (s) => (writeFileSync(`${data}.tmp`, s), renameSync(`${data}.tmp`, data))],
      ['delete-write', (s) => (unlinkSync(data), writeFileSync(data, s))],
      ['delete-wait-write', async (s) => (unlinkSync(data), await sleep(150), writeFileSync(data, s))],
      ['in-place', (s) => writeFileSync(data, s)],
    ];
    // Before the fix the single-file watch was gone after the second or third replace, and every write after it was lost
    let n = 0;
    for (let round = 0; round < 2; round++)
      for (const [way, write] of ways) {
        const marker = `v: ${++n}`;
        await write(`export const DATA = { ${marker} };\n`);
        expect(await until(marker), `${way} (#${n})`).toBe(true);
      }
  });
  it('a page load re-reads a served file whose mtime changed, even when no watcher saw it', { timeout: 30_000 }, async () => {
    // Blind the watcher to data.ts, then change it
    await server.watcher.unwatch([data, dir]);
    await sleep(100);
    writeFileSync(data, 'export const DATA = { v: "unseen" };\n');
    const t = Date.now() / 1000 + 5;
    utimesSync(data, t, t);
    await sleep(300);
    expect(await served()).not.toContain('unseen');
    await get('/');
    expect(await served()).toContain('unseen');
    // …and it is watched again: the next change arrives without a page load
    server.watcher.add(dir);
    await sleep(300);
    writeFileSync(data, 'export const DATA = { v: "watched" };\n');
    expect(await until('watched')).toBe(true);
  });
});

describe('the game folder: sources and outputs', () => {
  it('the outputs are not sources and are never watched', () => {
    expect(isGameSource(loc, join(dir, 'data.ts'))).toBe(true);
    expect(isGameSource(loc, join(dir, 'levels', 'one.ts'))).toBe(true);
    for (const out of ['qa/report.md', 'upload/index.html', 'dist/x.js', 'store/cover.png', 'node_modules/pixi.js/x.js', 'submission/a.zip']) {
      expect(isGameSource(loc, join(dir, out)), out).toBe(false);
      expect(isGameOutput(loc, join(dir, out)), out).toBe(true);
    }
    expect(isGameSource(loc, join(tmp, 'elsewhere.ts'))).toBe(false);
    expect(isGameOutput(loc, dir)).toBe(false);
  });
  it('devFreshness: only files changed since they were served', () => {
    const f = devFreshness(loc);
    const other = join(dir, 'other.ts');
    writeFileSync(other, 'export {};\n');
    f.served(`${other}?import`);
    f.served(join(tmp, 'not-the-game.ts'));
    expect(f.changed()).toEqual([]);
    const t = Date.now() / 1000 + 60;
    utimesSync(other, t, t);
    expect(f.changed()).toEqual([other]);
  });
});

describe('gp qa, gp covers, gp video: a frozen server (startDev frozen)', () => {
  it('keeps serving the game as it first served it: an edit during the run neither reaches the page nor reloads it', { timeout: 60_000 }, async () => {
    const fdir = join(tmp, 'games', 'frozen');
    const floc: GameLocation = { id: 'frozen', dir: fdir, file: join(fdir, 'game.yaml') };
    cpSync(dir, fdir, { recursive: true });
    const fdata = join(fdir, 'data.ts');
    writeFileSync(fdata, 'export const DATA = { v: "first" };\n');
    const frozen = await startDev(floc, 0, { frozen: true });
    try {
      const fbase = frozen.resolvedUrls!.local[0].replace(/\/$/, '');
      const fget = async (u: string) => (await fetch(fbase + u)).text();
      // No HMR client to reload the page, no watcher to see the edit
      expect(frozen.config.server.hmr).toBe(false);
      expect(frozen.config.server.watch).toBe(null);
      const reloads: unknown[] = [];
      const send = frozen.ws.send.bind(frozen.ws);
      frozen.ws.send = ((...a: Parameters<typeof send>) => (reloads.push(a[0]), send(...a))) as typeof send;
      await fget('/');
      expect(await fget(`/@fs${fdata}`)).toContain('first');
      // The game maker's next edit — and a page load after it (QA reloads the page)
      writeFileSync(`${fdata}.tmp`, 'export const DATA = { v: "edited" };\n');
      renameSync(`${fdata}.tmp`, fdata);
      const t = Date.now() / 1000 + 5;
      utimesSync(fdata, t, t);
      await sleep(500);
      await fget('/');
      expect(await fget(`/@fs${fdata}`)).toContain('first');
      expect(reloads).toEqual([]);
    } finally {
      await frozen.close();
    }
  });
});
