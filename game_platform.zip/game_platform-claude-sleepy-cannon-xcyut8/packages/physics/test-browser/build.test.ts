// A portal game with physics builds to one file without warnings: the `gp init --physics` skeleton, with the real
// @dimforge/rapier2d-compat (installed only in packages/core/test-browser/engines-real; skipped without it, like
// rapier-real.test.ts), through `gp build --target crazygames`'s buildPortal. The WebAssembly is inlined (no file the
// page loads separately), the size report gives Rapier's share, and the upload fits the budget game.yaml raises.

import { execFileSync } from 'node:child_process';
import { existsSync, mkdtempSync, readdirSync, readFileSync, rmSync, symlinkSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest';
import type { SizeReport } from '@gp/spec';
import { checkGame } from '../../cli/src/game.ts';
import { ROOT } from '../../cli/src/paths.ts';
import { buildPortal } from '../../cli/src/portal-build.ts';

const REAL = fileURLToPath(new URL('../../core/test-browser/engines-real/node_modules', import.meta.url));
const installed = existsSync(join(REAL, '@dimforge/rapier2d-compat/package.json'));
if (!installed) console.warn('[physics build] skipped: Rapier is not installed — npm ci --prefix packages/core/test-browser/engines-real');

const tmp = mkdtempSync(join(tmpdir(), 'gp-physics-build-'));
// vitest sets NODE_ENV=test, which Vite would take over the production mode (a dev bundle with the stubs): as in gp
const env = process.env.NODE_ENV;
beforeAll(() => {
  delete process.env.NODE_ENV;
});
afterAll(() => {
  process.env.NODE_ENV = env;
  rmSync(tmp, { recursive: true, force: true });
});

describe.skipIf(!installed)('a portal game with physics', () => {
  it('builds to one file without a warning: the WebAssembly inlined, Rapier’s share in the size report, within the raised budget', { timeout: 180_000 }, async () => {
    const repo = join(tmp, 'repo');
    execFileSync(process.execPath, [join(ROOT, 'packages/cli/src/gp.ts'), 'init', repo, '--id', 'ball-build', '--title', 'Ball Build', '--physics'], { env: { ...process.env, GP_NO_LOG: '1' }, stdio: 'pipe' });
    const dir = join(repo, 'games', 'ball-build');
    // The template's TODOs written (gp validate refuses them), as a game maker would
    const yaml = join(dir, 'game.yaml');
    // 150–160 characters: long enough for the listing, short enough for every other field
    const TEXT = 'A ball caroms off a platform under gravity and speeds up every second: tap it to score and knock it higher. Three misses end the run; coins unlock targets.';
    writeFileSync(yaml, readFileSync(yaml, 'utf8').replace(/"TODO[^"]*"/g, JSON.stringify(TEXT)).replace('genre: TODO', 'genre: action').replace('tags: [TODO]', 'tags: [arcade, physics]'));
    // The game's own node_modules: the real Rapier of the browser tests (scripts/setup.sh would npm ci it there)
    symlinkSync(REAL, join(dir, 'node_modules'), 'dir');
    const loc = { id: 'ball-build', dir, file: yaml };
    const r = checkGame(loc, 'dev');
    expect(r.issues.filter((i) => i.severity === 'error'), JSON.stringify(r.issues)).toEqual([]);
    expect(r.issues.map((i) => i.code)).not.toContain('W_PHYSICS_BUDGET');

    const warnings: string[] = [];
    const spy = vi.spyOn(console, 'warn').mockImplementation((...a: unknown[]) => void warnings.push(a.map(String).join(' ')));
    let pkg: Awaited<ReturnType<typeof buildPortal>>;
    try {
      pkg = await buildPortal(loc, r.game!);
    } finally {
      spy.mockRestore();
    }
    expect(warnings).toEqual([]);
    expect(pkg.problems).toEqual([]);
    // One file: the page and its one script, nothing else the page would load (no separate .wasm)
    expect(readdirSync(join(dir, 'upload'))).toEqual(['index.html', 'size.json']);
    expect(readdirSync(join(dir, 'dist', 'assets')).filter((f) => !f.endsWith('.map')).every((f) => f.endsWith('.js'))).toBe(true);
    const html = readFileSync(join(dir, 'upload/index.html'), 'utf8');
    // Rapier's WebAssembly, as base64 inside the page ("\0asm" → AGFzbQ)
    expect(html).toContain('AGFzbQ');
    const size = JSON.parse(readFileSync(join(dir, 'upload/size.json'), 'utf8')) as SizeReport;
    const rapier = size.packages.find((p) => p.name === '@dimforge/rapier2d-compat')!;
    expect(rapier.share).toBeGreaterThan(0.9);
    expect(size.packages.map((p) => p.name)).toContain('@gp/physics');
    expect(size.dataBytes).toBeGreaterThan(3_000_000);
    expect(size.budget).toMatchObject({ gzipKB: 1500, from: 'game.yaml budget.gzipKB' });
    expect(size.gzipBytes).toBeLessThan(1500 * 1024);
    expect(size.over).toEqual([]);
  });
});
