// Test page for TwinStick / LookInput (packages/core/test-browser/twin-stick.test.ts): a host and one input on #game,
// with every pause and first input logged. Not a game. Headless Chromium has no real pointer lock: requestPointerLock /
// exitPointerLock are played here (the lock is granted asynchronously, as browsers do; ?refuse=1 refuses it).
//   ?mode=look | aim
import { GameHost } from '../../src/index';
import { TwinStick } from '../../src/twin-stick';

const q = new URLSearchParams(location.search);
const canvas = document.getElementById('game') as HTMLCanvasElement;
const ui = document.getElementById('ui') as HTMLElement;
const host = new GameHost({
  saveKey: 'twin-stick-fixture',
  minTouchPx: 48,
  locale: 'en-US',
  ads: { policy: { noAdsAfterLaunchSec: 0, firstAdAfterRound: 0, everyRounds: 1, minIntervalSec: 0, maxAdWaitSec: 10, testAdCloseSec: 1 }, rewarded: true, admob: null },
  portal: null,
  keepEventLog: true,
  canvas,
  title: 'Twin-stick Fixture',
});

let locked: Element | null = null;
Object.defineProperty(document, 'pointerLockElement', { configurable: true, get: () => locked });
const lockCalls: number[] = [];
/** ?hold=1: the lock waits for grant() (the test looks at the moment between the click and the grant) */
let pending = false;
const grant = () => {
  pending = false;
  if (q.get('refuse')) document.dispatchEvent(new Event('pointerlockerror'));
  else {
    locked = canvas;
    document.dispatchEvent(new Event('pointerlockchange'));
  }
};
canvas.requestPointerLock = (() => {
  lockCalls.push(Date.now());
  pending = true;
  if (!q.get('hold')) setTimeout(grant, 30);
  return Promise.resolve();
}) as typeof canvas.requestPointerLock;
document.exitPointerLock = () => {
  if (!locked) return;
  locked = null;
  document.dispatchEvent(new Event('pointerlockchange'));
};

const input = new TwinStick({
  host,
  canvas,
  parent: ui,
  mode: q.get('mode') === 'look' ? 'look' : 'aim',
  buttons: [
    { id: 'fire', label: 'Fire', aims: true },
    { id: 'dash', label: 'Dash', keys: ['Space', 'ShiftLeft'] },
  ],
  mouseRight: 'skill',
  wheel: 'swap',
});
const log: string[] = [];
input.onPause((why) => log.push(`pause:${why}`));
input.onLock(() => log.push('lock'));
input.onFirstInput((k) => log.push(`first:${k}`));

/** Play a hidden tab: headless Chromium is never hidden by itself */
function setHidden(hidden: boolean): void {
  Object.defineProperty(document, 'hidden', { configurable: true, get: () => hidden });
  Object.defineProperty(document, 'visibilityState', { configurable: true, get: () => (hidden ? 'hidden' : 'visible') });
  document.dispatchEvent(new Event('visibilitychange'));
}

/** A synthetic pointer gesture on an element (a touch id of its own): down, moves, and optionally up */
function pointer(type: 'pointerdown' | 'pointermove' | 'pointerup', target: Element, x: number, y: number, id = 11, pointerType = 'touch'): void {
  target.dispatchEvent(new PointerEvent(type, { bubbles: true, cancelable: true, clientX: x, clientY: y, pointerId: id, pointerType, isPrimary: true, buttons: type === 'pointerup' ? 0 : 1 }));
}

(window as unknown as Record<string, unknown>).__t = {
  host,
  input,
  log,
  lockCalls,
  grant: () => pending && grant(),
  setHidden,
  pointer,
  el: (sel: string) => document.querySelector(sel),
  state: () => ({
    move: input.move(),
    fire: input.fire,
    yaw: input.yaw,
    pitch: input.pitch,
    touch: input.touch,
    locked: input.locked,
    refused: input.refused,
    layer: input.el.classList.contains('on'),
    prompt: document.querySelector('[data-gp=click-to-aim]')?.classList.contains('on') ?? null,
    promptText: document.querySelector('[data-gp=click-to-aim]')?.textContent ?? null,
    aim: input.aim({ x: 320, y: 180 }),
  }),
};
