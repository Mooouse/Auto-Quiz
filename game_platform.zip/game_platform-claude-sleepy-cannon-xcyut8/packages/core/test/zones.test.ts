// Zones: a deck with a hand and a discard, a blind bag with counts, a market row, the bust rule and its odds, the undo
// of the last draw — and a mini bag-builder round (Quacks-style push your luck) played the way a game would.

import { describe, expect, it } from 'vitest';
import { seededRng } from '../src/rng.ts';
import { UndoHistory } from '../src/undo.ts';
import { Zones, type ZonesState } from '../src/zones.ts';

type Card = { id: string; kind: 'attack' | 'block' | 'skill' };
const card = (id: string, kind: Card['kind']): Card => ({ id, kind });
const STARTER: Card[] = [
  ...Array.from({ length: 5 }, (_, i) => card(`strike${i}`, 'attack')),
  ...Array.from({ length: 4 }, (_, i) => card(`defend${i}`, 'block')),
  card('bash', 'skill'),
];
type Pile = 'draw' | 'hand' | 'discard' | 'exhaust';
const deck = () => new Zones<Card, Pile>({ piles: ['draw', 'hand', 'discard', 'exhaust'], draw: { from: 'draw', to: 'hand' }, reshuffle: { draw: 'discard' }, limit: { hand: 10 } });

describe('Zones: a deck', () => {
  it('a seeded shuffle, the same on every machine; another seed another order', () => {
    const z = deck();
    const a = z.start({ draw: STARTER }, 7);
    expect(z.start({ draw: STARTER }, 7)).toEqual(a);
    expect(z.start({ draw: STARTER }, 8).piles.draw.map((c) => c.id)).not.toEqual(a.piles.draw.map((c) => c.id));
    expect([...a.piles.draw].sort((x, y) => x.id.localeCompare(y.id))).toEqual([...STARTER].sort((x, y) => x.id.localeCompare(y.id)));
  });

  it('draws from the top, reshuffles the discard in when the draw pile runs out, stops at the hand limit', () => {
    const z = deck();
    let s = z.start({ draw: STARTER }, 1);
    const top = z.peek(s, 'draw', 5);
    s = z.draw(s, 5);
    expect(s.piles.hand).toEqual(top);
    expect(z.drawn(s)).toEqual(top);
    // play two cards, discard the rest of the hand
    s = z.move(s, 'hand', 0, 'discard')!;
    s = z.move(s, 'hand', 0, 'exhaust')!;
    s = z.moveAll(s, 'hand', 'discard');
    expect(z.size(s, 'discard')).toBe(4);
    s = z.draw(s, 5);
    expect(z.size(s, 'draw')).toBe(0);
    s = z.draw(s, 3); // the discard comes back shuffled
    expect(z.size(s, 'hand')).toBe(8);
    expect(z.size(s, 'discard')).toBe(0);
    expect(z.size(s, 'draw')).toBe(1);
    s = z.draw(s, 5); // 1 left in the draw pile, nothing to reshuffle
    expect(z.size(s, 'hand')).toBe(9);
    // the exhausted card never comes back
    expect(s.piles.exhaust).toHaveLength(1);
    // a hand at its limit takes no more
    s = z.add(s, card('wound', 'skill'), 'hand');
    expect(z.draw(s, 1)).toMatchObject({ last: null });
    expect(z.move(s, 'exhaust', 0, 'hand')).toBeNull();
  });

  it('odds the player may know: the next draw, and "an attack in the next hand" (hypergeometric)', () => {
    const z = deck();
    const s = z.start({ draw: STARTER }, 3);
    expect(z.odds(s, 'draw', (c) => c.kind === 'attack')).toBe(0.5);
    // 10 cards, 1 skill, draw 5: 1 − C(9,5)/C(10,5) = 0.5
    expect(z.chanceWithin(s, 'draw', (c) => c.kind === 'skill', 5)).toBeCloseTo(0.5, 10);
    // 5 attacks of 10, draw 5: 1 − C(5,5)/C(10,5) = 1 − 1/252
    expect(z.chanceWithin(s, 'draw', (c) => c.kind === 'attack', 5)).toBeCloseTo(1 - 1 / 252, 10);
    expect(z.chanceWithin(s, 'draw', () => false, 5)).toBe(0);
    // an empty draw pile: the odds are the discard's (what a draw would reshuffle)
    const empty = z.moveAll(s, 'draw', 'discard');
    expect(z.odds(empty, 'draw', (c) => c.kind === 'block')).toBe(0.4);
  });

  it('every state is new: an UndoHistory of states undoes a move', () => {
    const z = deck();
    const h = new UndoHistory(z.draw(z.start({ draw: STARTER }, 5), 5));
    const before = JSON.stringify(h.current);
    h.push(z.move(h.current, 'hand', 1, 'discard')!);
    expect(h.current.piles.discard).toHaveLength(1);
    h.undo();
    expect(JSON.stringify(h.current)).toBe(before);
  });

  it('a rewarded redraw: undoDraw puts the hand back, shuffle makes the next draw a new chance', () => {
    const z = deck();
    const s0 = z.start({ draw: STARTER }, 11);
    const s1 = z.draw(s0, 5);
    const back = z.undoDraw(s1)!;
    expect(back.piles.draw).toEqual(s0.piles.draw);
    expect(back.piles.hand).toEqual([]);
    expect(z.undoDraw(back)).toBeNull(); // only right after a draw
    const mixed = z.undoDraw(s1, { shuffle: true })!;
    expect(mixed.piles.draw.map((c) => c.id)).not.toEqual(s0.piles.draw.map((c) => c.id));
  });

  it('rejects broken definitions', () => {
    expect(() => new Zones({ piles: [] })).toThrow();
    expect(() => new Zones({ piles: ['a', 'a'] })).toThrow();
    expect(() => new Zones({ piles: ['a'], draw: { from: 'a', to: 'b' as 'a' } })).toThrow(/unknown pile/);
    expect(() => new Zones({ piles: ['a'], reshuffle: { a: 'a' } })).toThrow();
    expect(() => new Zones({ piles: ['a', 'b'], markets: { a: { from: 'b', slots: 0 } } })).toThrow();
  });
});

describe('Zones: a market row', () => {
  type MP = 'supply' | 'row' | 'mine' | 'gone';
  const items = Array.from({ length: 10 }, (_, i) => `c${i}`);

  it('slide: the rest move down, the new one comes in at the end; the price grows by slot', () => {
    const z = new Zones<string, MP>({ piles: ['supply', 'row', 'mine', 'gone'], markets: { row: { from: 'supply', slots: 4, decayTo: 'gone' } }, price: (_, slot) => 1 + slot });
    let s = z.start({ supply: items }, 2);
    expect(s.piles.row).toHaveLength(4);
    expect(s.piles.supply).toHaveLength(6);
    const [a, b, c, d] = s.piles.row;
    expect([0, 1, 2, 3].map((i) => z.price(s, 'row', i))).toEqual([1, 2, 3, 4]);
    s = z.take(s, 'row', 1, 'mine')!;
    expect(s.piles.mine).toEqual([b]);
    expect(s.piles.row.slice(0, 3)).toEqual([a, c, d]);
    expect(s.piles.row).toHaveLength(4);
    // the market decays: the oldest leaves, the row slides and refills
    s = z.decay(s, 'row');
    expect(s.piles.gone).toEqual([a]);
    expect(s.piles.row[0]).toBe(c);
    expect(z.take(s, 'row', 9, 'mine')).toBeNull();
    expect(Number.isNaN(z.price(s, 'row', 9))).toBe(true);
  });

  it('in-place: the new one takes the empty slot (and a dry supply leaves the row short)', () => {
    const z = new Zones<string, MP>({ piles: ['supply', 'row', 'mine', 'gone'], markets: { row: { from: 'supply', slots: 3, refill: 'in-place' } } });
    let s = z.start({ supply: items.slice(0, 4) }, 2);
    const [a, , c] = s.piles.row;
    const fresh = s.piles.supply[0];
    s = z.take(s, 'row', 1, 'mine')!;
    expect(s.piles.row).toEqual([a, fresh, c]);
    s = z.take(s, 'row', 0, 'mine')!;
    expect(s.piles.row).toEqual([fresh, c]);
  });

  it('a ring (Patchwork): take one of the next three, the pawn moves on past it', () => {
    const z = new Zones<string, 'ring' | 'mine'>({ piles: ['ring', 'mine'] });
    let s = z.start({ ring: ['a', 'b', 'c', 'd', 'e'] }, 1);
    expect(z.peek(s, 'ring', 3)).toEqual(['a', 'b', 'c']); // the ring isn't a draw pile: not shuffled
    s = z.rotate(z.move(s, 'ring', 1, 'mine')!, 'ring', 1);
    expect(s.piles.ring).toEqual(['c', 'd', 'e', 'a']);
  });
});

// --- A mini bag-builder: Quacks of Quedlinburg in 60 lines ------------------------------------------------------------

type Token = { kind: 'cherry' | 'pumpkin' | 'crow' | 'gold'; value: number };
const T = (kind: Token['kind'], value: number): Token => ({ kind, value });
const STARTING_BAG: Token[] = [T('cherry', 1), T('cherry', 1), T('cherry', 1), T('cherry', 1), T('cherry', 2), T('cherry', 2), T('cherry', 3), T('pumpkin', 1), T('crow', 1)];
const SHOP: Token[] = [T('pumpkin', 1), T('crow', 2), T('gold', 3), T('pumpkin', 1), T('crow', 1), T('gold', 2), T('pumpkin', 2), T('crow', 4)];
type BP = 'bag' | 'pot' | 'shop' | 'row';
/** The pot explodes when its cherry bombs add up past 7 */
const bomb = (pot: readonly Token[]) => pot.filter((t) => t.kind === 'cherry').reduce((s, t) => s + t.value, 0) > 7;
const quacks = () =>
  new Zones<Token, BP>({
    piles: ['bag', 'pot', 'shop', 'row'],
    blind: ['bag'],
    draw: { from: 'bag', to: 'pot' },
    bust: { pile: 'pot', when: bomb },
    markets: { row: { from: 'shop', slots: 3 } },
    price: (t, slot) => t.value * 2 + slot,
  });
const potScore = (pot: readonly Token[]) => pot.reduce((s, t) => s + (t.kind === 'cherry' ? 0 : t.value * (t.kind === 'gold' ? 3 : 1)), 0) + pot.length;

/** One night: draw while the bust chance is under `nerve`; a bust may be taken back once (the rewarded second chance) */
function night(z: Zones<Token, BP>, s: ZonesState<Token, BP>, nerve: number, secondChance: boolean): { s: ZonesState<Token, BP>; score: number; bust: boolean; saved: boolean } {
  let saved = false;
  while (z.size(s, 'bag') && z.bustChance(s) < nerve) {
    s = z.draw(s);
    if (z.busted(s) && secondChance && !saved) {
      s = z.undoDraw(s)!;
      saved = true;
      break; // the bomb went back into the bag: stop while ahead
    }
    if (z.busted(s)) break;
  }
  const bust = z.busted(s);
  return { s, score: bust ? 0 : potScore(s.piles.pot), bust, saved };
}

describe('Zones: a bag-builder round (push your luck)', () => {
  it('the bag is shown as counts, never as an order', () => {
    const z = quacks();
    const s = z.start({ bag: STARTING_BAG, shop: SHOP }, 4);
    expect(z.counts(s, 'bag')).toEqual({ cherry: 7, crow: 1, pumpkin: 1 });
    expect(z.peek(s, 'bag', 3)).toEqual([]);
    expect(s.piles.bag).toEqual(STARTING_BAG); // a blind pile isn't shuffled: it is drawn at random
  });

  it("bustChance() is exact: it matches the measured rate of busting, over many seeded nights", () => {
    const z = quacks();
    // a pot one bomb short: 6 cherries in, the bag holds the 2 and the 3 and two safe tokens
    let s = z.start({ bag: [T('cherry', 2), T('cherry', 3), T('pumpkin', 1), T('crow', 1)], pot: [T('cherry', 3), T('cherry', 3)] }, 1);
    expect(z.bustChance(s)).toBe(0.5);
    // within two draws: 1 − P(both safe) = 1 − (2/4 · 1/3)
    expect(z.bustChance(s, 2)).toBeCloseTo(1 - (2 / 4) * (1 / 3), 10);
    let busts = 0;
    const N = 4000;
    for (let seed = 0; seed < N; seed++) {
      s = { ...s, rng: seed * 2654435761 };
      if (z.busted(z.draw(s))) busts++;
    }
    expect(Math.abs(busts / N - 0.5)).toBeLessThan(0.03);
    expect(z.bustChance({ ...s, piles: { ...s.piles, bag: [] } })).toBe(0);
  });

  /** Five nights; after each the pot goes back into the bag and the coins buy the dearest token they reach */
  function run(seed: number): { s: ZonesState<Token, BP>; log: string[] } {
    const z = quacks();
    let s = z.start({ bag: STARTING_BAG, shop: SHOP }, seed);
    let coins = 0;
    let usedChance = false;
    const log: string[] = [];
    for (let n = 1; n <= 5; n++) {
      const r = night(z, s, 0.35, !usedChance);
      usedChance ||= r.saved;
      coins += r.score;
      log.push(`${n}:${r.bust ? 'bust' : r.score}${r.saved ? '*' : ''}`);
      s = z.moveAll(r.s, 'pot', 'bag');
      for (let slot = z.size(s, 'row') - 1; slot >= 0; slot--) {
        if (z.price(s, 'row', slot) <= coins) {
          coins -= z.price(s, 'row', slot);
          s = z.take(s, 'row', slot, 'bag')!;
          break;
        }
      }
    }
    return { s, log };
  }

  it('a whole run: nights of draws, a second chance once, the score buys tokens from the market into the bag', () => {
    const z = quacks();
    const { s, log } = run(20261019);
    expect(z.size(s, 'bag') + z.size(s, 'row') + z.size(s, 'shop')).toBe(STARTING_BAG.length + SHOP.length);
    expect(z.size(s, 'bag')).toBeGreaterThan(STARTING_BAG.length); // the build grew
    // this seed's story: four good nights, the 4th saved by the second chance, then a bust the chance can't save
    expect(log).toEqual(['1:8', '2:6', '3:8', '4:6*', '5:bust']);
    // the same seed plays the same run; another seed another
    expect(run(20261019)).toEqual({ s, log });
    expect(run(1).s).not.toEqual(s);
  });

  it('the second chance takes the bomb back, and the next draw is a new one (the rng moved on)', () => {
    const z = quacks();
    let s = z.start({ bag: [T('cherry', 3), T('cherry', 3), T('pumpkin', 1), T('pumpkin', 1), T('crow', 1)], pot: [T('cherry', 3), T('cherry', 2)] }, 9);
    let seed = 0;
    while (!z.busted(z.draw({ ...s, rng: seed }))) seed++;
    s = z.draw({ ...s, rng: seed });
    expect(z.busted(s)).toBe(true);
    const saved = z.undoDraw(s)!;
    expect(z.busted(saved)).toBe(false);
    expect(z.counts(saved, 'bag')).toEqual({ cherry: 2, crow: 1, pumpkin: 2 });
    expect(saved.rng).toBe(s.rng);
  });

  it('a mid-night save (JSON) loads and draws exactly what it would have drawn', () => {
    const z = quacks();
    let s = z.draw(z.start({ bag: STARTING_BAG, shop: SHOP }, 77), 2);
    const loaded = z.sanitize(JSON.parse(JSON.stringify(s)));
    expect(loaded).toEqual(s);
    expect(z.draw(loaded, 3)).toEqual(z.draw(s, 3));
    expect(z.undoDraw(loaded)).toEqual(z.undoDraw(s));
    s = z.draw(s, 1);
    // broken saves come back safe
    const junk = z.sanitize({ piles: { bag: 'x', pot: [T('crow', 1), undefined], ghost: [1] }, rng: -4, last: { from: 'bag', to: 'pot', n: 9, at: [] } }, 5);
    expect(junk).toEqual({ piles: { bag: [], pot: [T('crow', 1)], shop: [], row: [] }, rng: 5, last: null });
    expect(z.sanitize(null).piles.bag).toEqual([]);
  });

  it('the run is seeded by its own rng: a seededRng run seed gives the same start', () => {
    const seed = seededRng(42).int(2 ** 31);
    expect(quacks().start({ bag: STARTING_BAG, shop: SHOP }, seed)).toEqual(quacks().start({ bag: STARTING_BAG, shop: SHOP }, seed));
  });
});
