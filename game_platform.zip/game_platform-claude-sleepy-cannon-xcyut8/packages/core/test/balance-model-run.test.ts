// A run-shaped balance model (game.yaml balance.anchor.shape: run, or the model's `shape: 'run'`): a roguelite's waves
// walked as runs from the first stage, the purchases between runs, the run's checks in place of the campaign's.

import { describe, expect, it } from 'vitest';
import { runAt, solveModel, walkModel, type BalanceModel } from '../src/balance-model.ts';

/** A roguelite: 20 waves a run (a boss every 5th), a fresh hero clears about 6 of them; 12 upgrades bought between runs */
function arena(over: Partial<BalanceModel> = {}): BalanceModel {
  const stages = Array.from({ length: 20 }, (_, i) => {
    const w = i + 1;
    const boss = w % 5 === 0;
    return { id: `wave-${w}`, difficulty: 3 + 0.6 * w + (boss ? 0.6 : 0), reward: 4 + w + (boss ? 10 : 0), minutes: 0.6, ...(boss ? { kind: 'boss' as const } : {}) };
  });
  // Each part is a new thing for the player (news), every 4th a big unlock
  const items = Array.from({ length: 12 }, (_, i) => ({ id: `part-${i + 1}`, cost: Math.round(20 * 1.25 ** i), mult: 1.07, news: { kind: i % 4 === 3 ? ('unlock' as const) : ('item' as const) } }));
  return { start: { power: 10 }, stages, items, measure: 'waves a run', overheadMin: 0.2, sessionMin: 20, shape: 'run', ...over };
}
const RUN_ANCHOR = { name: 'waves a run', unit: 'waves', says: 'how many of the 20 waves a run clears', shape: 'run' as const };
const status = (r: ReturnType<typeof solveModel>, name: string) => r.checks.find((c) => c.name === `model: ${name}`)?.status;
const failures = (r: ReturnType<typeof solveModel>) => r.checks.filter((c) => c.status === 'fail').map((c) => `${c.name}: ${c.detail}`).join('\n');

describe('a run-shaped model (balance.anchor.shape: run)', () => {
  it('a run at a power, in expected values: each stage reached by clearing all before it', () => {
    // Two stages won half the time: the second is reached half the time, both cleared a quarter of the time
    const m: BalanceModel = { start: { power: 1 }, stages: [{ id: 'a', difficulty: 1, reward: 10, minutes: 1 }, { id: 'b', difficulty: 1, reward: 20, minutes: 2 }], items: [], overheadMin: 0, lossReward: 0, deathShare: 0.5 };
    const r = runAt(m, 1);
    expect(r.depth).toBeCloseTo(0.75);
    expect(r.win).toBeCloseTo(0.25);
    expect(r.reach).toEqual([1, 0.5]);
    // a: 1 × 1 × (0.5 + 0.5 × 0.5) min, b: 0.5 × 2 × (0.5 + 0.5 × 0.5) min
    expect(r.minutes).toBeCloseTo(0.75 + 0.75);
    expect(r.coins).toBeCloseTo(5 + 0.5 * 20 * 0.5);
  });

  it("a paced roguelite passes the strict checks; the campaign's per-stage checks are left out, not failed", () => {
    const r = solveModel(arena(), { anchor: RUN_ANCHOR });
    expect(r.shape).toBe('run');
    expect(r.failed, failures(r)).toBe(0);
    for (const n of ['No grind', 'No stretch that plays itself', 'No hard streak', 'Stage time grows steadily']) {
      expect(status(r, n), n).toBe('skip');
      expect(r.checks.find((c) => c.name === `model: ${n}`)!.detail).toContain('not for a run');
    }
    for (const n of ['A first run shows the game', 'Progress carries into the run', 'A winning run fits the session', 'The runs get further in the first session', 'The first reward within a minute', 'The session ends with a goal in reach', 'The meta outlasts the session'])
      expect(status(r, n), n).toBe('ok');
    // The second run replays waves 1–6 before new ground: the run's own news (level-ups, drops) are not in the tables
    expect(status(r, 'A new thing every few minutes at first')).toBe('warn');
    // The report reads the depth of a run, fresh against fully progressed
    expect(r.report.measure).toContain('stages cleared a run');
    expect(r.report.full!).toBeGreaterThan(r.report.fresh! * 1.5);
    expect(r.run!.fresh.depth).toBeGreaterThan(4);
    expect(r.run!.winMinutes).toBeCloseTo(0.2 + 20 * 0.6);
    expect(r.cheap.runs!.length).toBe(r.cheap.attempts);
    expect(r.markdown).toContain('### Runs (cheapest-first player, expected values)');
    expect(r.markdown).toContain('Runs reaching it');
    // The same tables as a campaign: the per-stage checks are made
    const c = solveModel(arena({ shape: undefined }), { anchor: { ...RUN_ANCHOR, shape: 'campaign' } });
    expect(c.shape).toBe('campaign');
    expect(status(c, 'No hard streak')).not.toBe('skip');
    expect(c.run).toBeNull();
  });

  it("game.yaml's shape wins over the model's; the model's own shape counts without an anchor; without one the run checks warn", () => {
    expect(solveModel(arena()).shape).toBe('run');
    expect(solveModel(arena(), { anchor: { ...RUN_ANCHOR, shape: 'campaign' } }).shape).toBe('campaign');
    expect(solveModel(arena({ shape: undefined }), { anchor: RUN_ANCHOR }).shape).toBe('run');
    expect(status(solveModel(arena({ start: { power: 3 } })), 'A first run shows the game')).toBe('warn');
    expect(status(solveModel(arena({ start: { power: 3 } }), { anchor: RUN_ANCHOR }), 'A first run shows the game')).toBe('fail');
  });

  it('a stage won 99.9 % of the time is cleared in the first run, at its minute of that run', () => {
    const r = walkModel(arena(), 'cheapest');
    expect(r.timeline[0]).toMatchObject({ id: 'wave-1', what: 'stage' });
    expect(r.timeline[0].min).toBeCloseTo(0.2 + 0.6);
    expect(r.stages[0]).toMatchObject({ arriveMin: 0.2, attempts: 1 });
    expect(r.farmMin).toBe(0);
  });

  it('a meta that adds nothing to the run, a winning run longer than the session, a first run over at once: each fails', () => {
    const weak = solveModel(arena({ items: arena().items.map((i) => ({ ...i, mult: 1.005 })) }), { anchor: RUN_ANCHOR });
    expect(status(weak, 'Progress carries into the run')).toBe('fail');
    expect(status(weak, 'The runs get further in the first session')).toBe('fail');
    const long = solveModel(arena({ stages: arena().stages.map((s) => ({ ...s, minutes: 2 })) }), { anchor: RUN_ANCHOR });
    expect(status(long, 'A winning run fits the session')).toBe('fail');
    expect(long.checks.find((c) => c.name === 'model: A winning run fits the session')!.detail).toContain('40.2 min');
    expect(status(solveModel(arena({ start: { power: 2 } }), { anchor: RUN_ANCHOR }), 'A first run shows the game')).toBe('fail');
  });

  it("the meta of a run is its purchases; finish 'stages' waits for a first win, and a win never in reach is stuck", () => {
    const items = walkModel(arena(), 'cheapest');
    expect(items.stuck).toBeNull();
    expect(items.items.every((i) => i.boughtMin !== null)).toBe(true);
    const lastRun = items.runs!.at(-1)!;
    expect(items.finishMin).toBeCloseTo(lastRun.startMin + lastRun.minutes);
    const win = walkModel(arena({ finish: 'stages', maxMinutes: 120, start: { power: 5 }, items: [] }), 'cheapest');
    expect(win.stuck).toMatch(/wave-\d+: not yet cleared by half the players/);
    const easy = walkModel(arena({ finish: 'stages', start: { power: 40 } }), 'cheapest');
    expect(easy.stuck).toBeNull();
    expect(easy.stages.at(-1)!.clearedMin).not.toBeNull();
  });
});
