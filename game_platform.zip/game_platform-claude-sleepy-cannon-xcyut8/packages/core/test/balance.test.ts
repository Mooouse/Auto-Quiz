// The balance evaluator (balance.ts) on the numbers the games reported.
import { describe, expect, it } from 'vitest';
import { balanceTargets, evaluateBalance, meanCurve, offerLog, type BalanceReport } from '../src/balance.ts';

const status = (r: BalanceReport) => Object.fromEntries(evaluateBalance(r, 'crazygames').rows.map((x) => [x.name, x.status]));

describe('evaluateBalance', () => {
  it('a healthy curve passes (Starsilk, 2026-09-30: depth 1 in ≤ 2 tries, 24–30 min, a careful buyer no faster)', () => {
    const v = evaluateBalance({
      measure: 'depths cleared',
      fresh: 2,
      full: 10,
      cheap: { firstPurchaseRun: 1, finishMin: 27, goalsMin: [2.1, 4, 6.5, 9, 12, 15, 18, 21, 24, 27] },
      careful: { firstPurchaseRun: 1, finishMin: 26 },
      dead: [],
      offers: [1, 2, 3].map((stage) => ({ stage, ids: Array.from({ length: 30 }, (_, i) => `u${(i * 7 + stage) % 20}`) })),
    });
    expect(v.ok).toBe(true);
    expect(v.warned).toBe(0);
    // The curve's eight rows are ok; the decision rows (skills, choices, builds, stages) are not reported here
    expect(v.rows.filter((r) => r.status !== 'skip').map((r) => r.status)).toEqual(Array(8).fill('ok'));
    expect(v.markdown).toContain('| ✅ | The meta lasts |');
  });
  it('fails only where the numbers are unambiguous', () => {
    // Everything bought in 2 minutes; never a first purchase for the careful one; a purchase that does nothing
    expect(status({ cheap: { firstPurchaseRun: 1, finishMin: 2 } })['The meta lasts']).toBe('fail');
    expect(status({ cheap: { firstPurchaseRun: null, finishMin: null } })['The first purchase comes early']).toBe('fail');
    expect(status({ cheap: { firstPurchaseRun: 8, finishMin: 30 } })['The first purchase comes early']).toBe('fail');
    expect(status({ dead: ['magnet'] })['Every purchase changes something']).toBe('fail');
    expect(status({ fresh: 0.5, full: 0.4 })['Fully progressed is clearly stronger']).toBe('fail');
    expect(status({ cheap: { firstPurchaseRun: 1, finishMin: 90 }, careful: { firstPurchaseRun: 1, finishMin: 30 } })['No trap, no dominant pick']).toBe('fail');
    expect(status({ cheap: { firstPurchaseRun: 1, finishMin: null }, careful: { firstPurchaseRun: 1, finishMin: 30 } })['No trap, no dominant pick']).toBe('fail');
    // Cheapest-first finishes, the careful buyer never does: the value measure is off (not "neither finished")
    const r = evaluateBalance({ cheap: { firstPurchaseRun: 1, finishMin: 30 }, careful: { firstPurchaseRun: 1, finishMin: null } }).rows.find((x) => x.name === 'No trap, no dominant pick')!;
    expect(r.status).toBe('warn');
    expect(r.detail).toMatch(/careful never.*value measure is off/);
    expect(status({ cheap: { firstPurchaseRun: 1, finishMin: null }, careful: { firstPurchaseRun: 1, finishMin: null } })['No trap, no dominant pick']).toBe('skip');
  });
  it('warns where a curve is only doubtful', () => {
    const s = status({
      fresh: 10,
      full: 12,
      cheap: { firstPurchaseRun: 3, finishMin: 8, goalsMin: [4, 14] },
      careful: { firstPurchaseRun: 3, finishMin: 5 },
    });
    expect(s).toMatchObject({
      'The first purchase comes early': 'warn',
      'The first new thing arrives soon': 'warn',
      'The meta lasts': 'warn',
      'No long stretch without a new thing': 'warn',
      'Fully progressed is clearly stronger': 'warn',
      'No trap, no dominant pick': 'warn',
    });
    expect(status({ cheap: { firstPurchaseRun: 1, finishMin: null } })['The meta lasts']).toBe('warn'); // endless, or out of reach
    expect(status({ fresh: 3, full: 3 })['Fully progressed is clearly stronger']).toBe('warn'); // sideways unlocks: say so
  });
  it('the late run still offers variety: warns when the late stages\' offers collapse to a few (Frankengun\'s "the same six upgrades")', () => {
    const POOL = Array.from({ length: 20 }, (_, i) => `part${i}`);
    // 3 seeds × 3 offers × 3 cards per wave: 27 cards each
    const wave = (w: number, pool: readonly string[]) => ({ stage: `wave ${w}`, ids: Array.from({ length: 27 }, (_, i) => pool[(i * 7 + w) % pool.length]!) });
    const healthy = Array.from({ length: 12 }, (_, i) => wave(i + 1, POOL));
    const row = (r: BalanceReport) => evaluateBalance(r).rows.find((x) => x.name === 'The late run still offers variety')!;
    expect(row({ offers: healthy }).status).toBe('ok');
    expect(row({ offers: healthy }).detail).toMatch(/^late \(stages wave 9–wave 12\): 20 distinct; the most earlier: 20$/);
    // Waves 9–12 draw from six parts only: a warning that names the worst stage and its repeats
    const collapsed = healthy.map((s, i) => (i >= 8 ? wave(i + 1, POOL.slice(0, 6)) : s));
    const r = row({ offers: collapsed });
    expect(r.status).toBe('warn');
    expect(r.detail).toMatch(/late \(stages wave 9–wave 12\): 6 distinct; the most earlier: 20 — stage wave 9 offered 6 distinct in 27 cards \(part\d+ ×\d+/);
    expect(evaluateBalance({ offers: collapsed }).ok).toBe(true); // never a failure
    // Few cards shown (one 3-card offer a stage): the floor of 8 can't apply, only the collapse against earlier stages
    const small = [1, 2, 3, 4, 5, 6].map((w) => ({ stage: w, ids: [`a${w}`, `b${w}`, `c${w}`] }));
    expect(row({ offers: small }).status).toBe('ok');
    expect(row({ offers: [...small.slice(0, 4), { stage: 5, ids: ['x', 'x', 'x'] }, { stage: 6, ids: ['x', 'y', 'x'] }] }).status).toBe('warn');
    expect(row({}).status).toBe('skip');
    // offerLog: by stage, in the order they came, repeats kept
    const log = offerLog();
    log.add(1, ['a', 'b']);
    log.add(2, ['a']);
    log.add(1, ['a']);
    expect(log.stages()).toEqual([{ stage: 1, ids: ['a', 'b', 'a'] }, { stage: 2, ids: ['a'] }]);
  });
  it('skips what the game did not report', () => {
    const v = evaluateBalance({});
    expect(v.ok).toBe(true);
    expect(v.rows.every((r) => r.status === 'skip')).toBe(true);
  });
  it('meanCurve: averages seeds; one seed that never finished makes it null', () => {
    const m = meanCurve([
      { firstPurchaseRun: 1, finishMin: 20, goalsMin: [1, 5, 9] },
      { firstPurchaseRun: 2, finishMin: 30, goalsMin: [2, 6] },
    ]);
    expect(m).toEqual({ firstPurchaseRun: 1.5, firstPurchaseMin: null, finishMin: 25, finishRun: null, goalsMin: [1.5, 5.5] });
    expect(meanCurve([{ firstPurchaseRun: 1, finishMin: 20 }, { firstPurchaseRun: 1, finishMin: null }]).finishMin).toBeNull();
  });
  it('targets per channel; an unknown channel gets the portal\'s', () => {
    expect(balanceTargets('crazygames').firstPurchaseRuns).toBe(2);
    expect(balanceTargets('nowhere')).toEqual(balanceTargets('crazygames'));
  });
});
