// The concepts already live on the portal (taken.ts): a pitch that matches one is flagged by gp uniqueness

import { describe, expect, it } from 'vitest';
import { takenConceptsFor } from '../src/taken.ts';

describe('taken concepts', () => {
  it('flags a pulse running through a board of parts (Pulseboard, found by Kettlebot)', () => {
    const ids = takenConceptsFor('A pulse runs through the parts of your board and each component fires in turn').map((c) => c.id);
    expect(ids).toContain('pulse-circuit');
  });
  it("doesn't flag Kettlebot's own heat-routing pitch", () => {
    const ids = takenConceptsFor("Build a little scrap robot's body from salvaged parts on a grid; every part heats the parts it touches, and an overheated part bursts and grows back mutated.").map((c) => c.id);
    expect(ids).not.toContain('pulse-circuit');
  });
  it("doesn't flag a remade game's own concept after a rename: the id still says it's ours (Petri Defense, id germ-bait)", () => {
    const text = 'Lure the germs with sugar into the acid';
    const id = takenConceptsFor(text).find((c) => c.titles.includes('Germ Bait (ours)'))?.id;
    expect(id).toBeTruthy();
    expect(takenConceptsFor(text, 'Petri Defense').map((c) => c.id)).toContain(id);
    expect(takenConceptsFor(text, 'Petri Defense', 'germ-bait').map((c) => c.id)).not.toContain(id);
  });
  it('flags a heist arena: steal from rival bases and carry it home (Steal Brainrot Online, found for game6)', () => {
    expect(takenConceptsFor("Sneak into rival raccoons' dens, grab the trash they hoard and carry the stack home").map((c) => c.id)).toContain('steal-base');
  });
});
