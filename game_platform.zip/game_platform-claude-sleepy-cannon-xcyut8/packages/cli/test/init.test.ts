// gp init: the repository it makes, and its scripts/gp.sh — one game or several, and the commands that take no game.

import { execFileSync } from 'node:child_process';
import { cpSync, existsSync, mkdtempSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { missingDependencies } from '../src/deps.ts';
import { engineChecks, physicsChecks } from '../src/game.ts';
import { ROOT } from '../src/paths.ts';

const tmp = mkdtempSync(join(tmpdir(), 'gp-init-'));
const repo = join(tmp, 'lantern-repo');
afterAll(() => rmSync(tmp, { recursive: true, force: true }));

const env = { ...process.env, GP_NO_LOG: '1', NO_COLOR: '1', GP_PLATFORM: ROOT };
function run(file: string, args: string[], cwd = repo): { code: number; out: string } {
  try {
    return { code: 0, out: execFileSync(file, args, { cwd, encoding: 'utf8', env, stdio: ['ignore', 'pipe', 'pipe'] }) };
  } catch (e) {
    const x = e as { status: number; stdout: string; stderr: string };
    return { code: x.status, out: x.stdout + x.stderr };
  }
}
const gpsh = (...args: string[]) => run('bash', [join(repo, 'scripts/gp.sh'), ...args]);

beforeAll(() => {
  const r = run(process.execPath, [join(ROOT, 'packages/cli/src/gp.ts'), 'init', repo, '--id', 'lantern-walk', '--title', "Lantern's Walk"], tmp);
  expect(r.code, r.out).toBe(0);
});

describe('gp init', () => {
  it('writes the skeleton with the id and title filled in, scripts executable', () => {
    const yaml = readFileSync(join(repo, 'games/lantern-walk/game.yaml'), 'utf8');
    expect(yaml).toContain('id: lantern-walk');
    expect(yaml).toContain(`"Lantern's Walk"`);
    expect(existsSync(join(repo, 'games/__ID__'))).toBe(false);
    for (const s of ['gp.sh', 'setup.sh']) expect(statSync(join(repo, 'scripts', s)).mode & 0o111).not.toBe(0);
    // Refuses a folder that isn't empty
    expect(run(process.execPath, [join(ROOT, 'packages/cli/src/gp.ts'), 'init', repo, '--id', 'other'], tmp).code).toBe(1);
  });
});

describe('scripts/gp.sh', () => {
  it('runs a command on the only game, and the commands without a game without one', () => {
    const v = gpsh('validate', '--json');
    // The template's concept and money are TODO: validate refuses them, on this game
    expect(v.code).toBe(1);
    expect(v.out).toContain('E_CONCEPT');
    const ex = gpsh('explain', 'money');
    expect(ex.code, ex.out).toBe(0);
    expect(ex.out).not.toContain('Nothing known');
    expect(gpsh('forecast', '--idea', '--channel', 'crazygames', '--genre', 'idle').code).toBe(0);
    expect(gpsh('catalog', 'kit').code).toBe(0);
  });

  it('with several games: asks which, and takes an id or a path', () => {
    cpSync(join(repo, 'games/lantern-walk'), join(repo, 'games/second-game'), { recursive: true });
    const f = join(repo, 'games/second-game/game.yaml');
    writeFileSync(f, readFileSync(f, 'utf8').replace('id: lantern-walk', 'id: second-game'));
    const which = gpsh('validate');
    expect(which.code).toBe(1);
    expect(which.out).toContain('Several games here');
    expect(which.out).toContain('lantern-walk second-game');
    const byId = gpsh('validate', 'second-game');
    expect(byId.out).toContain(join('games', 'second-game', 'game.yaml'));
    expect(byId.out).not.toContain(join('games', 'lantern-walk', 'game.yaml'));
    const byPath = run('bash', [join(repo, 'scripts/gp.sh'), 'validate', 'lantern-walk'], join(repo, 'games'));
    expect(byPath.out).toContain(join('games', 'lantern-walk', 'game.yaml'));
    const relPath = run('bash', [join(repo, 'scripts/gp.sh'), 'validate', './second-game'], join(repo, 'games'));
    expect(relPath.out).toContain(join('games', 'second-game', 'game.yaml'));
    expect(gpsh('explain', 'E_CONCEPT').code).toBe(0);
  });
});

describe('gp init --engine', () => {
  const gp = (args: string[]) => run(process.execPath, [join(ROOT, 'packages/cli/src/gp.ts'), ...args], tmp);
  const TEMPLATE_MAIN = readFileSync(join(ROOT, 'templates/game-repo/games/__ID__/main.ts'), 'utf8');

  it('default: the Canvas 2D skeleton as it is, game.yaml names the engine, no package.json', () => {
    const yaml = readFileSync(join(repo, 'games/lantern-walk/game.yaml'), 'utf8');
    expect(yaml).toContain('engine: { name: canvas }');
    expect(existsSync(join(repo, 'games/lantern-walk/package.json'))).toBe(false);
    expect(existsSync(join(repo, 'games/lantern-walk/view.ts'))).toBe(false);
    expect(existsSync(join(repo, 'engines'))).toBe(false);
    expect(readFileSync(join(repo, 'games/lantern-walk/main.ts'), 'utf8')).toContain("canvas.getContext('2d')");
  });

  for (const [engine, pkg, version] of [
    ['pixi', 'pixi.js', '8.21.0'],
    ['phaser', 'phaser', '4.2.1'],
    ['three', 'three', '0.186.1'],
  ]) {
    it(`--engine ${engine}: main.ts and view.ts through the adapter, ${pkg} ${version} pinned, game.yaml engine section`, () => {
      const dir = join(tmp, `repo-${engine}`);
      const r = gp(['init', dir, '--id', `${engine}-game`, '--title', `The ${engine} game`, '--engine', engine]);
      expect(r.code, r.out).toBe(0);
      expect(r.out).toContain(`${pkg} ${version} is pinned`);
      const game = join(dir, 'games', `${engine}-game`);
      const main = readFileSync(join(game, 'main.ts'), 'utf8');
      const view = readFileSync(join(game, 'view.ts'), 'utf8');
      expect(main).toContain("from './view.ts'");
      expect(main).not.toContain('getContext(');
      expect(main).not.toContain('requestAnimationFrame');
      expect(view).toContain(`from '@gp/core/engines/${engine}'`);
      expect(view).toContain(`from '${pkg}'`);
      for (const t of [main, view]) expect(t).not.toMatch(/__(ENGINE|ENGINE_ID|TITLE|ID)__/);
      const json = JSON.parse(readFileSync(join(game, 'package.json'), 'utf8')) as { dependencies: Record<string, string>; devDependencies?: Record<string, string> };
      expect(json.dependencies).toEqual({ [pkg]: version });
      if (engine === 'three') expect(json.devDependencies).toEqual({ '@types/three': '0.186.0' });
      expect(readFileSync(join(game, 'game.yaml'), 'utf8')).toContain(`engine: { name: ${engine}, version: ${version} }`);
      expect(existsSync(join(dir, 'engines'))).toBe(false);
      // gp validate takes the engine section (the template's TODO concept is its only error), and the pins agree with
      // package.json (not installed: no network in tests — W_DEPS_MISSING once the concept is written)
      const v = run('bash', [join(dir, 'scripts/gp.sh'), 'validate', '--json'], dir);
      const issues = (JSON.parse(v.out) as { issues: { code: string }[] }).issues.map((i) => i.code);
      expect(issues.filter((c) => c.includes('ENGINE'))).toEqual(engine === 'three' ? ['I_ENGINE_WEBGL2'] : []);
      const loc = { id: `${engine}-game`, dir: game, file: join(game, 'game.yaml') };
      expect(engineChecks(loc, { name: engine, version, package: pkg })).toEqual([]);
      expect(missingDependencies(loc)).toEqual([pkg]);
    });
  }

  it('the engine skeleton keeps the QA contract of the Canvas one (every data-gp hook and host call)', () => {
    const ENGINE_MAIN = readFileSync(join(ROOT, 'templates/game-repo/engines/main.ts'), 'utf8');
    const hooks = (t: string) => new Set([...t.matchAll(/gp: '([a-z-]+)'|dataset\.gp = '([a-z-]+)'|data-gp="([a-z-]+)"|host\.(\w+)\(/g)].map((m) => m[1] ?? m[2] ?? m[3] ?? `host.${m[4]}`));
    // What the adapter does for the engine skeleton (packages/core/src/engines/driver.ts): back from a pause it resumes
    // the run or redraws the still frame itself
    const ADAPTER_OWNS = new Set(['host.onResume']);
    const missing = [...hooks(TEMPLATE_MAIN)].filter((h) => !hooks(ENGINE_MAIN).has(h) && !ADAPTER_OWNS.has(h));
    expect(missing, 'templates/game-repo/engines/main.ts lost what games/__ID__/main.ts has: bring the change over').toEqual([]);
  });

  it('kaplay and unknown engines are refused with the reason', () => {
    const k = gp(['init', join(tmp, 'repo-kaplay'), '--id', 'kaplay-game', '--engine', 'kaplay']);
    expect(k.code).toBe(1);
    expect(k.out).toContain('Kaplay is not supported');
    expect(existsSync(join(tmp, 'repo-kaplay'))).toBe(false);
    expect(gp(['init', join(tmp, 'repo-x'), '--id', 'x-game', '--engine', 'babylon']).out).toContain('no adapter');
  });
});

describe('gp init --physics', () => {
  const gp = (args: string[]) => run(process.execPath, [join(ROOT, 'packages/cli/src/gp.ts'), ...args], tmp);
  const RAPIER = '@dimforge/rapier2d-compat';
  for (const [engine, extra] of [
    ['canvas', {}],
    ['pixi', { 'pixi.js': '8.21.0' }],
  ] as const) {
    it(`${engine === 'canvas' ? 'default (Canvas 2D)' : '--engine pixi'}: the sim on Rapier through @gp/physics, its WebAssembly awaited first, the -compat build pinned, the budget raised`, () => {
      const dir = join(tmp, `repo-physics-${engine}`);
      const r = gp(['init', dir, '--id', `${engine}-ball`, '--title', 'Ball Lab', ...(engine === 'canvas' ? [] : ['--engine', engine]), '--physics']);
      expect(r.code, r.out).toBe(0);
      expect(r.out).toContain(`${RAPIER} 0.21.0 through @gp/physics`);
      const game = join(dir, 'games', `${engine}-ball`);
      const read = (f: string) => readFileSync(join(game, f), 'utf8');
      const [main, view, sim, bot, test] = ['main.ts', 'view.ts', 'sim.ts', 'bot.ts', 'sim.test.ts'].map(read);
      // The engine skeleton for Canvas 2D too: the world steps on the adapter's fixed step, never on a loop of its own
      expect(main).toContain("from './view.ts'");
      expect(main).not.toMatch(/requestAnimationFrame|getContext\(/);
      expect(main.indexOf('await loadPhysics();')).toBeGreaterThan(0);
      expect(main.indexOf('await loadPhysics();')).toBeLessThan(main.indexOf('await createView('));
      expect(view).toContain(`from '@gp/core/engines/${engine}'`);
      expect(view).toContain('platformOf');
      expect(sim).toContain(`from '${RAPIER}'`);
      expect(sim).toContain("from '@gp/physics'");
      expect(sim).toContain('p.reset()');
      expect(bot).toContain('export async function balance(): Promise<BalanceReport> {\n  // The bot plays');
      expect(bot).toContain('await loadPhysics();');
      expect(test).toContain('beforeAll(loadPhysics);');
      expect(test).toContain('evaluateBalance(await balance(),');
      for (const t of [main, view, sim, bot, test]) expect(t).not.toMatch(/__(ENGINE|ENGINE_ID|TITLE|ID)__/);
      const json = JSON.parse(read('package.json')) as { dependencies: Record<string, string> };
      expect(json.dependencies).toEqual({ ...extra, [RAPIER]: '0.21.0' });
      const yaml = read('game.yaml');
      expect(yaml).toContain(`engine: { name: ${engine}, ${engine === 'pixi' ? 'version: 8.21.0, ' : ''}physics: { name: rapier2d, version: 0.21.0 } }`);
      expect(yaml).toContain('\nbudget: { gzipKB: 1500 }\n');
      expect(existsSync(join(dir, 'physics'))).toBe(false);
      // gp validate takes it: no physics issue (the budget is raised), the pins agree (not installed: W_DEPS_MISSING)
      const v = run('bash', [join(dir, 'scripts/gp.sh'), 'validate', '--json'], dir);
      const issues = (JSON.parse(v.out) as { issues: { code: string }[] }).issues.map((i) => i.code);
      expect(issues.filter((c) => /PHYSICS|ENGINE|BUDGET/.test(c))).toEqual([]);
      const loc = { id: `${engine}-ball`, dir: game, file: join(game, 'game.yaml') };
      expect(physicsChecks(loc, { name: 'rapier2d', version: '0.21.0', package: RAPIER })).toEqual([]);
      expect(missingDependencies(loc).sort()).toEqual([...Object.keys(extra), RAPIER].sort());
    });
  }

  it('--physics=rapier2d-deterministic pins the deterministic build', () => {
    const dir = join(tmp, 'repo-physics-det');
    expect(gp(['init', dir, '--id', 'det-ball', '--physics=rapier2d-deterministic']).code).toBe(0);
    const game = join(dir, 'games', 'det-ball');
    expect(readFileSync(join(game, 'sim.ts'), 'utf8')).toContain("from '@dimforge/rapier2d-deterministic-compat'");
    expect(readFileSync(join(game, 'game.yaml'), 'utf8')).toContain('physics: { name: rapier2d-deterministic, version: 0.21.0 }');
    expect(JSON.parse(readFileSync(join(game, 'package.json'), 'utf8')).dependencies).toEqual({ '@dimforge/rapier2d-deterministic-compat': '0.21.0' });
  });

  it('refused with Phaser or three, and for a library the block doesn’t run — nothing written', () => {
    const p = gp(['init', join(tmp, 'repo-physics-phaser'), '--id', 'ph-ball', '--engine', 'phaser', '--physics']);
    expect(p.code).toBe(1);
    expect(p.out).toContain('Canvas 2D or Pixi');
    expect(p.out).toContain('Arcade');
    expect(gp(['init', join(tmp, 'repo-physics-three'), '--id', 'th-ball', '--engine', 'three', '--physics']).code).toBe(1);
    const b = gp(['init', join(tmp, 'repo-physics-box2d'), '--id', 'bx-ball', '--physics=box2d']);
    expect(b.code).toBe(1);
    expect(b.out).toContain('rapier2d');
    for (const d of ['repo-physics-phaser', 'repo-physics-three', 'repo-physics-box2d']) expect(existsSync(join(tmp, d))).toBe(false);
  });

  it("the physics sim keeps the plain sim's exports (main.ts, bot.ts and sim.test.ts use them unchanged)", () => {
    const exports = (t: string) => new Set([...t.matchAll(/^export (?:async )?(?:const|function|interface|type) (\w+)/gm)].map((m) => m[1]));
    const plain = exports(readFileSync(join(ROOT, 'templates/game-repo/games/__ID__/sim.ts'), 'utf8'));
    const physics = exports(readFileSync(join(ROOT, 'templates/game-repo/physics/sim.ts'), 'utf8'));
    expect([...plain].filter((e) => !physics.has(e))).toEqual([]);
    expect(physics).toContain('loadPhysics');
  });
});
