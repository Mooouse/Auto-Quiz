// The validator: the reference game passes and resolves to the original's exact values;
// each rule rejects what it should, with a code, a line and a fix.

import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import type { KidsConfig } from '@gp/kit-kids/meta';
import { ERRORS, musicIssues, sourceHasMusic, validateText } from '../src/index.ts';

const kids = (g: { kit: unknown }) => g.kit as KidsConfig;

const BALLOON = readFileSync(new URL('../../../docs/examples/kids/game.yaml', import.meta.url), 'utf8');
const PUBLISHER = { admob: { publisherId: 'pub-7106564298463512' }, developer: { name: 'Qma', email: 'a@b.c', website: 'https://qmacyber.github.io' } };

/** Replace one line of the reference game.yaml */
const edit = (from: string, to: string) => {
  expect(BALLOON).toContain(from);
  return BALLOON.replace(from, to);
};
const codes = (text: string, mode: 'dev' | 'release' = 'dev') => validateText(text, { mode, publisher: PUBLISHER }).issues.map((i) => i.code);

describe('balloon-pop (reference game)', () => {
  const r = validateText(BALLOON, { mode: 'dev', publisher: PUBLISHER });
  it('is valid', () => {
    expect(r.issues).toEqual([]);
    expect(r.ok).toBe(true);
  });
  it('resolves to the values of the original "Pop the balloon!" (src/config.ts, src/i18n.ts)', () => {
    const g = r.game!;
    expect(g.saveKey).toBe('balloonpop.save.v1');
    expect(g.round).toMatchObject({ goal: 15, maxOnScreen: 6, spawnEvery: [0.45, 0.95], prefill: 2, celebrateSec: 1.4, target: { radius: 0.105, min: 38, max: 92 } });
    expect(g.round!.trajectory).toEqual({ type: 'rise', time: [5.5, 7.5], sway: 0.15 });
    expect(g.ads!.policy).toEqual({ noAdsAfterLaunchSec: 60, firstAdAfterRound: 2, everyRounds: 2, minIntervalSec: 90, maxAdWaitSec: 120, testAdCloseSec: 5 });
    expect(g.ads!.admob).toMatchObject({ childDirected: true, underAgeOfConsent: true, maxAdContentRating: 'G', nonPersonalized: true, isTesting: true });
    expect(g.billing).toEqual({ product: 'remove_ads' });
    expect(g.minTouchPx).toBe(64);
    expect(kids(g).modes.map((m) => [m.id, m.items.length, m.show, m.pop])).toEqual([
      ['colors', 7, 'none', 'word'],
      ['numbers', 10, 'label', 'label'],
      ['letters', 26, 'label', 'label'],
      ['animals', 26, 'emoji', 'emoji'],
    ]);
    expect(kids(g).rewards.stickers).toHaveLength(24);
    expect(kids(g).strings.gatePrompt).toBe('For grown-ups. Tap the numbers:');
    expect(kids(g).privacyPolicyUrl).toBe('https://qmacyber.github.io/balloon-pop/privacy-policy.html');
  });
  it('dev builds always get Google test ad IDs', () => {
    expect(r.game!.android.admobAppId).toBe('ca-app-pub-3940256099942544~3347511713');
  });
});

describe('rules', () => {
  it('unknown field: suggests the right one, with a line number', () => {
    const v = validateText(edit('menu: { backgroundTargets: 4 }', 'menue: { backgroundTargets: 4 }'), { mode: 'dev' });
    const i = v.issues.find((x) => x.code === 'E_UNKNOWN_FIELD')!;
    expect(i.fix).toContain('"menu"');
    expect(i.line).toBe(BALLOON.split('\n').findIndex((l) => l.startsWith('menu:')) + 1);
  });
  it('unknown content pack: did you mean', () => {
    const v = validateText(edit('content: numbers-1-10-en', 'content: numbers-1-10'), { mode: 'dev' });
    expect(v.issues[0].code).toBe('E_REF_UNKNOWN');
    expect(v.issues[0].fix).toContain('numbers-1-10-en');
  });
  it('ad limits may not be looser than the channel', () => {
    expect(codes(edit('ads: { appId: auto, interstitial: auto }', 'ads: { appId: auto, interstitial: auto, limits: { minIntervalSec: 30 } }'))).toContain('E_ADS_LIMITS');
    // Families has no time path for the first ad: a game can't add one, however long
    expect(codes(edit('ads: { appId: auto, interstitial: auto }', 'ads: { appId: auto, interstitial: auto, limits: { firstAdAfterSec: 3600 } }'))).toContain('E_ADS_LIMITS');
  });
  it('.inf / .nan are rejected (they would switch the limits off at runtime)', () => {
    expect(codes(edit('ads: { appId: auto, interstitial: auto }', 'ads: { appId: auto, interstitial: auto, limits: { minIntervalSec: .inf } }'))).toContain('E_TYPE');
    expect(codes(edit('ads: { appId: auto, interstitial: auto }', 'ads: { appId: auto, interstitial: auto, limits: { minIntervalSec: .nan } }'))).toContain('E_TYPE');
  });
  it('targets too small for toddlers', () => {
    expect(codes(edit('target: { radius: 0.105, min: 38, max: 92 }', 'target: { radius: 0.105, min: 30, max: 92 }'))).toContain('E_TARGET_TOO_SMALL');
  });
  it('no voice for toddlers is an error', () => {
    expect(codes(edit('content: animals-en\n', 'content: animals-en\n    say: false\n'))).toContain('E_VOICE_REQUIRED');
  });
  it('a child audience needs the parent gate', () => {
    expect(codes(edit('menu: { backgroundTargets: 4 }', 'menu: { backgroundTargets: 4 }\nparentGate: false'))).toContain('E_PARENT_GATE_REQUIRED');
  });
  it('channel must match the audience', () => {
    expect(codes(edit('audience: ages-2-5', 'audience: general'))).toContain('E_CHANNEL_AUDIENCE');
    expect(codes(edit('channel: android-families', 'channel: android'))).toContain('E_CHANNEL_AUDIENCE');
  });
  it('Google Play title limit is an error on Android', () => {
    expect(codes(edit('title: "Pop the balloon!"', 'title: "Pop the balloon — the best toddler game"'))).toContain('E_TITLE_LONG');
  });
  it('an upper-case inline color list resolves to the palette (Colors mode keeps working)', () => {
    const inline =
      'items: [{ color: "#FF4B4B", word: red }, { color: "#FF9A1F", word: orange }, { color: "#FFD21F", word: yellow }, { color: "#45C74A", word: green }, { color: "#3478F6", word: blue }, { color: "#9A5AE6", word: purple }, { color: "#FF6FB5", word: pink }]';
    const v = validateText(edit('content: colors-en', inline), { mode: 'dev' });
    expect(v.ok).toBe(true);
    expect(kids(v.game!).modes[0].items[0].color).toBe('#ff4b4b');
    expect(kids(v.game!).modes[0].colorBound).toBe(true);
  });
  it('release builds need real AdMob IDs of this publisher', () => {
    expect(codes(BALLOON, 'release')).toContain('E_RELEASE_IDS');
    const other = edit('ads: { appId: auto, interstitial: auto }', 'ads: { appId: "ca-app-pub-1111111111111111~2222222222", interstitial: "ca-app-pub-1111111111111111/3333333333" }');
    expect(codes(other, 'release')).toContain('E_ADMOB_PUBLISHER');
    const own = edit('ads: { appId: auto, interstitial: auto }', 'ads: { appId: "ca-app-pub-7106564298463512~2222222222", interstitial: "ca-app-pub-7106564298463512/3333333333" }');
    const rel = validateText(own, { mode: 'release', publisher: PUBLISHER });
    expect(rel.ok).toBe(true);
    expect(rel.game!.ads!.admob!.interstitialId).toBe('ca-app-pub-7106564298463512/3333333333');
    expect(rel.game!.ads!.admob!.isTesting).toBe(false);
  });
  it('YAML syntax errors point to a line', () => {
    const v = validateText('spec: 0\nid: [unclosed\n', { mode: 'dev' });
    expect(v.issues[0].code).toBe('E_YAML');
    expect(v.issues[0].line).toBeGreaterThan(0);
  });
  it('every code the validator can report is in the error catalog', () => {
    const src = [...['resolve.ts', 'check-schema.ts', 'load.ts', 'index.ts', 'story-depth.ts', 'money.ts', 'results.ts', 'sound.ts', 'genres.ts'].map((f) => `../src/${f}`), '../../core/src/story.ts', '../../cli/src/story.ts', '../../core/src/i18n.ts', '../../cli/src/i18n.ts']
      .map((f) => readFileSync(new URL(f, import.meta.url), 'utf8'))
      .join('\n');
    const used = new Set([...src.matchAll(/'((?:E|W|I)_[A-Z_]+)'/g)].map((m) => m[1]));
    expect(used).toContain('E_STORY_SCENE_LONG'); // the story engine's codes are reported by gp validate too
    for (const c of used) expect(ERRORS, `missing ${c}`).toHaveProperty(c);
  });
});

describe('languages', () => {
  const CODE = readFileSync(new URL('../../../docs/examples/code/game.yaml', import.meta.url), 'utf8');
  const langs = (line: string) => CODE.replace(/^languages: .*$/m, line);
  it('default English only; a portal game is asked for the ten top languages (W_I18N_LANGS)', () => {
    const one = validateText(langs(''), { mode: 'dev' });
    expect(one.game!.languages).toEqual(['en']);
    const w = one.issues.find((i) => i.code === 'W_I18N_LANGS')!;
    expect(w.message).toContain('Spanish, Portuguese (Brazil), French, German, Russian, Turkish, Italian, Polish, Indonesian');
    expect(w.fix).toContain('gp translate');
    expect(validateText(CODE, { mode: 'dev' }).issues.map((i) => i.code)).not.toContain('W_I18N_LANGS');
    // Off the portals nobody asks
    expect(validateText(langs('').replace('channel: crazygames', 'channel: web'), { mode: 'dev' }).issues.map((i) => i.code)).not.toContain('W_I18N_LANGS');
  });
  it('English is required, each language once, only codes the platform knows; any case is the canonical code', () => {
    expect(codes(langs('languages: [es, de]'))).toContain('E_I18N_ENGLISH');
    expect(codes(langs('languages: [en, de, de]'))).toContain('E_I18N_LANGS');
    expect(codes(langs('languages: [en, xx]'))).toContain('E_ENUM');
    expect(validateText(langs('languages: [en, ja, ko, zh-CN]'), { mode: 'dev' }).game!.languages).toEqual(['en', 'ja', 'ko', 'zh-CN']);
  });
  it('the glossary is kept, trimmed, each name once', () => {
    expect(validateText(`${CODE}glossary: [" Everflame ", Everflame, Ambrose]\n`, { mode: 'dev' }).game!.glossary).toEqual(['Everflame', 'Ambrose']);
  });
});

describe('casual kit on CrazyGames', () => {
  const CASUAL = readFileSync(new URL('../../../docs/examples/casual.game.yaml', import.meta.url), 'utf8');
  const cedit = (from: string, to: string) => {
    expect(CASUAL).toContain(from);
    return CASUAL.replace(from, to);
  };
  it('the example is valid and resolves to the portal channel', () => {
    const r = validateText(CASUAL, { mode: 'dev' });
    expect(r.issues).toEqual([]);
    expect(r.game!.portal).toBe('crazygames');
    expect(r.game!.ads!.admob).toBeNull();
    expect(r.game!.ads!.policy).toMatchObject({ noAdsAfterLaunchSec: 180, firstAdAfterRound: 3, firstAdAfterSec: 300, everyRounds: 1, minIntervalSec: 180 });
    expect(r.game!.billing).toBeNull();
    expect(r.game!.minTouchPx).toBe(48);
    expect(r.game!.round).toMatchObject({ mechanic: 'tap-score', goal: { time: 45 } });
  });
  it('originality: a concept is required on CrazyGames, with 3+ closest games; a looks-only difference is flagged', () => {
    const c = (text: string) => validateText(text, { mode: 'dev' }).issues.map((i) => i.code);
    const start = CASUAL.indexOf('concept:');
    const end = CASUAL.indexOf('\n', CASUAL.indexOf('  different:'));
    const without = CASUAL.slice(0, start) + CASUAL.slice(end + 1);
    expect(c(without)).toContain('E_CONCEPT');
    const one = validateText(cedit('closest: ["Bubble Pop", "Balloon Popping", "Pop It Master"]', 'closest: ["Bubble Pop"]'), { mode: 'dev' }).issues;
    expect(one.some((i) => i.severity === 'error' && i.path.join('.') === 'concept.closest')).toBe(true);
    const looks = CASUAL.slice(0, CASUAL.indexOf('  different:')) + '  different: "A neon theme with cute characters and a new art style and music."' + CASUAL.slice(end);
    expect(c(looks)).toContain('W_CONCEPT_THEME');
    // Not reviewed on the kids channel: balloon-pop has no concept and stays valid
    expect(codes(BALLOON)).not.toContain('E_CONCEPT');
  });
  it('a concept that reads like a live one is flagged with the titles (Petri Panic would have been)', () => {
    const start = CASUAL.indexOf('concept:');
    const end = CASUAL.indexOf('\n', CASUAL.indexOf('  different:'));
    const petri = CASUAL.slice(0, start) + `concept:
  pitch: "A survivors-like: steer a cell through hordes of germs, auto-attack and pick level-up cards."
  closest: ["Vampire Survivors", "Survivor.io", "Brotato"]
  different: "Mutations change how the cell splits when it takes damage, so each run plays differently."` + CASUAL.slice(end);
    const issues = validateText(petri, { mode: 'dev' }).issues.filter((i) => i.code === 'W_CONCEPT_TAKEN');
    expect(issues).toHaveLength(1);
    expect(issues[0].message).toContain('Cell Survivor');
    expect(validateText(CASUAL, { mode: 'dev' }).issues.map((i) => i.code)).not.toContain('W_CONCEPT_TAKEN');
  });
  it('taken concepts: ordinary words don\'t trigger them', async () => {
    const { takenConceptsFor } = await import('../src/taken.ts');
    for (const text of ['Reach the top of the tower and push the crates', 'Arrows show the way; run out of time and you lose', 'Fill every cell of the grid with a number', 'A sort of racing game with balls', 'Hold the line against waves of robots'])
      expect(takenConceptsFor(text).map((t) => t.id), text).toEqual([]);
    expect(takenConceptsFor('Knock rival spinning tops out of the arena').map((t) => t.id)).toContain('spinning-tops');
    expect(takenConceptsFor('Pour and sort liquids between tubes').map((t) => t.id)).toContain('tube-sort');
  });
  it('taken concepts from the searches of games 6–11 are caught', async () => {
    const { takenConceptsFor } = await import('../src/taken.ts');
    const cases: [string, string][] = [
      ['Herd the rain clouds over thirsty fields', 'weather-puzzle'],
      ['Find the liar: one suspect is lying in every case', 'liar-deduction'],
      ['Draw a loop around the enemies with your mouse to trap them', 'cursor-lasso'],
      ['Walk the labyrinth with Ariadne\'s thread', 'labyrinth-thread'],
      ['Untangle the ropes before the timer runs out', 'rope-untangle'],
      ['Be the dark lord: defend your dungeon from raiding heroes with traps', 'villain-td'],
      ['Rotate tiles to build a maze the waves must walk', 'maze-td'],
      ['A twin-stick roguelike: clear the rooms of a dungeon', 'twin-stick-roguelike'],
      ['Hang weights on the rods of a mobile and keep it balanced', 'balance-mobile'],
      ['Lure the swarm with sugar into the acid', 'bait-swarm'],
      ['Drop fruits into a jar and merge equal ones', 'drop-merge'],
    ];
    for (const [text, id] of cases) expect(takenConceptsFor(text).map((t) => t.id), text).toContain(id);
  });
  it('taken concepts: words far apart or in a negation are not a match (Nimbus Drift, Hang the Moon, Starsilk)', async () => {
    const { takenConceptsFor, withoutNegations } = await import('../src/taken.ts');
    const ids = (text: string) => takenConceptsFor(text).map((t) => t.id);
    // Nimbus Drift's first wording: "merge" and "drop" in different parts of the text are not a drop-and-merge puzzle
    expect(ids('Every swipe moves all clouds at once; on storm levels clouds that collide merge into storms that pour double, and each field shows the drops it needs')).not.toContain('drop-merge');
    // Hang the Moon: what the game is NOT
    expect(ids('Nothing is dropped, stacked or merged: you pick the hook for each piece of a fixed queue')).toEqual([]);
    // Starsilk: "never draw with a cursor", then what it does
    expect(ids('You never draw with a cursor: a thread lies wherever your walking body goes')).not.toContain('cursor-lasso');
    // A negation ends with its clause: what follows still counts
    expect(ids('No timer. Drop fruits into a jar and merge them')).toContain('drop-merge');
    expect(ids('A merge puzzle where you drop fruits, with no timer')).toContain('drop-merge');
    expect(withoutNegations('Shadows can\'t cross it, so you herd them').replace(/\s+/g, ' ')).toBe('Shadows , so you herd them');
  });
  it('taken concepts: a negation doesn\'t reach past its part, a comma or a few words', async () => {
    const { conceptText, takenConceptsFor, withoutNegations } = await import('../src/taken.ts');
    const ids = (text: string) => takenConceptsFor(text).map((t) => t.id);
    // A negation in the title doesn't blank the pitch
    expect(conceptText('Don\'t Look Down', 'Drop fruits into a jar and merge them into bigger ones.', '')).toBe('Don\'t Look Down. Drop fruits into a jar and merge them into bigger ones.');
    expect(ids(conceptText('Don\'t Look Down', 'Drop fruits into a jar and merge them into bigger ones.'))).toContain('drop-merge');
    // A comma ends it
    expect(ids('With no timer, you drop fruits into a jar and merge them into bigger ones')).toContain('drop-merge');
    expect(ids('There is no end to it, you drop fruits and merge them')).toContain('drop-merge');
    // … and so do a few words
    expect(ids('it isn\'t hard to drop and merge fruits in a jar')).toContain('drop-merge');
    // A negated list goes on after its commas
    expect(withoutNegations('Nothing is dropped, stacked or merged: you pick').replace(/\s+/g, ' ')).toBe(' : you pick');
    expect(ids('No falling, stacking or merging of fruit')).toEqual([]);
  });
  it('taken concepts: one word can\'t stand for two groups, and loose words don\'t match', async () => {
    const { takenConceptsFor } = await import('../src/taken.ts');
    for (const text of ['Pull levers to open the castle gates', 'The Minotaur hunts you through dark halls', 'Tips: hang on to the rope', 'Its scales deflect weak weights', 'Rain of arrows on the enemy field'])
      expect(takenConceptsFor(text).map((t) => t.id), text).toEqual([]);
    expect(takenConceptsFor('Escape the Minotaur through the maze with a thread').map((t) => t.id)).toContain('labyrinth-thread');
  });
  it('the real games still read like their taken concepts (Hang the Moon, Nimbus Drift)', async () => {
    const { conceptText, takenConceptsFor } = await import('../src/taken.ts');
    const hang = conceptText(
      'Hang the Moon',
      'Hang moons, stars and planets on a swaying mobile of golden rods, and keep every rod from tipping as it grows.',
      "No falling or combining pieces: you pick the hook for each piece of a fixed queue on a hanging tree of levers. Weight x distance tips each rod live, clouds pull up, new rods grow the tree, and every night is proven solvable with a best 'level' finish to aim for.",
    );
    expect(takenConceptsFor(hang).map((t) => t.id)).toEqual(['balance-mobile']);
    const nimbus = conceptText(
      'Nimbus Drift',
      'Blow the wind to herd a sky of little clouds over a valley, so that each field gets exactly the rain it needs.',
      'Every swipe moves all clouds at once, and the goal is where they stop, not a path: a cloud rains only where it comes to rest and only if it moved, one rain too many floods a field, a stop over the village spoils its fair, lakes refill clouds, and on storm levels clouds that collide fuse into storms that pour double and burn forests.',
    );
    expect(takenConceptsFor(nimbus).map((t) => t.id)).toEqual(['weather-puzzle']);
  });
  it('a game is not taken by another title that only starts with its own', async () => {
    const { takenConceptsFor } = await import('../src/taken.ts');
    const titles = (text: string, self: string, id: string) => takenConceptsFor(text, self).find((t) => t.id === id)?.titles.join() ?? '';
    expect(titles('Untangle the ropes before the timer runs out', 'Tangle', 'rope-untangle')).toContain('Tangle Master');
    expect(titles('Rotate tiles to build a maze the waves must walk', 'Maze', 'maze-td')).toContain('Maze Tower Defence');
    expect(titles('A twin-stick roguelike: clear the rooms of a dungeon', 'Soul', 'twin-stick-roguelike')).toContain('Soul Knight');
    expect(titles('Herd the rain clouds over thirsty fields', 'Cloud', 'weather-puzzle')).toContain('Cloud Shepherd');
    expect(titles('Herd the rain clouds over thirsty fields', ' nimbus drift ', 'weather-puzzle')).not.toContain('Nimbus Drift');
  });
  it('a game is not taken by its own "(ours)" entry, but still by the live titles next to it', async () => {
    const { takenConceptsFor } = await import('../src/taken.ts');
    const hang = 'Hang the Moon Hang moons, stars and planets on a swaying mobile of golden rods, and keep every rod from tipping as it grows.';
    expect(takenConceptsFor(hang).map((t) => t.id)).toContain('balance-mobile');
    expect(takenConceptsFor(hang, 'Hang the Moon').map((t) => t.id)).not.toContain('balance-mobile');
    const nimbus = 'Nimbus Drift Blow the wind to herd a sky of little clouds over a valley, so that each field gets exactly the rain it needs.';
    const w = takenConceptsFor(nimbus, 'Nimbus Drift').find((t) => t.id === 'weather-puzzle');
    expect(w?.titles.join()).toContain('Cloud Shepherd');
    expect(w?.titles.join()).not.toContain('Nimbus Drift');
  });
  it('a generic title is a portal rule; kids games on Google Play can be called "Bubbles"', () => {
    expect(codes(edit('title: "Pop the balloon!"', 'title: "Bubbles"'))).not.toContain('E_TITLE_GENERIC');
  });
  it('titles: not a common word, not someone else\'s name, ≤ 35 characters on CrazyGames', () => {
    const c = (title: string) => validateText(cedit('title: "Pop Rush"', `title: "${title}"`), { mode: 'dev' }).issues.map((i) => i.code);
    expect(c('Chess')).toContain('E_TITLE_GENERIC');
    expect(c('Super Chess')).not.toContain('E_TITLE_GENERIC');
    expect(c('Tetris Blast')).toContain('E_TITLE_GENERIC');
    expect(c('Supersonic Sheep')).not.toContain('E_TITLE_GENERIC');
    expect(c('Numero Uno Pizza')).not.toContain('E_TITLE_GENERIC');
    expect(c('A Very Long Name For A Tiny Popping Game')).toContain('E_TITLE_LONG');
  });
  it('rewarded ads: on by default on CrazyGames, can be switched off, never on Android Families', () => {
    expect(validateText(CASUAL, { mode: 'dev' }).game!.ads!.rewarded).toBe(true);
    const off = validateText(cedit('result:', 'monetization:\n  ads: { rewarded: false }\nresult:'), { mode: 'dev' });
    expect(off.issues).toEqual([]);
    expect(off.game!.ads!.rewarded).toBe(false);
    expect(validateText(BALLOON, { mode: "dev", publisher: PUBLISHER }).game!.ads!.rewarded).toBe(false);
    expect(codes(edit('ads: { appId: auto, interstitial: auto }', 'ads: { appId: auto, interstitial: auto, rewarded: true }'))).toContain('E_REWARDED_UNSUPPORTED');
  });
  it('the channel accepts only a general audience', () => {
    expect(codes(cedit('audience: general', 'audience: ages-9-12'))).toContain('E_CHANNEL_AUDIENCE');
  });
  it('no clock and penalties for children, no casual kit for children', () => {
    const kidsWeb = cedit('audience: general', 'audience: ages-6-8').replace('channel: crazygames', 'channel: web');
    const c = codes(kidsWeb);
    expect(c).toContain('E_NO_FAIL');
    expect(c).toContain('E_KIT_AUDIENCE');
  });
  it('kit and mechanic must fit', () => {
    expect(codes(cedit('mechanic: tap-score', 'mechanic: tap-collect'))).toContain('E_MECHANIC_KIT');
  });
  it('only spiky targets have penalties', () => {
    expect(codes(cedit('{ kind: normal, weight: 88, score: 10 }', '{ kind: normal, weight: 88, score: 10, penalty: { time: 1 } }'))).toContain('E_TARGET_KIND');
  });
  it('appId is required on Android channels only', () => {
    expect(codes(CASUAL)).not.toContain('E_APP_ID_REQUIRED');
    expect(codes(edit('appId: com.babygames.balloonpop      # never change after the first release\n', ''))).toContain('E_APP_ID_REQUIRED');
  });
  it('ad limits on the portal may only be stricter', () => {
    expect(codes(cedit('result:', 'monetization:\n  ads: { limits: { minIntervalSec: 60 } }\nresult:'))).toContain('E_ADS_LIMITS');
    // firstAdAfterSec is a floor too: a game may wait longer for its first ad, never less
    expect(codes(cedit('result:', 'monetization:\n  ads: { limits: { firstAdAfterSec: 200 } }\nresult:'))).toContain('E_ADS_LIMITS');
    const later = validateText(cedit('result:', 'monetization:\n  ads: { limits: { firstAdAfterSec: 600 } }\nresult:'), { mode: 'dev' });
    expect(later.issues.map((i) => i.code)).not.toContain('E_ADS_LIMITS');
    expect(later.game!.ads!.policy.firstAdAfterSec).toBe(600);
  });
});

describe('code kit (own mechanics on platform services)', () => {
  const CODE = readFileSync(new URL('../../../docs/examples/code/game.yaml', import.meta.url), 'utf8');
  const kedit = (from: string, to: string) => {
    expect(CODE).toContain(from);
    return CODE.replace(from, to);
  };
  it('the example is valid: no round, no theme, the channel rules still apply', () => {
    const r = validateText(CODE, { mode: 'dev' });
    // Germ Dodge is an example, not a game to submit, and says so: no difference yet, no twist, a taken microbe theme, no music
    expect(r.issues.map((i) => i.code).sort()).toEqual(['W_CONCEPT_TAKEN', 'W_CONCEPT_THEME', 'W_MONEY_SESSION', 'W_SOUND_MUSIC', 'W_TWIST_MISSING']);
    expect(r.game!.sound).toEqual({ music: false, why: 'A platform example of the host contract, never submitted: effects only' });
    expect(r.game!.round).toBeNull();
    expect(r.game!.theme).toBeNull();
    expect(r.game!.kit).toEqual({ kit: 'code', entry: 'main.ts', background: '#0f2230', engine: null, physics: null, anchor: { name: 'survival time', unit: 's', says: 'how long a fresh player lasts against the swarm in one run', shape: 'campaign' }, difficulty: null });
    expect(r.game!.ads!.policy).toMatchObject({ noAdsAfterLaunchSec: 180, minIntervalSec: 180 });
    expect(r.game!.ads!.rewarded).toBe(true);
    expect(r.game!.portal).toBe('crazygames');
  });
  it('a declared twist without the words that explain it: a warning, gone once they are named', () => {
    const twist = (t: string) => kedit('  different: "Nothing yet:', `  twist: ${t}\n  different: "Nothing yet:`);
    const c = codes(twist('{ event: near-miss }'));
    expect(c).toContain('W_TWIST_UNEXPLAINED');
    expect(c).not.toContain('W_TWIST_MISSING');
    const named = validateText(twist('{ event: near-miss, explained: "a germ that grazes you splits" }'), { mode: 'dev' });
    expect(named.issues.map((i) => i.code)).not.toContain('W_TWIST_UNEXPLAINED');
    expect(named.game!.concept!.twist!.explained).toBe('a germ that grazes you splits');
    // Too short to be words a player reads
    expect(codes(twist('{ event: near-miss, explained: "a" }'))).toContain('E_LENGTH');
  });
  it('balance.anchor: a portal code game without it gets W_BALANCE_ANCHOR (a TODO counts as none); the own site does not; other kits have no such field', () => {
    const anchorLine = CODE.split('\n').find((l) => l.startsWith('  anchor:'))!;
    const without = kedit(`balance:\n${anchorLine}\n`, '');
    const r = validateText(without, { mode: 'dev' });
    expect(r.issues.find((i) => i.code === 'W_BALANCE_ANCHOR')).toMatchObject({ severity: 'warning', path: ['balance', 'anchor'] });
    expect((r.game!.kit as { anchor: unknown }).anchor).toBeNull();
    const todo = codes(kedit(anchorLine, '  anchor: { name: "TODO: the anchor", unit: "s", says: "TODO: what it says, in a sentence" }'));
    expect(todo).toContain('W_BALANCE_ANCHOR');
    expect(codes(without.replace('channel: crazygames', 'channel: web'))).not.toContain('W_BALANCE_ANCHOR');
    expect(codes(kedit(anchorLine, '  anchor: { name: "survival time", unit: "s" }'))).toContain('E_REQUIRED');
    // shape: a campaign by default; a roguelite's run says so — anything else is refused
    const run = validateText(kedit(anchorLine, '  anchor: { name: "waves a run", unit: "waves", says: "how many of the 20 waves a run clears", shape: run }'), { mode: 'dev' });
    expect((run.game!.kit as { anchor: { shape: string } }).anchor.shape).toBe('run');
    expect((validateText(CODE, { mode: 'dev' }).game!.kit as { anchor: { shape: string } }).anchor.shape).toBe('campaign');
    expect(codes(kedit(anchorLine, '  anchor: { name: "waves a run", unit: "waves", says: "how many of the 20 waves a run clears", shape: loop }'))).toContain('E_ENUM');
    expect(codes(edit('menu: { backgroundTargets: 4 }', 'balance:\n  anchor: { name: "pops", unit: "balloons", says: "balloons a child pops in one round" }\nmenu: { backgroundTargets: 4 }'))).toContain('E_UNKNOWN_FIELD');
  });
  it('balance.difficulty: the skill ladder\'s win rates and the winning run\'s minutes; a range the wrong way round is refused', () => {
    const anchorLine = CODE.split('\n').find((l) => l.startsWith('  anchor:'))!;
    const withDiff = (d: string) => kedit(anchorLine, `${anchorLine}\n  difficulty: ${d}`);
    const r = validateText(withDiff('{ skilled: { winRate: 0.2, tolerance: 0.05 }, naive: { winRate: 0 }, winningRunMin: [30, 40] }'), { mode: 'dev' });
    expect(r.issues.filter((i) => i.severity === 'error')).toEqual([]);
    expect((r.game!.kit as { difficulty: unknown }).difficulty).toEqual({ naive: { winRate: 0 }, skilled: { winRate: 0.2, tolerance: 0.05 }, winningRunMin: [30, 40] });
    const back = validateText(withDiff('{ winningRunMin: [40, 30] }'), { mode: 'dev' });
    expect(back.issues.find((i) => i.code === 'E_RANGE_ORDER')).toMatchObject({ path: ['balance', 'difficulty', 'winningRunMin'] });
    expect(codes(withDiff('{ skilled: { winRate: 1.5 } }'))).toContain('E_RANGE');
    expect(codes(withDiff('{ expert: { winRate: 0.5 } }'))).toContain('E_UNKNOWN_FIELD');
    expect(codes(withDiff('{ skilled: { tolerance: 0.1 } }'))).toContain('E_REQUIRED');
  });
  it('music on CrazyGames: `sound.music: false` needs a why (then a warning); the code or a description decides the rest', () => {
    const soundLine = CODE.split('\n').find((l) => l.startsWith('sound:'))!;
    const noWhy = validateText(kedit(soundLine, 'sound: { music: false }'), { mode: 'dev' });
    expect(noWhy.issues.find((i) => i.code === 'E_SOUND_MUSIC')).toMatchObject({ severity: 'error', path: ['sound', 'music'] });
    const own = validateText(kedit(soundLine, 'sound: { music: "own synth in sound.ts: a theme per act" }'), { mode: 'dev' });
    expect(own.issues.map((i) => i.code)).not.toContain('W_SOUND_MUSIC');
    expect(own.game!.sound.music).toBe('own synth in sound.ts: a theme per act');
    // Not said: the spec alone can't see the code (gp validate's musicIssues reads it); the own site asks nothing
    const unsaid = validateText(kedit(soundLine, ''), { mode: 'dev' });
    expect(unsaid.issues.some((i) => i.code.includes('SOUND'))).toBe(false);
    expect(unsaid.game!.sound).toEqual({ music: null, why: null });
    expect(musicIssues(unsaid.game!, false).map((i) => [i.code, i.severity])).toEqual([['E_SOUND_MUSIC', 'error']]);
    expect(musicIssues(unsaid.game!, true)).toEqual([]);
    expect(musicIssues(own.game!, false)).toEqual([]);
    const web = validateText(kedit(soundLine, 'sound: { music: false }').replace('channel: crazygames', 'channel: web'), { mode: 'dev' });
    expect(web.issues.some((i) => i.code.includes('SOUND'))).toBe(false);
    expect(musicIssues({ ...unsaid.game!, channel: { id: 'web', platform: 'web' } }, false)).toEqual([]);
    expect(codes(kedit(soundLine, 'sound: { music: 3 }')).some((c) => c.startsWith('E_'))).toBe(true);
    expect(codes(kedit(soundLine, 'sound: { music: "a" }')).some((c) => c.startsWith('E_'))).toBe(true);
  });
  it('sourceHasMusic: an import of createMusic or a theme from @gp/core/sound, or a createMusic call; comments do not count', () => {
    expect(sourceHasMusic("import { createMixer, createMusic } from '@gp/core/sound';")).toBe(true);
    expect(sourceHasMusic("import { musicTheme } from \"@gp/core/sound\";")).toBe(true);
    expect(sourceHasMusic('const m = sound.createMusic(mixer, themes);')).toBe(true);
    expect(sourceHasMusic("import { createMixer } from '@gp/core/sound';\n// later: createMusic(mixer)\n/* createMusic( */")).toBe(false);
    expect(sourceHasMusic("import { FONT_FALLBACK } from '@gp/core';")).toBe(false);
  });
  it('not for children, not for Android', () => {
    expect(codes(kedit('audience: general', 'audience: ages-9-12').replace('channel: crazygames', 'channel: web'))).toContain('E_KIT_AUDIENCE');
    expect(codes(kedit('channel: crazygames', 'channel: android'))).toContain('E_KIT_CHANNEL');
  });
  it('a round or a theme is an unknown field', () => {
    expect(codes(kedit('\nkit: code\n', '\nkit: code\nround: { mechanic: tap-score }\n'))).toContain('E_UNKNOWN_FIELD');
    expect(codes(kedit('\nkit: code\n', '\nkit: code\ntheme: neon-pop\n'))).toContain('E_UNKNOWN_FIELD');
  });
  it('entry must be a .ts file, background a color', () => {
    expect(codes(kedit('entry: main.ts', 'entry: main.js'))).toContain('E_PATTERN');
    expect(codes(kedit('background: "#0f2230"', 'background: blue'))).toContain('E_PATTERN');
  });
  it('ad limits still can only get stricter', () => {
    expect(codes(CODE + 'monetization:\n  ads: { limits: { minIntervalSec: 60 } }\n')).toContain('E_ADS_LIMITS');
  });
});
