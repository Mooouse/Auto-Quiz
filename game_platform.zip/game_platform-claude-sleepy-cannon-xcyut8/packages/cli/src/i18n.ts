// The game's texts per language: games/<id>/strings/<code>.yaml (docs/guides/i18n.md). Loaded and checked here for
// `gp validate`, served to the player as `virtual:gp/strings` by the Vite plugin, and listed for the translator by
// `gp translate`.
//
//   strings/en.yaml     play: Play                         the source: the game's agent writes English
//                       score: "Score: {n}"                {name} parameters, numbers formatted per language
//                       coins: { one: "{n} coin", other: "{n} coins" }   plural forms, chosen by {n}
//                       title: { play: Play }              nested maps are dotted keys (title.play)
//                       listing: { description, controls } the store texts (not shipped in the game; English is game.yaml's)
//   strings/de.yaml     the same keys, translated
//   strings/de.sources.json   written by `gp translate --write`: per key, a hash of the English it was translated from
//                       (and of the translation), so a changed English shows as a stale translation (W_I18N_STALE)

import { createHash } from 'node:crypto';
import { existsSync, readdirSync, readFileSync } from 'node:fs';
import { basename, join, relative } from 'node:path';
import { canonicalCode, charsetOf, checkStrings, flattenStrings, isPlural, LANGUAGE_CODES, languageInfo, pluralCategories, type LanguageStrings, type Strings } from '@gp/core/i18n';
import { PLATFORM_STRINGS } from '@gp/core/i18n-platform';
import { CASUAL_STRINGS_EN } from '@gp/kit-casual/meta';
import { KIDS_STRINGS_EN } from '@gp/kit-kids/meta';
import { brandsIn, CHANNELS, loadYaml, type GameSpecInput, type Issue, type ResolvedGame } from '@gp/spec';
import { shown, type GameLocation } from './paths.ts';

/** What the texts' checks need of a game: a resolved one, or one read from game.yaml as written (gp translate works on a
 *  game whose concept is still TODO) */
export type I18nGame = Pick<ResolvedGame, 'title' | 'languages' | 'glossary' | 'portal'> & { kit: { kit: string }; listing: { description: string | null; controls: string | null } };

/** The i18n view of a game.yaml as written (no resolve): its languages, title, glossary, kit, portal and listing */
export function i18nGameOf(spec: Partial<GameSpecInput>): I18nGame {
  const langs = [...new Set((spec.languages ?? ['en']).map(canonicalCode))];
  return {
    title: spec.title ?? '',
    languages: langs,
    glossary: spec.glossary ?? [],
    portal: (spec.channel && CHANNELS[spec.channel]?.portal) || null,
    kit: { kit: spec.kit ?? 'code' },
    listing: { description: spec.listing?.description?.trim() ?? null, controls: spec.listing?.controls?.trim() ?? null },
  };
}

/** games/<id>/strings/ next to game.yaml; docs/examples/<name>.game.yaml → docs/examples/<name>.strings/ */
export function stringsDir(loc: GameLocation): string {
  const name = basename(loc.file);
  return name === 'game.yaml' ? join(loc.dir, 'strings') : join(loc.dir, name.replace(/(\.game)?\.yaml$/, '.strings'));
}

export interface ListingText {
  description?: string;
  controls?: string;
}

export interface LoadedStrings {
  dir: string;
  /** Per language: its file */
  files: Record<string, string>;
  /** Per language: its texts (flattened, without `listing`) */
  strings: Strings;
  /** Per language: the store texts in its file */
  listing: Record<string, ListingText>;
  /** Per language: the 1-based line of each key in its file */
  lines: Record<string, Record<string, number>>;
  issues: Issue[];
}

const issue = (code: string, severity: Issue['severity'], path: (string | number)[], message: string, fix: string): Issue => ({ code, severity, path, message, fix });

/** Every strings/<code>.yaml there is (any language, declared or not) */
export function loadStrings(loc: GameLocation): LoadedStrings {
  const dir = stringsDir(loc);
  const out: LoadedStrings = { dir, files: {}, strings: {}, listing: {}, lines: {}, issues: [] };
  if (!existsSync(dir)) return out;
  for (const f of readdirSync(dir).sort()) {
    if (!/\.ya?ml$/.test(f)) continue;
    const file = join(dir, f);
    const where = shown(file);
    const code = canonicalCode(f.replace(/\.ya?ml$/, ''));
    if (!LANGUAGE_CODES.includes(code)) {
      out.issues.push(issue('E_I18N_FILE', 'error', ['languages'], `${where}: "${f.replace(/\.ya?ml$/, '')}" is not a language the platform knows`, `Name the file after one of ${LANGUAGE_CODES.join(', ')} (e.g. strings/pt-BR.yaml).`));
      continue;
    }
    const loaded = loadYaml(readFileSync(file, 'utf8'));
    if (loaded.issues.length) {
      for (const i of loaded.issues) out.issues.push({ ...i, code: 'E_I18N_FILE', path: ['languages'], message: `${where}:${i.line ?? '?'}: ${i.message}` });
      continue;
    }
    const data = (loaded.data ?? {}) as Record<string, unknown>;
    if (typeof data !== 'object' || Array.isArray(data)) {
      out.issues.push(issue('E_I18N_FILE', 'error', ['languages'], `${where}: the file is not a map of keys to texts`, 'Write `key: text` lines (nested maps for groups).'));
      continue;
    }
    const { listing, ...rest } = data;
    const flat = flattenStrings(rest);
    for (const key of flat.bad)
      out.issues.push(issue('E_I18N_FILE', 'error', ['languages'], `${where}:${loaded.lineOf(key.split('.')) ?? '?'}: "${key}" is not a text (a list or an empty value)`, 'Write a text, a map of texts, or plural forms { one, other }.'));
    if (listing !== undefined) {
      const l = listing as Record<string, unknown>;
      if (!l || typeof l !== 'object' || Array.isArray(l) || Object.keys(l).some((k) => (k !== 'description' && k !== 'controls') || typeof l[k] !== 'string'))
        out.issues.push(issue('E_I18N_FILE', 'error', ['languages'], `${where}:${loaded.lineOf(['listing']) ?? '?'}: listing must be { description: "…", controls: "…" }`, 'Translate game.yaml listing.description and listing.controls there.'));
      else out.listing[code] = l as ListingText;
    }
    out.files[code] = file;
    out.strings[code] = flat.strings;
    out.lines[code] = Object.fromEntries(Object.keys(flat.strings).map((k) => [k, loaded.lineOf(k.split('.')) ?? loaded.lineOf([k]) ?? 0]));
  }
  return out;
}

/** The kit's own text names a YAML-kit game may translate (or override) in its strings files, and `subtitle` */
function kitKeys(game: I18nGame): string[] | null {
  if (game.kit.kit === 'casual') return [...Object.keys(CASUAL_STRINGS_EN), 'subtitle'];
  if (game.kit.kit === 'kids') return Object.keys(KIDS_STRINGS_EN);
  return null;
}

/** For a YAML kit: the texts game.yaml writes itself (English), which every other language must translate */
function kitOwnTexts(game: I18nGame, spec: { titleScreen?: { subtitle?: string }; strings?: Record<string, string> }): LanguageStrings {
  const own: LanguageStrings = { ...(spec.strings ?? {}) };
  if (game.kit.kit === 'casual' && spec.titleScreen?.subtitle) own.subtitle = spec.titleScreen.subtitle;
  return own;
}

/** `t('key')` / `t("key")` calls in the game's code (not its tests), with where they are */
export function keysInCode(dir: string): { key: string; file: string; line: number }[] {
  const out: { key: string; file: string; line: number }[] = [];
  const walk = (d: string) => {
    for (const e of readdirSync(d, { withFileTypes: true })) {
      if (['node_modules', 'dist', 'qa', 'upload', 'store', 'submission', 'strings', '.git'].includes(e.name)) continue;
      const p = join(d, e.name);
      if (e.isDirectory()) walk(p);
      else if (/\.(ts|mts|js|mjs)$/.test(e.name) && !/\.test\.ts$/.test(e.name)) {
        readFileSync(p, 'utf8')
          .split('\n')
          .forEach((text, i) => {
            if (/^\s*(\/\/|\*)/.test(text)) return;
            for (const m of text.matchAll(/(?:^|[^\w$])t\(\s*(['"])([A-Za-z][\w.-]*)\1/g)) out.push({ key: m[2], file: p, line: i + 1 });
          });
      }
    }
  };
  walk(dir);
  return out;
}

/**
 * The checks of `gp validate` on a game's texts: the files load, the declared languages have every key of English with
 * the same parameters and the plural forms they need, keys the code asks for exist, the listing is translated (a portal
 * game), and the files are for declared languages. YAML kits: their own game.yaml texts in every language
 */
export function i18nChecks(loc: GameLocation, game: I18nGame, spec: Record<string, unknown> = {}): Issue[] {
  const L = loadStrings(loc);
  const issues = [...L.issues, ...trademarkChecks(game, L)];
  const langs = game.languages;
  const many = langs.length > 1;
  const dirShown = shown(L.dir);
  const at = (lang: string, key: string) => {
    const f = L.files[lang];
    if (!f) return `${dirShown}/${lang}.yaml`;
    const line = L.lines[lang]?.[key];
    return `${shown(f)}${line ? `:${line}` : ''}`;
  };
  for (const lang of Object.keys(L.files))
    if (!langs.includes(lang)) issues.push(issue('W_I18N_UNDECLARED', 'warning', ['languages'], `${shown(L.files[lang])}: ${languageInfo(lang)?.english ?? lang} is not in game.yaml languages, so it never ships`, `Add ${lang} to languages, or remove the file.`));
  const glossary = [game.title, ...game.glossary];
  const kit = kitKeys(game);
  if (kit) {
    // YAML kits: the platform translated the kit; the game's own texts (game.yaml) must come in every language
    const own = kitOwnTexts(game, spec as never);
    for (const lang of Object.keys(L.strings))
      for (const key of Object.keys(L.strings[lang]))
        if (!kit.includes(key)) issues.push(issue('E_I18N_KEY', 'error', ['languages'], `${at(lang, key)}: "${key}" is not a text of kit ${game.kit.kit}`, `Its texts: ${kit.join(', ')}.`));
    issues.push(...listingChecks(game, L));
    if (!many || !Object.keys(own).length) return issues;
    const base = { ...own, ...(L.strings.en ?? {}) };
    const strings: Strings = { ...L.strings, en: base };
    for (const i of checkStrings(strings, { languages: langs, glossary })) {
      // A kit text a language overrides (play: "Жми") is no stray key; unknown names were reported above
      if (i.code === 'W_I18N_EXTRA') continue;
      if (i.code === 'E_I18N_MISSING') issues.push(issue('W_I18N_KIT_TEXT', 'warning', ['languages'], `${i.message.replace(/^(\S+) misses/, '$1 misses the translation of')} — game.yaml's English is shown there`, `Add them to strings/${i.lang}.yaml (gp translate lists them).`));
      else issues.push(issue(i.code, i.severity, ['languages'], `${at(i.lang, i.key)}: ${i.message}`, i.fix));
    }
    issues.push(...staleChecks(game, L, base, at));
    return issues;
  }
  // kit: code — the game's own texts
  const en = L.strings.en;
  const used = keysInCode(loc.dir);
  if (many && !en) {
    issues.push(issue('E_I18N_FILE', 'error', ['languages'], `game.yaml declares ${langs.length} languages, but ${dirShown}/en.yaml doesn't exist`, `Write the game's texts in English into ${dirShown}/en.yaml (key: text) and use host.t('key') for them; then gp translate (docs/guides/i18n.md).`));
    return issues;
  }
  for (const lang of Object.keys(L.strings))
    for (const key of Object.keys(L.strings[lang]))
      if (key.startsWith('gp.')) issues.push(issue('E_I18N_KEY', 'error', ['languages'], `${at(lang, key)}: "${key}" — keys starting with "gp." are the platform's`, 'Rename the key (or use the platform\'s text as it is: host.t("gp.play")).'));
  if (en || used.length) {
    const known = new Set([...Object.keys(en ?? {}), ...Object.keys(PLATFORM_STRINGS)]);
    const unknown = used.filter((u) => !known.has(u.key));
    const seen = new Set<string>();
    for (const u of unknown) {
      if (seen.has(u.key)) continue;
      seen.add(u.key);
      issues.push(issue('E_I18N_KEY', 'error', ['languages'], `${shown(u.file)}:${u.line}: t("${u.key}") — no such key in ${dirShown}/en.yaml`, `Add "${u.key}: <the English text>" to strings/en.yaml (and translate it), or fix the key's spelling.`));
    }
  }
  if (!en) return issues;
  for (const i of checkStrings(L.strings, { languages: langs, glossary })) issues.push(issue(i.code, i.severity, ['languages'], `${i.key === '*' ? `${dirShown}/${i.lang}.yaml` : at(i.lang, i.key)}: ${i.message}`, i.fix));
  issues.push(...listingChecks(game, L));
  issues.push(...staleChecks(game, L, en, at));
  return issues;
}

// --- Stale translations: the English each one was made from ----------------------------------------------------------

/** strings/<code>.sources.json beside strings/<code>.yaml (not a YAML file: never read as a language) */
export function sourcesFile(dir: string, lang: string): string {
  return join(dir, `${lang}.sources.json`);
}

/** What a translation was made from: hashes of the English and of the translation when `gp translate --write` recorded it */
export interface SourceRecord {
  en: string;
  text: string;
}

/** A short hash of a text (a plural map: its forms in a fixed order) */
export function textHash(v: string | Record<string, string>): string {
  const canon = typeof v === 'string' ? v : JSON.stringify(Object.keys(v).sort().map((k) => [k, v[k]]));
  return createHash('sha256').update(canon).digest('hex').slice(0, 12);
}

/** A text a translator wrote (not empty, not TODO) */
const filled = (v: string | Record<string, string> | undefined): v is string | Record<string, string> =>
  v !== undefined && (typeof v === 'string' ? [v] : Object.values(v)).every((t) => !!t?.trim() && !/^\s*TODO\b/.test(t));

/** The recorded sources of a language, or null when there is no file yet (a game from before them: no warning) */
export function readSources(dir: string, lang: string): Record<string, SourceRecord> | null {
  const file = sourcesFile(dir, lang);
  if (!existsSync(file)) return null;
  try {
    const keys = (JSON.parse(readFileSync(file, 'utf8')) as { keys?: Record<string, SourceRecord> }).keys;
    return keys && typeof keys === 'object' ? keys : {};
  } catch {
    return {};
  }
}

/** Each translatable text of a language: its English and its translation (the listing as listing.description/controls) */
function translationPairs(game: I18nGame, L: LoadedStrings, source: LanguageStrings, lang: string): Map<string, { en: string | Record<string, string>; text: string | Record<string, string> | undefined }> {
  const out = new Map<string, { en: string | Record<string, string>; text: string | Record<string, string> | undefined }>();
  for (const [k, v] of Object.entries(source)) out.set(k, { en: v, text: L.strings[lang]?.[k] });
  if (listingWanted(game))
    for (const k of ['description', 'controls'] as const) {
      const en = game.listing[k];
      if (en) out.set(`listing.${k}`, { en, text: L.listing[lang]?.[k] });
    }
  return out;
}

/**
 * The keys of a language whose English changed since their translation was recorded, while the translation did not
 * (a translation edited since is taken as redone: `gp translate --write` records it). No sources file: none
 */
export function staleKeys(game: I18nGame, L: LoadedStrings, source: LanguageStrings, lang: string): string[] {
  const rec = readSources(L.dir, lang);
  if (!rec) return [];
  const out: string[] = [];
  for (const [k, { en, text }] of translationPairs(game, L, source, lang)) {
    const r = rec[k];
    if (r && filled(text) && r.en !== textHash(en) && r.text === textHash(text)) out.push(k);
  }
  return out;
}

const STALE_FIX = 'Translate the new English (gp translate lists it), then `gp translate --write` records it; if the translation still says the same, `gp translate --write --accept`. More: gp explain W_I18N_STALE';

function staleChecks(game: I18nGame, L: LoadedStrings, source: LanguageStrings, at: (lang: string, key: string) => string): Issue[] {
  const issues: Issue[] = [];
  for (const lang of game.languages) {
    if (lang === 'en') continue;
    for (const k of staleKeys(game, L, source, lang)) {
      const en = k.startsWith('listing.') ? game.listing[k.slice(8) as 'description' | 'controls']! : source[k];
      const shownEn = typeof en === 'string' ? en : Object.entries(en).map(([c, t]) => `${c}: ${t}`).join(' | ');
      issues.push(issue('W_I18N_STALE', 'warning', k.startsWith('listing.') ? ['listing'] : ['languages'], `${k.startsWith('listing.') ? shown(L.files[lang] ?? sourcesFile(L.dir, lang)) : at(lang, k)}: "${k}" was translated from another English — now "${shownEn.length > 80 ? `${shownEn.slice(0, 77)}…` : shownEn}"`, STALE_FIX));
    }
  }
  return issues;
}

/**
 * `gp translate --write`: record, per declared language, the English each written translation was made from. A key
 * without a record, or whose translation changed since, is recorded now; a stale one (the English changed, the
 * translation didn't) keeps its old record — so it stays stale — unless `accept`. Returns what changed, per file
 */
export function recordSources(loc: GameLocation, game: I18nGame, spec: Record<string, unknown>, write: (file: string, text: string) => void, opts: { accept?: boolean; lang?: string } = {}): string[] {
  const { source, loaded: L } = translateStatus(loc, game, spec);
  const done: string[] = [];
  for (const lang of game.languages) {
    if (lang === 'en' || (opts.lang && lang !== canonicalCode(opts.lang)) || !L.files[lang]) continue;
    const old = readSources(L.dir, lang) ?? {};
    const keys: Record<string, SourceRecord> = {};
    let added = 0;
    let accepted = 0;
    for (const [k, { en, text }] of translationPairs(game, L, source, lang)) {
      if (!filled(text)) continue;
      const now = { en: textHash(en), text: textHash(text) };
      const r = old[k];
      const stale = !!r && r.text === now.text && r.en !== now.en;
      if (stale && !opts.accept) {
        keys[k] = r;
        continue;
      }
      if (stale) accepted++;
      else if (!r || r.text !== now.text) added++;
      keys[k] = now;
    }
    const file = sourcesFile(L.dir, lang);
    const same = JSON.stringify(Object.entries(keys).sort()) === JSON.stringify(Object.entries(old).sort());
    if (same && existsSync(file)) continue;
    const body = {
      about: `The English each translation in ${lang}.yaml was made from (hashes), written by gp translate --write: gp translate --check warns (W_I18N_STALE) when the English of a key changes and its translation doesn't. Don't edit it.`,
      keys: Object.fromEntries(Object.entries(keys).sort(([a], [b]) => a.localeCompare(b))),
    };
    write(file, `${JSON.stringify(body, null, 2)}\n`);
    const dropped = Object.keys(old).filter((k) => !keys[k]).length;
    done.push(`${shown(file)}: ${Object.keys(keys).length} translation(s) recorded${added ? `, ${added} new or redone` : ''}${accepted ? `, ${accepted} accepted as they are` : ''}${dropped ? `, ${dropped} dropped` : ''}`);
  }
  return done;
}

/** A portal game with its English listing written: its other languages need the listing too */
const listingWanted = (game: I18nGame) => !!game.portal && !!game.listing.description && !/^\s*TODO\b/i.test(game.listing.description);

/** The store texts per language (the CrazyGames form takes English: the others are for the store page and other portals) */
/**
 * Brand and trademark names in the texts a player reads (W_TRADEMARK_TEXT): strings/<code>.yaml of every language and
 * the listing. The title is E_TITLE_GENERIC's; these are the car makers, other games and platforms named in the game
 * (Idle Garage's cars, a "Minecraft-style" line) — a portal refuses their use without a licence. One warning per name
 */
export function trademarkChecks(game: I18nGame, L: LoadedStrings): Issue[] {
  const where = new Map<string, string[]>();
  const add = (name: string, at: string) => {
    const xs = where.get(name) ?? [];
    if (!xs.includes(at)) xs.push(at);
    where.set(name, xs);
  };
  // The game's own title may contain a word of the list only if E_TITLE_GENERIC let it through: never report it twice
  const own = new Set(brandsIn(game.title));
  for (const [lang, texts] of Object.entries(L.strings))
    for (const [key, v] of Object.entries(texts))
      for (const name of brandsIn(typeof v === 'string' ? v : Object.values(v as Record<string, string>).join(' '))) if (!own.has(name)) add(name, `${lang}:${key}`);
  for (const [lang, l] of Object.entries(L.listing)) for (const name of brandsIn(`${l.description ?? ''} ${l.controls ?? ''}`)) if (!own.has(name)) add(name, `${lang}:listing`);
  for (const name of brandsIn(`${game.listing.description ?? ''} ${game.listing.controls ?? ''}`)) if (!own.has(name)) add(name, 'game.yaml listing');
  return [...where].map(([name, at]) =>
    issue(
      'W_TRADEMARK_TEXT',
      'warning',
      ['languages'],
      `"${name}" — a name someone else owns — is in the game's texts: ${at.slice(0, 4).join(', ')}${at.length > 4 ? ` and ${at.length - 4} more` : ''}`,
      'Use your own words: a made-up maker or model ("a Vanta GT"), a description ("a red Italian sports car"), never a brand, another game or a platform. gp explain W_TRADEMARK_TEXT',
    ),
  );
}

function listingChecks(game: I18nGame, L: LoadedStrings): Issue[] {
  if (game.languages.length < 2 || !listingWanted(game)) return [];
  const missing = game.languages.filter((l) => l !== 'en' && !(L.listing[l]?.description?.trim() && L.listing[l]?.controls?.trim()));
  if (!missing.length) return [];
  return [issue('W_I18N_LISTING', 'warning', ['listing'], `the listing (description, controls) is not translated into ${missing.join(', ')}`, 'Add `listing: { description: "…", controls: "…" }` to each strings/<code>.yaml — gp translate lists it with the English; gp submission writes listing-translations.md from it.')];
}

/** The game's texts for the player (virtual:gp/strings): its declared languages only, without the listing */
export function runtimeStrings(loc: GameLocation, game: Pick<ResolvedGame, 'languages'>): Strings {
  const L = loadStrings(loc);
  return Object.fromEntries(game.languages.filter((l) => L.strings[l]).map((l) => [l, L.strings[l]]));
}

// --- gp translate -------------------------------------------------------------------------------------------------

export interface TranslateStatus {
  lang: string;
  name: string;
  /** Keys with a text / keys English has */
  done: number;
  total: number;
  missing: string[];
  /** Keys translated from an English that has changed since (strings/<code>.sources.json): to translate again */
  stale: string[];
  listing: boolean;
  /** Characters beyond ASCII its texts use (a pixel font needs them) */
  charset: string;
}

/** What each declared language has and lacks, against English (or, for a YAML kit, game.yaml's own texts) */
export function translateStatus(loc: GameLocation, game: I18nGame, spec: Record<string, unknown> = {}): { source: LanguageStrings; rows: TranslateStatus[]; loaded: LoadedStrings } {
  const L = loadStrings(loc);
  const source = kitKeys(game) ? { ...kitOwnTexts(game, spec as never), ...(L.strings.en ?? {}) } : (L.strings.en ?? {});
  const total = Object.keys(source).length;
  const rows = game.languages.map((lang) => {
    const own = lang === 'en' ? source : (L.strings[lang] ?? {});
    const missing = Object.keys(source).filter((k) => {
      const v = own[k];
      if (v === undefined) return true;
      const texts = typeof v === 'string' ? [v] : Object.values(v);
      return texts.some((t) => !t?.trim() || /^\s*TODO\b/.test(t));
    });
    const listing = lang === 'en' || !listingWanted(game) || !!(L.listing[lang]?.description?.trim() && L.listing[lang]?.controls?.trim());
    const stale = lang === 'en' ? [] : staleKeys(game, L, source, lang);
    return { lang, name: languageInfo(lang)?.english ?? lang, done: total - missing.length, total, missing, stale, listing, charset: charsetOf(own) };
  });
  return { source, rows, loaded: L };
}

const yamlString = (s: string) => JSON.stringify(s);

/** The empty entries for a key in a language: "" or the plural forms it needs, each "" (gp validate refuses them empty) */
function blank(lang: string, v: LanguageStrings[string]): string {
  if (!isPlural(v)) return '""';
  return `{ ${pluralCategories(lang).required.map((c) => `${c}: ""`).join(', ')} }`;
}

/** Lines to append to strings/<lang>.yaml: every missing key, empty, with the English as a comment */
export function missingBlock(lang: string, source: LanguageStrings, keys: readonly string[]): string[] {
  return keys.map((k) => {
    const v = source[k];
    const en = typeof v === 'string' ? v : Object.entries(v).map(([c, t]) => `${c}: ${t}`).join(' | ');
    return `${/^[A-Za-z][\w.-]*$/.test(k) ? k : yamlString(k)}: ${blank(lang, v)}   # en: ${en.replace(/\n/g, ' ')}`;
  });
}

/** The brief for the game's agent: the rules, the glossary, and per language what to translate */
export function translateBrief(loc: GameLocation, game: I18nGame, spec: Record<string, unknown> = {}, only?: string): string {
  const { source, rows, loaded } = translateStatus(loc, game, spec);
  const glossary = [game.title, ...game.glossary];
  const dir = shown(loaded.dir);
  const yamlKit = !!kitKeys(game);
  const lines = [
    `# ${game.title} — translation brief`,
    '',
    `Written by \`gp translate\`. You (the game's agent) translate: there is no translation service — you are the translator. Fill ${dir}/<code>.yaml, then run \`gp translate --check\` (or \`gp validate\`) until it is clean, and \`gp qa\` (it plays the longest language at two sizes).`,
    '',
    '## Rules',
    '',
    '- **Keep every `{name}` exactly** (`{n}`, `{title}`): translate the words around it. Numbers are formatted for the language by the platform (1,234 · 1.234 · 1 234): never write them out.',
    '- **Plural forms**: a key with `{ one, other }` in English takes the forms the language needs (listed below per language): Russian and Polish `one, few, many, other` (1 монета, 2 монеты, 5 монет, 1,5 монеты); Indonesian, Japanese, Korean, Chinese only `other`.',
    '- **Length**: UI text stays within ~30% of English where the room is tight (buttons, HUD, labels). Say it shorter rather than longer; `gp validate` warns at twice the length, `gp qa` checks the longest language on screen.',
    `- **Names stay as they are** (the glossary): ${glossary.map((g) => `"${g}"`).join(', ')}.`,
    '- **Tone**: short, plain game UI; the imperative for actions. The platform\'s own texts use: es tú, pt-BR você, fr vous, de du, it tu, pl the informal 2nd person, ru вы (or impersonal), tr the polite plural, id neutral. Keep to it so a screen speaks one way.',
    "- **Translate the meaning, not the words**: a joke or a pun gets the language's own; a game term is the word players of that genre use in that language.",
    '- **Characters**: a pixel or bitmap font needs every letter the translation uses (ą ę ł ś ż, ş ğ ı İ, ß ä ö ü, é è ç, ñ ¿ ¡, Cyrillic): `gp translate --check` lists them per language. A system font (FONT_FALLBACK from @gp/core) has them all.',
    '- **Keys**: never rename or translate a key. A text English no longer has is reported (W_I18N_EXTRA).',
    '',
    `## Source: ${yamlKit ? "game.yaml's own texts (the kit's are translated by the platform)" : `${dir}/en.yaml`} — ${Object.keys(source).length} key(s)`,
    '',
  ];
  for (const r of rows) {
    if (r.lang === 'en' || (only && r.lang !== canonicalCode(only))) continue;
    const info = languageInfo(r.lang);
    const cats = pluralCategories(r.lang).required.join(', ');
    lines.push(`## ${info?.name ?? r.lang} — ${r.lang} (${r.name}): ${r.done}/${r.total}${r.listing ? '' : ', listing missing'}${r.stale.length ? `, ${r.stale.length} stale` : ''}`, '');
    if (r.stale.length) {
      lines.push(`**Stale** — the English changed since these were translated: translate them again (then \`gp translate --write\` records it; still right as they are: \`gp translate --write --accept\`):`, '');
      for (const k of r.stale) {
        const v = k.startsWith('listing.') ? game.listing[k.slice(8) as 'description' | 'controls'] ?? '' : source[k];
        const now = typeof v === 'string' ? v : Object.entries(v).map(([c, t]) => `${c}: ${t}`).join(' | ');
        const cur = k.startsWith('listing.') ? loaded.listing[r.lang]?.[k.slice(8) as 'description' | 'controls'] : loaded.strings[r.lang]?.[k];
        lines.push(`- \`${k}\` — en now: ${JSON.stringify(now)}; ${r.lang} still: ${JSON.stringify(typeof cur === 'string' ? cur : Object.entries(cur ?? {}).map(([c, t]) => `${c}: ${t}`).join(' | '))}`);
      }
      lines.push('');
    }
    if (!r.missing.length && r.listing) {
      if (!r.stale.length) lines.push('Complete.', '');
      continue;
    }
    lines.push(`Plural forms in ${r.lang}: ${cats}. ${loaded.files[r.lang] ? `File: ${shown(loaded.files[r.lang])}` : `File: ${dir}/${r.lang}.yaml (new — \`gp translate --write\` creates it with the keys)`}.`, '');
    if (r.missing.length) lines.push('```yaml', ...missingBlock(r.lang, source, r.missing), '```', '');
    if (!r.listing)
      lines.push('The store texts (in the same file):', '', '```yaml', 'listing:', `  description: ""   # en: ${game.listing.description}`, `  controls: ""   # en: ${game.listing.controls ?? ''}`, '```', '');
  }
  return lines.join('\n');
}

/** `gp translate --write`: each declared language's file gets its missing keys appended (empty, the English as a comment) */
export function writeMissing(loc: GameLocation, game: I18nGame, spec: Record<string, unknown>, write: (file: string, text: string) => void): string[] {
  const { source, rows, loaded } = translateStatus(loc, game, spec);
  const done: string[] = [];
  for (const r of rows) {
    if (r.lang === 'en') continue;
    const file = loaded.files[r.lang] ?? join(loaded.dir, `${r.lang}.yaml`);
    const absent = r.missing.filter((k) => loaded.strings[r.lang]?.[k] === undefined);
    const listing = !r.listing && !loaded.listing[r.lang];
    if (!absent.length && !listing) continue;
    const before = existsSync(file) ? readFileSync(file, 'utf8') : `# ${languageInfo(r.lang)?.english ?? r.lang} (${r.lang}) — the texts of ${game.title}, translated from ${relative(loaded.dir, join(loaded.dir, 'en.yaml'))} (docs/guides/i18n.md)\n`;
    const add = [
      ...(absent.length ? [`# Added by gp translate: translate each "" (the English is in the comment)`, ...missingBlock(r.lang, source, absent)] : []),
      ...(listing ? ['listing:', `  description: ""   # en: ${game.listing.description}`, `  controls: ""   # en: ${game.listing.controls ?? ''}`] : []),
    ];
    write(file, `${before.replace(/\n*$/, '\n')}${add.join('\n')}\n`);
    done.push(`${shown(file)}: ${absent.length} key(s)${listing ? ' + listing' : ''}`);
  }
  return done;
}

