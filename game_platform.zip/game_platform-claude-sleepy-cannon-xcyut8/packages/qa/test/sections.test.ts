// runSections: parallel sections report in the list's order, wait for what they read, and fail alone; failedSections
// picks what `gp qa --failed` re-runs

import { describe, expect, it } from 'vitest';
import { failedSections, runSections, type QaCheck, type QaContext, type QaResults } from '../src/index.ts';

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

function ctx(jobs: number, only: string[] | null = null) {
  const checks: QaCheck[] = [];
  let section: string | undefined;
  const timing: Record<string, number> = {};
  const c = {
    jobs,
    only: only ? new Set(only) : null,
    check: (scope: string, name: string, ok: boolean, details = '') => void checks.push({ scope, name, ok, details, section }),
    info: () => {},
    inSection: (s: string, replay: () => void) => {
      section = s;
      replay();
      section = undefined;
    },
    timed: (s: string, sec: number) => void (timing[s] = sec),
  } as unknown as QaContext;
  return { c, checks, timing };
}

describe('runSections', () => {
  it('runs them at once but reports them in the list order, each check in its section', async () => {
    const { c, checks, timing } = ctx(3);
    const started: string[] = [];
    const sec = (name: string, ms: number) => ({ name, run: async (x: QaContext) => (started.push(name), await sleep(ms), x.check(name, 'done', true)) });
    const t0 = Date.now();
    await runSections(c, [sec('a', 80), sec('b', 10), sec('c', 40)]);
    expect(Date.now() - t0).toBeLessThan(150);
    expect(started).toEqual(['a', 'b', 'c']);
    expect(checks.map((k) => `${k.section}:${k.scope}`)).toEqual(['a:a', 'b:b', 'c:c']);
    expect(Object.keys(timing).sort()).toEqual(['a', 'b', 'c']);
  });
  it('a section starts after the ones it reads (after)', async () => {
    const { c } = ctx(3);
    const log: string[] = [];
    await runSections(c, [
      { name: 'reader', after: ['writer'], run: async () => void log.push('read') },
      { name: 'writer', run: async () => (await sleep(30), log.push('wrote')) },
    ]);
    expect(log).toEqual(['wrote', 'read']);
  });
  it('a section that throws fails one check of its own; the others go on', async () => {
    const { c, checks } = ctx(2);
    await runSections(c, [
      { name: 'bad', run: async () => Promise.reject(new Error('boom')) },
      { name: 'good', run: async (x) => x.check('good', 'ran', true) },
    ]);
    expect(checks.map((k) => [k.section, k.name, k.ok])).toEqual([
      ['bad', 'section finished without an exception', false],
      ['good', 'ran', true],
    ]);
  });
  it('runs only ctx.only (gp qa --failed)', async () => {
    const { c, checks } = ctx(1, ['b']);
    await runSections(c, ['a', 'b', 'c'].map((n) => ({ name: n, run: async (x: QaContext) => x.check(n, 'ran', true) })));
    expect(checks.map((k) => k.section)).toEqual(['b']);
  });
});

describe('failedSections', () => {
  const base = { game: 'g', date: 'd', platform: 'p', passed: 1, failed: 1, infos: [] } as const;
  it('names the sections with a failed check', () => {
    const r: QaResults = { ...base, mode: 'full', checks: [{ scope: 's', name: 'x', ok: false, details: '', section: 'ads' }, { scope: 's', name: 'y', ok: true, details: '', section: 'focus' }] };
    expect(failedSections(r)).toEqual({ sections: ['ads'], quick: false });
  });
  it('a full run re-runs full; a quick run (or a re-run on top of one) re-runs quick', () => {
    const bad = [{ scope: 's', name: 'x', ok: false, details: '', section: 'phone-portrait' }];
    expect(failedSections({ ...base, mode: 'full', checks: bad })).toEqual({ sections: ['phone-portrait'], quick: false });
    expect(failedSections({ ...base, mode: 'quick', checks: bad })).toEqual({ sections: ['phone-portrait'], quick: true });
    expect(failedSections({ ...base, mode: 'failed', quick: true, base: 'd0', checks: bad })).toEqual({ sections: ['phone-portrait'], quick: true });
    expect(failedSections({ ...base, mode: 'failed', base: 'd0', checks: bad })).toEqual({ sections: ['phone-portrait'], quick: false });
    expect(failedSections({ ...base, mode: 'quick', checks: [] })).toEqual({ sections: [], quick: true });
  });
  it('refuses old results and a failure outside the sections', () => {
    expect(failedSections(null)).toHaveProperty('why');
    expect(failedSections({ ...base, checks: [] })).toHaveProperty('why');
    expect(failedSections({ ...base, mode: 'full', checks: [{ scope: 'runner', name: 'suite finished without an exception', ok: false, details: '' }] })).toHaveProperty('why');
  });
});
