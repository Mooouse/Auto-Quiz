// Sameness across the account: does this game's title, results or language screen look like one of our other games'?
//
// Our dense batch (13 games in 5 days, 2 approved) shared a "platform look" — the same HUD pill, results card and
// language sheet (docs/research/game-design-2026-10.md, S11). Google Play bans near-identical apps for the whole account,
// and a portal reviewer who has seen our last game sees the stock screens again. So `gp review` compares the game's own
// title, results and language screens with our other games' title screens and language sheets — the reference shots
// (publisher/reference/) and, when a checkout of the previews repository is at hand, every game in it — and the brief
// warns when a screen is very close to another game's. No ML: a downscaled colour histogram (how the screen is
// coloured) and a layout edge map (where its edges are), both of a 64×36 thumbnail.
//
//   <platform>/.gp/looks/<id>-<commit>-{title,language}.png   the previews' screens, captured once per preview commit
//                                                             (.gp/ is the local cache, not committed)

import { createServer, type Server } from 'node:http';
import { existsSync, mkdirSync, readdirSync, readFileSync, statSync } from 'node:fs';
import { extname, join, normalize, resolve } from 'node:path';
import type { Browser, Page } from 'playwright';
import { ROOT, type GameLocation } from './paths.ts';
import type { ReferenceShot } from './review-sheet.ts';

/** The thumbnail every screen is reduced to before it is compared */
export const LOOK_W = 64;
export const LOOK_H = 36;
/** The edge map's cell, in thumbnail pixels: 16×9 cells */
const CELL = 4;

/**
 * Two screens are "very close" when both their colours and their layout agree this much — what the platform's stock
 * screens give across two games. Calibrated on the 24 games of the previews, 2026-10-19 (the test keeps the numbers):
 * the stock language sheet of 17 games agreed 0.98–1.00 on both, pair by pair; two different title screens a median of
 * 0.13 (the weaker of the two) and 0.44 at the 90th percentile; the closest two titles — Firefly Rush and Starsilk,
 * both a centred dark menu, each with its own art — 0.82 colour, 0.80 layout. Colour alone matches any two dark games;
 * layout alone any two centred menus.
 */
export const VERY_CLOSE = { colour: 0.85, layout: 0.85 };
/** Close enough to mention, no warning: the same centred-menu template (Firefly Rush, Starsilk, Potion Logic, Scrap Royale) */
export const CLOSE = { colour: 0.7, layout: 0.7 };

export interface LookFeatures {
  /** 4 levels per channel: 64 bins, summing to 1 */
  hist: number[];
  /** Mean edge strength per 4×4 cell: 16×9 cells, row by row */
  edges: number[];
}

/** A screen's look from its RGBA pixels at LOOK_W×LOOK_H (the browser downscales it) */
export function lookFeatures(rgba: ArrayLike<number>, w = LOOK_W, h = LOOK_H): LookFeatures {
  const hist = new Array(64).fill(0);
  const lum = new Float64Array(w * h);
  for (let i = 0; i < w * h; i++) {
    const r = rgba[i * 4];
    const g = rgba[i * 4 + 1];
    const b = rgba[i * 4 + 2];
    hist[(r >> 6) * 16 + (g >> 6) * 4 + (b >> 6)]++;
    lum[i] = 0.299 * r + 0.587 * g + 0.114 * b;
  }
  for (let i = 0; i < 64; i++) hist[i] /= w * h;
  const cw = Math.floor(w / CELL);
  const ch = Math.floor(h / CELL);
  const edges = new Array(cw * ch).fill(0);
  for (let y = 0; y < ch * CELL; y++)
    for (let x = 0; x < cw * CELL; x++) {
      const i = y * w + x;
      const dx = x + 1 < w ? Math.abs(lum[i + 1] - lum[i]) : 0;
      const dy = y + 1 < h ? Math.abs(lum[i + w] - lum[i]) : 0;
      edges[Math.floor(y / CELL) * cw + Math.floor(x / CELL)] += (dx + dy) / (CELL * CELL);
    }
  return { hist, edges };
}

/** Pearson correlation, clipped to 0–1; two flat maps are the same layout, one flat and one not are not */
function correlation(a: readonly number[], b: readonly number[]): number {
  const n = Math.min(a.length, b.length);
  const ma = a.reduce((s, x) => s + x, 0) / n;
  const mb = b.reduce((s, x) => s + x, 0) / n;
  let ab = 0;
  let aa = 0;
  let bb = 0;
  for (let i = 0; i < n; i++) {
    ab += (a[i] - ma) * (b[i] - mb);
    aa += (a[i] - ma) ** 2;
    bb += (b[i] - mb) ** 2;
  }
  const flatA = Math.sqrt(aa / n) < 0.5;
  const flatB = Math.sqrt(bb / n) < 0.5;
  if (flatA || flatB) return flatA && flatB ? 1 : 0;
  return Math.max(0, ab / Math.sqrt(aa * bb));
}

export interface LookSimilarity {
  /** Histogram intersection, 0–1 */
  colour: number;
  /** Correlation of the edge maps, 0–1 */
  layout: number;
}

export function lookSimilarity(a: LookFeatures, b: LookFeatures): LookSimilarity {
  const colour = a.hist.reduce((s, x, i) => s + Math.min(x, b.hist[i] ?? 0), 0);
  const round = (x: number) => Math.round(x * 100) / 100;
  return { colour: round(colour), layout: round(correlation(a.edges, b.edges)) };
}

export type Closeness = 'very close' | 'close' | null;

export function closeness(s: LookSimilarity): Closeness {
  if (s.colour >= VERY_CLOSE.colour && s.layout >= VERY_CLOSE.layout) return 'very close';
  if (s.colour >= CLOSE.colour && s.layout >= CLOSE.layout) return 'close';
  return null;
}

/** One number to sort by: the weaker of the two agreements */
export const simScore = (s: LookSimilarity) => Math.min(s.colour, s.layout);

// --- The shots ----------------------------------------------------------------------------------------------------------

export interface OtherShot {
  /** The other game's id */
  game: string;
  title: string;
  screen: 'title' | 'language';
  file: string;
  /** Where it came from: publisher/reference, or a previews build (its commit) */
  source: string;
}

/** The previews checkout: GP_PREVIEWS, else a game-previews folder beside the platform */
export function previewsDir(): string | null {
  const dir = process.env.GP_PREVIEWS || join(ROOT, '..', 'game-previews');
  return existsSync(join(dir, 'games.json')) ? resolve(dir) : null;
}

export const LOOKS_CACHE = join(ROOT, '.gp', 'looks');

interface PreviewGame {
  id: string;
  title: string;
  commit?: string;
  updated?: string;
}

function previewGames(dir: string): PreviewGame[] {
  try {
    const list = JSON.parse(readFileSync(join(dir, 'games.json'), 'utf8')) as PreviewGame[];
    return list.filter((g) => typeof g.id === 'string' && existsSync(join(dir, g.id, 'index.html')));
  } catch {
    return [];
  }
}

const cacheKey = (g: PreviewGame) => `${g.id}-${(g.commit ?? g.updated ?? 'x').replace(/[^\w]/g, '').slice(0, 12)}`;

/** A static server for the previews folder (one-file uploads: index.html and its cover) */
function serveDir(dir: string): Promise<{ server: Server; url: string }> {
  const types: Record<string, string> = { '.html': 'text/html', '.js': 'text/javascript', '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.json': 'application/json', '.css': 'text/css', '.wasm': 'application/wasm', '.mp3': 'audio/mpeg', '.ogg': 'audio/ogg' };
  const server = createServer((req, res) => {
    const path = normalize(decodeURIComponent((req.url ?? '/').split('?')[0])).replace(/^(\.\.[/\\])+/, '');
    let file = join(dir, path);
    if (existsSync(file) && statSync(file).isDirectory()) file = join(file, 'index.html');
    if (!file.startsWith(dir) || !existsSync(file)) {
      res.writeHead(404).end();
      return;
    }
    res.writeHead(200, { 'content-type': types[extname(file)] ?? 'application/octet-stream' });
    res.end(readFileSync(file));
  });
  return new Promise((ok) => server.listen(0, '127.0.0.1', () => ok({ server, url: `http://127.0.0.1:${(server.address() as { port: number }).port}` })));
}

/**
 * Each preview's title and language sheet at 1280×720, from the cache or captured now: the page loads on a virtual clock,
 * then again (a first visit may land in play; a returning player sees the title), Play shown or 8 s; then the language
 * toggle (data-gp="lang") is opened when there is one. A game whose title can't be reached shows its first screen.
 */
export async function previewShots(browser: Browser | null, exclude: (g: { id: string; title: string }) => boolean, dir = previewsDir()): Promise<{ shots: OtherShot[]; problems: string[] }> {
  if (!dir) return { shots: [], problems: [] };
  const games = previewGames(dir).filter((g) => !exclude(g));
  mkdirSync(LOOKS_CACHE, { recursive: true });
  const shots: OtherShot[] = [];
  const problems: string[] = [];
  const todo = games.filter((g) => !existsSync(join(LOOKS_CACHE, `${cacheKey(g)}-title.png`)));
  if (todo.length && browser) {
    const { advanceClock, virtualClock } = await import('./clock.ts');
    const { server, url } = await serveDir(dir);
    try {
      const one = async (g: PreviewGame) => {
        const ctx = await browser.newContext({ viewport: { width: 1280, height: 720 }, deviceScaleFactor: 1 });
        try {
          const page = await ctx.newPage();
          await page.addInitScript(virtualClock);
          const step = async (sec: number) => {
            for (let i = 0; i < sec * 30; i++) await advanceClock(page, 1000 / 30);
          };
          const until = async (q: string, sec: number) => {
            for (let i = 0; i < sec * 30; i++) {
              if (await page.locator(`${q}:visible`).count().catch(() => 0)) return true;
              await advanceClock(page, 1000 / 30);
            }
            return false;
          };
          await page.goto(`${url}/${g.id}/index.html`, { timeout: 30_000 });
          await until('[data-gp=play]', 4);
          await step(1);
          await page.reload({ timeout: 30_000 });
          await until('[data-gp=play]', 8);
          await step(0.5);
          const base = join(LOOKS_CACHE, cacheKey(g));
          await page.screenshot({ path: `${base}-title.png` });
          const lang = page.locator('[data-gp=lang]:visible').first();
          if (await lang.count()) {
            await lang.click({ timeout: 2000 }).catch(() => {});
            await step(0.4);
            await page.screenshot({ path: `${base}-language.png` });
          }
        } catch (e) {
          problems.push(`preview ${g.id}: not captured (${String((e as Error).message).split('\n')[0]})`);
        } finally {
          await ctx.close();
        }
      };
      for (let i = 0; i < todo.length; i += 4) await Promise.all(todo.slice(i, i + 4).map(one));
    } finally {
      server.close();
    }
  }
  for (const g of games) {
    const base = join(LOOKS_CACHE, cacheKey(g));
    const src = `previews ${g.commit?.slice(0, 7) ?? g.updated?.slice(0, 10) ?? ''}`.trim();
    if (existsSync(`${base}-title.png`)) shots.push({ game: g.id, title: g.title, screen: 'title', file: `${base}-title.png`, source: src });
    if (existsSync(`${base}-language.png`)) shots.push({ game: g.id, title: g.title, screen: 'language', file: `${base}-language.png`, source: src });
  }
  return { shots, problems };
}

/** The other games' title shots of publisher/reference (a game the previews have is taken from there: newer) */
export function referenceTitles(refs: readonly ReferenceShot[], exclude: (g: { id: string; title: string }) => boolean): OtherShot[] {
  const seen = new Set<string>();
  return refs
    .filter((r) => r.screen === 'title' && existsSync(r.path) && !exclude({ id: r.game, title: r.title }))
    .filter((r) => !seen.has(r.game) && seen.add(r.game))
    .map((r) => ({ game: r.game, title: r.title, screen: 'title' as const, file: r.path, source: `publisher/reference (${r.outcome}, ${r.date})` }));
}

// --- This game's screens and the comparison ----------------------------------------------------------------------------

export type OwnScreen = 'title' | 'results' | 'language';

/** This game's title, results and language screens at 1280×720 from the last gp qa (the title also as gp review captured it) */
export function ownScreens(loc: GameLocation, capturedTitle?: string | null): { screen: OwnScreen; file: string }[] {
  const qa = join(loc.dir, 'qa');
  const files = existsSync(qa) ? readdirSync(qa) : [];
  const at = (...names: string[]) => names.map((n) => (files.includes(n) ? join(qa, n) : null)).find(Boolean) ?? null;
  const lang = at('lang-picker-desktop-1280x720.png', 'lang-picker-mobile-800x450.png', 'lang-picker-desktop-821x462.png');
  const out: { screen: OwnScreen; file: string | null }[] = [
    { screen: 'title', file: at('screen-title-desktop-1280x720.png') ?? capturedTitle ?? at('desktop-1280x720-1-first-screen.png') },
    { screen: 'results', file: at('screen-results-desktop-1280x720.png', 'desktop-1280x720-3-results.png') },
    { screen: 'language', file: lang },
  ];
  return out.filter((x): x is { screen: OwnScreen; file: string } => !!x.file);
}

export interface SamenessMatch {
  screen: OwnScreen;
  file: string;
  other: OtherShot;
  sim: LookSimilarity;
  closeness: Closeness;
}

export interface Sameness {
  /** This game's screens compared */
  screens: { screen: OwnScreen; file: string }[];
  /** How many other games' shots they were compared with */
  compared: number;
  games: number;
  /** For each of this game's screens, its closest other shot */
  closest: SamenessMatch[];
  /** Every pair at "very close" */
  veryClose: SamenessMatch[];
  /** The other games' title shots, closest first (the sheet's row) */
  row: { other: OtherShot; best: SamenessMatch | null }[];
  problems: string[];
}

/** Each picture's look, decoded and downscaled by the browser */
export async function featuresOf(page: Page, files: readonly string[]): Promise<(LookFeatures | null)[]> {
  const out: (LookFeatures | null)[] = [];
  for (const f of files) {
    const mime = f.endsWith('.png') ? 'image/png' : 'image/jpeg';
    const data = await page
      .evaluate(
        async ({ src, w, h }) => {
          const img = new Image();
          img.src = src;
          await img.decode();
          const c = document.createElement('canvas');
          c.width = w;
          c.height = h;
          const g = c.getContext('2d')!;
          g.imageSmoothingQuality = 'high';
          g.drawImage(img, 0, 0, w, h);
          return Array.from(g.getImageData(0, 0, w, h).data);
        },
        { src: `data:${mime};base64,${readFileSync(f).toString('base64')}`, w: LOOK_W, h: LOOK_H },
      )
      .catch(() => null);
    out.push(data ? lookFeatures(data) : null);
  }
  return out;
}

/** The comparison, pure: this game's screens' looks against the others' */
export function compareLooks(own: readonly { screen: OwnScreen; file: string; look: LookFeatures }[], others: readonly { shot: OtherShot; look: LookFeatures }[]): Pick<Sameness, 'closest' | 'veryClose' | 'row'> {
  const all: SamenessMatch[] = [];
  for (const o of own)
    for (const x of others) {
      const sim = lookSimilarity(o.look, x.look);
      all.push({ screen: o.screen, file: o.file, other: x.shot, sim, closeness: closeness(sim) });
    }
  const closest = own.map((o) => all.filter((m) => m.screen === o.screen).sort((a, b) => simScore(b.sim) - simScore(a.sim))[0]).filter(Boolean);
  const veryClose = all.filter((m) => m.closeness === 'very close').sort((a, b) => simScore(b.sim) - simScore(a.sim));
  const row = others
    .filter((x) => x.shot.screen === 'title')
    .map((x) => ({ other: x.shot, best: all.filter((m) => m.other === x.shot).sort((a, b) => simScore(b.sim) - simScore(a.sim))[0] ?? null }))
    .sort((a, b) => (b.best ? simScore(b.best.sim) : 0) - (a.best ? simScore(a.best.sim) : 0));
  return { closest, veryClose, row };
}

/** Compare this game's title, results and language screens with our other games' (the browser decodes the pictures) */
export async function sameness(browser: Browser, loc: GameLocation, game: { id: string; title: string }, refs: readonly ReferenceShot[], opts: { capturedTitle?: string | null; capturePreviews?: boolean } = {}): Promise<Sameness> {
  const exclude = (g: { id: string; title: string }) => g.id === game.id || g.id === loc.id || g.title.toLowerCase() === game.title.toLowerCase();
  const pv = await previewShots(opts.capturePreviews === false ? null : browser, exclude);
  const inPreviews = new Set(pv.shots.map((s) => s.game));
  const others = [...pv.shots, ...referenceTitles(refs, exclude).filter((r) => !inPreviews.has(r.game))];
  const screens = ownScreens(loc, opts.capturedTitle);
  const problems = [...pv.problems];
  if (!screens.length) problems.push('no title, results or language screen at 1280×720 to compare: run gp qa');
  const page = await browser.newPage();
  try {
    const ownLooks = await featuresOf(page, screens.map((s) => s.file));
    const otherLooks = await featuresOf(page, others.map((s) => s.file));
    const own = screens.flatMap((s, i) => (ownLooks[i] ? [{ ...s, look: ownLooks[i]! }] : []));
    const oth = others.flatMap((shot, i) => (otherLooks[i] ? [{ shot, look: otherLooks[i]! }] : []));
    return { screens, compared: oth.length, games: new Set(oth.map((x) => x.shot.game)).size, ...compareLooks(own, oth), problems };
  } finally {
    await page.close();
  }
}

/** The brief's lines: the closest screens, and a warning for every very close one */
export function samenessSection(s: Sameness | null | undefined): string[] {
  const L: string[] = ['### Sameness across the account: does it look like our other games?', ''];
  L.push('Our dense batch (13 games in 5 days, 2 approved) shared one "platform look" — the same HUD pill, results card and language sheet (docs/research/game-design-2026-10.md, S11); a reviewer who has seen our last game sees the stock screens again, and Google Play bans near-identical apps for the whole account. The game\'s title, results and language screens were compared with our other games\' titles and language sheets (a 64×36 colour histogram and a layout edge map: colour and layout agreement 0–1).', '');
  if (!s) {
    L.push('(Not compared: the review sheet was not built.)', '');
    return L;
  }
  if (!s.compared) {
    L.push(`(Not compared: ${s.problems.join('; ') || 'no shots of our other games — publisher/reference, or a previews checkout in GP_PREVIEWS'}.)`, '');
    return L;
  }
  L.push(`Compared with ${s.compared} shots of ${s.games} other games of ours.`, '');
  for (const m of s.closest) L.push(`- ${m.screen} — closest: ${m.other.title} (${m.other.screen}, ${m.other.source}): colour ${m.sim.colour}, layout ${m.sim.layout}${m.closeness ? ` — **${m.closeness}**` : ''}`);
  if (s.veryClose.length) {
    const shown = s.veryClose.slice(0, 6);
    L.push('', `**⚠ Very close to another of our games** (colour ≥ ${VERY_CLOSE.colour} and layout ≥ ${VERY_CLOSE.layout}): ${shown.map((m) => `this game's ${m.screen} ≈ ${m.other.title}'s ${m.other.screen} (${m.sim.colour} / ${m.sim.layout}, ${m.other.file})`).join('; ')}${s.veryClose.length > shown.length ? ` (+${s.veryClose.length - shown.length} more)` : ''}. Open both: if it is the platform's stock screen in its stock colours, write a \`[blocking]\` finding — the screen takes the game's own palette, type and art (screenTheme(), docs/guides/art.md) — or say why the likeness is fine (the same studio's sequel, a shared brand on purpose).`);
  } else L.push('', `No screen is very close to another game's (colour ≥ ${VERY_CLOSE.colour} and layout ≥ ${VERY_CLOSE.layout}). Still look at the row of our other games on the sheet: a likeness of the HUD or the cards is yours to see.`);
  if (s.problems.length) L.push('', ...s.problems.slice(0, 5).map((p) => `- ${p}`));
  L.push('');
  return L;
}
