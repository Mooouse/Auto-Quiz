// The calibration's look checks of the code kit's QA, judged without a browser (qa/look.ts): the title's key art under
// panels, play text size and contrast, collections of placeholders, the hero required for action games
// (docs/research/qa-calibration-2026-10.md)

import { describe, expect, it } from 'vitest';
import {
  contrastRatio,
  heroRequired,
  isHudNumber,
  isPlaceholderImage,
  isPlaceholderItem,
  judgePlayText,
  parseColor,
  silhouettesVerdict,
  textBackground,
  titleCoverVerdict,
  TITLE_COVER_FAIL,
  TITLE_COVER_WARN,
  type PlayText,
} from '../qa/look.ts';

/** An RGBA array of n pixels, each from f(i) */
const px = (n: number, f: (i: number) => [number, number, number]) => Array.from({ length: n }, (_, i) => [...f(i), 255]).flat();

describe('the title hides its key art (E_QA_TITLE_COVERED)', () => {
  it("Garage 1.0.0's centred panel (23 % of 1280×720 over a detailed garage) warns; over 45 % fails on crazygames only", () => {
    expect(TITLE_COVER_WARN).toBe(0.2);
    expect(TITLE_COVER_FAIL).toBe(0.45);
    const garage = titleCoverVerdict({ covered: 0.23, detail: true, dimmed: 0.77 }, true);
    expect(garage.level).toBe('warn');
    expect(garage.text).toMatch(/^23 % of the screen under opaque DOM panels over the canvas; a translucent layer dims 77 % more, over 20 %/);
    expect(titleCoverVerdict({ covered: 0.5, detail: true }, true).level).toBe('fail');
    expect(titleCoverVerdict({ covered: 0.5, detail: true }, false).level).toBe('warn');
    expect(titleCoverVerdict({ covered: 0.12, detail: true }, true).level).toBe('ok');
  });
  it('a flat or empty canvas behind has no key art to hide: not judged', () => {
    const v = titleCoverVerdict({ covered: 0.9, detail: false }, true);
    expect(v.level).toBe('ok');
    expect(v.text).toMatch(/not judged/);
  });
});

describe('play text at 1280×720 (E_QA_PLAY_TEXT)', () => {
  it('parses CSS and canvas colours', () => {
    expect(parseColor('rgb(255, 0, 10)')).toEqual([255, 0, 10, 1]);
    expect(parseColor('rgba(0, 0, 0, 0.5)')).toEqual([0, 0, 0, 0.5]);
    expect(parseColor('rgb(10 20 30 / 50%)')).toEqual([10, 20, 30, 0.5]);
    expect(parseColor('#fff')).toEqual([255, 255, 255, 1]);
    expect(parseColor('#11223380')![3]).toBeCloseTo(128 / 255, 5);
    expect(parseColor('transparent')).toEqual([0, 0, 0, 0]);
    expect(parseColor('linear-gradient(red, blue)')).toBeNull();
  });
  it('WCAG contrast: black on white 21:1, a colour on itself 1:1, half-transparent white on black in between', () => {
    expect(contrastRatio([0, 0, 0], [255, 255, 255])).toBeCloseTo(21, 1);
    expect(contrastRatio([120, 120, 120], [120, 120, 120])).toBeCloseTo(1, 5);
    const half = contrastRatio([255, 255, 255, 0.5], [0, 0, 0]);
    expect(half).toBeGreaterThan(4);
    expect(half).toBeLessThan(21);
  });
  it("the background behind a text is the median of the box's pixels that aren't the text's colour", () => {
    // 30 % white glyph pixels on a dark blue plate
    const box = px(100, (i) => (i % 10 < 3 ? [255, 255, 255] : [20, 30, 90]));
    expect(textBackground(box, [255, 255, 255, 1])).toEqual([20, 30, 90]);
    // A text in its background's colour: the box is all that colour
    expect(textBackground(px(50, () => [200, 200, 200]), [205, 205, 205, 1])).toEqual([200, 200, 200]);
    expect(textBackground([], [0, 0, 0])).toBeNull();
  });
  it('a HUD number is mostly digits', () => {
    for (const t of ['22/58', '1,250', '×3', '0:42', '12 HP']) expect(isHudNumber(t)).toBe(true);
    for (const t of ['Score', 'Chains 4 · Discards 3 · Bag 21', '']) expect(isHudNumber(t)).toBe(false);
  });
  const t = (o: Partial<PlayText>): PlayText => ({ text: 'Wave 3', px: 18, source: 'dom', where: 'div#hud', color: [255, 255, 255, 1], outline: null, bg: [20, 20, 40], ...o });
  it("a HUD number under 12 px fails on crazygames (a warning elsewhere); Velvet's 13 px line and a pale text on a pale sky warn", () => {
    const texts = [
      t({ text: '22/58', px: 10, source: 'canvas', where: 'canvas text' }),
      t({ text: 'Chains 4 · Discards 3 · Bag 21', px: 13 }),
      t({ text: 'Survive the night', color: [230, 230, 240, 1], bg: [200, 210, 230] }),
      t({ text: 'Fine', px: 20 }),
    ];
    const v = judgePlayText(texts, true);
    expect(v.judged).toBe(4);
    expect(v.fail).toEqual(['"22/58" (canvas text): a HUD number at 10.0 px, under 12 px']);
    expect(v.warn).toHaveLength(2);
    expect(v.warn.join('\n')).toMatch(/"Chains 4 · Discards 3 · Bag 21" \(div#hud\): 13\.0 px, under 14 px/);
    expect(v.warn.join('\n')).toMatch(/"Survive the night" \(div#hud\): contrast 1\.\d:1 against what's behind it, under 3:1/);
    const web = judgePlayText(texts, false);
    expect(web.fail).toEqual([]);
    expect(web.warn).toHaveLength(3);
  });
  it('an outline separates a text from what is behind it; unknown colours judge the size only; the same text counts once', () => {
    const pale = t({ text: 'Go!', color: [255, 255, 255, 1], bg: [240, 240, 240] });
    expect(judgePlayText([pale], true).warn).toHaveLength(1);
    expect(judgePlayText([{ ...pale, outline: [0, 0, 0, 1] }], true).warn).toHaveLength(0);
    expect(judgePlayText([t({ color: null, bg: null })], true).warn).toHaveLength(0);
    expect(judgePlayText([t({ px: 12 }), t({ px: 12 })], true).warn).toHaveLength(1);
    expect(judgePlayText([t({ text: '✦ ✦' })], true).judged).toBe(0);
  });
});

describe('a collection of placeholders (W_META_SILHOUETTES)', () => {
  it("a black car on a grey card is a silhouette, one flat colour an empty slot; a coloured picture is art", () => {
    expect(isPlaceholderImage(px(400, (i) => (i % 5 < 2 ? [10, 10, 12] : [52, 54, 58])))).toBe(true);
    expect(isPlaceholderImage(px(400, () => [40, 90, 200]))).toBe(true);
    expect(isPlaceholderImage(px(400, (i) => (i % 4 === 0 ? [220, 60, 40] : i % 4 === 1 ? [40, 160, 60] : i % 4 === 2 ? [250, 210, 60] : [52, 54, 58])))).toBe(false);
  });
  it('"???", silhouette images and empty slots are placeholders; a name or a picture is not', () => {
    expect(isPlaceholderItem({ text: '??? Arrives at the Industrial Plant', placeholderImage: true })).toBe(true);
    expect(isPlaceholderItem({ text: '???', placeholderImage: false })).toBe(true);
    expect(isPlaceholderItem({ text: 'Doodle Van', placeholderImage: true })).toBe(true);
    expect(isPlaceholderItem({ text: '', placeholderImage: null })).toBe(true);
    expect(isPlaceholderItem({ text: 'Doodle Van', placeholderImage: false })).toBe(false);
    expect(isPlaceholderItem({ text: 'Doodle Van', placeholderImage: null })).toBe(false);
  });
  it("Garage's album on a fresh save (15 of 15 placeholders) warns; half or fewer, or under 6 items, does not", () => {
    const album = Array.from({ length: 15 }, () => ({ text: '??? Arrives at the Industrial Plant', placeholderImage: true }));
    const v = silhouettesVerdict(album);
    expect(v.warn).toBe(true);
    expect(v.text).toMatch(/^15 of 15 visible items are placeholders/);
    const half = [...album.slice(0, 4), ...Array.from({ length: 4 }, () => ({ text: 'Doodle Van', placeholderImage: false }))];
    expect(silhouettesVerdict(half).warn).toBe(false);
    expect(silhouettesVerdict(album.slice(0, 5)).warn).toBe(false);
  });
});

describe('the hero required (E_QA_HERO_MISSING)', () => {
  it('action and shooting games (a sub-genre by its parent) and Arcade-tagged games; not puzzles, idle or cards', () => {
    expect(heroRequired('action')).toBe(true);
    expect(heroRequired('shooting')).toBe(true);
    expect(heroRequired('hypercasual', ['Casual', 'Arcade'])).toBe(true);
    for (const g of ['puzzle', 'idle', 'strategy', 'hypercasual', null]) expect(heroRequired(g, ['Casual'])).toBe(false);
  });
});
