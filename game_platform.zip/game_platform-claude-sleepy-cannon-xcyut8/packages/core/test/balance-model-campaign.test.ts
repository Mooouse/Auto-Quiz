// modelFromCampaign(): a balance model built from the bot's campaign — the recipe Craft Pickaxe and Garage Evolution
// wrote by hand (a running mean of the stages' minutes, at most ×1.3 a stage; the bot's purchases as the items).
import { describe, expect, it } from 'vitest';
import { modelFromCampaign, solveModel, type CampaignLog } from '../src/balance-model.ts';
import { seededRng } from '../src/rng.ts';

/**
 * A small idle game played by its bot: power is income a minute; a structure takes work ÷ power minutes (± a lucky
 * chest), pays what was earned digging it; between structures the bot buys the cheapest upgrade it can (+15 % power)
 */
function idleCampaign(seed: number): CampaignLog & { minutes: number } {
  const r = seededRng(seed);
  let power = 10;
  let coins = 0;
  let t = 0;
  let level = 0;
  const stages: CampaignLog['stages'][number][] = [];
  const buys: NonNullable<CampaignLog['buys']>[number][] = [];
  for (let k = 0; k < 24; k++) {
    const work = 12 * Math.pow(1.32, k);
    const minutes = (work / power) * (0.7 + r() * 0.6);
    stages.push({ id: `structure-${k + 1}`, minutes, reward: power * minutes, power, ...(k % 8 === 7 ? { news: { kind: 'unlock' as const, weight: 2 } } : {}) });
    t += minutes;
    coins += power * minutes;
    for (;;) {
      const cost = 25 * Math.pow(1.45, level);
      if (coins < cost) break;
      coins -= cost;
      const gain = power * 0.15;
      power += gain;
      buys.push({ min: t, cost, gain, id: `pick-${level + 1}` });
      level++;
    }
  }
  return { start: { power: 10 }, stages, buys, minutes: t };
}

describe('modelFromCampaign', () => {
  it('smooths the stage times (running mean of 5, at most ×1.3 a stage) and keeps bosses and news', () => {
    const m = modelFromCampaign({
      start: { power: 1 },
      stages: [
        { minutes: 1, reward: 10, power: 1 },
        { minutes: 1, reward: 10, power: 1.2 },
        { minutes: 4, reward: 10, power: 1.4 },
        { minutes: 2, reward: 10, power: 1.6, kind: 'boss', news: { kind: 'boss' } },
        { minutes: 1, reward: 10, power: 1.8 },
        { minutes: 0.01, reward: 10, power: 2 },
      ],
    });
    // Stage 1: the mean of 1, 1, 4 (the boss left out: it keeps its own 2); stage 2: of 1, 1, 4, 1 — under ×1.3 of stage 1
    expect(m.stages.map((s) => Math.round(s.minutes * 100) / 100)).toEqual([2, 1.75, 1.4, 2, 1.5, 1.67]);
    expect(m.stages[0]).toMatchObject({ id: 'stage-1', difficulty: 0.7, reward: 10 });
    expect(m.stages[3]).toMatchObject({ kind: 'boss', news: { kind: 'boss' } });
    expect(m.items).toEqual([]);
    // The cap: a jump from 1 to 5 minutes rises ×1.3 a stage
    const capped = modelFromCampaign({ start: { power: 1 }, stages: [1, 5, 5, 5].map((minutes) => ({ minutes, reward: 1, power: 1 })) }, { smooth: 1 });
    expect(capped.stages.map((s) => Math.round(s.minutes * 1000) / 1000)).toEqual([1, 1.3, 1.69, 2.197]);
  });

  it('batches the purchases (a quarter-minute is one item, each after the one before) with the power they added — or the power path, held', () => {
    const m = modelFromCampaign(
      {
        start: { power: 10 },
        stages: [{ minutes: 1, reward: 50, power: 10 }],
        buys: [
          { min: 1, cost: 20, gain: 2, id: 'pick' },
          { min: 1.1, cost: 30, gain: 3, id: 'drill', news: { kind: 'unlock' } },
          { min: 2, cost: 40, gain: 4, id: 'pick' },
        ],
      },
      { win: (r) => Math.min(1, r), finish: 'stages', sessionMin: 15 },
    );
    expect(m.items).toEqual([
      { id: 'buy-1', cost: 50, power: 5, news: { kind: 'unlock' } },
      { id: 'pick#2', cost: 40, power: 4, requires: 'buy-1' },
    ]);
    expect(m).toMatchObject({ finish: 'stages', sessionMin: 15, start: { power: 10 } });
    // Garage Evolution's way: the power after each purchase, a dip (a new garage's fresh tools) held at the best so far
    const held = modelFromCampaign({ start: { power: 10 }, stages: [], buys: [{ min: 1, cost: 10, powerAfter: 12 }, { min: 2, cost: 10, powerAfter: 9 }, { min: 3, cost: 10, powerAfter: 15 }] });
    expect(held.items.map((i) => i.mult)).toEqual([1.2, 1.0005, 1.24938]);
  });

  it("averages several seeds' campaigns and walks like the bot: the model's meta within 25 % of the bot's", () => {
    const camps = [1, 2, 3].map(idleCampaign);
    const model = modelFromCampaign(camps, { win: (r) => Math.min(1, r), lossReward: 0, farmBelow: 0.1, finish: 'stages', measure: 'income a minute' });
    expect(model.stages).toHaveLength(24);
    expect(model.stages[7].news).toEqual({ kind: 'unlock', weight: 2 });
    const res = solveModel(model);
    const bot = camps.reduce((a, c) => a + c.minutes, 0) / camps.length;
    expect(res.cheap.finishMin).not.toBeNull();
    expect(Math.abs(res.cheap.finishMin! - bot) / bot).toBeLessThan(0.25);
    expect(res.checks.filter((c) => c.status === 'fail')).toEqual([]);
    expect(() => modelFromCampaign([])).toThrow(/no campaign/);
  });
});
