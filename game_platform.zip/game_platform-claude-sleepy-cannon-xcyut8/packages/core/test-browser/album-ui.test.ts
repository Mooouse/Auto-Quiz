// Browser test of the album (mountAlbum): one screen at every size (pages per group, never a scroll), rows labelled,
// silhouettes for the missing, "new" marks gone once seen, a tap names an entry, the theme over the shared base.
// `npm run test:browser` (Playwright's Chromium).
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { layoutOf, metaLog, SIZES, startFixture, type Fixture } from './meta-helpers';

let fx: Fixture;
beforeAll(async () => {
  fx = await startFixture();
}, 60000);
afterAll(async () => fx?.close());

describe('mountAlbum', () => {
  it('fits one screen at every size: the pickaxes and the fish on pages, every button ≥ 48 px under the game\'s CSS', async () => {
    for (const viewport of SIZES) {
      const page = await fx.open('screen=album&found=20', viewport);
      expect(await layoutOf(page, 'gp-album'), `${viewport.width}×${viewport.height}`).toEqual([]);
      let pages = 1;
      const seen = new Set<string>();
      for (const id of await page.locator('[data-gp=album-cell]').evaluateAll((es) => es.map((e) => (e as HTMLElement).dataset.gpEntry!))) seen.add(id);
      while ((await page.getAttribute('[data-gp=album-next]', 'aria-disabled')) !== 'true' && pages < 20) {
        await page.tap('[data-gp=album-next]');
        pages++;
        expect(await layoutOf(page, 'gp-album'), `page ${pages} at ${viewport.width}×${viewport.height}`).toEqual([]);
        for (const id of await page.locator('[data-gp=album-cell]').evaluateAll((es) => es.map((e) => (e as HTMLElement).dataset.gpEntry!))) seen.add(id);
      }
      // Every entry is on some page, each group on its own pages
      expect(seen.size, `${viewport.width}×${viewport.height}`).toBe(100);
      if (viewport.width === 1280) expect(pages).toBeLessThanOrEqual(3);
      await page.close();
    }
  }, 90000);

  it('labels the rows, shows silhouettes for the missing and found ones in their picture, the counts and the bonus', async () => {
    const page = await fx.open('screen=album&found=10', SIZES[1]);
    expect(await page.innerText('[data-gp=album-count]')).toBe('10/100 found');
    expect(await page.locator('.gp-al-label', { hasText: 'Wood' }).count()).toBe(1);
    expect(await page.locator('[data-gp=album-cell][data-found]').count()).toBe(10);
    expect(await page.locator('[data-gp-entry="iron:1"]:not([data-found]) img').count()).toBe(1);
    // A missing one is a silhouette: its picture blacked out, its row's tint behind it
    const filter = await page.evaluate(() => getComputedStyle(document.querySelector('[data-gp-entry="iron:1"] img')!).filter);
    expect(filter).toContain('brightness(0)');
    expect(await page.innerText('.gp-al-sub')).toContain('Bonus for good: +10 %');
    await page.close();
  });

  it('a tap names the entry (or says it is not found yet); the "new" marks are gone the next time', async () => {
    const page = await fx.open('screen=album&found=6', SIZES[1]);
    expect(await page.locator('[data-gp=album-cell][data-new]').count()).toBe(2);
    await page.tap('[data-gp-entry="wood:5"]');
    expect(await page.innerText('[data-gp=album-info]')).toContain('Pickaxe wood:5');
    expect(await page.innerText('[data-gp=album-info]')).toContain('Rare · Wood');
    await page.tap('[data-gp-entry="iron:2"]');
    expect(await page.innerText('[data-gp=album-info]')).toContain('Not found yet');
    await page.tap('[data-gp=album-close]');
    expect((await metaLog(page)).at(-1)).toBe('close');
    const fresh = await page.evaluate(() => (window as unknown as { __meta: { album: { state(): { newCount: number } } } }).__meta.album.state().newCount);
    expect(fresh).toBe(0);
    await page.close();
  });

  it('a secret entry is "?" until found; the fish group has its own page; the shared theme and its own variable apply', async () => {
    const page = await fx.open('screen=album&found=6&theme=1', SIZES[1]);
    while ((await page.locator('[data-gp-entry=fish11]').count()) === 0) await page.tap('[data-gp=album-next]');
    expect(await page.innerText('.gp-al-sub b')).toBe('Fish');
    expect(await page.locator('[data-gp-entry=fish11] svg[data-mark=question]').count()).toBe(1);
    const st = await page.evaluate(() => ({ bg: getComputedStyle(document.getElementById('gp-album')!).backgroundColor }));
    expect(st.bg).toBe('rgb(7, 8, 9)');
    await page.close();
  });
});
