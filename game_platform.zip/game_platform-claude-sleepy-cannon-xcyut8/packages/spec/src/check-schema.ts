// Structural check of a parsed game.yaml against GAME_SCHEMA. Friendly messages, "did you mean", no dependencies.

import type { JsonSchema } from '@gp/core/schema';
import { formatPath, suggest, type Issue } from './errors.ts';

type Path = (string | number)[];

function typeOf(v: unknown): string {
  if (Array.isArray(v)) return 'array';
  if (v === null) return 'null';
  if (typeof v === 'number') return Number.isInteger(v) ? 'integer' : 'number';
  return typeof v;
}

const TYPE_WORDS: Record<string, string> = {
  object: 'a section (key: value pairs)',
  array: 'a list',
  string: 'text',
  number: 'a number',
  integer: 'a whole number',
  boolean: 'true or false',
};

function typeMatches(want: string, v: unknown): boolean {
  const t = typeOf(v);
  if (want === 'number') return t === 'number' || t === 'integer';
  return t === want;
}

/** Ids that exist for a catalog kind (for `x-gp-ref` fields) */
export type RefIds = (kind: NonNullable<JsonSchema['x-gp-ref']>) => string[];

/** Returns issues; an empty list means the value fits the schema */
export function checkSchema(value: unknown, schema: JsonSchema, refs: RefIds, path: Path = []): Issue[] {
  const issues: Issue[] = [];
  const at = formatPath(path);
  const err = (code: string, message: string, fix: string) => issues.push({ code, severity: 'error', path, message, fix });

  if (schema.oneOf) {
    const fits = schema.oneOf.filter((s) => checkSchema(value, s, refs, path).length === 0);
    if (fits.length === 0) {
      // If exactly one branch has the right type, report its problems — more useful than "none matched"
      const sameType = schema.oneOf.filter((s) => !s.type || typeMatches(s.type, value));
      if (sameType.length === 1) return checkSchema(value, sameType[0], refs, path);
      const forms = schema.oneOf.map((s) => s.description ?? TYPE_WORDS[s.type ?? ''] ?? 'a value').join('; or ');
      err('E_ONE_OF', `${at}: the value fits none of the allowed forms`, `Use ${forms}.`);
    }
    return issues;
  }
  if (schema.const !== undefined) {
    if (value !== schema.const) err('E_CONST', `${at} must be ${JSON.stringify(schema.const)}, got ${JSON.stringify(value)}`, `Set ${at}: ${schema.const}`);
    return issues;
  }
  if (schema.enum) {
    if (!schema.enum.includes(value as never)) {
      const opts = schema.enum.map(String);
      const s = typeof value === 'string' ? suggest(value, opts) : null;
      err('E_ENUM', `${at}: ${JSON.stringify(value)} is not allowed. Allowed: ${opts.join(', ')}`, s ? `Did you mean "${s}"? Set ${at}: ${s}` : `Use one of: ${opts.join(', ')}`);
    }
    return issues;
  }
  if (typeof value === 'number' && !Number.isFinite(value)) {
    err('E_TYPE', `${at}: ${value} is not a finite number (.inf / .nan are not allowed)`, 'Use a regular number; for "never", use a large one, e.g. 999999.');
    return issues;
  }
  if (value === null && schema.type) {
    err(
      'E_TYPE',
      `${at} is empty`,
      schema.type === 'object'
        ? `Add fields under ${at}, or remove the empty \`${path.at(-1)}:\` line.`
        : schema.type === 'string'
          ? `Write a value after "${path.at(-1)}:". Colors like #ff0000 must be quoted ("#ff0000"): an unquoted # starts a YAML comment.`
          : `Write a value after "${path.at(-1)}:".`,
    );
    return issues;
  }
  if (schema.type && !typeMatches(schema.type, value)) {
    err('E_TYPE', `${at} must be ${TYPE_WORDS[schema.type]}, got ${TYPE_WORDS[typeOf(value)] ?? typeOf(value)}`, `Write ${at} as ${TYPE_WORDS[schema.type]}${schema.examples ? `, e.g. ${JSON.stringify(schema.examples[0])}` : ''}.`);
    return issues;
  }
  if (typeof value === 'number') {
    const lo = schema.minimum ?? (schema.exclusiveMinimum !== undefined ? schema.exclusiveMinimum : undefined);
    if (schema.minimum !== undefined && value < schema.minimum) err('E_RANGE', `${at} = ${value} is below the minimum ${schema.minimum}`, `Use a value ≥ ${schema.minimum}${schema.maximum !== undefined ? ` and ≤ ${schema.maximum}` : ''}.`);
    else if (schema.exclusiveMinimum !== undefined && value <= schema.exclusiveMinimum) err('E_RANGE', `${at} = ${value} must be greater than ${schema.exclusiveMinimum}`, `Use a value > ${lo}.`);
    if (schema.maximum !== undefined && value > schema.maximum) err('E_RANGE', `${at} = ${value} is above the maximum ${schema.maximum}`, `Use a value ≤ ${schema.maximum}.`);
  }
  if (typeof value === 'string') {
    if (schema.pattern && !new RegExp(schema.pattern).test(value))
      err('E_PATTERN', `${at}: "${value}" has the wrong format (${schema.pattern})`, `${schema.description ?? 'See the format'}${schema.examples ? `. Example: ${schema.examples[0]}` : ''}`);
    if (schema.minLength !== undefined && value.length < schema.minLength) err('E_LENGTH', `${at} is empty or too short`, `Write at least ${schema.minLength} characters.`);
    if (schema.maxLength !== undefined && value.length > schema.maxLength) err('E_LENGTH', `${at} is ${value.length} characters, the limit is ${schema.maxLength}`, `Shorten it to ${schema.maxLength} characters.`);
    const kind = schema['x-gp-ref'];
    if (kind) {
      const ids = refs(kind);
      if (!ids.includes(value)) {
        const s = suggest(value, ids);
        err('E_REF_UNKNOWN', `${at}: there is no ${kind} "${value}"`, `${s ? `Did you mean "${s}"? ` : ''}Available: ${ids.join(', ')} (\`gp catalog ${kind}\`)`);
      }
    }
  }
  if (Array.isArray(value)) {
    if (schema.minItems !== undefined && value.length < schema.minItems) err('E_ITEMS', `${at} has ${value.length} items, needs at least ${schema.minItems}`, `Add items (at least ${schema.minItems}).`);
    if (schema.maxItems !== undefined && value.length > schema.maxItems) err('E_ITEMS', `${at} has ${value.length} items, at most ${schema.maxItems} allowed`, `Remove items (at most ${schema.maxItems}).`);
    if (schema.items) value.forEach((v, i) => issues.push(...checkSchema(v, schema.items!, refs, [...path, i])));
  }
  if (typeOf(value) === 'object') {
    const obj = value as Record<string, unknown>;
    const props = schema.properties ?? {};
    for (const r of schema.required ?? []) {
      if (!(r in obj)) {
        const d = props[r]?.description;
        err('E_REQUIRED', `${formatPath([...path, r])} is required${d ? ` — ${d}` : ''}`, `Add \`${r}:\` to ${path.length ? at : 'game.yaml'}. See \`gp explain ${formatPath([...path, r])}\`.`);
      }
    }
    for (const [k, v] of Object.entries(obj)) {
      const p = Object.hasOwn(props, k) ? props[k] : undefined;
      if (p) issues.push(...checkSchema(v, p, refs, [...path, k]));
      else if (schema.additionalProperties === false) {
        const s = suggest(k, Object.keys(props));
        issues.push({
          code: 'E_UNKNOWN_FIELD',
          severity: 'error',
          path: [...path, k],
          message: `${formatPath([...path, k])}: unknown field "${k}"${path.length ? ` in ${at}` : ''}`,
          fix: s ? `Did you mean "${s}"?` : `Known fields here: ${Object.keys(props).join(', ')}`,
        });
      } else if (typeof schema.additionalProperties === 'object') issues.push(...checkSchema(v, schema.additionalProperties, refs, [...path, k]));
    }
  }
  return issues;
}
