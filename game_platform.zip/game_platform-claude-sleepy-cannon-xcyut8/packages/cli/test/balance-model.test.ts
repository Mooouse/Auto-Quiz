// gp balance / gp qa read a game's balance model: alone (no bot yet) or beside the bot, on the main thread or in the worker

import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterAll, describe, expect, it } from 'vitest';
import { balanceDesign, balanceQa, runBalanceFile, runBalanceFileInWorker } from '../src/balance.ts';
import type { GameLocation } from '../src/paths.ts';

const dir = mkdtempSync(join(tmpdir(), 'gp-model-'));
afterAll(() => rmSync(dir, { recursive: true, force: true }));

const MODEL = `
import { curve, type BalanceModel } from '@gp/core/balance-model';
export function balanceModel(): BalanceModel {
  const d = curve.geometric(8, 10, 1.3);
  const r = curve.geometric(8, 20, 1.25);
  const items = ['blade', 'armour', 'boots'].flatMap((u, k) => curve.geometric(3, 15 + 10 * k, 1.8).map((cost, l) => ({ id: u + '-' + (l + 1), cost, mult: 1.2, ...(l ? { requires: u + '-' + l } : {}) })));
  return { start: { power: 11 }, stages: d.map((difficulty, i) => ({ id: 's' + (i + 1), difficulty, reward: r[i], minutes: 1.5 })), items, measure: 'DPS' };
}
`;

describe('the balance model in gp balance', () => {
  it("a game with only balanceModel(): the report is the model's, its checks come along", async () => {
    const file = join(dir, 'model-only.ts');
    writeFileSync(file, MODEL);
    const run = await runBalanceFile(file, 'crazygames');
    expect(run.source).toBe('model');
    expect(run.model?.checks.length).toBeGreaterThan(4);
    expect(run.verdict.rows.find((r) => r.name === 'The meta lasts')?.status).not.toBe('skip');
    expect(run.model?.markdown).toContain('### Stages');
  });
  it("beside a bot: the bot's report counts, the model adds its checks; the worker gives the same", async () => {
    const file = join(dir, 'bot.ts');
    writeFileSync(file, MODEL + `export function balance() { return { fresh: 1, full: 2, dead: [] }; }\n`);
    const run = await runBalanceFile(file, 'crazygames');
    expect(run.source).toBe('bot');
    expect(run.report.full).toBe(2);
    const inWorker = await runBalanceFileInWorker(file, 'crazygames');
    expect(inWorker.model?.checks.map((c) => c.status)).toEqual(run.model?.checks.map((c) => c.status));
    const checks: string[] = [];
    await balanceQa({ dir, id: 'x' } as unknown as GameLocation, 'crazygames', { check: (_s, n) => void checks.push(n), info: () => {} });
    expect(checks.some((n) => n.startsWith('model: '))).toBe(true);
  });
  it('a patch runs the model alone (the bot is skipped); a launch runs both and compares them', async () => {
    const file = join(dir, 'both.ts');
    writeFileSync(file, MODEL + `export function balance() { throw new Error('the bot ran'); }\n`);
    const patch = await runBalanceFile(file, 'crazygames', { bot: false });
    expect(patch.source).toBe('model');
    expect(patch.compare).toBeUndefined();
    await expect(runBalanceFile(file, 'crazygames')).rejects.toThrow('the bot ran');
    const file2 = join(dir, 'both2.ts');
    writeFileSync(file2, MODEL + `export function balance() { return { cheap: { firstPurchaseRun: 1, firstPurchaseMin: 2, finishMin: 999 } }; }\n`);
    const launch = await runBalanceFile(file2, 'crazygames');
    expect(launch.compare?.find((r) => r.name === "model vs bot: the meta's length")?.status).toBe('warn');
  });
});

describe('the anchor in gp balance and gp qa', () => {
  const game = (name: string, src: string) => {
    const d = join(dir, name);
    mkdirSync(d, { recursive: true });
    writeFileSync(join(d, 'bot.ts'), src);
    return { dir: d, id: name } as unknown as GameLocation;
  };
  const qa = () => {
    const out = { checks: [] as { name: string; ok: boolean }[], infos: [] as { name: string; details: string }[] };
    return { out, ctx: { check: (_s: string, name: string, ok: boolean) => void out.checks.push({ name, ok }), info: (_s: string, name: string, details: string) => void out.infos.push({ name, details }) } };
  };
  const ANCHOR = { name: 'damage', unit: 'DPS', says: 'what the hero deals a second' };
  it('declared: a first reward later than a minute fails QA; without it the same is a ⚠ line', async () => {
    const loc = game('strict', MODEL);
    const strict = qa();
    await balanceQa(loc, 'crazygames', strict.ctx, { design: { anchor: ANCHOR, sessionMin: 15 } });
    expect(strict.out.checks.find((c) => c.name === 'model: The first reward within a minute')?.ok).toBe(false);
    const lenient = qa();
    await balanceQa(loc, 'crazygames', lenient.ctx, { design: { sessionMin: 15 } });
    expect(lenient.out.checks.find((c) => c.name.includes('The first reward'))).toBeUndefined();
    expect(lenient.out.infos.find((i) => i.name === '⚠ model: The first reward within a minute')?.details).toContain('a warning until game.yaml declares balance.anchor');
    const run = await runBalanceFile(join(loc.dir, 'bot.ts'), 'crazygames', { design: { anchor: ANCHOR, sessionMin: 15, metaMin: 5 } });
    expect(run.model?.strict).toBe(true);
    expect(run.model?.checks.find((c) => c.name === "model: The meta's length agrees with money.meta")?.status).toBe('warn');
    // The worker passes the design through
    const inWorker = await runBalanceFileInWorker(join(loc.dir, 'bot.ts'), 'crazygames', { design: { anchor: ANCHOR, sessionMin: 15 } });
    expect(inWorker.model?.strict).toBe(true);
  });
  it("the model's first reward beside the first minute's first celebrated moment", async () => {
    const loc = game('notes', MODEL);
    const notes: { modelFirstRewardSec?: number | null; firstHighlightSec?: number | null } = { firstHighlightSec: 12 };
    const q = qa();
    await balanceQa(loc, 'crazygames', { ...q.ctx, notes });
    expect(notes.modelFirstRewardSec).toBeGreaterThan(0);
    expect(q.out.infos.find((i) => i.name === 'the first reward (balance model)')?.details).toMatch(/^\d+ s of play — the first minute's demo bot: the first celebrated moment 12 s after Play$/);
  });
  it('an anchor without a model says the first-session checks are not made', async () => {
    const q = qa();
    await balanceQa(game('bot-only', `export function balance() { return { fresh: 1, full: 2, dead: [] }; }\n`), 'crazygames', q.ctx, { design: { anchor: ANCHOR } });
    expect(q.out.infos.find((i) => i.name === '⚠ balance model' && i.details.includes('declares the anchor'))).toBeTruthy();
  });
  it('the design from game.yaml as written: a TODO anchor is none', () => {
    expect(balanceDesign(null, { balance: { anchor: { name: 'clear time', unit: 's', says: 'x' } }, money: { session: { minutes: 15 }, meta: { minutes: 60 } } })).toEqual({ anchor: { name: 'clear time', unit: 's', says: 'x', shape: 'campaign' }, sessionMin: 15, metaMin: 60, difficulty: null });
    expect(balanceDesign(null, { balance: { anchor: { name: 'waves a run', unit: 'waves', says: 'x', shape: 'run' } } }).anchor?.shape).toBe('run');
    expect(balanceDesign(null, { balance: { anchor: { name: 'TODO: the anchor', unit: 's' } } }).anchor).toBeNull();
    expect(balanceDesign(null, null)).toEqual({ anchor: null, sessionMin: null, metaMin: null, difficulty: null });
  });
});

describe('the skill ladder in gp balance and gp qa (game.yaml balance.difficulty)', () => {
  const LADDER = `
export function balance() {
  return {
    measure: 'waves a run',
    skills: { naive: { runs: 120, wins: 0, progress: 6 }, skilled: { runs: 120, wins: WINS, winMin: [31, 33, 35], progress: 14 } },
    choices: Array.from({ length: 60 }, (_, i) => ({ offered: ['laser', 'rock', 'coil'], picked: i % 4 ? 'laser' : 'coil' })),
  };
}
`;
  const DIFF = { skilled: { winRate: 0.2, tolerance: 0.05 }, winningRunMin: [30, 40] as const };
  it('a win rate off the target fails QA; on target it passes; a patch (the model alone) does not judge it', async () => {
    const d = join(dir, 'ladder');
    mkdirSync(d, { recursive: true });
    const loc = { dir: d, id: 'ladder' } as unknown as GameLocation;
    const run = async (wins: number) => {
      writeFileSync(join(d, 'bot.ts'), LADDER.replace('WINS', String(wins)) + MODEL);
      const out = { checks: [] as { name: string; ok: boolean }[], infos: [] as { name: string; details: string }[] };
      await balanceQa(loc, 'crazygames', { check: (_s, name, ok) => void out.checks.push({ name, ok }), info: (_s, name, details) => void out.infos.push({ name, details }) }, { design: { difficulty: DIFF } });
      return out;
    };
    const on = await run(24);
    expect(on.checks.find((c) => c.name === "The skilled player's win rate")?.ok).toBe(true);
    expect(on.checks.find((c) => c.name === "The winning run's length")?.ok).toBe(true);
    expect(on.checks.find((c) => c.name === 'Skill matters: naive falls behind skilled')?.ok).toBe(true);
    // laser picked 75 % of the times offered, rock never: both in one ⚠ row
    expect(on.infos.find((i) => i.name === '⚠ Offered choices are real choices')?.details).toMatch(/dominant: laser 75 %.*dead weight: rock 0 %/);
    const off = await run(60);
    expect(off.checks.find((c) => c.name === "The skilled player's win rate")?.ok).toBe(false);
    // Without a target the ladder is said, not checked
    const free = { checks: [] as string[], infos: [] as { name: string; details: string }[] };
    await balanceQa(loc, 'crazygames', { check: (_s, n) => void free.checks.push(n), info: (_s, name, details) => void free.infos.push({ name, details }) });
    expect(free.checks).not.toContain("The skilled player's win rate");
    expect(free.infos.find((i) => i.name === "The skilled player's win rate")?.details).toContain('skilled 50 % (60 of 120)');
    expect(free.infos.find((i) => i.name === 'balance report')?.details).not.toContain("The skilled player's win rate");
    // A patch runs the model alone: nothing measured, nothing failed
    const patch = await runBalanceFile(join(d, 'bot.ts'), 'crazygames', { bot: false, design: { difficulty: DIFF } });
    expect(patch.verdict.rows.find((r) => r.name === "The skilled player's win rate")?.status).toBe('skip');
    expect(patch.verdict.ok).toBe(true);
  });
  it('the design from game.yaml as written: the numbers that are numbers', () => {
    expect(balanceDesign(null, { balance: { difficulty: { skilled: { winRate: 0.2 }, naive: { winRate: 'x' }, winningRunMin: [40, 30] } } }).difficulty).toEqual({ skilled: { winRate: 0.2 }, winningRunMin: [30, 40] });
    expect(balanceDesign(null, { balance: { difficulty: 'hard' } }).difficulty).toBeNull();
  });
});

