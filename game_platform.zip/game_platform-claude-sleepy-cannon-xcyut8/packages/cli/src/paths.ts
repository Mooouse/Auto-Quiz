// Where things live in the repository.

import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import { basename, dirname, join, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

export const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '../../..');
/** Where `gp new` puts a YAML-kit game made inside the platform (created on demand: the platform ships no game of its own) */
export const GAMES_DIR = join(ROOT, 'games');
/** The examples with their own folder: docs/examples/<name>/game.yaml (kids: Balloon Pop, the kids kit's regression test; code; art) */
export const EXAMPLES_DIR = join(ROOT, 'docs/examples');
export const PLAYER_DIR = join(ROOT, 'packages/player');
export const PUBLISHER_FILE = join(ROOT, 'publisher/publisher.yaml');
export const SCHEMA_FILE = join(ROOT, 'packages/spec/schema/game.schema.json');
/** A path to print: relative to the platform when it's inside it, absolute when it isn't (a game in its own repository) */
export function shown(p: string): string {
  const r = relative(ROOT, p);
  return r.startsWith('..') ? p : r;
}
export const DOCS_REFERENCE_DIR = join(ROOT, 'docs/reference');

export interface GameLocation {
  id: string;
  dir: string;
  file: string;
}

/** A game.yaml anywhere: id from the file name (x.game.yaml → x) or its folder (…/x/game.yaml → x) */
function fromFile(file: string): GameLocation {
  const name = basename(file).replace(/(\.game)?\.yaml$/, '');
  return { id: name === 'game' ? basename(dirname(file)) : name, dir: dirname(file), file };
}

export function listGames(): string[] {
  if (!existsSync(GAMES_DIR)) return [];
  return readdirSync(GAMES_DIR, { withFileTypes: true })
    .filter((d) => d.isDirectory() && existsSync(join(GAMES_DIR, d.name, 'game.yaml')))
    .map((d) => d.name)
    .sort();
}

/** The folder examples (docs/examples/<name>/game.yaml), each found by its game.yaml `id` too: `balloon-pop` → docs/examples/kids */
export function listExamples(): (GameLocation & { gameId: string | null })[] {
  if (!existsSync(EXAMPLES_DIR)) return [];
  return readdirSync(EXAMPLES_DIR, { withFileTypes: true })
    .filter((d) => d.isDirectory() && existsSync(join(EXAMPLES_DIR, d.name, 'game.yaml')))
    .map((d) => {
      const dir = join(EXAMPLES_DIR, d.name);
      const file = join(dir, 'game.yaml');
      const gameId = readFileSync(file, 'utf8').match(/^id:\s*["']?([a-z][a-z0-9-]*)/m)?.[1] ?? null;
      return { id: d.name, dir, file, gameId };
    })
    .sort((a, b) => a.id.localeCompare(b.id));
}

/** What `--all` checks and an unknown id lists: the games in games/ and the folder examples */
function known(): string {
  return [...listGames(), ...listExamples().map((e) => e.gameId ?? e.id)].join(', ') || '(none)';
}

/** A game by id (games/<id>, or a folder example by its game.yaml id: "balloon-pop" → docs/examples/kids), folder or path to
 *  game.yaml; default: the game folder we are in */
export function locateGame(arg?: string): GameLocation {
  const tryDir = (dir: string): GameLocation | null => {
    const file = join(dir, 'game.yaml');
    return existsSync(file) ? { id: dir.split(/[\\/]/).pop()!, dir, file } : null;
  };
  if (arg) {
    const found =
      (arg.endsWith('.yaml') && existsSync(arg) ? fromFile(resolve(arg)) : null) ??
      tryDir(resolve(arg)) ??
      tryDir(join(GAMES_DIR, arg)) ??
      example(arg);
    if (found) return found;
    throw new Error(`No game "${arg}". Games: ${known()}. Create one: gp new <id> --from balloon-pop`);
  }
  let dir = process.cwd();
  while (dir !== dirname(dir)) {
    const g = tryDir(dir);
    if (g) return g;
    dir = dirname(dir);
  }
  throw new Error(`Which game? Pass an id: gp <command> <game>. Games: ${known()}`);
}

/** A folder example by its game.yaml id, under that id ("balloon-pop", not "kids") */
function example(id: string): GameLocation | null {
  const e = listExamples().find((x) => x.gameId === id);
  return e ? { id, dir: e.dir, file: e.file } : null;
}

/** The newest modification time of the game's own files (its code, data and game.yaml; not its outputs, and not its
 *  Markdown: REPORT.md, quality.md or CHANGELOG.md don't change what the covers and videos show) */
export function newestSourceMs(dir: string): number {
  const skip = new Set(['store', 'qa', 'dist', 'upload', 'submission', 'node_modules', '.git']);
  let newest = 0;
  const walk = (d: string) => {
    for (const e of readdirSync(d, { withFileTypes: true })) {
      if (skip.has(e.name)) continue;
      const p = join(d, e.name);
      if (e.isDirectory()) walk(p);
      else if (!e.name.endsWith('.md')) newest = Math.max(newest, statSync(p).mtimeMs);
    }
  };
  walk(dir);
  return newest;
}

/** The covers and videos older than the game's code: they show a game that no longer exists */
export function staleMedia(files: string[], sourceMs: number): string[] {
  return files.filter((f) => existsSync(f) && statSync(f).mtimeMs < sourceMs);
}
