// Browser test of the recorder mirror (recorder.ts): Playgama's QA Tool films the page's first <canvas> only, so DOM
// screens were invisible to it (Candle Crypt's "Ad not finished — no reward", 2026-10-10). After a recorder message the
// first canvas is the mirror, and it shows the game's canvas with the DOM painted over it.
// Runs with `npm run test:browser` (needs Playwright's Chromium).

import { fileURLToPath } from 'node:url';
import { chromium, type Browser } from 'playwright';
import { createServer, type ViteDevServer } from 'vite';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

let server: ViteDevServer;
let browser: Browser;
let base = '';

beforeAll(async () => {
  server = await createServer({ root: fileURLToPath(new URL('./recorder-fixture', import.meta.url)), configFile: false, logLevel: 'error', server: { port: 0 } });
  await server.listen();
  base = server.resolvedUrls!.local[0];
  browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
}, 60000);

afterAll(async () => {
  await browser?.close();
  await server?.close();
});

/** The mirror's pixels in a CSS-px box: how many are purple (the button), white (its text), red (the game) */
const PIXELS = `(box) => {
  const m = document.querySelector('canvas');
  const d = m.getContext('2d').getImageData(box.x, box.y, box.w, box.h).data;
  let purple = 0, white = 0, red = 0;
  for (let i = 0; i < d.length; i += 4) {
    const [r, g, b] = [d[i], d[i + 1], d[i + 2]];
    if (r > 110 && r < 150 && g > 40 && g < 80 && b > 210) purple++;
    else if (r > 230 && g > 230 && b > 230) white++;
    else if (r > 200 && g < 50 && b < 50) red++;
  }
  return { id: m.id, purple, white, red, total: d.length / 4, url: m.toDataURL().length };
}`;

describe('recorder mirror', () => {
  it('nothing changes for players: no recorder message, no mirror', async () => {
    const page = await browser.newPage({ viewport: { width: 640, height: 360 } });
    await page.goto(base);
    await page.waitForFunction('!!window.__t');
    await page.evaluate(() => window.postMessage({ type: 'platform', action: 'initialize' }, '*'));
    await page.waitForTimeout(100);
    expect(await page.evaluate(() => document.querySelector('canvas')!.id)).toBe('game');
    await page.close();
  });

  it("after the QA Tool's first recorder message the Bridge finds the mirror, with the game and the DOM screen in it", async () => {
    const page = await browser.newPage({ viewport: { width: 640, height: 360 } });
    const errors: string[] = [];
    page.on('pageerror', (e) => errors.push(e.message));
    await page.goto(base);
    await page.waitForFunction('!!window.__t');
    await page.evaluate(() => window.postMessage({ type: 'recorder', action: 'take_screenshot', id: 'x' }, '*'));
    await page.waitForFunction('window.__t.bridgeSaw.length === 1');
    // The Bridge's own listener, in the same message, already sees the mirror
    expect(await page.evaluate('window.__t.bridgeSaw')).toEqual(['gp-recorder']);
    await page.waitForTimeout(150);
    const b = await page.locator('#ad').boundingBox();
    const button = await page.evaluate(`(${PIXELS})(${JSON.stringify({ x: Math.round(b!.x), y: Math.round(b!.y), w: Math.round(b!.width), h: Math.round(b!.height) })})`) as { id: string; purple: number; white: number; total: number; url: number };
    expect(button.id).toBe('gp-recorder');
    expect(button.purple / button.total).toBeGreaterThan(0.4);
    // The words are there (white glyphs), not only the box
    expect(button.white / button.total).toBeGreaterThan(0.03);
    const corner = await page.evaluate(`(${PIXELS})({ x: 0, y: 0, w: 60, h: 60 })`) as { red: number; total: number; url: number };
    expect(corner.red / corner.total).toBeGreaterThan(0.95);
    expect(corner.url).toBeGreaterThan(1000);
    // A second message doesn't add a second mirror; the mirror never takes a tap
    await page.evaluate(() => window.postMessage({ type: 'recorder', action: 'start_capture', options: {} }, '*'));
    await page.waitForTimeout(50);
    expect(await page.evaluate(() => document.querySelectorAll('canvas').length)).toBe(2);
    expect(await page.evaluate(() => document.elementFromPoint(5, 5)!.id)).not.toBe('gp-recorder');
    expect(errors).toEqual([]);
    await page.close();
  });
});
