// three.js (r163+, WebGL2 only) through the engine contract: its WebGLRenderer on #game, the adapter's fixed-step loop.
// For games where 3D is the point (engine lab: 151 KB gzipped, but no WebGL1 and no Canvas fallback — the low-end
// devices get "can't run"). For flat 2D use Canvas 2D or Pixi.
//
//   import { AudioContext, AudioListener, OrthographicCamera, Scene, WebGLRenderer } from 'three';
//   const eng = threeAdapter(host, canvas, { WebGLRenderer, AudioContext, AudioListener }, { background: '#101826' });
//   eng.scene = new Scene(); eng.camera = new OrthographicCamera(…);
//   eng.onResize(({ width, height }) => { …camera…; camera.updateProjectionMatrix(); });
//   eng.onStep((dt) => …); eng.onFrame(() => …); eng.setRunning(true);
//
// What it does for you (games/lab-three/NOTES.md): a WebGL2 check before three logs its three console errors, with an
// Error the player shows as "can't run"; no MSAA (software WebGL paid ~40 %); setPixelRatio + setSize(…, false) — the
// platform's CSS sizes #game; the loop stopped while standing still (three never pauses itself); listener() gives an
// AudioListener on the host's AudioContext wired into host.audio.out (three makes its own context and wires its
// listener to ctx.destination otherwise). three rebuilds after a context loss by itself; the adapter redraws.
//
// Pictures from the engine's own scenes (Frankengun's armory thumbnails and covers, game22 view.ts / cover.ts):
//   const pic = eng.snapshot(240, 120, () => ({ scene: thumbScene, camera: thumbCam }));   // a 2D canvas, transparent background
//   img.src = pic.toDataURL('image/png');                    // cache it: one render per model, not per frame
//   fitToRect(cam, box, hero, { width: L.w, height: L.h });  // the cover: the model fills the hero rectangle, wherever it is
// and the quality lever: eng.setRenderScale(0.65, { dprMax: 1 }) (a quality level, @gp/core/quality).

import type { GameHost } from '../host';
import { createDriver, type Engine, type EngineOptions } from './driver';

export type { Engine, EngineAudio, EngineOptions, EngineSize } from './driver';

/** The part of three's WebGLRenderer the adapter uses (structural: @gp/core doesn't depend on three) */
export interface ThreeRendererLike {
  render(scene: never, camera: never): void;
  setPixelRatio(ratio: number): void;
  setSize(width: number, height: number, updateStyle?: boolean): void;
  setClearColor(color: never, alpha?: number): void;
  // For snapshot() (every WebGLRenderer has them)
  setRenderTarget?(target: never): void;
  getRenderTarget?(): unknown;
  getClearColor?(target: never): unknown;
  getClearAlpha?(): number;
  clear?(): void;
  readRenderTargetPixels?(target: never, x: number, y: number, w: number, h: number, buffer: Uint8Array): void;
  outputColorSpace?: string;
}

/** The part of three's WebGLRenderTarget snapshot() uses */
export interface ThreeTargetLike {
  texture: { colorSpace: string };
  dispose(): void;
}

export interface ThreeListenerLike {
  readonly context: AudioContext;
  readonly gain: GainNode;
}

/** The pieces of `three` the adapter needs: `{ WebGLRenderer }`, plus `AudioContext` and `AudioListener` for listener() */
export interface ThreeModule<R extends ThreeRendererLike, L extends ThreeListenerLike> {
  WebGLRenderer: new (params: never) => R;
  AudioContext?: { setContext(ctx: AudioContext): void };
  AudioListener?: new () => L;
  /** For snapshot(): pictures of the engine's scenes */
  WebGLRenderTarget?: new (width: number, height: number, options?: never) => ThreeTargetLike;
  /** For snapshot(): to put the clear colour back exactly (three's Color) */
  Color?: new () => unknown;
}

export interface SnapshotOptions {
  /** MSAA samples of the off-screen target (default 4: smooth edges for a picture, where the game itself runs without) */
  samples?: number;
  /** The background: a CSS colour, or null (default) for transparent */
  background?: string | null;
}

export interface ThreeOptions extends EngineOptions {
  /** The clear colour (a CSS colour) */
  background?: string;
  /** More WebGLRenderer parameters (they win over the adapter's, except canvas) */
  renderer?: Record<string, unknown>;
}

export interface ThreeEngine<R extends ThreeRendererLike, L extends ThreeListenerLike, S = unknown, Cam = unknown> extends Engine {
  readonly renderer: R;
  /** What the adapter renders every frame (renderer.render(scene, camera)); set both, or draw yourself in onFrame */
  scene: S | null;
  camera: Cam | null;
  /**
   * three's AudioListener on the host's AudioContext, its output into host.audio.out; null while sound can't start
   * (before the first tap, an ad, a hidden tab). Needs AudioContext and AudioListener passed in
   */
  listener(): L | null;
  /**
   * Render something off screen into a new 2D canvas of w×h px (a DOM thumbnail, the cover's key art): `draw` renders
   * with the target bound — return `{ scene, camera }` and the adapter renders it, or call renderer.render yourself.
   * The renderer's target and clear colour are put back. Needs WebGLRenderTarget (and Color) passed in.
   * `.toDataURL('image/png')` for an <img>; cache it — one render per picture, never per frame
   */
  snapshot(w: number, h: number, draw: (renderer: R) => { scene: unknown; camera: unknown } | void, opts?: SnapshotOptions): HTMLCanvasElement;
}

/** WebGL2 on a throwaway canvas: three r163+ asks for nothing else */
function hasWebGL2(): boolean {
  try {
    const gl = document.createElement('canvas').getContext('webgl2');
    gl?.getExtension('WEBGL_lose_context')?.loseContext();
    return !!gl;
  } catch {
    return false;
  }
}

/** three's renderer on #game, created stopped. Throws a readable Error without WebGL2 (the player shows "can't run") */
export function threeAdapter<R extends ThreeRendererLike, L extends ThreeListenerLike, S = unknown, Cam = unknown>(
  host: GameHost,
  canvas: HTMLCanvasElement,
  three: ThreeModule<R, L>,
  opts: ThreeOptions = {},
): ThreeEngine<R, L, S, Cam> {
  if (!hasWebGL2()) throw new Error('this game needs WebGL2, which this browser or device does not have');
  let renderer: R;
  try {
    renderer = new three.WebGLRenderer({ antialias: false, ...opts.renderer, canvas } as never);
  } catch (e) {
    throw new Error(`WebGL2 could not start (${e instanceof Error ? e.message : String(e)})`);
  }
  if (opts.background !== undefined) renderer.setClearColor(opts.background as never);
  let listener: L | null = null;
  const view = { scene: null as S | null, camera: null as Cam | null };

  const d = createDriver(host, canvas, opts, (drv) => {
    const render = () => {
      if (view.scene && view.camera) renderer.render(view.scene as never, view.camera as never);
    };
    const loop = drv.loop({ render });
    return {
      start: loop.start,
      stop: loop.stop,
      render,
      resize(s) {
        renderer.setPixelRatio(s.dpr);
        renderer.setSize(s.width, s.height, false);
      },
      webgl: true,
    };
  });

  const eng = Object.assign(d.engine, {
    renderer,
    snapshot(w: number, h: number, draw: (r: R) => { scene: unknown; camera: unknown } | void, o: SnapshotOptions = {}): HTMLCanvasElement {
      const W = Math.max(1, Math.round(w));
      const H = Math.max(1, Math.round(h));
      const r = renderer;
      if (!three.WebGLRenderTarget) throw new Error('threeAdapter: pass WebGLRenderTarget from three for snapshot()');
      if (!r.setRenderTarget || !r.readRenderTargetPixels || !r.clear) throw new Error('threeAdapter.snapshot(): the renderer has no setRenderTarget / readRenderTargetPixels');
      const rt = new three.WebGLRenderTarget(W, H, { samples: o.samples ?? 4 } as never);
      rt.texture.colorSpace = r.outputColorSpace ?? 'srgb';
      const prevTarget = r.getRenderTarget?.() ?? null;
      const prevColor = three.Color ? new three.Color() : null;
      if (prevColor) r.getClearColor?.(prevColor as never);
      const prevAlpha = r.getClearAlpha?.() ?? 1;
      const px = new Uint8Array(W * H * 4);
      try {
        r.setRenderTarget(rt as never);
        if (o.background) r.setClearColor(o.background as never, 1);
        else r.setClearColor(0 as never, 0);
        r.clear();
        const v = draw(r);
        if (v) r.render(v.scene as never, v.camera as never);
        r.readRenderTargetPixels(rt as never, 0, 0, W, H, px);
      } finally {
        r.setRenderTarget(prevTarget as never);
        // Without three's Color: the adapter's background option (or black), with the alpha it had
        r.setClearColor((prevColor ?? opts.background ?? 0) as never, prevAlpha);
        rt.dispose();
      }
      // WebGL's rows start at the bottom
      const c = document.createElement('canvas');
      c.width = W;
      c.height = H;
      const g = c.getContext('2d')!;
      const img = g.createImageData(W, H);
      for (let y = 0; y < H; y++) img.data.set(px.subarray((H - 1 - y) * W * 4, (H - y) * W * 4), y * W * 4);
      g.putImageData(img, 0, 0);
      return c;
    },
    listener(): L | null {
      if (!three.AudioContext || !three.AudioListener) throw new Error('threeAdapter: pass AudioContext and AudioListener from three for listener()');
      const a = d.engine.audio.live();
      if (!a) return null;
      if (!listener || listener.context !== a.ctx) {
        // Before the first AudioListener, or three makes its own AudioContext
        three.AudioContext.setContext(a.ctx);
        listener = new three.AudioListener();
        // three wires the listener to ctx.destination: through the host instead (its mute, its silence under an ad)
        listener.gain.disconnect();
        listener.gain.connect(a.out);
      }
      return listener;
    },
  });
  Object.defineProperties(eng, {
    scene: { get: () => view.scene, set: (v: S | null) => (view.scene = v), enumerable: true },
    camera: { get: () => view.camera, set: (v: Cam | null) => (view.camera = v), enumerable: true },
  });
  // gp qa reads the camera's horizontal field of view in portrait (≥ 60°: Frankengun saw a slit at 360×800)
  host.engineCamera = () => view.camera;
  return eng as typeof eng & { scene: S | null; camera: Cam | null };
}

// --- Framing a subject: fitToRect ---------------------------------------------------------------------------------

interface XYZ {
  x: number;
  y: number;
  z: number;
}

/** The part of a three camera fitToRect() moves (PerspectiveCamera, or OrthographicCamera's left/right/top/bottom) */
export interface FitCamera {
  position: { set(x: number, y: number, z: number): unknown };
  lookAt(x: number, y: number, z: number): void;
  updateProjectionMatrix(): void;
  updateMatrixWorld?(force?: boolean): void;
  setViewOffset?(fullWidth: number, fullHeight: number, x: number, y: number, width: number, height: number): void;
  /** Perspective: the vertical field of view (degrees) and the aspect */
  fov?: number;
  aspect?: number;
  /** Orthographic: the frustum's planes */
  left?: number;
  right?: number;
  top?: number;
  bottom?: number;
  zoom?: number;
}

export interface FitOptions {
  /** The way the camera looks at the subject (default: along −z, from the front) */
  direction?: XYZ;
  /** Room round the subject, a share of the rectangle on each side (default 0.06) */
  padding?: number;
}

/**
 * Frame a subject (its bounding box: a three Box3, or any { min, max }) so it fills `rect` of a frame of `frame` size
 * (the same units: the cover's px), wherever the rectangle is: the camera goes to the distance where the box's bounding
 * sphere fits the rectangle, looking along `direction`, and its view offset moves the subject's centre to the
 * rectangle's centre (the cover's hero area; Frankengun's cover.ts did it by hand). Perspective (fov) or orthographic
 * (left/right/top/bottom) cameras. Returns the camera's distance from the subject's centre
 */
export function fitToRect(camera: FitCamera, box: { min: XYZ; max: XYZ }, rect: { x: number; y: number; w: number; h: number }, frame: { width: number; height: number }, o: FitOptions = {}): number {
  const c = { x: (box.min.x + box.max.x) / 2, y: (box.min.y + box.max.y) / 2, z: (box.min.z + box.max.z) / 2 };
  const radius = Math.max(1e-6, Math.hypot(box.max.x - box.min.x, box.max.y - box.min.y, box.max.z - box.min.z) / 2);
  const dir = o.direction ?? { x: 0, y: 0, z: -1 };
  const dl = Math.hypot(dir.x, dir.y, dir.z) || 1;
  const pad = 1 - 2 * Math.max(0, Math.min(0.4, o.padding ?? 0.06));
  // The rectangle's share of the frame, each way
  const fx = Math.max(1e-3, (rect.w / frame.width) * pad);
  const fy = Math.max(1e-3, (rect.h / frame.height) * pad);
  const aspect = frame.width / frame.height;
  let dist: number;
  if (camera.fov !== undefined) {
    camera.aspect = aspect;
    const tv = Math.tan((camera.fov * Math.PI) / 360);
    // The half-angles the rectangle spans, vertically and across; the sphere fits the narrower
    const half = Math.min(Math.atan(tv * fy), Math.atan(tv * aspect * fx));
    dist = radius / Math.sin(half);
  } else {
    // Orthographic: the frustum's half height the sphere needs over the rectangle's share
    const halfH = Math.max(radius / fy, radius / (fx * aspect));
    camera.top = halfH;
    camera.bottom = -halfH;
    camera.left = -halfH * aspect;
    camera.right = halfH * aspect;
    camera.zoom = 1;
    dist = radius * 4;
  }
  camera.position.set(c.x - (dir.x / dl) * dist, c.y - (dir.y / dl) * dist, c.z - (dir.z / dl) * dist);
  camera.lookAt(c.x, c.y, c.z);
  // The centre moved from the frame's middle to the rectangle's: the whole view shifted by the difference
  const dx = rect.x + rect.w / 2 - frame.width / 2;
  const dy = rect.y + rect.h / 2 - frame.height / 2;
  camera.setViewOffset?.(frame.width, frame.height, -dx, -dy, frame.width, frame.height);
  camera.updateProjectionMatrix();
  camera.updateMatrixWorld?.(true);
  return dist;
}
