// A tiny event bus. Scenes and services report what happens; QA and (later) analytics listen.
// Events are the stable test interface: tests never depend on class names or private fields.

export type GameEventType =
  | 'scene'
  | 'round:start'
  | 'target:pop'
  | 'target:miss'
  | 'target:penalty'
  | 'score'
  | 'round:end'
  /** A moment worth celebrating (new best score) — portals use it as an engagement signal */
  | 'highlight'
  /** The game's twist happened (host.twist): { event } — QA checks a new player meets it early */
  | 'twist'
  | 'ad:start'
  | 'ad:end'
  /** A rewarded ad the player chose finished: { placement, ok } (ok — give the reward) */
  | 'ad:rewarded'
  | 'purchase'
  /** The WebGL context of the game's canvas was lost (kit: code — the host pauses with reason 'context') */
  | 'context:lost'
  /** …and it is back: the game resumes (once nothing else holds it paused) */
  | 'context:restored'
  /** …and it will never come back (no listener called preventDefault()): the "reload" screen is up */
  | 'context:gone'
  /** The player switched the language (host.setLanguage): { lang } */
  | 'language'
  /** The player signed in on the portal (host.signIn) */
  | 'account:signed-in'
  /** The game shows a screen (host.screen): { name } — 'title', 'results', 'shop' … */
  | 'screen'
  /** The player failed (host.fail): died, lost a level — a Continue may still save the run */
  | 'fail'
  /**
   * A step of the first-minute funnel (host.ts, FUNNEL_STEPS): { step, sec } — boot, loaded, title, firstInput,
   * gameplayStart, play15, play30, play60, firstFail, firstResults, exit. Each once a session (exit: the last screen)
   */
  | 'funnel';

export interface GameEvent {
  type: GameEventType;
  /** Seconds since app start */
  t: number;
  data: Record<string, unknown>;
}

type Listener = (e: GameEvent) => void;

const MAX_LOG = 2000;

export class EventBus {
  private readonly listeners = new Set<Listener>();
  /** Recent events, kept only when `keepLog` is on (dev and E2E builds) */
  readonly log: GameEvent[] = [];

  constructor(
    private readonly clock: () => number,
    private readonly keepLog = false,
  ) {}

  emit(type: GameEventType, data: Record<string, unknown> = {}): void {
    const e: GameEvent = { type, t: this.clock(), data };
    if (this.keepLog) {
      if (this.log.length >= MAX_LOG) this.log.shift();
      this.log.push(e);
    }
    for (const l of this.listeners) l(e);
  }

  on(listener: Listener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  count(type: GameEventType, match: (d: Record<string, unknown>) => boolean = () => true): number {
    return this.log.filter((e) => e.type === type && match(e.data)).length;
  }
}
