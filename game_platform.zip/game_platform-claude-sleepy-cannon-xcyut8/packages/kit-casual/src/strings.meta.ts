// The casual kit's texts in every language the platform knows (pure data: Node checks it, the player picks one).
// English is CASUAL_STRINGS_EN (index.meta.ts); a game's own `strings` in game.yaml replace the English ones, and its
// strings/<lang>.yaml the others (docs/guides/i18n.md → the YAML kits).

import type { StringTable } from '@gp/core/i18n';

const NB = ' ';

export const CASUAL_STRINGS: StringTable = {
  play: { en: 'Play', es: 'Jugar', 'pt-BR': 'Jogar', fr: 'Jouer', de: 'Spielen', ru: 'Играть', tr: 'Oyna', it: 'Gioca', pl: 'Graj', id: 'Main', ja: 'プレイ', ko: '플레이', 'zh-CN': '开始' },
  playAgain: { en: 'Play again', es: 'Jugar de nuevo', 'pt-BR': 'Jogar de novo', fr: 'Rejouer', de: 'Nochmal spielen', ru: 'Ещё раз', tr: 'Tekrar oyna', it: 'Gioca ancora', pl: 'Zagraj ponownie', id: 'Main lagi', ja: 'もう一度', ko: '다시 하기', 'zh-CN': '再玩一次' },
  best: { en: 'Best', es: 'Récord', 'pt-BR': 'Recorde', fr: 'Record', de: 'Rekord', ru: 'Рекорд', tr: 'En iyi', it: 'Record', pl: 'Rekord', id: 'Terbaik', ja: 'ベスト', ko: '최고', 'zh-CN': '最佳' },
  newBest: { en: 'New best!', es: '¡Nuevo récord!', 'pt-BR': 'Novo recorde!', fr: `Nouveau record${NB}!`, de: 'Neuer Rekord!', ru: 'Новый рекорд!', tr: 'Yeni rekor!', it: 'Nuovo record!', pl: 'Nowy rekord!', id: 'Rekor baru!', ja: '新記録！', ko: '신기록!', 'zh-CN': '新纪录！' },
  score: { en: 'Score', es: 'Puntos', 'pt-BR': 'Pontos', fr: 'Score', de: 'Punkte', ru: 'Очки', tr: 'Puan', it: 'Punti', pl: 'Wynik', id: 'Skor', ja: 'スコア', ko: '점수', 'zh-CN': '得分' },
  go: { en: 'Go!', es: '¡Ya!', 'pt-BR': 'Já!', fr: `Go${NB}!`, de: 'Los!', ru: 'Вперёд!', tr: 'Başla!', it: 'Via!', pl: 'Start!', id: 'Mulai!', ja: 'スタート！', ko: '시작!', 'zh-CN': '开始！' },
  timeUp: { en: 'Time!', es: '¡Tiempo!', 'pt-BR': 'Tempo!', fr: `Fini${NB}!`, de: 'Zeit!', ru: 'Время!', tr: 'Süre bitti!', it: 'Tempo!', pl: 'Koniec czasu!', id: 'Waktu habis!', ja: 'タイムアップ！', ko: '시간 종료!', 'zh-CN': '时间到！' },
  sound: { en: 'Sound', es: 'Sonido', 'pt-BR': 'Som', fr: 'Son', de: 'Ton', ru: 'Звук', tr: 'Ses', it: 'Suono', pl: 'Dźwięk', id: 'Suara', ja: 'サウンド', ko: '사운드', 'zh-CN': '音效' },
  on: { en: 'on', es: 'sí', 'pt-BR': 'ligado', fr: 'oui', de: 'an', ru: 'вкл.', tr: 'açık', it: 'sì', pl: 'wł.', id: 'nyala', ja: 'オン', ko: '켜짐', 'zh-CN': '开' },
  off: { en: 'off', es: 'no', 'pt-BR': 'desligado', fr: 'non', de: 'aus', ru: 'выкл.', tr: 'kapalı', it: 'no', pl: 'wył.', id: 'mati', ja: 'オフ', ko: '꺼짐', 'zh-CN': '关' },
  pops: { en: 'Pops', es: 'Explotados', 'pt-BR': 'Estourados', fr: 'Éclatés', de: 'Geplatzt', ru: 'Лопнуто', tr: 'Patlatılan', it: 'Scoppiati', pl: 'Pęknięte', id: 'Pecah', ja: '割った数', ko: '터뜨린 수', 'zh-CN': '戳破' },
  combo: { en: 'Best combo', es: 'Mejor combo', 'pt-BR': 'Melhor combo', fr: 'Meilleur combo', de: 'Bestes Combo', ru: 'Лучшее комбо', tr: 'En iyi kombo', it: 'Combo migliore', pl: 'Najlepsze combo', id: 'Kombo terbaik', ja: '最大コンボ', ko: '최고 콤보', 'zh-CN': '最佳连击' },
  accuracy: { en: 'Accuracy', es: 'Precisión', 'pt-BR': 'Precisão', fr: 'Précision', de: 'Genauigkeit', ru: 'Точность', tr: 'İsabet', it: 'Precisione', pl: 'Celność', id: 'Akurasi', ja: '命中率', ko: '정확도', 'zh-CN': '命中率' },
};
