// The decision-quality checks of the balance report (balance.ts): the bot skill ladder and the declared difficulty,
// the pick rate of every offered option, build diversity, and "hard stages are short".
import { describe, expect, it } from 'vitest';
import {
  buildCore, buildDiversity, choiceLog, decisionsMarkdown, evaluateBalance, pickRates, pickRatesCsv, skillSummary, stageStats, winningRunMin,
  type BalanceReport, type BotRun, type DifficultyTarget,
} from '../src/balance.ts';
import { seededRng } from '../src/rng.ts';

const row = (r: BalanceReport, name: string, difficulty?: DifficultyTarget, from?: 'bot' | 'model') => evaluateBalance(r, 'crazygames', { difficulty, from }).rows.find((x) => x.name === name);

/** Frankengun's targets, measured: the skilled bot wins 24 of 120 (4 of 20), a winning run ≈ 33 min */
const FRANKENGUN: BalanceReport = {
  measure: 'waves a run',
  skills: {
    naive: { runs: 120, wins: 0, progress: 6.2 },
    average: { runs: 120, wins: 3, winMin: [34, 36, 35], progress: 10.5 },
    skilled: { runs: 120, wins: 24, winMin: 33, progress: 14.1 },
  },
};

describe('the bot skill ladder', () => {
  it('summarises given and tagged runs per skill: win rate, the median winning run, mean progress', () => {
    const runs: BotRun[] = [
      { skill: 'skilled', won: true, minutes: 30, progress: 20 },
      { skill: 'skilled', won: false, minutes: 12, progress: 9 },
      { skill: 'skilled', won: true, minutes: 40, progress: 20 },
      { won: false, minutes: 8, progress: 6 }, // no skill: average
    ];
    const s = skillSummary({ runs, skills: { skilled: { runs: 2, wins: 0, progress: 5 } } });
    expect(s.skilled).toEqual({ skill: 'skilled', runs: 5, wins: 2, winRate: 0.4, winMin: 35, progress: (5 * 2 + 49) / 5 });
    expect(s.average).toMatchObject({ runs: 1, wins: 0, winRate: 0, winMin: null, progress: 6 });
    expect(s.naive).toBeUndefined();
    // A game without a win (an endless dodger): progress only
    expect(skillSummary({ skills: { naive: { runs: 24, progress: 40 } } }).naive).toMatchObject({ wins: null, winRate: null, progress: 40 });
    expect(winningRunMin(FRANKENGUN)).toEqual({ skill: 'skilled', minutes: 33, wins: 24 });
    expect(winningRunMin({ skills: { average: { runs: 10, wins: 1, winMin: 50 } } })).toEqual({ skill: 'average', minutes: 50, wins: 1 });
    expect(winningRunMin({ skills: { skilled: { runs: 10, wins: 0 } } })).toBeNull();
  });

  it('skill matters: naive far behind skilled is ok; naive keeping up warns (the game plays itself)', () => {
    const ok = row(FRANKENGUN, 'Skill matters: naive falls behind skilled')!;
    expect(ok.status).toBe('ok');
    expect(ok.detail).toContain('naive at 44 % of skilled');
    const flat = row({ skills: { naive: { runs: 40, progress: 9 }, skilled: { runs: 40, progress: 10 } } }, 'Skill matters: naive falls behind skilled')!;
    expect(flat.status).toBe('warn');
    expect(flat.detail).toMatch(/keeps up/);
    // By win rate when there is no progress; better naive than skilled: the bots are off
    expect(row({ skills: { naive: { runs: 40, wins: 10 }, skilled: { runs: 40, wins: 5 } } }, 'Skill matters: naive falls behind skilled')!.detail).toMatch(/does better/);
    expect(row({ skills: { skilled: { runs: 40, wins: 5 } } }, 'Skill matters: naive falls behind skilled')!.status).toBe('skip');
    expect(row({}, 'Skill matters: naive falls behind skilled')!.status).toBe('skip');
  });

  it('game.yaml balance.difficulty: the skilled win rate within ± tolerance, the winning run in its range — else a failure', () => {
    const target: DifficultyTarget = { skilled: { winRate: 0.2, tolerance: 0.05 }, winningRunMin: [30, 40] };
    expect(evaluateBalance(FRANKENGUN, 'crazygames', { difficulty: target }).ok).toBe(true);
    expect(row(FRANKENGUN, "The skilled player's win rate", target)).toMatchObject({ status: 'ok', detail: '24 of 120 runs (20 %)' });
    expect(row(FRANKENGUN, "The winning run's length", target)!.status).toBe('ok');
    // Too easy: 48 of 120; the winning run too short
    const easy: BalanceReport = { skills: { skilled: { runs: 120, wins: 48, winMin: 22 } } };
    expect(row(easy, "The skilled player's win rate", target)).toMatchObject({ status: 'fail', detail: '48 of 120 runs (40 %): too easy for the skilled player' });
    expect(row(easy, "The winning run's length", target)).toMatchObject({ status: 'fail' });
    expect(evaluateBalance(easy, 'crazygames', { difficulty: target }).failed).toBe(2);
    // The default tolerance is 0.1
    expect(row({ skills: { skilled: { runs: 100, wins: 29 } } }, "The skilled player's win rate", { skilled: { winRate: 0.2 } })!.status).toBe('ok');
    // Too few runs, or not measured: a warning, not a verdict
    expect(row({ skills: { skilled: { runs: 10, wins: 2 } } }, "The skilled player's win rate", target)!.detail).toMatch(/too few runs/);
    expect(row({}, "The skilled player's win rate", target)!.status).toBe('warn');
    expect(row({ skills: { skilled: { runs: 120, wins: 0 } } }, "The winning run's length", target)!.status).toBe('warn');
    // A patch runs the model alone: the ladder isn't measured, nothing to hold it to
    expect(row({}, "The skilled player's win rate", target, 'model')!.status).toBe('skip');
    expect(row({}, "The winning run's length", target, 'model')!.status).toBe('skip');
    // Not declared: said, not checked
    expect(row(FRANKENGUN, "The skilled player's win rate")).toMatchObject({ status: 'skip', target: expect.stringMatching(/^no target declared/) });
    expect(row(FRANKENGUN, "The winning run's length")!.detail).toContain('33 min');
    expect(row({}, "The winning run's length")).toBeUndefined();
  });
});

describe('decision quality', () => {
  /** A bot over 60 runs of 6 offers each: 1 of 3 cards from 8, picking by its value of each with a little noise */
  function play(value: Record<string, number>, runs = 60) {
    const ids = Object.keys(value);
    const r = seededRng(7);
    const log = choiceLog();
    for (let run = 0; run < runs; run++) {
      for (let wave = 1; wave <= 6; wave++) {
        const offer = ids.map((id) => [r(), id] as const).sort((x, y) => x[0] - y[0]).slice(0, 3).map(([, id]) => id);
        const best = offer.reduce((a, b) => (value[b] + r() > value[a] + r() ? b : a));
        log.pick(offer, best, wave);
      }
      log.endRun();
    }
    return log;
  }

  it('choiceLog: every offer and the pick, a build per run, the offers by stage', () => {
    const log = choiceLog();
    log.pick(['a', 'b', 'c'], 'a', 1);
    log.pick(['b', 'c'], null, 2);
    log.endRun();
    log.pick(['a', 'b'], 'b');
    log.endRun(['b', 'b', 'z']);
    expect(log.choices()).toEqual([
      { offered: ['a', 'b', 'c'], picked: 'a', stage: 1, run: 1 },
      { offered: ['b', 'c'], picked: null, stage: 2, run: 1 },
      { offered: ['a', 'b'], picked: 'b', run: 2 },
    ]);
    expect(log.builds()).toEqual([['a'], ['b', 'b', 'z']]);
    expect(log.offers()).toEqual([{ stage: 1, ids: ['a', 'b', 'c'] }, { stage: 2, ids: ['b', 'c'] }]);
    // An offer of one option is no choice: it doesn't count
    expect(pickRates([{ offered: ['a', 'a'], picked: 'a' }, ...log.choices()])).toEqual([
      { id: 'a', offered: 2, picked: 1, rate: 0.5 },
      { id: 'b', offered: 3, picked: 1, rate: 1 / 3 },
      { id: 'c', offered: 2, picked: 0, rate: 0 },
    ]);
  });

  it('pick rates: a no-brainer (> 60 %) and a never-pick (< 5 %) warn; options offered under 20 times are not judged', () => {
    const even = play({ a: 1, b: 1.1, c: 1.2, d: 1, e: 1.1, f: 1.2, g: 1, h: 1.1 });
    const ok = row({ choices: even.choices() }, 'Offered choices are real choices')!;
    expect(ok.status).toBe('ok');
    expect(ok.detail).toMatch(/^8 of 8 options judged over 360 offers: pick rates \d+ %–\d+ %$/);
    // "laser" always wins, "rock" never does
    const skewed = play({ laser: 9, a: 1, b: 1.1, c: 1.2, d: 1, e: 1.1, f: 1.2, rock: -9 });
    const r = row({ choices: skewed.choices() }, 'Offered choices are real choices')!;
    expect(r.status).toBe('warn');
    expect(r.detail).toMatch(/dominant: laser 100 % of \d+/);
    expect(r.detail).toMatch(/dead weight: rock 0 % of \d+/);
    expect(evaluateBalance({ choices: skewed.choices() }).ok).toBe(true); // a warning, never a failure
    expect(row({ choices: [{ offered: ['a', 'b'], picked: 'a' }] }, 'Offered choices are real choices')!.status).toBe('skip');
    expect(row({}, 'Offered choices are real choices')!.status).toBe('skip');
    // The table and the CSV
    const md = decisionsMarkdown({ choices: skewed.choices(), ...FRANKENGUN });
    expect(md).toContain('### The skill ladder');
    expect(md).toMatch(/\| skilled \| 120 \| 24 \| 20 % \| 33 min \| 14\.1 \|/);
    expect(md).toMatch(/\| laser \| \d+ \| \d+ \| 100 % \| dominant \|/);
    expect(pickRatesCsv({ choices: skewed.choices() }).split('\n')[0]).toBe('option,offered,picked,rate');
    expect(decisionsMarkdown({})).toBe('');
  });

  it('builds: the same build every run warns; varied builds pass (mean Jaccard, distinct top-3 cores)', () => {
    expect(buildCore(['scope', 'drum', 'drum', 'pierce', 'scope', 'drum', 'magnet'])).toBe('drum+pierce+scope');
    const varied = play({ a: 1, b: 1.1, c: 1.2, d: 1, e: 1.1, f: 1.2, g: 1, h: 1.1 }).builds();
    const d = buildDiversity(varied);
    expect(d.runs).toBe(60);
    expect(d.jaccard!).toBeLessThan(0.6);
    expect(row({ builds: varied }, 'Builds differ from run to run')!.status).toBe('ok');
    const same = Array.from({ length: 10 }, (_, i) => ['drum', 'scope', 'pierce', 'magnet', i % 5 ? 'drum' : 'coil']);
    const r = row({ builds: same }, 'Builds differ from run to run')!;
    expect(r.status).toBe('warn');
    expect(r.detail).toMatch(/10 runs: 1 distinct top-3 cores \(the most common, drum\+pierce\+scope, in 100 %\), builds \d+ % alike: every run ends in nearly the same build/);
    // From tagged runs too; too few runs are not judged
    expect(row({ runs: same.map((build) => ({ won: false, minutes: 10, build })) }, 'Builds differ from run to run')!.status).toBe('warn');
    expect(row({ builds: same.slice(0, 3) }, 'Builds differ from run to run')!.status).toBe('skip');
  });

  it('hard stages are short: a stage cleared under 30 % that takes longer than the median warns (King)', () => {
    // 40 runs of a 10-wave run: waves 1–8 almost always cleared, wave 9 a hard and long one, wave 10 hard and short
    const runs: BotRun[] = Array.from({ length: 40 }, (_, i) => {
      const stages = [];
      for (let w = 1; w <= 10; w++) {
        const cleared = w < 9 ? true : w === 9 ? i % 5 === 0 : i % 2 === 0;
        stages.push({ stage: `wave ${w}`, cleared, minutes: w === 9 ? 3 : w === 10 ? 0.5 : 1 });
        if (!cleared) break;
      }
      return { skill: 'average' as const, won: stages.length === 10 && stages[9].cleared, minutes: stages.reduce((a, s) => a + s.minutes, 0), stages };
    });
    const st = stageStats({ runs });
    expect(st[8]).toEqual({ stage: 'wave 9', attempts: 40, clears: 8, minutes: 3 });
    expect(st[9]).toEqual({ stage: 'wave 10', attempts: 8, clears: 4, minutes: 0.5 });
    const r = row({ runs }, 'Hard stages are short')!;
    expect(r.status).toBe('warn');
    expect(r.detail).toMatch(/^wave 9: 20 % cleared, 3 min an attempt — longer than the median stage \(1 min\)/);
    // Shorten wave 9: ok, and wave 10 (8 attempts) is too rarely reached to judge
    const short = runs.map((run) => ({ ...run, stages: run.stages!.map((s) => (s.stage === 'wave 9' ? { ...s, minutes: 0.8 } : s)) }));
    expect(row({ runs: short }, 'Hard stages are short')).toMatchObject({ status: 'ok', detail: expect.stringMatching(/^1 hard stage\(s\) \(wave 9: 20 % cleared/) });
    // Given as stage stats; nothing reported: skipped
    expect(row({ stages: [{ stage: 1, attempts: 50, clears: 45, minutes: 1 }, { stage: 2, attempts: 45, clears: 40, minutes: 1.2 }] }, 'Hard stages are short')!.detail).toMatch(/none under 30 % cleared/);
    expect(row({}, 'Hard stages are short')!.status).toBe('skip');
  });
});
