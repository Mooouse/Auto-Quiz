// Story depth: the recommendation per kind of game (docs/guides/story.md §1), the game.yaml `story` section, and the
// checks of a story file's content against its depth. A game that needs no story is never asked for one.

import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import type { SceneDef, StoryDef } from '@gp/core/story';
import { AUDIENCES, checkStoryContent, contentDepth, readStoryExports, storyFit, validateText, type StoryDepth } from '../src/index.ts';

const read = (f: string) => readFileSync(new URL(f, import.meta.url), 'utf8');
const BALLOON = read('../../../docs/examples/kids/game.yaml');
const CASUAL = read('../../../docs/examples/casual.game.yaml');
const CODE = read('../../../docs/examples/code/game.yaml');
const issues = (text: string) => validateText(text, { mode: 'dev' }).issues;
const storyIssues = (text: string) => issues(text).filter((i) => i.path[0] === 'story');
const codes = (text: string) => storyIssues(text).map((i) => i.code);
const withStory = (text: string, story: string) => `${text.trimEnd()}\nstory: ${story}\n`;
const withTags = (tags: string) => CODE.replace('tags: [Casual, Arcade]', `tags: [${tags}]`);

describe('the recommended depth', () => {
  it('follows the table: audience first, then the genre of a 13+ game', () => {
    const rec = (audience: string, kit = 'code', tags?: string[]) => storyFit({ audience, kit, tags }).recommended;
    expect(rec('ages-2-5', 'kids')).toEqual(['premise']);
    expect(rec('ages-6-8', 'kids')).toEqual(['barks']);
    expect(rec('ages-9-12', 'kids')).toEqual(['barks']);
    expect(rec('general', 'casual')).toEqual(['premise', 'barks']);
    expect(rec('general', 'code', ['Clicker', 'Idle'])).toEqual(['chapters']);
    expect(rec('general', 'code', ['Puzzle', 'Logic'])).toEqual(['premise']);
    expect(rec('general', 'code', ['Tower Defense', 'Puzzle'])).toEqual(['premise', 'barks']); // the first genre tag wins
    expect(storyFit({ audience: 'general', kit: 'code', tags: ['Arcade'], genre: 'idle' }).fit.id).toBe('web-idle');
    expect(storyFit({ audience: 'general', kit: 'code', text: 'An idle cafe where cats brew coffee' }).genre).toBe('idle');
  });
});

describe('game.yaml story section', () => {
  it('a game that needs no story and has none: nothing is asked, required or warned', () => {
    for (const g of [BALLOON, CASUAL, CODE]) expect(storyIssues(g)).toEqual([]);
  });
  it('an idle code game without a story gets one info hint, never an error or a warning', () => {
    const i = storyIssues(withTags('Clicker, Idle'));
    expect(i.map((x) => [x.code, x.severity])).toEqual([['I_STORY_DEPTH', 'info']]);
    expect(validateText(withTags('Clicker, Idle'), { mode: 'dev' }).ok).toBe(true);
    // Saying "none" is a decision: no hint
    expect(codes(withStory(withTags('Clicker, Idle'), '{ depth: none }'))).toEqual([]);
  });
  it('a depth within what the game supports is fine; the premise is required at depth premise', () => {
    expect(codes(withStory(CODE, '{ depth: premise, premise: "A lost cell swims home through a body at war." }'))).toEqual([]);
    expect(codes(withStory(CODE, '{ depth: premise }'))).toContain('E_STORY_SECTION');
    expect(codes(withStory(CODE, '{ depth: chapters }'))).toContain('E_STORY_SECTION'); // chapters live in a file
    expect(codes(withStory(CODE, '{ depth: chapters, file: story.ts }'))).toEqual([]); // meta is checked from the files (the CLI)
  });
  it('a depth outside what the kind of game supports is a warning', () => {
    // Kids 2–5 don't read: no branching (and every line voiced)
    const kids = codes(withStory(BALLOON, '{ depth: branching, file: story.ts }'));
    expect(kids).toContain('W_STORY_DEPTH');
    expect(kids).toContain('E_STORY_VOICE');
    // An arcade game with no meta progression: no chapters
    const casual = storyIssues(withStory(CASUAL, '{ depth: chapters, file: story.ts }'));
    expect(casual.find((i) => i.code === 'W_STORY_DEPTH')?.message).toMatch(/no meta progression/);
    // Branching in an action game
    expect(codes(withStory(CODE, '{ depth: branching, file: story.ts }'))).toContain('W_STORY_DEPTH');
    // The YAML kits can show a premise, not barks
    expect(codes(withStory(CASUAL, '{ depth: barks, file: story.ts }'))).toContain('W_STORY_DEPTH');
  });
  it('kids 6–8: barks must be voiced', () => {
    const six = BALLOON.replace('audience: ages-2-5', 'audience: ages-6-8');
    expect(codes(withStory(six, '{ depth: barks, file: story.ts }'))).toContain('E_STORY_VOICE');
    expect(codes(withStory(six, '{ depth: barks, file: story.ts, voiced: true }'))).not.toContain('E_STORY_VOICE');
  });
  it('a premise is one line, written', () => {
    expect(codes(withStory(CODE, `{ depth: premise, premise: "${'word '.repeat(35).trim()}" }`))).toContain('W_STORY_HEAVY');
    expect(codes(withStory(CODE, '{ depth: premise, premise: "TODO: who, what, why" }'))).toContain('W_STORY_TODO');
  });
  it('unknown depths and fields are schema errors', () => {
    expect(issues(withStory(CODE, '{ depth: saga }')).map((i) => i.code)).toContain('E_ENUM');
    expect(issues(withStory(CODE, '{ depth: premise, premise: "A lost cell swims home.", chapters: 6 }')).map((i) => i.code)).toContain('E_UNKNOWN_FIELD');
  });
  it('the resolved game carries the section', () => {
    const g = validateText(withStory(CODE, '{ depth: premise, premise: "A lost cell swims home through a body at war." }'), { mode: 'dev' }).game!;
    expect(g.story).toEqual({ depth: 'premise', premise: 'A lost cell swims home through a body at war.', file: null, voiced: false, genre: 'action' });
    expect(validateText(CODE, { mode: 'dev' }).game!.story).toBeNull();
  });
});

// --- The story file's content

/** A chapter of `lines` lines of 8 words */
const chapter = (n: number, lines = 1): { at: 'run-end'; when: string; lines: string[] } => ({ at: 'run-end', when: `cleared >= ${n}`, lines: Array.from({ length: lines }, (_, i) => `pip: Line ${i} of the chapter, and it goes on.`) });
function def(chapters: number, extra: Partial<StoryDef> = {}, lines = 1): StoryDef & { scenes: Record<string, SceneDef> } {
  const scenes: Record<string, SceneDef> = { hello: { at: 'first-action', lines: ['pip: Tap the cauldron.'] } };
  for (let n = 1; n <= chapters; n++) scenes[`c${n}`] = chapter(n, lines);
  return { cast: { pip: { name: 'Pip' } }, vars: { game: ['cleared'] }, chapters: Object.keys(scenes).filter((k) => k !== 'hello'), scenes, ...extra };
}
const general = AUDIENCES.general;
const check = (exports: Record<string, unknown>, depth: StoryDepth, audience = general, tags?: string[]) => {
  const { fit } = storyFit({ audience: audience.id, kit: audience.child ? 'kids' : 'code', tags });
  return checkStoryContent(readStoryExports(exports), { depth, audience, fit, file: 'story.ts' });
};
const barks = (n: number, line = 'Hot hot hot!') => ({ BARKS: { boil: Array.from({ length: n }, (_, i) => `${line} ${i}`) } });
const c = (x: ReturnType<typeof check>) => x.map((i) => i.code);

describe('story file against its depth', () => {
  it('reads a StoryDef, bark lists and a cast from the exports', () => {
    const content = readStoryExports({ STORY: def(6), ...barks(40), CAST: { x: { name: 'Nobody' } } });
    expect(content.chapters).toBe(6);
    expect(content.barks.reduce((n, b) => n + b.lines.length, 0)).toBe(40);
    expect(content.cast).toContain('Pip');
    expect(contentDepth(content)).toBe('chapters');
    expect(contentDepth(readStoryExports(barks(40)))).toBe('barks');
  });
  it('a story that fits its depth has nothing to correct', () => {
    expect(check({ STORY: def(6), ...barks(40) }, 'chapters')).toEqual([]);
    expect(check(barks(60), 'barks')).toEqual([]);
  });
  it('too thin: "depth chapters but only 2 chapters", barks that repeat', () => {
    const thin = check({ STORY: def(2) }, 'chapters');
    expect(thin.find((i) => i.code === 'W_STORY_THIN')?.message).toMatch(/only 2 chapters/);
    expect(c(check(barks(10), 'barks'))).toContain('W_STORY_THIN');
    expect(c(check({ STORY: def(6) }, 'barks'))).toContain('W_STORY_HEAVY'); // and no bark lists either
  });
  it('too heavy: "depth barks but 4,000 words of chapters"', () => {
    const heavy = check({ STORY: def(12, {}, 12), ...barks(60) }, 'barks');
    const h = heavy.find((i) => i.code === 'W_STORY_HEAVY')!;
    expect(h.message).toMatch(/depth barks, but story\.ts holds 12 chapters/);
    expect(h.message).toMatch(/that is depth chapters/);
    expect(c(check({ STORY: def(12, {}, 24) }, 'chapters'))).toContain('W_STORY_HEAVY'); // > 2,000 words of chapters
  });
  it('branching needs a consequence and 2–3 endings', () => {
    const thin = check({ STORY: def(6) }, 'branching', general, ['Idle']);
    expect(thin.filter((i) => i.code === 'W_STORY_THIN').map((i) => i.message).join(' ')).toMatch(/no choice changes a later line.*0 endings/);
    const b = def(6);
    b.scenes.c2 = { at: 'run-end', when: 'cleared >= 2', lines: [{ who: 'pip', text: 'Help me?', choose: [{ id: 'yes', text: 'Yes.', do: { set: 'helped' } }, { id: 'no', text: 'No.', then: ['pip: Fine.'] }] }] };
    b.scenes.c6 = { at: 'run-end', when: 'cleared >= 6', lines: [{ text: 'Together.', if: 'helped', ending: 'together' }, { text: 'Alone.', if: 'not helped', ending: 'alone' }] };
    expect(check({ STORY: b }, 'branching', general, ['Idle'])).toEqual([]);
    expect(c(check({ STORY: b }, 'chapters'))).toEqual(['I_STORY_DEPTH']); // it is branching: a hint
  });
  it('play before story: no scene due at the first run start on a fresh save', () => {
    const early = def(6);
    delete (early.scenes.c1 as { at?: string }).at; // a chapter without `at` plays at run-start
    delete (early.scenes.c1 as { when?: string }).when;
    const e = check({ STORY: early }, 'chapters').find((i) => i.code === 'E_STORY_BEFORE_PLAY')!;
    expect(e.severity).toBe('error');
    expect(e.message).toMatch(/scenes\.c1.*without `at`/);
    // A long intro in the game's own format: a warning (it can't tell when it plays)
    expect(c(check({ INTRO: [{ who: 'a', text: 'word '.repeat(40) }] }, 'premise'))).toContain('W_STORY_BEFORE_PLAY');
  });
  it('the engine\'s checks run, with the audience\'s limits', () => {
    const long = def(6);
    long.scenes.c3 = { at: 'run-end', when: 'cleared >= 3', lines: ['pip: ' + 'x'.repeat(120)] };
    expect(c(check({ STORY: long }, 'chapters'))).toContain('W_STORY_LINE_LONG');
    expect(c(check({ STORY: long }, 'chapters', AUDIENCES['ages-9-12']))).toContain('E_STORY_LINE_LONG'); // 90 for 9–12
  });
  it('barks fit a bubble; no line points to the shop or ads', () => {
    expect(c(check(barks(40, 'A very long bark that goes on and on and will never fit in a bubble'), 'barks'))).toContain('W_STORY_BARK_LONG');
    const shop13 = check({ BARKS: { idle: [...barks(40).BARKS.boil, 'The shop has upgrades. Just saying.'] } }, 'barks');
    expect(shop13.find((i) => i.code === 'W_STORY_SHOP')?.severity).toBe('warning');
    // A chapter on the results screen may mention the shop for 13+, never for children
    const s = def(6);
    s.scenes.c2 = { at: 'run-end', when: 'cleared >= 2', lines: ['pip: The shop has new stock.'] };
    expect(c(check({ STORY: s }, 'chapters'))).not.toContain('W_STORY_SHOP');
    const kids = check({ BARKS: { pop: ['Buy more balloons!', 'Pop!'] } }, 'barks', AUDIENCES['ages-6-8']);
    expect(kids.find((i) => i.code === 'E_STORY_SHOP')?.severity).toBe('error');
  });
  it('the game\'s own format: counted, and told it can\'t be checked in full', () => {
    const own = { CHAPTERS: [[{ who: 'a', text: 'word '.repeat(60) }], [{ who: 'a', text: 'Short.' }]] };
    const i = check(own, 'chapters');
    expect(c(i)).toEqual(expect.arrayContaining(['W_STORY_FORMAT', 'W_STORY_THIN']));
    expect(readStoryExports(own).chapters).toBe(2);
  });
});
