// What every scene of the kit gets: the app, the theme, the resolved config and scene factories
// (factories keep the scenes free of circular imports).

import type { App, Scene, Theme } from '@gp/core';
import type { TapCollectConfig } from '@gp/blocks';
import type { KidsConfig, KidsMode } from './index.meta.ts';

export interface KidsContext {
  readonly app: App;
  readonly theme: Theme;
  readonly kids: KidsConfig;
  readonly round: TapCollectConfig;
  menu(): Scene;
  play(mode: KidsMode): Scene;
  reward(mode: KidsMode, sticker: number): Scene;
  album(): Scene;
  gate(): Scene;
  settings(): Scene;
}
