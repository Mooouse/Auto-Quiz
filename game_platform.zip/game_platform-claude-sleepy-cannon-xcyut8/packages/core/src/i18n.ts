// Translations: every game in the languages its players speak (docs/guides/i18n.md). Pure: no DOM, no globals — Node
// reads it too (gp validate, gp translate), the host and the kits get an I18n through their constructor.
//
// - strings: one table per language, key → text; `{name}` is a parameter, a number parameter is formatted for the
//   language (Intl.NumberFormat: 1,234 · 1.234 · 1 234); a text with plural forms is { one, few, many, other } chosen by
//   the `n` parameter (Intl.PluralRules: Russian and Polish have three integer forms, Indonesian one);
// - languages: the game's (game.yaml `languages`); a key missing in the current language falls back to English;
// - the language: the player's own choice (saved), else the portal's (CrazyGames systemInfo.locale), else the browser's,
//   else English — `detectLanguage` matches each against the game's languages (pt-PT finds pt-BR, never zh-TW → zh-CN).

/** A plural category (CLDR): which ones a language has is Intl.PluralRules' business */
export type PluralCategory = 'zero' | 'one' | 'two' | 'few' | 'many' | 'other';

/** A text with plural forms, chosen by the `n` parameter: `other` is always there (the fallback) */
export type PluralForms = Partial<Record<PluralCategory, string>> & { other: string };

export type StringValue = string | PluralForms;

/** One language: key → text (or plural forms) */
export type LanguageStrings = Record<string, StringValue>;

/** Every language: code → its strings (what games/<id>/strings/<code>.yaml hold, flattened) */
export type Strings = Record<string, LanguageStrings>;

/** Per key: { en: …, de: … } — how the platform writes its own tables */
export type StringTable = Record<string, Record<string, StringValue>>;

export type Params = Record<string, string | number>;

/** The pictures the language picker draws (inline SVG): a flag stands for the language, its name says it */
export type FlagId = 'gb' | 'es' | 'br' | 'fr' | 'de' | 'ru' | 'tr' | 'it' | 'pl' | 'id' | 'jp' | 'kr' | 'cn';

export interface LanguageInfo {
  /** BCP 47, as game.yaml `languages` and the strings files write it */
  code: string;
  /** The language's own name: what the picker shows ("Deutsch") */
  name: string;
  /** In English, for reports */
  english: string;
  flag: FlagId;
  /** One of the ten the CrazyGames audience speaks most: a portal game declares all ten (W_I18N_LANGS) */
  top: boolean;
  /** Fonts that have its letters, put before the generic fallback (CJK: system fonts per OS) */
  fonts?: string;
}

/**
 * The languages the platform knows: its own texts (host, kits, shop, dialogue, picker) are translated into every one.
 * The first ten are the CrazyGames audience's top languages; Japanese, Korean and Chinese are ready but not asked for.
 */
export const LANGUAGES: readonly LanguageInfo[] = [
  { code: 'en', name: 'English', english: 'English', flag: 'gb', top: true },
  { code: 'es', name: 'Español', english: 'Spanish', flag: 'es', top: true },
  { code: 'pt-BR', name: 'Português (Brasil)', english: 'Portuguese (Brazil)', flag: 'br', top: true },
  { code: 'fr', name: 'Français', english: 'French', flag: 'fr', top: true },
  { code: 'de', name: 'Deutsch', english: 'German', flag: 'de', top: true },
  { code: 'ru', name: 'Русский', english: 'Russian', flag: 'ru', top: true },
  { code: 'tr', name: 'Türkçe', english: 'Turkish', flag: 'tr', top: true },
  { code: 'it', name: 'Italiano', english: 'Italian', flag: 'it', top: true },
  { code: 'pl', name: 'Polski', english: 'Polish', flag: 'pl', top: true },
  { code: 'id', name: 'Bahasa Indonesia', english: 'Indonesian', flag: 'id', top: true },
  { code: 'ja', name: '日本語', english: 'Japanese', flag: 'jp', top: false, fonts: '"Hiragino Sans", "Hiragino Kaku Gothic ProN", "Yu Gothic UI", "Yu Gothic", Meiryo, "Noto Sans JP", "Noto Sans CJK JP"' },
  { code: 'ko', name: '한국어', english: 'Korean', flag: 'kr', top: false, fonts: '"Apple SD Gothic Neo", "Malgun Gothic", "Noto Sans KR", "Noto Sans CJK KR"' },
  { code: 'zh-CN', name: '简体中文', english: 'Chinese (Simplified)', flag: 'cn', top: false, fonts: '"PingFang SC", "Microsoft YaHei", "Noto Sans SC", "Noto Sans CJK SC"' },
];

export const LANGUAGE_CODES: readonly string[] = LANGUAGES.map((l) => l.code);

/** The ten languages a portal game ships in (CrazyGames' audience): W_I18N_LANGS names the missing ones */
export const TOP_LANGUAGES: readonly string[] = LANGUAGES.filter((l) => l.top).map((l) => l.code);

/** The language every game has: CrazyGames requires English, and every missing key falls back to it */
export const BASE_LANGUAGE = 'en';

/**
 * A font stack with the letters of every language the platform knows: Latin with diacritics (ą ł ş ğ ı ß ñ), Cyrillic,
 * and the CJK system fonts of each OS. Put it after your own font: `font: 600 18px "My Font", ${FONT_FALLBACK}`. A pixel
 * or bitmap font needs a glyph for every character the strings use (`gp translate` lists them per language)
 */
export const FONT_FALLBACK =
  'system-ui, -apple-system, "Segoe UI", Roboto, "Noto Sans", "Helvetica Neue", Arial, ' +
  LANGUAGES.filter((l) => l.fonts)
    .map((l) => l.fonts)
    .join(', ') +
  ', sans-serif';

/** The platform's entry for a code (any case: "pt-br" is pt-BR), or null */
/** A glossary name as a whole word ("Tom" is not in "Tomorrow"; Potion Logic 2.0): letters and digits around it don't count */
function hasName(text: string, name: string): boolean {
  const esc = name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return new RegExp(`(^|[^\\p{L}\\p{N}])${esc}($|[^\\p{L}\\p{N}])`, 'u').test(text);
}

export function languageInfo(code: string): LanguageInfo | null {
  const c = code.toLowerCase();
  return LANGUAGES.find((l) => l.code.toLowerCase() === c) ?? null;
}

/** "pt-BR" as the platform writes it, for any case; unknown codes as given */
export const canonicalCode = (code: string): string => languageInfo(code)?.code ?? code;

const base = (code: string) => code.toLowerCase().split(/[-_]/)[0];
/** Chinese: a Traditional locale (zh-TW, zh-HK, zh-Hant) must not get Simplified text */
const traditional = (code: string) => /^zh[-_](tw|hk|mo|hant)/i.test(code);

/**
 * The language of `available` a wanted locale means: the same code ("de-DE" → "de" only through the base), else the same
 * base language ("pt-PT" → "pt-BR", "es-419" → "es"). null when none fits
 */
export function matchLanguage(wanted: string | null | undefined, available: readonly string[]): string | null {
  if (!wanted || typeof wanted !== 'string') return null;
  const w = wanted.trim().replace(/_/g, '-');
  if (!w) return null;
  const exact = available.find((a) => a.toLowerCase() === w.toLowerCase());
  if (exact) return exact;
  if (base(w) === 'zh' && traditional(w)) return available.find((a) => traditional(a)) ?? null;
  return available.find((a) => base(a) === base(w) && !(base(a) === 'zh' && traditional(a))) ?? null;
}

/** The first candidate (in order: saved choice, portal, browser) that one of `available` matches, else `fallback` */
export function detectLanguage(candidates: readonly (string | null | undefined)[], available: readonly string[], fallback = BASE_LANGUAGE): string {
  for (const c of candidates) {
    const m = matchLanguage(c, available);
    if (m) return m;
  }
  return available.includes(fallback) ? fallback : (available[0] ?? fallback);
}

// --- Texts ---------------------------------------------------------------------------------------------------------

const PARAM = /\{([A-Za-z_][A-Za-z0-9_]*)\}/g;

/** The parameter names in a text ("{n} coins" → ["n"]), sorted, each once */
export function paramsOf(text: string): string[] {
  return [...new Set([...text.matchAll(PARAM)].map((m) => m[1]))].sort();
}

const PLURAL_KEYS: readonly PluralCategory[] = ['zero', 'one', 'two', 'few', 'many', 'other'];

/** A value with plural forms: an object with `other` and nothing but plural categories */
export function isPlural(v: unknown): v is PluralForms {
  return !!v && typeof v === 'object' && !Array.isArray(v) && 'other' in v && Object.keys(v).every((k) => (PLURAL_KEYS as readonly string[]).includes(k));
}

const rulesCache = new Map<string, Intl.PluralRules>();
const numberCache = new Map<string, Intl.NumberFormat>();
function rules(lang: string): Intl.PluralRules {
  let r = rulesCache.get(lang);
  if (!r) rulesCache.set(lang, (r = new Intl.PluralRules(lang)));
  return r;
}

/**
 * The plural forms a language's texts must have: the categories whole numbers from 0 to 1000 fall into, and `other`
 * (fractions, and the fallback). en: one, other · ru, pl: one, few, many, other · id, ja: other. (es, fr, it, pt have a
 * `many` for a million: optional, `other` stands in)
 */
export function pluralCategories(lang: string): { required: PluralCategory[]; all: PluralCategory[] } {
  const r = rules(lang);
  const hit = new Set<PluralCategory>(['other']);
  for (let i = 0; i <= 1000; i++) hit.add(r.select(i) as PluralCategory);
  const all = r.resolvedOptions().pluralCategories as PluralCategory[];
  return { required: PLURAL_KEYS.filter((k) => hit.has(k)), all: PLURAL_KEYS.filter((k) => all.includes(k) || k === 'other') };
}

/** `n` formatted for the language (grouping as its readers write it) */
export function formatNumber(lang: string, n: number, opts?: Intl.NumberFormatOptions): string {
  if (opts) return new Intl.NumberFormat(lang, opts).format(n);
  let f = numberCache.get(lang);
  if (!f) numberCache.set(lang, (f = new Intl.NumberFormat(lang, { maximumFractionDigits: 2 })));
  return f.format(n);
}

/** Put the parameters into a text: numbers formatted for the language; an unknown {name} stays as it is (QA sees it) */
export function fillParams(text: string, params: Params | undefined, lang: string): string {
  if (!params) return text;
  return text.replace(PARAM, (all, name: string) => {
    const v = params[name];
    if (v === undefined) return all;
    return typeof v === 'number' ? formatNumber(lang, v) : String(v);
  });
}

/** The text of a value for a count: its plural form for `n` (Intl.PluralRules), `other` when there is no such form */
export function pluralText(value: StringValue, lang: string, n: unknown): string {
  if (typeof value === 'string') return value;
  const num = typeof n === 'number' ? n : Number(n);
  const cat = Number.isFinite(num) ? (rules(lang).select(num) as PluralCategory) : 'other';
  return value[cat] ?? value.other;
}

/** Per-key tables ({ key: { en, de } }) as per-language ones ({ en: { key }, de: { key } }) */
export function byLanguage(table: StringTable): Strings {
  const out: Strings = {};
  for (const [key, langs] of Object.entries(table))
    for (const [lang, v] of Object.entries(langs)) {
      const c = canonicalCode(lang);
      (out[c] ??= {})[key] = v;
    }
  return out;
}

/** Several sources, later ones win per key (the platform's texts under the game's) */
export function mergeStrings(...sources: (Strings | null | undefined)[]): Strings {
  const out: Strings = {};
  for (const s of sources)
    for (const [lang, strings] of Object.entries(s ?? {})) {
      const c = canonicalCode(lang);
      out[c] = { ...out[c], ...strings };
    }
  return out;
}

/**
 * Nested maps as dotted keys: { title: { play: "Play" } } → { "title.play": "Play" }. A map of plural forms is a value,
 * not a level. Lists are not texts: they are reported (`bad`)
 */
export function flattenStrings(data: unknown, prefix = '', out: LanguageStrings = {}, bad: string[] = []): { strings: LanguageStrings; bad: string[] } {
  if (data && typeof data === 'object' && !Array.isArray(data)) {
    for (const [k, v] of Object.entries(data as Record<string, unknown>)) {
      const key = prefix ? `${prefix}.${k}` : k;
      if (typeof v === 'string') out[key] = v;
      else if (typeof v === 'number' || typeof v === 'boolean') out[key] = String(v);
      else if (isPlural(v) && Object.values(v).every((x) => typeof x === 'string')) out[key] = v as PluralForms;
      else if (v && typeof v === 'object' && !Array.isArray(v)) flattenStrings(v, key, out, bad);
      else bad.push(key);
    }
  }
  return { strings: out, bad };
}

// --- The runtime ---------------------------------------------------------------------------------------------------

export interface I18n {
  /** The current language's code (one of `languages`) */
  readonly lang: string;
  /** The game's languages, in its order (game.yaml `languages`) */
  readonly languages: readonly string[];
  /** Where a missing key comes from: English */
  readonly fallback: string;
  /**
   * The text of `key` in the current language, with its parameters: t('score', { n: 1200 }) → "Score: 1,200". Plural
   * forms are chosen by `n`. A key missing in the language comes from English; a key missing everywhere comes back as
   * itself (gp validate reports it before that)
   */
  t(key: string, params?: Params): string;
  /** The key has a text in the language (default: the current one) */
  has(key: string, lang?: string): boolean;
  /** A number as the current language writes it (Intl.NumberFormat options for currency, percent, compact) */
  number(n: number, opts?: Intl.NumberFormatOptions): string;
  /** The plural category of `n` in the current language */
  plural(n: number): PluralCategory;
  /** Switch to one of `languages` (any case; "pt" finds pt-BR): false when it isn't one. onChange listeners run */
  setLanguage(code: string): boolean;
  /** Called after every switch: re-render the screen. Returns the unsubscribe */
  onChange(fn: (lang: string) => void): () => void;
  /** The platform's entry for the current language (name, flag, fonts) */
  info(): LanguageInfo;
  /** Every key's text in a language (default: the current one), plural ones as their `other` form: for QA and reports */
  dump(lang?: string): Record<string, string>;
}

export interface I18nOptions {
  /** The texts: one table per language (several sources merge, later ones win per key) */
  strings: Strings | Strings[];
  /** The languages offered, in order (default: those the strings have) — English first by convention */
  languages?: readonly string[];
  /** Where a missing key comes from (default "en") */
  fallback?: string;
  /** The starting language (matched against `languages`; default: the fallback) */
  lang?: string;
  /** A key missing in the current language (once per key and language): dev builds warn */
  onMissing?(key: string, lang: string): void;
}

export function createI18n(opts: I18nOptions): I18n {
  const strings = mergeStrings(...(Array.isArray(opts.strings) ? opts.strings : [opts.strings]));
  const fallback = canonicalCode(opts.fallback ?? BASE_LANGUAGE);
  const languages = (opts.languages?.length ? opts.languages.map(canonicalCode) : Object.keys(strings)).filter((l, i, a) => a.indexOf(l) === i);
  if (!languages.length) languages.push(fallback);
  let lang = matchLanguage(opts.lang, languages) ?? (languages.includes(fallback) ? fallback : languages[0]);
  const listeners = new Set<(lang: string) => void>();
  const missed = new Set<string>();
  const lookup = (key: string, l: string): StringValue | undefined => strings[l]?.[key];
  const i18n: I18n = {
    get lang() {
      return lang;
    },
    languages,
    fallback,
    t(key, params) {
      let v = lookup(key, lang);
      if (v === undefined) {
        if (!missed.has(`${lang}:${key}`)) {
          missed.add(`${lang}:${key}`);
          opts.onMissing?.(key, lang);
        }
        v = lookup(key, fallback);
      }
      if (v === undefined) return key;
      const l = lookup(key, lang) === undefined ? fallback : lang;
      return fillParams(pluralText(v, l, params?.n), params, lang);
    },
    has: (key, l = lang) => lookup(key, canonicalCode(l)) !== undefined,
    number: (n, o) => formatNumber(lang, n, o),
    plural: (n) => rules(lang).select(n) as PluralCategory,
    setLanguage(code) {
      const m = matchLanguage(code, languages);
      if (!m) return false;
      if (m !== lang) {
        lang = m;
        for (const f of [...listeners]) f(lang);
      }
      return true;
    },
    onChange(fn) {
      listeners.add(fn);
      return () => listeners.delete(fn);
    },
    info: () => languageInfo(lang) ?? { code: lang, name: lang, english: lang, flag: 'gb', top: false },
    dump(l = lang) {
      const c = canonicalCode(l);
      const keys = new Set([...Object.keys(strings[fallback] ?? {}), ...Object.keys(strings[c] ?? {})]);
      const out: Record<string, string> = {};
      for (const k of keys) {
        const v = lookup(k, c) ?? lookup(k, fallback)!;
        out[k] = typeof v === 'string' ? v : v.other;
      }
      return out;
    },
  };
  return i18n;
}

// --- Checks (gp validate, gp translate, the platform's own tables) -------------------------------------------------

export interface StringIssue {
  code: string;
  severity: 'error' | 'warning';
  lang: string;
  key: string;
  message: string;
  fix: string;
}

export interface StringCheckOptions {
  /** The languages the game declares; the first one checked against is `base` */
  languages: readonly string[];
  /** The source language every other is checked against (default "en") */
  base?: string;
  /** Names that stay as they are in every language (the game's title, characters, places) */
  glossary?: readonly string[];
  /** A translation this much longer than English (and 10+ characters longer) is reported (default 2) */
  maxGrowth?: number;
}

const KEY = /^[A-Za-z][A-Za-z0-9_-]*(\.[A-Za-z0-9_-]+)*$/;
const textOf = (v: StringValue): string[] => (typeof v === 'string' ? [v] : Object.values(v).filter((x): x is string => typeof x === 'string'));
const paramSet = (v: StringValue) => [...new Set(textOf(v).flatMap(paramsOf))].sort();

/**
 * Every key of the base language in every declared language, not empty, with the same parameters, the plural forms the
 * language needs, the glossary's names kept, and not wildly longer than English. Keys the base doesn't have are reported
 * too (a typo, or a text English lost)
 */
export function checkStrings(strings: Strings, opts: StringCheckOptions): StringIssue[] {
  const issues: StringIssue[] = [];
  const baseLang = canonicalCode(opts.base ?? BASE_LANGUAGE);
  const src = strings[baseLang] ?? {};
  const growth = opts.maxGrowth ?? 2;
  const add = (severity: StringIssue['severity'], code: string, lang: string, key: string, message: string, fix: string) => issues.push({ code, severity, lang, key, message, fix });
  for (const key of Object.keys(src)) if (!KEY.test(key)) add('error', 'E_I18N_KEY', baseLang, key, `key "${key}" is not a plain key`, 'Use letters, digits, - and _, with dots between levels (title.play).');
  for (const lang of opts.languages.map(canonicalCode)) {
    const own = strings[lang];
    if (!own) {
      if (lang !== baseLang || Object.keys(src).length) add('error', 'E_I18N_MISSING', lang, '*', `no strings in ${lang} at all`, `Write strings/${lang}.yaml: every key of strings/${baseLang}.yaml, translated (gp translate lists them).`);
      continue;
    }
    const cats = pluralCategories(lang);
    for (const [key, value] of Object.entries(own)) {
      const where = `${lang} "${key}"`;
      if (!(key in src) && lang !== baseLang) {
        add('warning', 'W_I18N_EXTRA', lang, key, `${where} is not in ${baseLang}`, `Remove it, or add it to strings/${baseLang}.yaml (a renamed key leaves its old translations behind).`);
        continue;
      }
      for (const text of textOf(value))
        if (!text.trim() || /^\s*TODO\b/.test(text)) add('error', 'E_I18N_EMPTY', lang, key, `${where} is ${text.trim() ? 'still TODO' : 'empty'}`, 'Write the text (in English for en, translated for the others).');
      if (isPlural(value)) {
        const missing = cats.required.filter((c) => !value[c]);
        const extra = (Object.keys(value) as PluralCategory[]).filter((c) => !cats.all.includes(c));
        if (missing.length) add('error', 'E_I18N_PLURAL', lang, key, `${where} needs the plural form(s) ${missing.join(', ')} (${lang} has ${cats.required.join(', ')})`, `Write { ${cats.required.map((c) => `${c}: "…"`).join(', ')} } — Intl.PluralRules picks one by {n}.`);
        if (extra.length) add('warning', 'W_I18N_PLURAL', lang, key, `${where} has form(s) ${extra.join(', ')} that ${lang} never uses`, `${lang} uses ${cats.all.join(', ')}: remove the others.`);
      }
      const b = src[key];
      if (b === undefined || lang === baseLang) continue;
      const want = paramSet(b);
      const have = paramSet(value);
      if (want.join() !== have.join())
        add('error', 'E_I18N_PARAMS', lang, key, `${where} has parameters {${have.join('}, {')}}, ${baseLang} has {${want.join('}, {')}}`.replace(/\{\}/g, 'none'), 'Keep every {name} exactly as in English (translate the words around it, never the name inside the braces).');
      const en = textOf(b)[0] ?? '';
      const tr = textOf(value)[0] ?? '';
      if (en.length && tr.length > en.length * growth && tr.length - en.length >= 10)
        add('warning', 'W_I18N_LONG', lang, key, `${where} is ${tr.length} characters, ${baseLang} ${en.length}`, 'Say it shorter: UI text should stay within ~30% of English where the room is tight (gp qa checks the longest language on screen).');
      for (const name of opts.glossary ?? [])
        if (name && textOf(b).some((t) => hasName(t, name)) && !textOf(value).some((t) => hasName(t, name)))
          add('warning', 'W_I18N_GLOSSARY', lang, key, `${where} drops "${name}" (a glossary name: it stays as it is in every language)`, `Keep "${name}" untranslated in the text.`);
    }
    if (lang === baseLang) continue;
    const missing = Object.keys(src).filter((k) => !(k in own));
    if (missing.length)
      add('error', 'E_I18N_MISSING', lang, missing[0], `${lang} misses ${missing.length} key(s): ${missing.slice(0, 6).join(', ')}${missing.length > 6 ? ', …' : ''}`, `Translate them into strings/${lang}.yaml (gp translate writes the list for the game's agent).`);
  }
  return issues;
}

/** The characters a language's texts use (without ASCII): the glyphs a pixel or bitmap font must have */
export function charsetOf(strings: LanguageStrings): string {
  const set = new Set<string>();
  for (const v of Object.values(strings)) for (const t of textOf(v)) for (const ch of t) if (ch.charCodeAt(0) > 126) set.add(ch);
  return [...set].sort().join('');
}
