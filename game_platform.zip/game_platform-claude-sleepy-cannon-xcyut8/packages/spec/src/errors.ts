// The error catalog. Every problem the validator reports has a code; each code has an explanation and
// a generic fix here. `gp explain <CODE>` prints it, docs/reference/errors.md is generated from it.
// Messages at the report site add the specifics (field, value, allowed values, the exact fix).

export interface ErrorInfo {
  title: string;
  /** Why this is a problem */
  why: string;
  /** How to fix it, in general */
  fix: string;
  /** A minimal YAML example of the fix */
  example?: string;
}

export const ERRORS: Record<string, ErrorInfo> = {
  E_YAML: {
    title: 'The file is not valid YAML',
    why: 'game.yaml could not be parsed, so nothing else can be checked.',
    fix: 'Fix the syntax at the reported line: indentation (2 spaces), a missing colon, an unclosed quote or bracket.',
  },
  E_TYPE: {
    title: 'Wrong value type',
    why: 'The field expects a different kind of value (number, text, list, yes/no, section).',
    fix: 'Use the type shown in the message. Numbers without quotes, `true`/`false` for yes/no, `- item` or `[a, b]` for lists.',
  },
  E_REQUIRED: {
    title: 'A required field is missing',
    why: 'The game cannot be built without it.',
    fix: 'Add the field. `gp explain <field>` shows what it means and an example.',
  },
  E_UNKNOWN_FIELD: {
    title: 'Unknown field',
    why: 'The platform does not know this field — usually a typo, or a field from another section. Unknown fields are never silently ignored.',
    fix: 'Rename it to the suggested field, move it to the right section, or remove it.',
  },
  E_ENUM: {
    title: 'Value not allowed',
    why: 'The field accepts only a fixed set of values.',
    fix: 'Pick one of the allowed values listed in the message.',
  },
  E_CONST: {
    title: 'Value must be exactly one thing',
    why: 'This field selects a building block and has exactly one allowed value in this section.',
    fix: 'Use the value shown in the message.',
  },
  E_RANGE: {
    title: 'Number out of range',
    why: 'The value is below the minimum or above the maximum the platform supports.',
    fix: 'Use a value within the range shown in the message.',
  },
  E_PATTERN: {
    title: 'Wrong format',
    why: 'The text does not match the expected format (e.g. kebab-case id, #rrggbb color, reverse-domain app id).',
    fix: 'Write the value in the format shown in the message.',
  },
  E_LENGTH: {
    title: 'Text too long or too short',
    why: 'Store limits or layout limits apply.',
    fix: 'Shorten or lengthen the text to fit the limit in the message.',
  },
  E_ITEMS: {
    title: 'Wrong number of list items',
    why: 'The list has too few or too many items.',
    fix: 'Add or remove items to fit the limit in the message.',
  },
  E_ONE_OF: {
    title: 'Value matches none of the allowed forms',
    why: 'The field accepts several forms (e.g. a pack id or an inline list) and the value is none of them.',
    fix: 'Use one of the forms shown in the message.',
  },
  E_REF_UNKNOWN: {
    title: 'Unknown building block',
    why: 'The id does not exist in the catalog (theme, content pack, sticker pack, mechanic, trajectory, kit).',
    fix: 'Use an id from the catalog (`gp catalog`). The message suggests the closest one.',
  },
  E_MODE_CONTENT: {
    title: 'A mode needs exactly one content source',
    why: 'Each mode shows items from a content pack (`content`) or from an inline list (`items`) — one of them, not both, not neither.',
    fix: 'Set `content: <pack id>` or `items: [...]` on the mode.',
    example: 'modes:\n  - { id: numbers, content: numbers-1-10-en }\n  - id: fruits\n    show: emoji\n    pop: emoji\n    items: [{ emoji: "🍎", word: apple }, { emoji: "🍌", word: banana }]',
  },
  E_MODE_DUPLICATE: {
    title: 'Two modes with the same id',
    why: 'Mode ids identify menu cards and rounds; they must be unique.',
    fix: 'Rename one of the modes.',
  },
  E_ITEM_FIELD: {
    title: 'Items lack the field the mode shows',
    why: 'The mode draws or pops up a field (`show`/`pop`) that some items do not have — those targets would be blank.',
    fix: 'Add the field to every item, or change `show`/`pop` to a field the items have.',
  },
  E_COLOR_NOT_NAMED: {
    title: 'A theme color has no name in the color-bound pack',
    why: 'In a color-bound mode the pop-up and the voice name the target color; a palette color without a name would show nothing.',
    fix: 'Use a pack that names every color of the theme palette, or a theme whose palette the pack covers.',
  },
  E_PALETTE_INDEX: {
    title: 'Palette index out of range',
    why: 'A card preview refers to a palette color by index, but the theme palette is shorter.',
    fix: 'Use an index below the palette length (see `gp explain <theme>`), or a #rrggbb color.',
  },
  E_RANGE_ORDER: {
    title: '[min, max] in the wrong order',
    why: 'The first number of a range must not be larger than the second.',
    fix: 'Swap the numbers.',
  },
  E_TARGET_TOO_SMALL: {
    title: 'Tap targets too small for the audience',
    why: 'Small targets are hard to hit for young children; the audience profile sets a minimum radius.',
    fix: 'Raise `round.target.min` to the audience minimum (or leave it out to use the default).',
  },
  E_PREFILL: {
    title: 'More targets at start than may be on screen',
    why: '`round.prefill` cannot be larger than `round.maxOnScreen`.',
    fix: 'Lower `prefill` or raise `maxOnScreen`.',
  },
  E_CHANNEL_AUDIENCE: {
    title: 'Channel and audience do not match',
    why: 'The android-families channel is for child-directed apps; a general-audience game must use the android channel, and vice versa a child audience on Google Play must use android-families.',
    fix: 'Pick the channel that matches the audience.',
  },
  E_PARENT_GATE_REQUIRED: {
    title: 'Child audience without a parent gate',
    why: 'Families policy and COPPA: settings, purchases and external links must not be reachable by a child.',
    fix: 'Set `parentGate: true` (the default).',
  },
  E_PRIVACY_POLICY: {
    title: 'Privacy policy URL missing or not https',
    why: 'Google Play requires a privacy policy for this channel, reachable from the store listing and the app.',
    fix: 'Set `privacyPolicyUrl: https://…` (publish the page on the developer website first).',
  },
  E_ADS_LIMITS: {
    title: 'Ad limits looser than the channel allows',
    why: 'The channel profile sets floors for ad frequency (Families: no ads in the first 60 s, not before round 2, at most once per 2 rounds and 90 s). A game may only make them stricter.',
    fix: 'Raise the limit to at least the channel value, or remove the override.',
  },
  E_ADS_UNSUPPORTED: {
    title: 'Ads are not available for this channel yet',
    why: 'The web channel has no ad provider yet; the general android channel needs a GDPR consent flow (UMP) the platform does not have yet.',
    fix: 'Set `monetization.ads.enabled: false` (and `monetization.removeAds: false`).',
  },
  E_KIT_CHANNEL: {
    title: 'This kit does not build for this channel',
    why: 'kit code games are web games: Android packaging needs a theme\'s icon and splash set and the kids kit\'s rules for Google Play Families.',
    fix: 'Use `channel: crazygames` or `channel: web`, or a kit with a round for Android.',
  },
  E_REWARDED_UNSUPPORTED: {
    title: 'Rewarded ads are not available for this channel',
    why: 'Rewarded ads exist only where the ad provider has them: web portals (CrazyGames). AdMob rewarded ads are not in the platform yet, and a channel without ads has none. Children never get ads they can choose (Families), so `money.rewarded` is refused for a child audience too.',
    fix: 'Remove `monetization.ads.rewarded` (or `money.rewarded`), or pick a channel that allows them (`gp explain crazygames`).',
  },
  E_CONCEPT: {
    title: 'No concept: what makes this game its own',
    why: 'CrazyGames reviews every game for originality and rejects "clones or asset flips" and concepts "quite close to existing titles" — Petri Panic, a well-made survivors-like, was rejected that way. A build can pass every check and still be refused: decide the difference before building.',
    fix: 'Add `concept: { pitch, closest: [3+ games on the portal it could be mistaken for], different }` — see `gp explain concept` and docs/guides/game-design.md#originality.',
  },
  E_TITLE_GENERIC: {
    title: 'Title is a common word or someone else\'s name',
    why: 'Portals and stores reject titles that are just a common identifier ("Chess", "Snake": CrazyGames — "Super Chess" is fine, "Chess" is not) and titles that use a trademark the developer doesn\'t own ("Scrabble", "Tetris", "Flappy Bird"). It also makes the game easy to confuse with others.',
    fix: 'Give the game its own name: two or more words that say what is special about it.',
  },
  W_TRADEMARK_TEXT: {
    title: 'A brand or another game\'s name in the game\'s texts',
    why: 'Portals and stores refuse trademarks used without a licence, and not only in the title: a car maker on a car (Ferrari, Porsche, BMW), another game ("Minecraft-style", Tetris) or a platform (Nintendo, Xbox) in a line the player reads, or in the listing. It also makes the game read as borrowed. The title is checked by E_TITLE_GENERIC; this looks at strings/<code>.yaml of every language and the listing.',
    fix: 'Use your own words: a made-up maker or model ("a Vanta GT", "the Corsa Rossa"), or a description ("a red Italian sports car"). Another hit\'s signature words (Balatro\'s Mult and seals, Minecraft\'s Creeper and Nether) lower `gp uniqueness` too.',
  },
  E_BILLING_UNSUPPORTED: {
    title: 'Purchases are not available for this channel',
    why: 'In-app purchases exist only on Google Play.',
    fix: 'Set `monetization.removeAds: false`.',
  },
  E_ADMOB_ID: {
    title: 'AdMob ID in the wrong format',
    why: 'App IDs look like `ca-app-pub-<16 digits>~<10 digits>`, ad unit IDs like `ca-app-pub-<16 digits>/<10 digits>`.',
    fix: 'Copy the ID from AdMob, or use `auto` and let `gp admob provision` fill it in.',
  },
  E_ADMOB_PUBLISHER: {
    title: 'AdMob ID belongs to another publisher',
    why: 'The ID does not start with the publisher ID from publisher/publisher.yaml — ads would be paid to someone else, or the ID is mistyped.',
    fix: 'Use an ID from your own AdMob account.',
  },
  E_RELEASE_IDS: {
    title: 'Release build without real ad IDs',
    why: 'A release build must use your AdMob IDs; test IDs earn nothing, and `auto` means they were never filled in.',
    fix: 'Run `gp admob provision` or paste the IDs from AdMob. Dev builds always use test IDs, so this only blocks release builds.',
  },
  E_RELEASE_TODO: {
    title: 'Release build with a TODO',
    why: 'A placeholder is still in the game or publisher data.',
    fix: 'Fill in the value marked TODO(publisher).',
  },
  E_TITLE_LONG: {
    title: 'Title longer than the store or portal allows',
    why: 'Google Play rejects titles over 30 characters; the CrazyGames form takes 35, and the name there must match the title in the game.',
    fix: 'Shorten `title` (30 characters on Google Play, 35 on CrazyGames).',
  },
  E_VOICE_REQUIRED: {
    title: 'Voice switched off for an audience that does not read',
    why: 'Toddlers (ages-2-5) do not read: the spoken word is how the game tells them what they popped. Without it the mode needs reading.',
    fix: 'Remove `say: false` from the mode.',
  },
  W_SILENT_ITEMS: {
    title: 'Some items have nothing to say',
    why: 'Items without `word` are silent, while the rest of the mode speaks — it feels broken.',
    fix: 'Add `word` to every item.',
  },
  E_APP_ID_REQUIRED: {
    title: 'Android channel without an appId',
    why: 'An Android app is identified by its application id; it can never change after the first release.',
    fix: 'Add `appId: <reverse domain>.<game>` (`gp new` fills it in from publisher.yaml `appIdPrefix`).',
  },
  E_MECHANIC_KIT: {
    title: 'The kit does not work with this mechanic',
    why: 'A kit\'s scenes (menu, result screen) are built for certain round mechanics: kids — tap-collect (reward per round), casual — tap-score (score and best score).',
    fix: 'Use the mechanic the kit lists (`gp explain <kit>`), or the kit that fits the mechanic.',
  },
  E_KIT_AUDIENCE: {
    title: 'The kit is not for this audience',
    why: 'The casual kit has no parent gate and is a score race — not for child-directed games.',
    fix: 'Use `kit: kids` for children, or `audience: general` for teens and adults.',
  },
  E_NO_FAIL: {
    title: 'Losing or a clock for a child audience',
    why: 'Child-directed games have no losing, no timers, no penalties (the audience profile).',
    fix: 'Use a mechanic without a clock (tap-collect) for children.',
  },
  E_TARGET_KIND: {
    title: 'Target kinds don\'t make sense',
    why: 'Only spiky (bad) targets have a penalty, and a round needs at least one kind that scores.',
    fix: 'Keep penalties on `kind: spiky` only, and include a `normal` kind.',
  },
  W_ADMOB_IGNORED: {
    title: 'AdMob IDs on a portal channel',
    why: 'On a web portal the portal\'s SDK shows the ads; AdMob is not used.',
    fix: 'Remove `appId`/`interstitial` from `monetization.ads`.',
  },
  W_TITLE_LONG: {
    title: 'Title longer than the Google Play limit',
    why: 'Google Play titles are at most 30 characters.',
    fix: 'Shorten `title` to 30 characters.',
  },
  W_TITLE_HOOK: {
    title: 'The title has no word players of the genre recognise',
    why: 'A portal title is read before the game is seen — in the search box, on tag pages and under a 200 px thumbnail. On the first Basic Launch day Spin Brawl ("Brawl" points at Brawl Stars) had 135 plays; Dread Throne, Starsilk and Nimbus Drift had 14–20. A hook is a common word the genre\'s hits made famous (brawl, clash, defense, merge, idle, drift); the hit\'s own name stays forbidden (E_TITLE_GENERIC).',
    fix: 'One word of the game\'s own + one hook of its genre, 2–3 words, ≤ 24 characters: `gp name` scores the title and suggests others. A game already live keeps its name and adds a genre subtitle.',
  },
  W_CONCEPT_TAKEN: {
    title: 'The concept reads like one already live on the portal',
    why: 'The platform keeps a list of genre + theme pairs found live on CrazyGames (packages/spec/src/taken.ts, from our searches): Petri Panic was rejected for exactly such a match. A warning, not a ban — the list is only what searches found.',
    fix: 'Put those titles in `concept.closest` and say in `concept.different` what the player does that they don\'t; if it is the same core action, change it.',
  },
  W_PLACEHOLDER: {
    title: 'The template\'s placeholder is still in the game',
    why: '`gp init` makes a skeleton around a PLACEHOLDER mechanic so QA passes from the start; a game that still has it is the template, not a game. `gp submission` refuses it.',
    fix: 'Replace the placeholder mechanic, texts and art (sim.ts, data.ts, main.ts), then remove the PLACEHOLDER comments.',
  },
  I_GENRE_EXPECTS: {
    title: "The genre's players expect something the code doesn't seem to have",
    why: "Each genre's players on CrazyGames come with expectations: an idle game without offline earnings or a number that keeps growing, a puzzle without levels, stars and undo, a roguelite without a run seed or run choices reads as unfinished to them — and the Basic Launch scores the game against its genre's peers. `gp validate` looks for each must-have of the genre (money.genre, or a listing tag) cheaply: a block imported from @gp/* (packages/spec/src/genres.ts names them), a sign of the game's own code for it, or the money design (a rewarded hint, a revive). A hint, not a rule: the search can miss the game's own way of doing it.",
    fix: 'Add the must-haves that fit the game, from the blocks the hint names (`gp catalog blocks --genre <g>`, `gp explain genre.<g>`); if the game deliberately has none of it, say why in REPORT.md. A wrong genre? Set money.genre.',
    example: 'money:\n  genre: idle   # must-haves: a growing number, a level shop, offline earnings, prestige later',
  },
  W_GENRE_BLOCK: {
    title: 'A block of another genre',
    why: "Some blocks only make sense in one genre (packages/spec/src/genres.ts, `only`): offline earnings, prestige and several sites with a map are idle mechanics — in an action or puzzle game they are a design from another genre, and players of that genre don't look for them. Either the game is that genre and money.genre says otherwise (the benchmarks, the hints and the forecast then use the wrong genre), or the block doesn't belong.",
    fix: "Set money.genre to the block's genre if the game is one. If the game is a hybrid — a layer of that genre on top of its own (an idle base that earns while you raid, a rebirth in a speed runner: the Roblox hits) — declare the layer: `money.hybrid: [idle]`; the benchmarks and must-haves stay the main genre's. Otherwise remove the block and use what fits the genre (`gp catalog blocks --genre <g>`).",
    example: 'money:\n  genre: action\n  hybrid: [idle]   # an action game with a den that earns while away: offlineEarnings and Prestige fit',
  },
  W_MONEY_HYBRID: {
    title: 'A hybrid layer of the game\'s own genre',
    why: '`money.hybrid` names the genres of a second layer on top of `money.genre` (so their blocks fit). The game\'s own genre there adds nothing.',
    fix: 'Remove it, or name the genre of the other layer.',
  },
  E_PAID_RANDOM: {
    title: 'A random outcome sold for money',
    why: "From June 2026 PEGI rates a game with paid random items (a loot box, an egg, a gacha roll bought with real money or with a currency sold for real money) 16 by default, and simulated gambling 18; CrazyGames takes PEGI 12 games only, and several countries treat paid loot boxes as gambling. The platform refuses the design, not a number: `money.loot` declares each roll's cost, and a roll that costs real money, or a currency sold for it, is the paid random item (docs/research/roblox-2026-10.md P2, §0 #8).",
    fix: 'Sell a known thing instead (the item itself, a guaranteed tier, a cosmetic shown before buying), and let rolls cost a currency earned in play (`cost: earned`) or nothing (`cost: free`, a daily egg).',
    example: 'money:\n  loot:\n    - { id: meadow-egg, cost: earned, odds: "the egg card lists each tier\'s chance" }',
  },
  W_REWARDED_RANDOM: {
    title: 'A rewarded ad that buys a spin',
    why: "A rewarded offer must say exactly what it gives and give it (CrazyGames: rewarded ads are special opportunities, never misleading). \"Watch an ad to spin\" is a random prize for an ad — a gamble the player can't judge, and the casino look PEGI rates up. The platform's rule: a rewarded ad gives a guaranteed thing — a floor on a roll the player makes anyway, a second item, ×2, a reroll of run choices (which are then picked, not won).",
    fix: 'Rewrite the offer as a guaranteed thing ("a rare or better on your next egg": LootTable.roll(source, { floor: \'rare\' })), and make the roll itself cost a currency earned in play or nothing.',
    example: 'money:\n  rewarded:\n    - { placement: lucky-egg, kind: boost, gives: "your next egg is rare or better" }',
  },
  W_LOOT_ODDS: {
    title: 'A random roll whose odds are not shown',
    why: 'A player sees the chance of each tier before every roll (PEGI 2026 and the portals: "clear about what it is"; the 1-in-X display is also what makes a rare find exciting). `gp validate` sees it two ways: a `money.loot` entry without `odds` (where they are shown), and a code game that imports LootTable but never reads odds(), oddsText() or formatOdds(). Whether the panel is really on screen before the roll is a `gp review` item.',
    fix: 'Show `table.oddsText(source)` (or a row per `table.odds(source)`) next to the roll button, and write where in game.yaml: `money.loot: [{ id, cost: earned, odds: "…" }]`.',
    example: 'money:\n  loot:\n    - { id: storm-chest, cost: earned, odds: "the chest card: Common 60% · Rare 30% · Epic 9% · Mythic 1 in 100" }',
  },
  E_BUDGET: {
    title: 'The size budget is not allowed here',
    why: "`budget.gzipKB` raises a web portal's size budget on purpose (a physics or 3D game). It can't go above the channel's hard limit (CrazyGames: 20 MB, which fails the build), and a channel without a web upload has no budget.",
    fix: 'Keep budget.gzipKB within the hard limit, or remove `budget`; make the upload smaller where you can (docs/guides/code-games.md#the-size-and-load-budget).',
    example: 'budget: { gzipKB: 1500 }',
  },
  E_ENGINE_UNSUPPORTED: {
    title: 'The engine has no adapter on the platform',
    why: "A `kit: code` game draws with Canvas 2D, Pixi, Phaser or three through its adapter in @gp/core/engines/<name>, which makes the engine obey the host (start stopped, pause, resize, sound through the host, a lost WebGL context). The engine lab (QmaCyber/game12) measured six engines: Kaplay can't be made to obey the host through its public API (its loop can't be stopped, it makes its own AudioContext, no WebGL fallback, no context-loss recovery) and was the slowest; Rapier is physics, not an engine.",
    fix: 'Set engine.name to canvas, pixi, phaser or three — Canvas 2D for most games, Pixi for many sprites (docs/guides/code-games.md#engines).',
    example: 'engine: { name: pixi, version: 8.21.0 }',
  },
  E_ENGINE_VERSION: {
    title: "The engine's version is missing, outside the adapter's range, or not the one installed",
    why: "The adapter relies on the engine's behaviour (Phaser's loop and its private Arcade accumulator, Pixi's Ticker.system, three's WebGL2-only renderer), so it supports one major version, the one the engine lab measured. game.yaml pins the exact version; games/<id>/package.json must pin the same, and that one must be installed — an engine upgrade is a decision, not an accident of npm install.",
    fix: 'Pin the same exact version in game.yaml `engine.version` and games/<id>/package.json (pixi.js 8.x, phaser 4.x, three 0.163–0.199), then `npm ci` in the game folder (scripts/setup.sh).',
    example: 'engine: { name: phaser, version: 4.2.1 }   # games/<id>/package.json: { "dependencies": { "phaser": "4.2.1" } }',
  },
  W_ENGINE_VERSION: {
    title: 'Canvas 2D has no version',
    why: "Canvas 2D is the browser's own: there is no package to pin.",
    fix: 'Remove engine.version.',
  },
  I_ENGINE_WEBGL2: {
    title: 'three.js needs WebGL2',
    why: "three r163+ has no WebGL1 path and no Canvas renderer: in the engine lab, Chromium without WebGL2 got the \"can't run\" screen. The forums research warns that the low-end devices without it are a real share of portal players.",
    fix: 'Fine where 3D is the point; for a flat 2D game, Canvas 2D or Pixi play everywhere.',
  },
  E_PHYSICS_UNSUPPORTED: {
    title: 'The physics block has no such library',
    why: "Physics in a `kit: code` game runs through the physics block @gp/physics, which makes the world obey the platform: a fixed step on the game's clock (the adapter's onStep), nothing while the host is paused (a hidden tab, an ad, a lost WebGL context), every WebAssembly object freed on reset, the same floats for the same seed and inputs. It runs Rapier 2D: rapier2d, or rapier2d-deterministic for the same floats on every machine. Box2D, Matter.js and 3D physics have no block (a block request, AGENTS.md §5).",
    fix: 'Set engine.physics.name to rapier2d (or rapier2d-deterministic) — docs/guides/code-games.md#physics.',
    example: 'engine: { name: canvas, physics: { name: rapier2d, version: 0.21.0 } }',
  },
  E_PHYSICS_VERSION: {
    title: "The physics package's version is missing, outside the block's range, or not the one installed",
    why: "Rapier is 0.x: any minor may change its API, so the block supports the minor its browser test runs on the real package (pauses, 100 resets with flat WebAssembly memory, determinism — packages/physics/test-browser). game.yaml pins the exact version; games/<id>/package.json must pin the same -compat package at that version, and that one must be installed. The -compat build, because the plain one imports its .wasm as an ES module: it doesn't load in Node (balance(), unit tests) and needs a top-level await, for no smaller upload.",
    fix: 'Pin the same exact version in game.yaml `engine.physics.version` and games/<id>/package.json (@dimforge/rapier2d-compat 0.21.x), then `npm ci` in the game folder (scripts/setup.sh).',
    example: 'engine: { name: canvas, physics: { name: rapier2d, version: 0.21.0 } }   # games/<id>/package.json: { "dependencies": { "@dimforge/rapier2d-compat": "0.21.0" } }',
  },
  W_PHYSICS_BUDGET: {
    title: 'Physics is over the portal size budget',
    why: "Rapier's WebAssembly is ≈ 2.4 MB; in the one-file upload it is base64 inside the JS: ≈ 1.3 MB gzipped, 3.4 MB raw — three times CrazyGames' 400 KB budget, ≈ 8 s to a tappable Play on the slow-phone profile (the engine lab). The build only warns; the forecast counts the longer load.",
    fix: "Use physics only where it is the mechanic (stacking, piles, joints), and then raise the budget on purpose: `budget: { gzipKB: 1500 }`. A game that only needs bounces and overlaps does them in its own code with Canvas 2D.",
    example: 'budget: { gzipKB: 1500 }',
  },
  W_PHYSICS_UNDECLARED: {
    title: 'A physics package without engine.physics',
    why: "The game's package.json lists Rapier, but game.yaml doesn't say so: `gp validate` can't check its version, and the game misses the physics block (@gp/physics: the fixed step on the game's clock, the host's pauses, the WebAssembly freed on reset, determinism) — the engine lab's Rapier variant did each of those by hand.",
    fix: 'Declare it — `engine: { name: canvas, physics: { name: rapier2d, version: 0.21.0 } }` — and run the world through createPhysics() from @gp/physics (docs/guides/code-games.md#physics).',
  },
  W_PATCH_NOTES: {
    title: 'An update without patch notes',
    why: "CHANGELOG.md has more than one version, so this is an update of a released game, and `gp submission` refuses an update without games/<id>/patch-notes.md — the portal's update form asks what changed for players. Alien Scan Logic 1.2.0 found out only at the submission.",
    fix: 'Write games/<id>/patch-notes.md: what changed for players, in plain English, at most 2000 characters (not the CHANGELOG).',
  },
  E_ART_ID: {
    title: 'Two art assets share an id',
    why: "An asset's id is its file name (assets/<id>.webp) and its key in ART (assets/index.ts): two with one id would overwrite each other.",
    fix: 'Give every entry in `art.assets` its own id.',
    example: 'art:\n  assets:\n    - { id: hero, kind: sprite, prompt: "the candle knight, idle" }\n    - { id: hero-run, kind: sprite, prompt: "the candle knight, running" }',
  },
  E_ART_PART: {
    title: "An art part names a sprite that isn't there",
    why: "`gp art import` cuts parts out of an owner's picture — a car's wheels, its paint mask — as sprites of their own, each with `part: { of, at }`: the sprite it belongs to and where its centre sits in it (assets/index.ts exports them as PARTS). A part of an asset that was removed or renamed has nothing to be drawn on.",
    fix: 'Point `part.of` at the sprite it was cut from, run `gp art import <dir> <id>` again for that picture (it rewrites its parts), or remove the part.',
    example: 'art:\n  assets:\n    - { id: red-car, kind: sprite, source: import, prompt: "the red coupe, side view" }\n    - { id: red-car-wheel-1, kind: sprite, source: import, prompt: "the red coupe\'s front wheel", part: { of: red-car, at: [96, 118] } }',
  },
  W_ART_MISSING: {
    title: "Art assets declared in game.yaml aren't generated yet",
    why: 'game.yaml `art.assets` lists images the game imports from assets/index.ts; until `gp art` makes them, the build has nothing to import (and an index.ts that lists other assets breaks it).',
    fix: 'Run `gp art <id>` with GEMINI_API_KEY in the environment: it makes the missing images and rewrites assets/index.ts. `gp art --provider mock` makes placeholders with no network. An imported picture (`source: import`): `gp art import <dir> <id>` with the folder of the owner\'s originals.',
  },
  W_ART_REALISTIC: {
    title: 'The art direction asks for realism',
    why: 'Our games use cartoon, game-like art (the owner, 2026-10-10): clean shapes, bold silhouettes, simple shading, a saturated palette. Words like "photorealistic", "8k" or "cinematic lighting" pull an image model toward photographs, which look out of place in a casual game and read as raw AI output. `gp art` already adds the cartoon house style to every request; the game\'s own words should not fight it.',
    fix: 'Describe the cartoon look you want: shapes, shading (cel, soft gradients), outline, palette and light.',
    example: 'art:\n  style: "chunky cartoon shapes, soft cel shading, warm candle rim light from the upper left, teal and amber palette"',
  },
  W_ART_PROVENANCE: {
    title: "An image in assets/ isn't the one provenance.yaml records",
    why: 'assets/provenance.yaml says what made every image — model, full prompt, date, hash — so the art can be remade, its license traced and the store disclosure written. An image changed by hand or copied in from elsewhere no longer matches.',
    fix: 'Edited by hand: `gp art --record` (records the new hash, marked edited). The owner\'s own picture: `gp art import <dir> <id>` records it as `source: owner` with the original\'s name and hash. From elsewhere: remake it with `gp art --only <id>`, or keep a record of where it came from and its license.',
  },
  W_DEPS_MISSING: {
    title: "The game's own npm dependencies aren't installed",
    why: 'A `kit: code` game may import its own npm packages (an engine, a physics library), declared in games/<id>/package.json and installed into games/<id>/node_modules. Not installed, the build and the dev server can\'t resolve them.',
    fix: 'Run `npm ci` (or `npm install`) in the game folder; `scripts/setup.sh` of a `gp init` repository does it for every game.',
  },
  W_SCOPE: {
    title: 'A first submission with more screens than our approved games had',
    why: "CrazyGames rejected broad \"systems\" games for \"the overall quality\" (\"needs content and polishing… looks like a prototype\"): in the calibration of 2026-10-19 the rejected games declared 16–20 screens to QA, the approved ones 10–12 (docs/research/qa-calibration-2026-10.md). The count comes from the last `gp qa` (the screens it opened from host.qa({ screens })), so it shows after the first QA run; a game with a record in publisher/results.yaml is not a first submission and is not warned.",
    fix: 'Cut to one core, one meta track and one return hook — at most 15 screens, each drawn and animated; merge settings, help and the like, and keep the rest for an update. `gp review` then asks the reviewer for a [blocking] "prototype risk" finding unless every screen is finished.',
  },
  W_TWIST_MISSING: {
    title: 'No declared twist',
    why: 'A concept on paper is not a game in play: with `concept.twist` the game says when its twist happens (`host.twist()`), and `gp qa` checks that a new player meets it within the first seconds.',
    fix: 'Add `concept.twist: { event, within }` and call `host.twist(event)` at that moment in the game.',
  },
  W_TWIST_UNEXPLAINED: {
    title: 'The twist is declared, its explanation is not',
    why: 'A twist the player meets but doesn\'t understand is not a twist to them. Echoflies passed QA 116/116 while the line that explained its echoes was on screen for 30 ms; a playtest found it, QA and the code review could not. With `concept.twist.explained`, `gp qa` checks the words are readable (2 s + 50 ms per character) before or when `host.twist()` fires.',
    fix: 'Add `concept.twist.explained: "<the words on screen>"` and show them in the DOM (or in a host.qa canvasUi rect with `text`) before or when the twist fires, until the player has read them (a hint that waits for a tap: let the demo bot wait too).',
  },
  W_MECHANIC_COPY: {
    title: 'The mechanic is still the template\'s or the example\'s',
    why: 'The game\'s rules code is mostly the same as the platform template\'s or the code example\'s: whatever the concept says, the game plays like them.',
    fix: 'Replace the rules (sim.ts / the update loop) with your own mechanic; keep only the host wiring.',
  },
  W_CONCEPT_NOTES: {
    title: 'The originality search notes are still TODO',
    why: 'docs/concept.md is where the portal search is written down (the ideas checked, what the portal has, the verdict); the concept in game.yaml is its conclusion.',
    fix: 'Fill in docs/concept.md: the searches, the live titles found, why the chosen twist is not live.',
  },
  W_LISTING: {
    title: 'No listing texts',
    why: 'The portal form asks for a description and the controls; `gp submission` writes them into listing.md next to the upload, covers and videos.',
    fix: 'Add `listing: { description, controls, orientation }` to game.yaml.',
  },
  W_CONCEPT_THEME: {
    title: 'The concept differs only in its looks',
    why: '"A theme swap is not a twist": a new setting, art style or name over the same rules is exactly what portals call too close to existing titles.',
    fix: 'Say in `concept.different` what the player does differently: a new rule, input, goal or combination of mechanics.',
  },
  W_CONTENT_LANG: {
    title: 'Content language differs from the game language',
    why: 'Text-to-speech speaks in the game language; words from a pack in another language would be read with the wrong accent.',
    fix: 'Use packs in the game language, or change `locale`.',
  },

  // --- Languages: game.yaml `languages`, the strings files (docs/guides/i18n.md; `gp translate`)
  E_I18N_LANGS: {
    title: 'A language is listed twice',
    why: '`languages` is the list the picker shows and QA checks; a language twice is a typo.',
    fix: 'List each language once, English first.',
    example: 'languages: [en, es, pt-BR, fr, de, ru, tr, it, pl, id]',
  },
  E_I18N_ENGLISH: {
    title: 'The game has no English',
    why: 'CrazyGames requires English ("The game must have English localization"), and every text a language misses falls back to English.',
    fix: 'Put `en` first in `languages` and write strings/en.yaml.',
  },
  W_I18N_LANGS: {
    title: 'The game misses some of its audience\'s languages',
    why: "Most of CrazyGames' players don't play in English: the ten top languages (en, es, pt-BR, fr, de, ru, tr, it, pl, id) reach far more of them. The platform's own texts are translated already; the game's are a brief for its agent (`gp translate`).",
    fix: 'Add the missing languages to `languages`, run `gp translate`, translate what it lists into strings/<code>.yaml, and `gp validate` again.',
    example: 'languages: [en, es, pt-BR, fr, de, ru, tr, it, pl, id]',
  },
  E_I18N_FILE: {
    title: "A strings file can't be read",
    why: 'The texts of each language are in games/<id>/strings/<code>.yaml: a key with its text, nested maps for groups, { one, other } for plural forms. A file that is missing, not YAML or has lists instead of texts can\'t be shipped.',
    fix: 'Create or fix the file the message names (`gp translate` lists what each language needs).',
    example: 'play: Play\nscore: "Score: {n}"\ncoins: { one: "{n} coin", other: "{n} coins" }',
  },
  E_I18N_MISSING: {
    title: 'Texts are missing in a language',
    why: 'A key without a text in the player\'s language shows English in the middle of a translated screen (and a placeholder key nowhere at all).',
    fix: 'Translate the listed keys into strings/<code>.yaml — `gp translate` writes them, with the English, into a brief.',
  },
  E_I18N_EMPTY: {
    title: 'An empty or TODO text',
    why: 'An empty text is an empty button or label on screen; a TODO is a placeholder a player would read.',
    fix: 'Write the text.',
  },
  E_I18N_PARAMS: {
    title: 'A translation has other parameters than English',
    why: 'The game fills `{name}` parameters by name: a translated or dropped one shows "{n}" or loses the number on screen.',
    fix: 'Keep every `{name}` exactly as in English; translate the words around it.',
  },
  E_I18N_PLURAL: {
    title: 'A plural text misses forms the language needs',
    why: 'Languages count differently: Russian and Polish have one, few and many (1 монета, 2 монеты, 5 монет), Indonesian, Japanese and Chinese one form. Intl.PluralRules picks the form by `{n}`; a missing one shows `other`.',
    fix: 'Write every form the message lists (`gp translate` names them per language).',
    example: 'coins: { one: "{n} монета", few: "{n} монеты", many: "{n} монет", other: "{n} монеты" }',
  },
  W_I18N_PLURAL: {
    title: 'A plural form the language never uses',
    why: 'Intl.PluralRules never picks it for this language: usually a form copied from another language.',
    fix: 'Remove it (the message lists the forms the language has).',
  },
  E_I18N_KEY: {
    title: 'An unknown or malformed text key',
    why: 'The code asks for a key no strings file has (a typo: the player would see the key), or a key is not a plain name, or a game key starts with "gp." (the platform\'s texts).',
    fix: 'Add the key to strings/en.yaml (and translate it), or fix the name in the code. Keys: letters, digits, - and _, dots between levels.',
  },
  W_I18N_EXTRA: {
    title: 'A translation of a key English doesn\'t have',
    why: 'Usually a key renamed in English whose old translations stayed behind: nothing shows them.',
    fix: 'Remove it from that language, or add the key to strings/en.yaml.',
  },
  W_I18N_UNDECLARED: {
    title: 'A strings file for a language the game doesn\'t declare',
    why: 'The game ships only the languages in `languages`: the file is never shown (and never checked).',
    fix: 'Add the language to `languages`, or remove the file.',
  },
  W_I18N_LONG: {
    title: 'A translation far longer than English',
    why: 'UI text has the room English takes: a translation twice as long overflows buttons and panels on a phone (gp qa checks the longest language on screen).',
    fix: 'Say it shorter; keep UI text within ~30% of English where the room is tight.',
  },
  W_I18N_GLOSSARY: {
    title: 'A translation drops a glossary name',
    why: 'Names in `glossary` (the game\'s characters, places, its own words) stay as they are in every language, so players and the store page call them the same.',
    fix: 'Keep the name untranslated in the text.',
  },
  W_I18N_LISTING: {
    title: 'The listing is not translated',
    why: 'The store page in the player\'s language (CrazyGames\' form takes English only; the translations are for the store page, other portals and the game\'s own site).',
    fix: 'Add `listing: { description, controls }` to strings/<code>.yaml for each language (`gp translate` includes them).',
  },
  W_I18N_STALE: {
    title: 'A translation of an English text that has changed since',
    why: "`gp translate --write` records, per key, a hash of the English each translation was made from (strings/<code>.sources.json). The English changed and the translation didn't: the player reads the old meaning — a rule, a price or a control that is no longer true. A game without the file (from before it) gets no warning until its first `--write`.",
    fix: 'Translate the new English into strings/<code>.yaml (`gp translate` lists the stale keys with the English beside them), then `gp translate --write` records it. If the translation still says the same (a typo fixed in English), `gp translate --write --accept` takes the translations as they are.',
    example: '# strings/en.yaml: "dash: Double-tap to dash" → "dash: Swipe to dash"\n# strings/de.yaml still: dash: "Doppeltippen zum Sprinten" → W_I18N_STALE until it is redone and recorded',
  },
  W_I18N_KIT_TEXT: {
    title: 'A text of game.yaml has no translation',
    why: "The kit's texts are translated by the platform; the game's own (titleScreen.subtitle, `strings` overrides) are English until strings/<code>.yaml has them — a mixed-language screen.",
    fix: 'Add the key (subtitle, or the `strings` name) to strings/<code>.yaml for each language.',
  },

  // --- Money: the game.yaml `money` section (docs/guides/game-design.md → Design for money; `gp forecast` estimates it)
  E_MONEY: {
    title: 'The money design is TODO or malformed',
    why: 'Where a game earns is decided in its architecture — the natural breaks (the only places a midgame ad can go), what each rewarded offer gives, how long a session and the meta last — before building, like the concept. A TODO means it hasn\'t been decided; a genre the model doesn\'t know has no benchmarks; a placement listed twice counts twice.',
    fix: 'Write the genre, the session (minutes, breaks and where they are), each rewarded offer with what it gives, and the reason to return — then run `gp forecast`.',
    example: 'money:\n  genre: puzzle\n  session: { minutes: 18, breaks: 7, breaksAt: "level end → Next level" }\n  rewarded:\n    - { placement: hint, kind: hint, gives: "shows one good move" }\n  returns: { kind: daily, what: "a new night every day" }',
  },
  E_MONEY_NONE: {
    title: 'The design cannot show a single ad',
    why: 'The channel pays a share of its ads, ads are on, and the money section declares no natural break and no rewarded offer: no midgame ad can be shown (never during play) and nothing can be offered. That is a decision to write down, not a default to ship — the only error among the money checks, because the design, not a guess, says so.',
    fix: 'Add a natural break (a level, run or day end: `host.adBreak()` on the way into the next) or a rewarded offer; or say the game is not for money: `monetization.ads.enabled: false`.',
  },
  E_MONEY_RETURN: {
    title: 'No reason to come back tomorrow (CrazyGames)',
    why: "D1 retention is one of the three Basic Launch metrics that decide Full Launch (each scores 1–5 per device class, Full Launch needs ≥ 9 of 15 on one; docs/research/feedback-and-metrics-2026-10.md §1). None of our six launched games had a daily or a stated \"tomorrow\" at launch, and all came back at 1.0–3.9 % (the platform average is 6.7 %; about 4 % already scores 3 in Candle Crypt's category). On CrazyGames a game whose `money` section names no return — `returns` missing, or `kind: none` — is a game that hasn't decided where its D1 comes from: an error, like a TODO.",
    fix: 'Write `money.returns: { kind, what }` with a real reason: `daily` (a daily seed or case, shown on the title — @gp/core/daily), `meta` (a goal left at 60–80 % at the session\'s end), `story` (the next chapter), `social`. Never a loss-framed streak.',
    example: 'money:\n  returns: { kind: daily, what: "a new seeded crypt every day, its best depth on the title" }',
  },
  E_RESULTS_SCORES: {
    title: 'A Basic Launch score screen that doesn\'t add up',
    why: 'publisher/results.yaml records the score screen per device class: three scores 1–5 and the total of 15 (Full Launch needs 9+). A total that isn\'t the sum of its scores was copied from two screens, and the forecast and the playbook read it.',
    fix: 'Copy the three scores and the total from the same screen (the day in `scores.date`).',
    example: 'basicLaunch:\n  scores:\n    date: "2026-10-10"\n    desktop: { playtime: { value: 9.52, score: 4, next: 12.22 }, d1: { value: 0.0296, score: 2, next: 0.0394 }, conversion: { value: 0.5125, score: 1, next: 0.54 }, total: 7 }',
  },
  W_MONEY_MISSING: {
    title: 'No money design',
    why: 'On a portal a `kit: code` game writes its money design with its concept: `gp forecast` otherwise guesses it from the genre, the code (host.adBreak, rewarded placements) and the balance report, and `gp submission` refuses to hand over without it. Old games are not reworked: this is a warning, never an error.',
    fix: 'Add `money:` (the template has it; `gp explain money`), then `gp forecast`.',
  },
  W_MONEY_REWARDED_OFF: {
    title: 'Rewarded offers, but rewarded ads are off',
    why: '`money.rewarded` lists offers while `monetization.ads.rewarded: false`: none of them can be shown.',
    fix: 'Remove `monetization.ads.rewarded: false`, or the offers.',
  },
  W_MONEY_BREAKS: {
    title: 'No natural break in a session',
    why: 'A midgame ad may only come at a natural break (a level or run end, a day end) — never during play and never on a navigational button. Without one, only the rewarded offers earn: midgame is 40–60% of a casual game\'s earnings on CrazyGames.',
    fix: 'Give the session an end every 2–5 min (levels, runs, days) and call `host.adBreak()` on the way into the next.',
  },
  W_MONEY_BREAK_GAP: {
    title: 'Natural breaks too far apart',
    why: 'The channel allows one midgame ad per 3 min (CrazyGames), and only at a break: a break every 20+ min leaves most of that unused, and players get no rest either.',
    fix: 'Split the session into levels, runs or days of 3–5 min.',
  },
  W_MONEY_SESSION: {
    title: 'A session shorter than the Basic Launch playtime gate',
    why: 'CrazyGames compares Basic Launch\'s average playtime with other games (top games 10+ min): a design for shorter sessions rarely reaches Full Launch, where the revenue is.',
    fix: 'Design for 10+ minutes: a meta that carries runs, levels with stars, a second track (docs/guides/game-design.md → Depth).',
  },
  W_MONEY_META: {
    title: 'The meta is done within a session',
    why: 'A progression finished in the first session leaves nothing to come back for (D1) and nothing to play for after it.',
    fix: 'Make the meta last well past a session (10–180 min, docs/guides/upgrades.md) and measure it with the balance bot (`gp balance`).',
  },
  W_MONEY_RETURN: {
    title: 'No reason to come back tomorrow',
    why: 'Basic Launch reads D1 retention (the platform average is 6.7%, strong games 10–15%). A warning on a reviewing channel other than CrazyGames; on CrazyGames it is the error E_MONEY_RETURN.',
    fix: 'A daily seed or case, a meta goal left at 80%, the next story chapter — never a loss-framed streak.',
  },
  W_MONEY_IAP: {
    title: 'A price for a purchase the game doesn\'t have',
    why: '`money.removeAdsPrice` prices the "Remove ads" purchase for the forecast; the game has none (or the channel has no purchases).',
    fix: 'Remove `money.removeAdsPrice`, or enable `monetization.removeAds`.',
  },

  // --- Balance: the game.yaml `balance` section (docs/guides/upgrades.md → Start from time, then the anchor)
  W_BALANCE_ANCHOR: {
    title: 'No balance anchor',
    why: "Our portal games lost players in the first session (4–7 min of average play against 10+, D1 1–2.4 % against 10–15 %, 26–76 % past the first minute against 80 %+). The owner's balance method starts from time — the session's length, entered by hand — then the anchor: the one number the genre converts everything into (time to kill and to die, distance over the session, lap time, rooms a run, income a minute). Declared, the balance model's first-session checks (the first reward within a minute, a new thing every 3 min of the first 10, no two big rewards in a minute, no hard streak, no jump in a stage's time, a goal in reach at the session's end, a meta of 2+ sessions) fail like the others; without it they only warn, so games made before them keep passing.",
    fix: 'Add `balance: { anchor: { name, unit, says } }` and build balanceModel() in that unit (its `measure` names it). A roguelite whose stages are a run\'s waves, floors or rooms adds `shape: run`: the model plays runs from the first stage, and a run\'s checks replace the campaign\'s per-stage ones.',
    example: 'balance:\n  anchor: { name: "clear time", unit: "s", says: "how long one room takes a fresh hero" }',
  },

  // --- Sound: the game.yaml `sound` section and the game's code (docs/guides/code-games.md → Music and ambience)
  E_SOUND_MUSIC: {
    title: 'A CrazyGames code game without music',
    why: "Players and judges asked for background music in six of our games (Dread Throne, Firefly Rush, Hang the Moon, Nimbus Drift, Spin Brawl, Candle Crypt), and 6 of the 10 quality rejections of 2026-10-02…06 had none (docs/research/feedback-and-metrics-2026-10.md §3.2); since 10-02 every approved game had music. QA can't hear, so the validator asks the code and game.yaml: on `channel: crazygames` a `kit: code` game needs music — the code calls `createMusic` from @gp/core/sound, or game.yaml `sound.music` says what plays (the game's own music code or tracks). `sound.music: false` needs a `why` (then it is the warning W_SOUND_MUSIC — `gp review --check` and `gp submission` still refuse it on CrazyGames).",
    fix: 'Add music through the host: `createMixer(host)`, `createMusic(mixer, { calm: musicTheme(\'calm\', seed) })` from @gp/core/sound, two sliders (music, effects) in the settings; or, for music of your own, say what plays in game.yaml `sound.music`.',
    example: 'sound:\n  music: "procedural themes per act (sound.ts: own synth), a boss theme, music and effects sliders"',
  },
  W_SOUND_MUSIC: {
    title: 'No music, on purpose',
    why: 'game.yaml says `sound.music: false` with a reason. The validator lets it through (a platform example, a prototype), but on CrazyGames `gp review --check` and `gp submission` refuse a code game without music: the reviewers asked for it in six games and most quality rejections had none.',
    fix: 'Add music before the submission (`createMusic` from @gp/core/sound), then remove `sound.music: false`.',
  },

  // --- Story: the game.yaml `story` section and the story file (docs/guides/story.md; `gp story` forms and checks it)
  I_STORY_DEPTH: {
    title: 'A hint about the story depth',
    why: 'An info, never a problem: this kind of game gains most from a story (idle and clicker games: waiting leaves room for short chapters), or the story file already is a deeper depth than declared. A game where no story is fine never gets it.',
    fix: 'Run `gp story` for the recommended depth and why; or write `story: { depth: none }` to say it is a decision. Per-item flavour text (a line under each car, upgrade or card) is not a story: it counts as `story: { depth: none }` too.',
  },
  W_STORY_DEPTH: {
    title: 'The story depth is outside what this kind of game supports',
    why: 'The table in docs/guides/story.md §1: children 2–5 don\'t read (no chapters or branching), action games keep chapters short and only as a reward for meta progression, and the YAML kits have no bark or dialogue block yet. More story than the game can hold is text players skip.',
    fix: 'Use the depth `gp story` recommends, or the most the message names.',
    example: 'story:\n  depth: barks\n  premise: "The Demon King just wants some peace and quiet."\n  file: story.ts',
  },
  E_STORY_SECTION: {
    title: 'The story depth needs a field',
    why: 'Depth premise is the premise line itself; chapters and branching live in a story file, so they can be counted and checked (`gp validate` loads it).',
    fix: 'Add `premise:` (one line) or `file: story.ts` (`gp story --write` forms one).',
    example: 'story: { depth: chapters, premise: "A candle goes down to relight the Great Candle.", file: story.ts }',
  },
  E_STORY_VOICE: {
    title: 'Story lines for young children must be voiced',
    why: 'Ages 2–5 don\'t read, and ages 6–8 read about 60 words a minute: a line on screen without a voice is a line they miss (the same rule as E_VOICE_REQUIRED).',
    fix: 'Speak every story line (TTS or recorded audio) and set `story.voiced: true`; or keep the story wordless (depth premise).',
  },
  E_STORY_FILE: {
    title: 'The story file can\'t be read',
    why: '`story.file` is where the story is; `gp validate` loads it (Node, type stripping) to count and check it. A file that is missing or runs code on import can\'t be checked.',
    fix: 'Create it (`gp story --write`), fix the path, or keep it data only: `import type` from @gp/core, no values (the `Bag` goes in main.ts). A JSON file works too.',
  },
  W_STORY_FORMAT: {
    title: 'The story is in the game\'s own format',
    why: 'Without a `StoryDef` the platform can only count words: scene length, Skip, choices, pacing and consequences can\'t be checked, and the story engine can\'t play it.',
    fix: 'Export `STORY: StoryDef` from the story file (docs/guides/story.md §4).',
  },
  W_STORY_THIN: {
    title: 'The story is too thin for its depth',
    why: 'A depth promises something: barks that don\'t repeat within minutes (50–200), 6–12 chapters, choices whose flags change later lines and 2–3 endings. Less than that is a lighter depth.',
    fix: 'Write what the message names, or set the lighter depth it amounts to.',
  },
  W_STORY_HEAVY: {
    title: 'The story is too heavy for its depth',
    why: 'Reading more doesn\'t make players stay: in the one large study (10M+ players) those who read less stayed longer and paid more. Words past what the depth pays off are cost (writing, translation, QA) without players.',
    fix: 'Cut it to the depth, or set the depth the story amounts to if this kind of game supports it (`gp story`).',
  },
  W_STORY_TODO: {
    title: 'Story text is still TODO',
    why: '`gp story` forms a skeleton with TODO lines; a game ships with its own words.',
    fix: 'Write the premise, the characters and every line.',
  },
  E_STORY_BEFORE_PLAY: {
    title: 'A scene plays before the player has done anything',
    why: 'Web 13+: text before the first action loses players (Brew & Banter\'s first chapter blocked the first tap for 30 s). On a fresh save, at the first run\'s start, no scene may be due; a main chapter without `at` plays at run-start.',
    fix: 'Set `at: run-end` on the first chapter (the first reward), or a `when` that is false on a fresh save; before play only a `first-action` scene of ≤ 20 words.',
  },
  W_STORY_BEFORE_PLAY: {
    title: 'A long intro in the story file',
    why: 'An export named like an intro (INTRO, PROLOGUE, OPENING) with more than 20 words: if it plays before the first action, players leave before they play.',
    fix: 'One line of ≤ 20 words before play; the tutorial as barks during play; the rest after the first run.',
  },
  W_STORY_BARK_LONG: {
    title: 'A bark too long for a bubble',
    why: 'Barks are read at a glance during play: ≤ 60 characters (≤ 10 words for ages 6–8).',
    fix: 'Cut it, or move it into a chapter.',
  },
  E_STORY_SHOP: {
    title: 'A story line in a children\'s game points to the shop or ads',
    why: 'Google Play Families: characters must never push purchases or ads to children.',
    fix: 'Take the line or the effect out of the story.',
  },
  W_STORY_SHOP: {
    title: 'A line during play points to the shop or ads',
    why: 'No story line pushes the shop or an ad during play (13+); a "the shop has new stock" line on the results screen is fine.',
    fix: 'Move it to the results screen, or explain in REPORT.md why it is fine (a merchant inside the game\'s own shop).',
  },
  W_STORY_STRINGS: {
    title: 'The story\'s keys in strings/en.yaml are out of step with the story file',
    why: 'Once the story\'s lines, choices and barks are strings keys (`gp story --strings`), the game shows them through host.i18n and `gp translate` lists them for every language. A line changed, added or removed in the story file and not in strings/en.yaml shows the old English (or none) and its translations go stale unnoticed.',
    fix: 'Run `gp story --strings` again (it rewrites the story.* and bark.* keys from the story file), then `gp translate`.',
  },
  I_STORY_STRINGS: {
    title: 'The story is English only in a game of several languages',
    why: 'StoryRunner and the bark lists return the story file\'s English: without strings keys the story stays English while the rest of the game is translated (Swarm Smash kept a hand-made copy in strings and a test to keep them in step).',
    fix: 'Run `gp story --strings`, then `gp translate --write`; show the texts with new StoryRunner(story, scene, state, progress, { i18n: host.i18n }) and barkText(host.i18n, event, i, line) (docs/guides/story.md).',
  },
  W_STORY_SKIP: {
    title: 'No Skip QA can find on the story scenes',
    why: 'Every blocking scene can be skipped. `mountDialogue` always has Skip (`data-gp="dialog-skip"`); a dialogue screen of the game\'s own needs the same hook, or `gp qa` can\'t check it.',
    fix: 'Use `mountDialogue`, or put `data-gp="dialog"` and `data-gp="dialog-skip"` on your own scene screen.',
  },
  // From the story engine's checker (validateStory in @gp/core/story.ts), reported by `gp validate` for the story file
  E_STORY_CONDITION: { title: 'A story condition doesn\'t parse', why: 'Conditions are parsed, never eval\'ed: names, numbers, not / and / or, ( ), comparisons, seen(), chose().', fix: 'Fix the condition at the reported place.' },
  E_STORY_REF: { title: 'A story reference points to nothing', why: 'A goto, label, chapter, seen(), chose() or a condition names something that doesn\'t exist; or a scene has nothing to show.', fix: 'Fix the name, or add what it points to.' },
  E_STORY_IDS: { title: 'A story id is duplicated or malformed', why: 'Scene, choice and line ids are save data and translation keys.', fix: 'Give each one its own plain id (letters, digits, - _).' },
  E_STORY_VARS: { title: 'A story var is declared wrong', why: 'Story vars default to true/false or a number, and never share a name with a game var.', fix: 'Write `name: false` or `name: 0`, and rename clashes.' },
  E_STORY_EFFECT: { title: 'A story effect does something it can\'t', why: 'give/fire/cue names must be declared in rewards/events/cues; set/clear are for flags, add for numbers; game vars are read-only.', fix: 'Declare the name, or use the right effect.' },
  E_STORY_SPEAKER: { title: 'A speaker is not in the cast', why: 'Every line\'s speaker needs a name plate. Text with ": " after a word reads that word as a speaker.', fix: 'Add the speaker to `cast`, or use the object form `{ text: … }`.' },
  E_STORY_MOOD: { title: 'A mood the speaker doesn\'t have', why: 'Portraits exist per mood.', fix: 'Use one of the speaker\'s moods, or declare it.' },
  E_STORY_LINE_LONG: { title: 'A story line is too long', why: 'It overflows the dialogue box on phones (web 13+: 140 characters; children less).', fix: 'Split it into two lines.' },
  W_STORY_LINE_LONG: { title: 'A story line is long', why: 'Shorter lines read better (web 13+: over 100 characters).', fix: 'Split it.' },
  E_STORY_SCENE_LONG: { title: 'A scene is too long', why: 'Over 200 words on its longest path (web 13+) is a wall of text.', fix: 'Cut or split it, or say why with `long: "<reason>"`.' },
  W_STORY_SCENE_LONG: { title: 'A scene is long', why: 'Chapters work best at ≤ 8 lines and ≤ 120 words (web 13+).', fix: 'Cut it, or say why with `long:`.' },
  E_STORY_FIRST_ACTION: { title: 'Too many words at the first action', why: 'Before play only a premise line: ≤ 20 words.', fix: 'Tell the rest after the first run.' },
  E_STORY_FIRST_SCENE: { title: 'The first chapter is too long', why: 'Play first, story after: the first chapter is ≤ 60 words (web 13+).', fix: 'Shorten it.' },
  E_STORY_CHOICES: { title: 'Choices are malformed', why: '1–3 choices per point (2 for children), each with its own text.', fix: 'Cut or fix the choices.' },
  W_STORY_CHOICE_LONG: { title: 'A choice is long', why: 'A choice is a short reply (≤ 40 characters).', fix: 'Shorten it.' },
  W_STORY_NO_PAYOFF: { title: 'A choice changes nothing', why: 'A choice with no reply and no effect means nothing to the player.', fix: 'Add a reply (`then`) or an effect (`do`), or drop it.' },
  W_STORY_NARRATOR_WALL: { title: 'Three narrator lines in a row', why: 'Exposition: characters carry a story better.', fix: 'Let a character say it, or cut it.' },
  W_STORY_PATHS: { title: 'Too many story states to check', why: 'The checker walks every path up to a bound.', fix: 'Split the scene, or use fewer flags in it.' },
  E_STORY_DEAD_END: { title: 'A scene can get stuck', why: 'A goto loop with no way out never ends.', fix: 'Give every loop a choice that leaves it.' },
  W_STORY_ALL_HIDDEN: { title: 'All choices can be hidden', why: 'On some path every choice at a point is hidden and the line plays as a plain one.', fix: 'Add a choice without a condition.' },
  W_STORY_LINE_UNREACHABLE: { title: 'A line is never shown', why: 'No path reaches it (its `if` reads a flag nobody sets?).', fix: 'Fix the condition, or remove the line.' },
  E_STORY_UNREACHABLE: { title: 'A scene can never play', why: 'Its `when` reads story vars nothing changes.', fix: 'Set the flag somewhere, or fix the condition.' },
  // --- gp qa's look checks (packages/kit-code/qa: suite.ts, look.ts; @gp/qa flat, glyphs, probe): the code a failed or
  // warned QA line names, for `gp explain` — CrazyGames rejected our games for "the overall quality" while QA was green
  E_QA_DESKTOP_EMPTY: {
    title: 'A screen is empty or flat at a desktop size (gp qa, crazygames)',
    why: "CrazyGames' reviewers judge a game on a desktop screen; our phone-first layouts left a column of buttons in a bare field there, and a play frame of one flat colour (Germ Dodge: 99 %). On crazygames `gp qa` measures every screen it reaches and every declared screen at 1280×720 and 821×462 and fails one that is clearly empty: 70 % or more of it one colour, 80 % or more featureless (8×8-pixel blocks with no visible variation), or one featureless area of 40 % of the screen. Calibrated on our approved games, which stay well under it; a play frame is measured again 2 s later before it fails (an act card passing by). The later play frame too: at 1280×720, 15 s into a demo run (section desktop-look; the blind review found play frames that thin out — a sparse scene, a mostly empty table), unless the run has ended by then.",
    fix: 'Fill the desktop screen: a lit background with layers behind every screen (@gp/art scenery and light), the world scaled with the screen (a unit from the short side), panels sized for 1280×720 instead of a phone column in the middle. docs/guides/art.md.',
  },
  E_QA_HERO_SMALL: {
    title: "The player's object is a speck on the screen (gp qa, crazygames)",
    why: 'A hero drawn at its phone size on a 1280×720 screen is lost in an empty field: reviewers read it as a prototype. With `host.qa({ hero })` (a rect, or a function returning the player\'s object rect in CSS px) `gp qa` measures it in play at every size; on crazygames its size, √(w·h), must be at least 6 % of the screen\'s short side (43 px at 1280×720, 28 px at 821×462).',
    fix: "Scale the world with the screen (Germ Dodge: a unit of the short side / 470; the art showcase: the camera's zoom), or show less of it. Declare the hero: `host.qa({ …, hero: () => ({ x, y, w, h }) })`.",
  },
  E_QA_GLYPH_ICON: {
    title: 'A font glyph stands in for an icon (gp qa)',
    why: "Emoji and the symbol blocks (◆ ✓ ✕ ◎ ● ▌ ▶ ◀ ⚡ ★ 🔒 — Arrows, Misc Technical, Box Drawing, Block Elements, Geometric Shapes, Misc Symbols, Dingbats) look like a web page's, differ per device and never match the game's art: Frankengun's review blocked on them, Candle Crypt's owner asked for every one to be a drawn icon. `gp qa` scans the visible text of every screen it reaches (text, ::before/::after content, canvasUi text) and fails the game's own, naming the element and the screen. Inside the platform's own roots (#gp-*) it is a warning while the platform replaces its glyphs with drawn icons. © ® ™ are marks, not icons, and an arrow between two words or numbers is running text (\"×1.0 → ×1.1\"; \"← Back\" still counts).",
    fix: 'Draw the icon (an inline SVG or a canvas sprite in the game\'s style) and drop the glyph from the text — strings too ("▶ Continue" → "Continue" with a drawn arrow).',
  },
  E_QA_FIRST_RUN_LOST: {
    title: "A new player's first minute ends in a loss or a results screen (gp qa, crazygames)",
    why: "On a phone a new player taps around before they understand the game. QA's naive touch bot (random taps and drags at 360×800) plays a fresh first visit for 60 s on crazygames: a host.fail() or a host.roundEnd() in that time fails — the first minute is CrazyGames' conversion and most players who lose in it leave. Before 2026-10-19 the bot played 30 s and counted a loss as \"a run event\" (Frankengun's first run was lost at 40 s). A level won (host.roundEnd({ won: true })) is no loss.",
    fix: 'Make the first run safe for its first minute: the first threats sleep, a hit only knocks the player back while a shield lasts (Germ Dodge), a timed level runs past a minute (the art showcase\'s first shift) — `host.firstVisit` says it is that player.',
  },
  E_QA_HUD_OVERLAP: {
    title: 'HUD text over another text or a control (gp qa)',
    why: 'Two HUD labels drawn into each other (Frankengun\'s ammo count over its wave banner), a hint over the on-screen stick, a toast over the score: illegible, and the reviewers see it in the first seconds. `gp qa` samples every visible text in play at every size (and in the longest language) and fails one whose line boxes overlap another text\'s by more than a third of a line, or a button or a `data-gp-touch` control by more than 2 px — measured again 400 ms later, so a text sliding in doesn\'t count. Under a dialog that covers the screen nothing counts.',
    fix: 'Give each HUD text its own place (corners, a stack with gaps), keep hints clear of the controls, wrap long texts (max-width).',
  },
  W_TITLE_CHOICES: {
    title: 'The title screen offers many choices (gp qa)',
    why: 'After the first run the title is where a returning player starts again; with more than 6 buttons (Frankengun had 9: modes, shop, daily, season, settings, language, credits…) the way back into play is one of many. `gp qa` counts the visible controls (and canvas buttons) on the title after a run and warns above 6.',
    fix: 'Keep Play big and alone at the top; fold the rest into one menu (settings, language, credits), or show them after the run on the results screen.',
  },
  E_QA_BITMAP_MAGNIFIED: {
    title: 'A bitmap is drawn magnified (gp qa)',
    why: 'A small sprite drawn 2–3× its own pixels is smoothed into mush («Пиксельное месиво», Garage). `gp qa`\'s probe watches every drawImage on a canvas in the page and works out the source pixels per device pixel (the context\'s transform × the destination size × how the page scales the canvas): over 1.25× is a warning, over 2× fails, named with the screen and the image size. Crisp pixel art (imageSmoothingEnabled false) sources under 16 px a side (strips, patterns) and soft sources (a glow, a blur: no step between neighbouring pixels over 24 of 255 — Candle Crypt\'s glow drawn 16–32×) are not counted.',
    fix: 'Bake or paint the image at the size it is drawn × devicePixelRatio (SpriteCache bakes at the density; `gp art` paints at the asset\'s size), or keep pixel art crisp.',
  },
  W_SYSTEM_FONT: {
    title: "Most text renders in the system's face (gp qa)",
    why: "Text in system-ui, Georgia, Arial or DejaVu reads as a web page, not a game (Velvet's Georgia and system-ui; one of the reasons our DOM screens looked like a web app to CrazyGames' reviewers). `gp qa` weighs the visible characters (DOM text and canvas text) by the face that renders them — a font the game loaded (a FontFace in document.fonts) or a generic / system face — and warns when more than half are the system's.",
    fix: 'Load a display face of the game\'s own for titles, buttons and numbers (a FontFace, @font-face; Latin and Cyrillic for our languages) and keep the system face as the fallback.',
  },
  E_QA_PORTRAIT_FOV: {
    title: "A 3D camera sees a slit in portrait (gp qa, three)",
    why: "three's PerspectiveCamera keeps its vertical field of view, so on a phone held upright (360×800) a 75° camera sees about 38° across: the world is a slit (Frankengun). For a game on the three engine `gp qa` reads the camera in play at 360×800 — the adapter's `eng.camera`, or `host.qa({ camera })` — and fails under 60° across.",
    fix: 'On every resize widen the vertical fov in portrait so the horizontal one stays ≥ 60°: `camera.fov = Math.max(base, 2 * Math.atan(Math.tan(30 * Math.PI / 180) / camera.aspect) * 180 / Math.PI)`, then `camera.updateProjectionMatrix()`. docs/guides/three-fps.md.',
  },
  // From the calibration and the blind scored review (docs/research/qa-calibration-2026-10.md)
  E_QA_TITLE_COVERED: {
    title: "The title hides its key art behind a panel (gp qa)",
    why: "The blind scored review of our games marked titles down most for one thing: a centred dark modal over the key art (Garage, Swarm Smash, Candle Crypt) where the approved front-page games show full-bleed art with the buttons beside it. `gp qa` measures the first screen at 1280×720 (and a declared screen named title, menu or home): the share of the screen under opaque DOM layers over the canvas (a background colour or gradient, or a backdrop blur, at 60 % opacity or more; an image background is art, not a panel), and whether the canvas alone (the DOM hidden) has detail. With detail behind, over 20 % warns (Garage 1.0.0's title panel: 23 %) and over 45 % fails on crazygames (a warning elsewhere). A flat or empty canvas has no key art to hide: not judged.",
    fix: 'Let the key art fill the screen and put the title and the buttons beside it or over its empty part — a column at one side, a bar along the bottom, the logo over the sky — instead of a centred modal; keep a panel only as big as its buttons.',
  },
  E_QA_PLAY_TEXT: {
    title: 'Play text is small or low in contrast at 1280×720 (gp qa)',
    why: "Rejected games read as unfinished partly through their play text: Velvet Domino Rogue's 13 px \"Chains 4 · Discards 3 · Bag 21\", Swarm Smash's objective line barely visible under its progress bar, Candle Crypt's pixel HUD. `gp qa` (section desktop-look) reads every visible text in play at 1280×720, 2 s and 15 s into a demo run — the DOM's text and the canvas text the probe records from fillText/strokeText (its font size, position and colour through the context's transform) — and samples the screenshot under each to find the colour behind it. A HUD number (mostly digits) under 12 px fails on crazygames; any text under 14 px, or under 3:1 (WCAG) against what's behind it, warns. An outline (a text stroke, a hard shadow, a strokeText at the same place) counts as what's behind.",
    fix: "HUD numbers of 16 px or more in the game's face at 1280×720 (scale the HUD with the screen), and a plate or an outline behind any text over the scene; never a pale text on a pale sky.",
  },
  E_QA_HERO_MISSING: {
    title: "An action game doesn't say where its hero is (gp qa, crazygames)",
    why: "Small sprites on a desktop screen (Candle Crypt's 32-px heroes, Swarm Smash's ≈ 30-px enemies) were one thing the rejected action games shared; E_QA_HERO_SMALL would have caught them, but only once `host.qa({ hero })` is declared. On crazygames a game whose genre is action or shooting (money.genre, or a sub-genre whose parent is one: roguelite, survivors, platformer) or that is tagged Arcade must declare it: QA fails once (at the first size) without it.",
    fix: "Declare the player's object in CSS px: `host.qa({ …, hero: () => (state === 'play' ? { x, y, w, h } : null) })` — then make it at least 6 % of the screen's short side (E_QA_HERO_SMALL).",
  },
  W_META_SILHOUETTES: {
    title: 'A collection screen is a wall of placeholders on a fresh save (gp qa)',
    why: "The blind review marked meta screens down when they were silhouettes or near-identical dark icons: albums of \"???\", codexes of 37 dark icons (Garage's album, Swarm Smash). `gp qa` opens every declared screen on a fresh save; the largest group of 6 or more alike items on screen (siblings of one tag and class) is judged item by item — a \"???\" text, images with near-zero colour variance (silhouettes, flat slots), or an empty slot is a placeholder — and more than half placeholders warns.",
    fix: "Show what can be had: the first finds earned or nearly earned, the locked ones in colour (dimmed, with how to get them) rather than black shapes, fewer slots at once (a page per area), or open the screen only after the first finds.",
  },
  W_SCOPE_SCREENS: {
    title: 'The game declares more than 15 screens (gp qa)',
    why: "Scope separated our CrazyGames answers better than any look check: the rejected games declared 16–20 screens (75 weapons, 78 parts with 16 synergies, a roguelite with 16 screens), the approved ones 10–12. Each extra screen is one a reviewer may open unfinished. `gp qa` counts the declared screens (`host.qa({ screens })`) and warns over 15; `gp review`'s brief asks the reviewer for a `[blocking]` prototype-risk finding unless every screen is finished.",
    fix: 'Fold side screens together (stats into the results, settings into one sheet), cut the ones that are not drawn and animated, and grow the content of the core screens instead.',
  },
};

/** More declared screens than this: W_SCOPE_SCREENS in gp qa, a prototype risk in gp review's brief */
export const SCOPE_MAX_SCREENS = 15;

/** error: must be fixed · warning: read, then fix or explain · info: a hint, nothing to fix */
export type Severity = 'error' | 'warning' | 'info';

export interface Issue {
  code: string;
  severity: Severity;
  /** Path in game.yaml, e.g. ["modes", 2, "content"] */
  path: (string | number)[];
  message: string;
  /** Concrete fix for this case */
  fix: string;
  /** 1-based line in game.yaml, when known */
  line?: number;
}

export function formatPath(path: readonly (string | number)[]): string {
  let s = '';
  for (const p of path) s += typeof p === 'number' ? `[${p}]` : s ? `.${p}` : p;
  return s || '(root)';
}

/** Edit distance, for "did you mean" */
export function distance(a: string, b: string): number {
  const d = Array.from({ length: a.length + 1 }, (_, i) => [i, ...Array(b.length).fill(0)] as number[]);
  for (let j = 1; j <= b.length; j++) d[0][j] = j;
  for (let i = 1; i <= a.length; i++)
    for (let j = 1; j <= b.length; j++) d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
  return d[a.length][b.length];
}

export function suggest(value: string, options: readonly string[]): string | null {
  let best: string | null = null;
  let bestD = Infinity;
  for (const o of options) {
    const dd = distance(value.toLowerCase(), o.toLowerCase());
    if (dd < bestD) {
      bestD = dd;
      best = o;
    }
  }
  return best !== null && bestD <= Math.max(2, Math.floor(best.length / 3)) ? best : null;
}
