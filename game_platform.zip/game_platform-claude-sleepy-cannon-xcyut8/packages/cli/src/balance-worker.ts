// gp qa's balance section off the main thread: a game's balance() simulates synchronously for up to minutes (Dread
// Throne: ≈ 190 s), and on the main thread it would hold every browser section's awaits for that long.

import { parentPort, workerData } from 'node:worker_threads';
import { runBalanceFile } from './balance.ts';

const { file, channel, opts } = workerData as { file: string; channel: string; opts?: { bot?: boolean } };
runBalanceFile(file, channel, opts).then(
  (run) => parentPort!.postMessage({ ok: true, run }),
  (e: unknown) => parentPort!.postMessage({ ok: false, message: String((e as Error)?.message ?? e) }),
);
