// The lesson run's hints (C4 in docs/research/feedback-and-metrics-2026-10.md): one short line at a time, shown when an
// action is first needed and gone the moment the player does it. What each game rebuilt by hand (Candle Crypt 1.4.1's
// "one hint at a time", Starsilk 2.0's lesson depth, Dread Throne's "tutorial tips helper" request) and what went wrong
// without it: Firefly Rush's hints ran to 85 words, Sigil Clash taught with text banners, Starsilk 1.0 with a modal.
//
//   const tips = hints({ seen: save.hints, onSeen: () => host.save(save) });   // save.hints: string[] in the game's save
//   tips.show('move', host.t('hint.move'), { after: 1500 });   // only if the player hasn't moved within 1.5 s
//   …when the player moves: tips.done('move');                // gone, never shown again (seen is saved)
//
// The rules it keeps: one hint on screen (the rest wait in a queue), ≤ 6 words (a dev warning past that), never cut
// short (another hint takes its place only after it was on screen for its reading time, readingSec(): 2 s + 50 ms a
// character — only the player doing it, done(), takes it away sooner), never over a modal (a dialogue, the language
// sheet, a shop: it waits, and the time behind the modal doesn't count as read), never in the way (no pointer events),
// read out by screen readers (role=status). Themeable: screenTheme() (its bg, ink and font), or `--gp-hint-bg`,
// `--gp-hint-ink`, `--gp-hint-radius`, `--gp-hint-font` on #gp-hint; placed by `position` and `top` (or `--gp-hints-top`: a board game keeps its board clear).

import { coachHand, type CoachHand, type CoachHandOptions } from './coach.ts';
import { FONT_FALLBACK } from './i18n.ts';
import { readingSec } from './reading.ts';

/** Words a hint should keep to: one look, no reading (docs/guides/first-minute.md) */
export const HINT_MAX_WORDS = 6;

export interface HintsOptions {
  /** Where the hint shows (default document.body: it survives the game replacing its #ui layer) */
  root?: HTMLElement;
  /** The ids of hints already learned, from the game's save: the list is changed in place (done() adds to it) */
  seen?: string[];
  /** A hint was learned: save the game (the `seen` list is in it) */
  onSeen?(seen: string[]): void;
  /** A learned hint never shows again (default true). false: done() only hides it */
  once?: boolean;
  /**
   * One at a time, the others wait in order until the one on screen is done (default true). false: a new hint replaces
   * the one on screen once that one has been read (its reading time); of several that come meanwhile, the latest
   */
  queue?: boolean;
  /** Wait while a modal is open (default true): a dialogue, the language sheet, a shop, anything aria-modal */
  neverOverModal?: boolean;
  /** Your own test for "a modal is open" (default: the platform's sheets and [aria-modal=true], dialog[open]) */
  isModal?(): boolean;
  /**
   * Where on the screen (default 'bottom': above the thumbs' reach, below the action; 'top' when `top` is given).
   * 'center' sits over the middle, where a card or board game has its main object: give it a `top` instead
   */
  position?: 'top' | 'center' | 'bottom';
  /**
   * The hint's distance from the top of the screen, for 'top' and 'center': px (72) or any CSS length ('18%',
   * 'calc(env(safe-area-inset-top) + 64px)'). The same as setting `--gp-hints-top` in the game's CSS (on :root or
   * #gp-hint), which also moves it later (a layout for landscape). Default: 12 % below the safe area ('top'), 50 % ('center')
   */
  top?: number | string;
}

export interface HintShowOptions {
  /** Show it only if the player hasn't done it within this many ms (default 0: at once) */
  after?: number;
  /** Seconds on screen before another hint may take its place (default readingSec(text): 2 s + 50 ms a character) */
  minSec?: number;
  /**
   * The coach's hand beside the words (coach.ts): the gesture at a point or between two — it shows while the hint is
   * on screen, and goes with it (done(), a modal over it, clear())
   */
  hand?: CoachHandOptions;
}

export interface Hints {
  /** The hint for an action that is needed now. Ignored when learned already (once) or already shown or waiting */
  show(id: string, text: string, opts?: HintShowOptions): void;
  /** The player did it: the hint goes (or never comes), is marked learned and saved, and the next one in the queue shows */
  done(id: string): void;
  /** Learned already (in `seen`) */
  seen(id: string): boolean;
  /** The hint on screen now, or null */
  readonly current: string | null;
  /** Hide everything and forget the queue (a screen change: results, the title); learned stays learned */
  clear(): void;
  destroy(): void;
}

const CSS = `
:where(#gp-hint) { --gp-hint-bg: var(--gp-theme-bg, rgba(12, 18, 28, 0.82)); --gp-hint-ink: var(--gp-theme-ink, #ffffff); --gp-hint-radius: 999px;
  --gp-hint-font: 700 18px var(--gp-theme-font, ${FONT_FALLBACK}); }
#gp-hint { position: fixed; left: 50%; transform: translate(-50%, 8px); z-index: 30; pointer-events: none; max-width: min(88vw, 520px);
  box-sizing: border-box; padding: 10px 20px; border-radius: var(--gp-hint-radius); background: var(--gp-hint-bg); color: var(--gp-hint-ink);
  font: var(--gp-hint-font); text-align: center; line-height: 1.25; opacity: 0; transition: opacity 0.25s ease, transform 0.25s ease; }
#gp-hint[data-pos=bottom] { bottom: calc(env(safe-area-inset-bottom, 0px) + 14%); }
#gp-hint[data-pos=top] { top: var(--gp-hints-top, calc(env(safe-area-inset-top, 0px) + 12%)); }
#gp-hint[data-pos=center] { top: var(--gp-hints-top, 50%); }
#gp-hint.gp-on { opacity: 1; transform: translate(-50%, 0); }
@media (prefers-reduced-motion: reduce) { #gp-hint { transition: none; } }
`;

/** A visible modal of the platform's or any [aria-modal=true] / <dialog open> */
function modalOpen(): boolean {
  for (const el of document.querySelectorAll<HTMLElement>('[data-gp=dialog], [data-gp=lang-sheet], #gp-shop, #gp-welcome, [aria-modal=true], dialog[open]')) {
    const r = el.getBoundingClientRect();
    if (r.width > 0 && r.height > 0 && getComputedStyle(el).visibility !== 'hidden') return true;
  }
  return false;
}

const words = (t: string) => (t.match(/[\p{L}\p{N}']+/gu) ?? []).length;

export function hints(opts: HintsOptions = {}): Hints {
  const once = opts.once ?? true;
  const queued = opts.queue ?? true;
  const guard = opts.neverOverModal ?? true;
  const isModal = opts.isModal ?? modalOpen;
  const seen = opts.seen ?? [];
  if (!document.getElementById('gp-hint-css')) {
    const style = document.createElement('style');
    style.id = 'gp-hint-css';
    style.textContent = CSS;
    document.head.append(style);
  }
  const el = document.createElement('div');
  el.id = 'gp-hint';
  el.dataset.gp = 'hint';
  el.dataset.pos = opts.position ?? (opts.top !== undefined ? 'top' : 'bottom');
  if (opts.top !== undefined) el.style.setProperty('--gp-hints-top', typeof opts.top === 'number' ? `${opts.top}px` : opts.top);
  el.setAttribute('role', 'status');
  el.setAttribute('aria-live', 'polite');
  el.hidden = true;
  (opts.root ?? document.body).append(el);

  type Hint = { id: string; text: string; minMs: number; readMs: number; since: number | null; hand?: CoachHandOptions };
  let hand: { id: string; ui: CoachHand } | null = null;
  let current: Hint | null = null;
  const waiting: Hint[] = [];
  const delayed = new Map<string, ReturnType<typeof setTimeout>>();
  let watch: ReturnType<typeof setInterval> | null = null;
  let hideTimer: ReturnType<typeof setTimeout> | null = null;
  let swapTimer: ReturnType<typeof setTimeout> | null = null;
  /** How long the hint on screen has been readable: visible, not behind a modal */
  const shownMs = (h: Hint) => h.readMs + (h.since === null ? 0 : performance.now() - h.since);

  const render = () => {
    const blocked = guard && isModal();
    // Without a queue the latest waiting hint takes the place of the one on screen, once that one has been read
    if (!queued && current && waiting.length && shownMs(current) >= current.minMs) current = waiting.shift()!;
    const on = !!current && !blocked;
    if (current) {
      if (on && current.since === null) current.since = performance.now();
      if (!on && current.since !== null) {
        current.readMs += performance.now() - current.since;
        current.since = null;
      }
    }
    if (swapTimer) clearTimeout(swapTimer);
    swapTimer = null;
    if (!queued && current && waiting.length && on) swapTimer = setTimeout(render, Math.max(0, current.minMs - shownMs(current)) + 1);
    if (current) {
      if (el.dataset.hint !== current.id || el.textContent !== current.text) {
        el.textContent = current.text;
        el.dataset.hint = current.id;
      }
      if (hideTimer) clearTimeout(hideTimer);
      hideTimer = null;
      if (el.hidden) {
        el.hidden = false;
        // Lay it out before the class changes, so it fades in (no requestAnimationFrame: still screens stay still)
        void el.offsetWidth;
      }
      el.classList.toggle('gp-on', on);
      // The hint's hand: on screen with it, hidden behind a modal, gone with it
      if (current.hand && on) {
        // A new hint, or its hand's layer gone with the page the game replaced: a hand of its own
        if (hand?.id !== current.id || !hand.ui.el.isConnected) {
          hand?.ui.destroy();
          hand = { id: current.id, ui: coachHand({ root: opts.root, ...current.hand }) };
        } else if (!hand.ui.visible) hand.ui.show();
      } else if (hand && (hand.id !== current.id || !on)) {
        if (hand.id !== current.id) (hand.ui.destroy(), (hand = null));
        else hand.ui.hide();
      }
    } else {
      hand?.ui.destroy();
      hand = null;
      el.classList.remove('gp-on');
      if (!hideTimer)
        hideTimer = setTimeout(() => {
          hideTimer = null;
          if (!current) el.hidden = true;
        }, 300);
    }
    // While something is up, look for a modal four times a second (a dialogue that opens over the hint)
    const need = guard && (!!current || waiting.length > 0);
    if (need && !watch) watch = setInterval(render, 250);
    if (!need && watch) {
      clearInterval(watch);
      watch = null;
    }
  };

  const next = () => {
    current = waiting.shift() ?? null;
    render();
  };

  const api: Hints = {
    show(id, text, o = {}) {
      if ((once && seen.includes(id)) || current?.id === id || waiting.some((w) => w.id === id) || delayed.has(id)) return;
      if (import.meta.env.DEV && words(text) > HINT_MAX_WORDS) console.warn(`[hints] "${id}" has ${words(text)} words: keep a hint to ${HINT_MAX_WORDS} or fewer — show the rule, don't write it (docs/guides/first-minute.md)`);
      const go = () => {
        delayed.delete(id);
        if (once && seen.includes(id)) return;
        const h: Hint = { id, text, minMs: (o.minSec ?? readingSec(text)) * 1000, readMs: 0, since: null, hand: o.hand };
        if (!current) current = h;
        // Never cut short: it waits its turn (in order, or as the one that replaces the current hint once it is read)
        else if (queued) waiting.push(h);
        else waiting.splice(0, waiting.length, h);
        render();
      };
      if (o.after && o.after > 0) delayed.set(id, setTimeout(go, o.after));
      else go();
    },
    done(id) {
      const t = delayed.get(id);
      if (t) clearTimeout(t);
      delayed.delete(id);
      const i = waiting.findIndex((w) => w.id === id);
      if (i >= 0) waiting.splice(i, 1);
      if (once && !seen.includes(id)) {
        seen.push(id);
        opts.onSeen?.(seen);
      }
      if (current?.id === id) next();
      else render();
    },
    seen: (id) => seen.includes(id),
    get current() {
      return current && !(guard && isModal()) ? current.id : null;
    },
    clear() {
      if (swapTimer) clearTimeout(swapTimer);
      swapTimer = null;
      for (const t of delayed.values()) clearTimeout(t);
      delayed.clear();
      waiting.length = 0;
      current = null;
      render();
    },
    destroy() {
      api.clear();
      if (watch) clearInterval(watch);
      watch = null;
      el.remove();
    },
  };
  return api;
}
