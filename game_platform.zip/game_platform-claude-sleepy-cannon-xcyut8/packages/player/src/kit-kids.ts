// The kids kit's save fields and flow. kits.ts imports this module only when the game's kit is `kids` (GP_KIT, fixed at
// build time), so a casual or code game's bundle doesn't carry the kids kit.

import type { TapCollectConfig } from '@gp/blocks';
import { createKidsFlow, KIDS_SAVE_DEFAULTS, type KidsConfig } from '@gp/kit-kids';
import { KIDS_NUMBER_WORDS, KIDS_STRINGS, type KidsStrings } from '@gp/kit-kids/meta';
import type { BlockKit } from './kits.ts';

export const kit: BlockKit = {
  save: KIDS_SAVE_DEFAULTS,
  flow: (app, game, theme) => createKidsFlow(app, theme, game.kit as KidsConfig, game.round as TapCollectConfig),
  strings: KIDS_STRINGS,
  own: (game) => ({ ...(game.kit as KidsConfig).strings }),
  // The grown-ups' texts (the parent gate and settings) in the device's language; praise and content stay in `locale`
  translate(game, i18n) {
    const k = game.kit as KidsConfig;
    k.strings = Object.fromEntries(Object.keys(k.strings).map((key) => [key, i18n.t(key)])) as KidsStrings;
    if (i18n.lang !== 'en') k.numberWords = [...(KIDS_NUMBER_WORDS[i18n.lang] ?? k.numberWords)];
  },
};
