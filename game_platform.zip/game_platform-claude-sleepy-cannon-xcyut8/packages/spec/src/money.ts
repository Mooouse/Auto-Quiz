// Money: the path from a game to revenue, per channel, as data + pure code. `gp forecast` (idea and game), the money
// checks of `gp validate`, the forecast line of `gp qa` and forecast.md of `gp submission` all come from here.
//
// The model (docs/guides/game-design.md → Design for money; the inputs: docs/research/revenue-2026-09.md §7):
//   CrazyGames:  QA review (P = the pass rate × a factor from `gp uniqueness`) → Basic Launch (7–21 days, ads off, no
//                revenue; P(Full Launch) from the design against the metric gates) → Full Launch:
//                revenue/day = plays/day × share of gross × (midgame per play × fill × eCPM + rewarded per play × fill × eCPM) / 1000
//                midgame per play: the natural breaks, evenly spaced on the session's clock, run through the channel's ad
//                policy (profiles.ts, the same shouldShowAd the runtime uses: the first at round 3 or 5 min, then ≤ 1 per
//                3 min) and capped by what games achieve per player-hour;
//                rewarded per play: Σ offers × take rate per placement, capped per player-hour;
//                both together ≤ 20 per player-hour (rewarded counted in: midgame gets what rewarded leaves).
//   Google Play Families: review → organic installs; DAU × interstitials (the Families policy, capped per DAU) × eCPM,
//                + installs × "Remove ads" buy rate × price × store share. No rewarded ads for children, ever.
//   web, android (general): no ad provider in the platform yet → no revenue; the forecast says so.
// Every input is a low / mid / high range in ONE table (MONEY_TABLE) with its source, confidence and date: change the
// numbers there, nowhere else. Pessimistic takes every input at its worse end, optimistic at its better end: the true
// range is narrower than that. Recorded results (publisher/results.yaml, results.ts) narrow it once there are enough.

import { shouldShowAd, type AdPolicy } from '@gp/core/ads-policy';
import { AUDIENCES, CHANNELS } from './profiles.ts';
import { conceptText, takenConceptsFor } from './taken.ts';

export const MONEY_CHECKED = '2026-09-30';

/**
 * The research note's scale (docs/research/revenue-2026-09.md §7): high — the platform's own docs or terms · medium —
 * derived from primary numbers or several sources · low — secondary sources, vendor data, one anecdote · very low —
 * a placeholder with almost nothing behind it · judgement — the team's rule, no source (replace with our own results)
 */
export type Confidence = 'high' | 'medium' | 'low' | 'very low' | 'judgement';

export interface MoneyRow {
  what: string;
  unit: string;
  low: number;
  mid: number;
  high: number;
  /** Which end is good for the game: pessimistic takes the other one */
  better: 'high' | 'low';
  source: string;
  confidence: Confidence;
  checked: string;
}

export const GENRES = ['puzzle', 'idle', 'action', 'shooting', 'strategy', 'io', 'driving', 'hypercasual', 'kids', 'other'] as const;
export type Genre = (typeof GENRES)[number];
/**
 * Sub-genres a game may name instead (money.genre, `gp forecast --idea --genre`): each one benchmarks as its money genre
 * (the rows above have no numbers of their own for them). What their players expect is in genres.ts (SUBGENRE_INFO).
 */
export const SUBGENRES = {
  roguelite: 'action',
  survivors: 'action',
  platformer: 'action',
  'tower-defense': 'strategy',
  deckbuilder: 'strategy',
  clicker: 'idle',
  incremental: 'idle',
  tycoon: 'idle',
  merge: 'idle',
} as const satisfies Record<string, Genre>;
export type SubGenre = keyof typeof SUBGENRES;
/** The money genre of a genre or sub-genre id ("roguelite" → action); null for anything else */
export function moneyGenre(id: string | undefined | null): Genre | null {
  if (!id) return null;
  if ((GENRES as readonly string[]).includes(id)) return id as Genre;
  return (SUBGENRES as Record<string, Genre>)[id] ?? null;
}
/** Every id money.genre takes: the genres, then the sub-genres */
export const GENRE_IDS: readonly string[] = [...GENRES, ...Object.keys(SUBGENRES)];
export const REWARDED_KINDS = ['revive', 'continue', 'x2', 'reroll', 'trial', 'hint', 'undo', 'boost', 'restock', 'spin', 'currency', 'other'] as const;
export type RewardedKind = (typeof REWARDED_KINDS)[number];
export const RETURN_KINDS = ['daily', 'meta', 'story', 'social', 'none'] as const;
export type ReturnKind = (typeof RETURN_KINDS)[number];

const REV = 'revenue-2026-09.md';
const CG = 'crazygames-requirements-2026-09.md';
const row = (what: string, unit: string, [low, mid, high]: [number, number, number], better: 'high' | 'low', source: string, confidence: Confidence, checked = MONEY_CHECKED): MoneyRow => ({
  what,
  unit,
  low,
  mid,
  high,
  better,
  source,
  confidence,
  checked,
});
/** A genre's average play per session on CrazyGames: mid = the portal's genre average, low/high = ×0.5 / ×1.3 (a new game spreads around it) */
const genreMin = (avg: number, source: string, confidence: Confidence) => row('average play per session', 'min', [Math.round(avg * 5) / 10, avg, Math.round(avg * 13) / 10], 'high', source, confidence);
const GENRE_SRC = `${REV} §5 (CrazyGames' monetization guides); low/high ×0.5 / ×1.3: judgement`;

/**
 * THE table: every number the model uses (sources: docs/research/, file names below). Replace a row when research or
 * our own results bring a better number, keep the id; `gp forecast` prints the rows it used with their confidence.
 * Money is in EUR; rows in USD are converted with `fx.usdEur`.
 */
export const MONEY_TABLE: Record<string, MoneyRow> = {
  'fx.usdEur': row('EUR per USD', 'EUR', [0.86, 0.86, 0.86], 'high', 'ECB reference rate, 2026 (≈ 1.16 USD per EUR) — re-check', 'medium'),
  // --- CrazyGames: the path
  'cg.review.days': row('first QA review', 'days', [1, 2, 3], 'low', `${REV} §1.6: review ≈ 2 days; ${CG} §11: "1 to 2 days", "0-3 days"`, 'medium'),
  'cg.review.pass': row('P(a typical first submission passes the QA review)', 'probability', [0.1, 0.4, 0.7], 'high', `${REV} §7: NOT FOUND ("90–99% rejected" claims have no method); Petri Panic rejected for originality`, 'very low'),
  'cg.original.85': row('× P(review): gp uniqueness 85+', 'factor', [1.5, 1.5, 1.5], 'high', 'docs/guides/uniqueness.md', 'judgement'),
  'cg.original.70': row('× P(review): gp uniqueness 70–84 (passes gp submission)', 'factor', [1.2, 1.2, 1.2], 'high', 'docs/guides/uniqueness.md', 'judgement'),
  'cg.original.50': row('× P(review): gp uniqueness 50–69 ("risky")', 'factor', [0.6, 0.6, 0.6], 'high', 'docs/guides/uniqueness.md', 'judgement'),
  'cg.original.0': row('× P(review): gp uniqueness under 50, or a gate ("too close")', 'factor', [0.15, 0.15, 0.15], 'high', 'Petri Panic: a live genre + theme match, rejected (publisher/results.yaml)', 'judgement'),
  'cg.original.unknown': row('× P(review): no concept scored yet', 'factor', [1, 1, 1], 'high', 'a typical submission', 'judgement'),
  // A game the portal has judged before, submitted again: P(approval) is at most this (gp forecast reads the history in
  // publisher/results.yaml; calibrate() pulls these toward the recorded resubmissions from 3 of a kind)
  'cg.resubmit.afterStop': row('P(approval) at most, a resubmission after a Basic Launch stop', 'probability', [0.05, 0.25, 0.45], 'high', 'publisher/results.yaml: 1 of 4 approved (Hang the Moon 2026-10-11; Spin Brawl, Starsilk, Candle Crypt rejected 2026-10-11/12 — all four approved the first time); the ends judgement (n = 4)', 'low'),
  'cg.resubmit.afterReject': row('P(approval) at most, a resubmission (or a remake under a new name) after a rejection', 'probability', [0.02, 0.12, 0.3], 'high', 'publisher/results.yaml: no same-id resubmission after a rejection recorded; both remakes of rejected games were rejected (Gnome Sort, Firefly Rush); judgement', 'very low'),
  'cg.basic.days': row('Basic Launch (ads off, no revenue)', 'days', [7, 14, 21], 'low', `${REV} §1.5: ends after ≥ 7 days and ≥ 500 plays, or after 21 days`, 'high'),
  'cg.full.days': row('Full Implementation update + second QA review, until Full Launch', 'days', [2, 5, 10], 'low', `${REV} §1.6: "a few days"; submission to Full Launch ≈ 3–4 weeks (Liquid Swarm: 22 days)`, 'medium'),
  'cg.full.meetAll': row('P(all three Basic Launch metrics at benchmark | approved), a design that meets the gates on paper', 'probability', [0.15, 0.3, 0.45], 'high', `${REV} §1.6: the benchmark is ≈ top 20–30% of games; the rate NOT FOUND`, 'judgement'),
  'cg.full.ifAll': row('P(Full Launch | all metrics at benchmark)', 'probability', [0.5, 0.75, 0.9], 'high', `${REV} §7`, 'judgement'),
  'cg.full.someShare': row('share of the rest with some metrics at benchmark', 'share', [0.5, 0.5, 0.5], 'high', 'the team\'s rule', 'judgement'),
  'cg.full.ifSome': row('P(Full Launch | some metrics at benchmark) — a retry', 'probability', [0, 0.1, 0.3], 'high', `${REV} §7`, 'judgement'),
  'cg.full.gateMin': row('Basic Launch playtime benchmark', 'min', [10, 10, 10], 'high', `${REV} §1.6: top titles play 10+ min`, 'high'),
  'cg.full.returnNone': row('× P(metrics at benchmark): no reason to come back tomorrow (D1 10–15% for strong games)', 'factor', [0.65, 0.75, 0.85], 'high', `${REV} §6.4`, 'judgement'),
  'cg.full.returnDaily': row('× P(metrics at benchmark): a daily reason (seed, case, calendar)', 'factor', [1.05, 1.15, 1.25], 'high', 'marketer.md (LinkedIn Games: 84% next-day return); forums-2026-09.md §3 (Clues by Sam)', 'judgement'),
  'cg.full.metaShort': row('× P(metrics at benchmark): the meta is done within the first session', 'factor', [0.6, 0.7, 0.8], 'high', 'docs/guides/upgrades.md (meta 10+ min)', 'judgement'),
  'cg.full.metaUnknown': row('× P(metrics at benchmark): meta length unknown (no balance() report, no money.meta)', 'factor', [0.8, 0.85, 0.9], 'high', 'the team\'s rule', 'judgement'),
  // Load time: "into fun in under 10 s" (Defold, forums-2026-09.md); Liquid Swarm lost ≈ a third of its revenue (+5% bounce)
  // to heavier tech on low-end devices; the engine lab: 0.4 s (Canvas 2D) to 7.9 s (Rapier) to a tappable Play on a
  // slow phone. Full above cg.load.slowSec, none up to the channel's warnLoadSec (CrazyGames 3 s), linear between.
  'cg.full.slowLoad': row('× P(metrics at benchmark): 10 s+ to a tappable Play on a slow phone (1.6 Mbps, 4× CPU; gp build\'s estimate)', 'factor', [0.6, 0.75, 0.9], 'high', 'forums-2026-09.md: "into fun in under 10 s" (Defold), Liquid Swarm: WebGL2 on low-end devices −⅓ revenue; engine lab (QmaCyber/game12): 0.4–7.9 s', 'judgement'),
  'cg.load.slowSec': row('seconds to a tappable Play at which the slow-load factor applies in full', 's', [10, 10, 10], 'low', 'forums-2026-09.md: players decide in the first 10 s (Poki, Defold)', 'low'),
  'cg.full.big': row('× P(metrics at benchmark): upload over 20 MB (not on the mobile homepage, slower load)', 'factor', [0.7, 0.8, 0.9], 'high', `${REV} §6.5; ${CG} §2: top titles "below 20 MB", load "under 10 seconds"`, 'judgement'),
  'cg.platform.d1': row('platform average D1 retention', '%', [6.7, 6.7, 6.7], 'high', `${REV} §5`, 'high'),
  // --- CrazyGames: plays
  'cg.plays.week1': row('plays per day in the first Full Launch week (48 h on the homepage)', 'plays/day', [300, 1500, 10000], 'high', `${REV} §7: typical 300–1,500, good 5,000–25,000 (Puckit ≈ 23k peak), hit 100k+`, 'low'),
  'cg.plays.steady': row('plays per day in weeks 2–4 of Full Launch', 'plays/day', [150, 1000, 5000], 'high', `${REV} §7: typical 100–500, good 2,000–6,000 (Puckit ≈ 2.5k; Liquid Swarm ≈ 3–6k)`, 'low'),
  'cg.plays.decay': row('plays lost per month after that, no updates', 'share', [0.05, 0.2, 0.4], 'low', `${REV} §7: NOT FOUND (updates can grow a game: Liquid Swarm)`, 'very low'),
  // --- CrazyGames: money per play
  'cg.share': row('developer share of GROSS ad revenue', 'share', [0.45, 0.5, 0.6], 'high', `${REV} §1.1: 60% of net (2026 jam terms), net = gross − direct costs (20% in the 2021 terms) ≈ 48% of gross`, 'medium'),
  'cg.mobileShare': row('mobile share of plays (the eCPM blend)', 'share', [0.7, 0.7, 0.7], 'high', `${REV} §2.1: ≈ 70% of visits are mobile (Semrush, Aug 2026); of plays NOT FOUND`, 'medium'),
  'cg.midgame.ecpmDesktop': row('midgame eCPM, desktop, CrazyGames traffic blend (gross)', 'USD / 1000', [2, 5, 10], 'high', `${REV} §7`, 'low'),
  'cg.midgame.ecpmMobile': row('midgame eCPM, mobile web, CrazyGames traffic blend (gross)', 'USD / 1000', [1, 3, 7], 'high', `${REV} §7`, 'low'),
  'cg.rewarded.ecpm': row('rewarded eCPM, CrazyGames traffic blend (gross)', 'USD / 1000', [3, 8, 15], 'high', `${REV} §7: US $15–28, EU $8–15, tier-3 $1–3`, 'low'),
  'cg.midgame.fill': row('fill rate, midgame', 'share', [0.6, 0.8, 0.95], 'high', `${REV} §2.2: CrazyGames' own rate NOT FOUND`, 'low'),
  'cg.rewarded.fill': row('fill rate, rewarded', 'share', [0.3, 0.7, 0.95], 'high', `${REV} §2.2: ≤ 30% GAM web rewarded vs 95% AppLixir`, 'low'),
  'cg.midgame.perHour': row('midgame ads per player-hour achieved (a cap on the design\'s count)', 'ads/h', [5, 11, 20], 'high', `${REV} §2.4: top puzzle/clicker ≈ 11, word ≈ 21; allowed ≤ 20 (1 per 3 min)`, 'medium'),
  'cg.rewarded.maxPerHour': row('rewarded views per player-hour, at most', 'views/h', [12, 12, 12], 'high', `${REV} §2.4: top puzzle/word/clicker ≈ 11–12 (the high end of 1 · 5 · 12)`, 'medium'),
  // The research says "≤ 20 an hour, rewarded counted in" (§ key facts #2) but its own table (§2.4) has top puzzles at ≈ 25
  // impressions an hour in all (11 midgame + 12 rewarded) and word games at ≈ 34: the derived numbers are upper bounds
  // (top games' impressions over genre-average playtimes). The model takes the portal's rule, the stricter reading.
  'cg.ads.maxPerHour': row('midgame + rewarded per player-hour, at most (midgame gets what rewarded leaves)', 'ads/h', [20, 20, 20], 'high', `${REV} §1 #2: "≤ 20 an hour, rewarded counted in" (1 per 3 min); its §2.4 table has top puzzles ≈ 25 in all — see the comment`, 'medium'),
  'cg.check.per1000': row('developer revenue per 1,000 plays (a cross-check, not an input)', 'EUR', [1, 4.3, 12.9], 'high', `${REV} §7: €1 · $5 · $15; platform average ≈ $6.5–8 (derived)`, 'low'),
  // --- Rewarded: the share of offers a player takes, by what the offer gives (per offer shown)
  'rewarded.take.revive': row('rewarded revive (once per session — CrazyGames): offers taken', 'share', [0.3, 0.5, 0.7], 'high', `${REV} §6.3: revive among the best-converting placements, "once per session"`, 'judgement'),
  'rewarded.take.continue': row('rewarded continue (a revive: once per session): offers taken', 'share', [0.3, 0.5, 0.7], 'high', 'the same as revive', 'judgement'),
  'rewarded.take.x2': row('rewarded ×2 reward on the results: offers taken', 'share', [0.1, 0.2, 0.3], 'high', `${REV} §6.3 ("×2 loot")`, 'judgement'),
  'rewarded.take.reroll': row('rewarded reroll: offers taken', 'share', [0.05, 0.1, 0.2], 'high', 'the team\'s rule', 'judgement'),
  'rewarded.take.trial': row('rewarded trial (a locked thing for one run, once per session): offers taken', 'share', [0.1, 0.2, 0.3], 'high', `${REV} §6.3 ("try a locked item for one run")`, 'judgement'),
  'rewarded.take.hint': row('rewarded hint (a cooldown): offers taken', 'share', [0.1, 0.15, 0.25], 'high', `${REV} §5: top puzzles 4.2 rewarded per play, the hint the best placement`, 'judgement'),
  'rewarded.take.undo': row('rewarded undo / extra move on the fail screen: offers taken', 'share', [0.1, 0.15, 0.25], 'high', 'forums-2026-09.md §2 ("fail offer")', 'judgement'),
  'rewarded.take.boost': row('rewarded boost (welcome back ×2, a head start): offers taken', 'share', [0.05, 0.1, 0.2], 'high', `${REV} §6.3 ("welcome-back multipliers")`, 'judgement'),
  // A shop's "restock now" (restockShop, @gp/core/restock): Grow a Garden sells a forced restock (79 R$, fan wikis); on the
  // web it is a rewarded offer next to the countdown, once per cooldown (15 min by default) — a want, never a wait
  'rewarded.take.restock': row('rewarded "restock now" (a fresh shop stock, once per cooldown): offers taken', 'share', [0.05, 0.12, 0.2], 'high', 'roblox-2026-10.md P1 (Grow a Garden: a paid forced restock); the rate NOT FOUND — between reroll and x2', 'judgement'),
  'rewarded.take.spin': row('rewarded extra spin of a lucky wheel (once the free one is used, once a day): offers taken', 'share', [0.1, 0.2, 0.35], 'high', 'Craft Pickaxe Idle (game21) and the mining simulators: a second spin a day after the free one — the team\'s rule until results come in', 'judgement'),
  'rewarded.take.currency': row('rewarded currency (gems for an ad in the shop, a few a day): offers taken', 'share', [0.05, 0.12, 0.25], 'high', 'Idle Miner Tycoon\'s and Craft Pickaxe Idle\'s "+10 gems" — the team\'s rule until results come in', 'judgement'),
  'rewarded.take.other': row('another rewarded offer: offers taken', 'share', [0.05, 0.1, 0.15], 'high', 'the team\'s rule', 'judgement'),
  // --- Genres: average play per session (CrazyGames), D1, and how often a natural break comes by default
  'genre.puzzle.minutes': genreMin(21, GENRE_SRC, 'high'),
  'genre.idle.minutes': genreMin(15, GENRE_SRC, 'high'),
  'genre.action.minutes': genreMin(13, GENRE_SRC, 'high'),
  'genre.shooting.minutes': genreMin(12, GENRE_SRC, 'high'),
  'genre.strategy.minutes': genreMin(13, `${REV} §5: tower defense / roguelite NOT FOUND — the action average`, 'very low'),
  'genre.io.minutes': genreMin(9, GENRE_SRC, 'high'),
  'genre.driving.minutes': genreMin(8.7, GENRE_SRC, 'high'),
  'genre.hypercasual.minutes': genreMin(8.6, GENRE_SRC, 'high'),
  'genre.kids.minutes': row('a child\'s session on Google Play', 'min', [3, 6, 10], 'high', 'docs/guides/game-design.md (a stop every 30–60 s)', 'judgement'),
  'genre.other.minutes': genreMin(10, `between the genre averages (${REV} §5)`, 'judgement'),
  'genre.puzzle.d1': row('puzzle D1 retention', '%', [6.2, 6.2, 6.2], 'high', `${REV} §5`, 'high'),
  'genre.idle.d1': row('clicker / idle D1 retention', '%', [6.6, 6.6, 6.6], 'high', `${REV} §5`, 'high'),
  'genre.action.d1': row('action D1 retention', '%', [8.1, 8.1, 8.1], 'high', `${REV} §5`, 'high'),
  'genre.shooting.d1': row('shooting D1 retention', '%', [6.5, 6.5, 6.5], 'high', `${REV} §5`, 'high'),
  'genre.strategy.d1': row('strategy / tower defense D1 retention', '%', [6.7, 6.7, 6.7], 'high', `${REV} §5: NOT FOUND — the platform average`, 'very low'),
  'genre.io.d1': row('.io D1 retention', '%', [5.7, 5.7, 5.7], 'high', `${REV} §5`, 'high'),
  'genre.driving.d1': row('driving D1 retention', '%', [5.7, 5.7, 5.7], 'high', `${REV} §5`, 'high'),
  'genre.hypercasual.d1': row('hypercasual D1 retention', '%', [6, 6, 6], 'high', `${REV} §5`, 'high'),
  'genre.kids.d1': row('kids D1 retention (unused: Google Play has no Basic Launch)', '%', [6.7, 6.7, 6.7], 'high', 'unused', 'judgement'),
  'genre.other.d1': row('D1 retention, genre unknown', '%', [6.7, 6.7, 6.7], 'high', `platform average (${REV} §5)`, 'high'),
  'genre.puzzle.breakEvery': row('a level ends every (the default when the game doesn\'t say)', 'min', [2.5, 2.5, 2.5], 'low', 'the team\'s rule', 'judgement'),
  'genre.idle.breakEvery': row('a day / season / prestige ends every', 'min', [5, 5, 5], 'low', 'the team\'s rule', 'judgement'),
  'genre.action.breakEvery': row('a run or stage ends every', 'min', [4, 4, 4], 'low', 'the team\'s rule', 'judgement'),
  'genre.shooting.breakEvery': row('a run or stage ends every', 'min', [4, 4, 4], 'low', 'the team\'s rule', 'judgement'),
  'genre.strategy.breakEvery': row('a wave set or stage ends every', 'min', [5, 5, 5], 'low', 'the team\'s rule', 'judgement'),
  'genre.io.breakEvery': row('a death / round ends every', 'min', [3, 3, 3], 'low', 'the team\'s rule', 'judgement'),
  'genre.driving.breakEvery': row('a race ends every', 'min', [2.5, 2.5, 2.5], 'low', 'the team\'s rule', 'judgement'),
  'genre.hypercasual.breakEvery': row('a round ends every', 'min', [1, 1, 1], 'low', 'the casual kit: 45-s rounds + the score screen', 'medium'),
  'genre.kids.breakEvery': row('a round ends every', 'min', [0.75, 0.75, 0.75], 'low', 'balloon-pop: 15 pops ≈ 45 s', 'medium'),
  'genre.other.breakEvery': row('a run ends every', 'min', [4, 4, 4], 'low', 'the team\'s rule', 'judgement'),
  // --- Google Play Families (AdMob, child-directed)
  'gp.review.days': row('Google Play review', 'days', [2, 4, 7], 'low', 'Google: "up to 7 days", longer for new developer accounts', 'medium'),
  'gp.review.pass': row('P(approved for Families), all platform checks green', 'probability', [0.6, 0.8, 0.9], 'high', 'forums-2026-09.md §5 (AD_ID, SDKs, ads not closable — the platform checks them)', 'judgement'),
  'gp.installs.perMonth': row('new-app installs per month, no marketing', 'installs/month', [10, 100, 1500], 'high', `${REV} §4.2: 63% of listings < 1,000 lifetime installs; kids NOT FOUND`, 'low'),
  'gp.installs.month2': row('installs in month 2, × month 1', 'factor', [0.8, 1, 1.3], 'high', 'the team\'s rule', 'judgement'),
  'gp.installs.month3': row('installs in month 3, × month 1', 'factor', [0.7, 1, 1.5], 'high', 'the team\'s rule', 'judgement'),
  'gp.activeDays': row('days an install plays in its first month', 'days', [1.5, 3, 6], 'high', 'marketer.md §5: D1 ≥ 25% target', 'very low'),
  'gp.sessionsPerDay': row('sessions per active child per day', 'sessions', [1, 1.3, 1.8], 'high', 'the team\'s rule', 'very low'),
  'gp.adsPerDau': row('interstitials per active child per day, achieved (a cap on the design\'s count)', 'ads/day', [1, 2.5, 4], 'high', `${REV} §7 (the Families rules, natural breaks)`, 'low'),
  'gp.ecpm': row('Families interstitial eCPM, global blend', 'USD / 1000', [0.8, 2, 4], 'high', `${REV} §4.1: US $4–8, COPPA 2.5–5× below general`, 'low'),
  'gp.share': row('developer share of AdMob revenue (AdMob reports the publisher\'s earnings)', 'share', [1, 1, 1], 'high', 'AdMob reports', 'medium'),
  'gp.check.arpdau': row('kids ARPDAU from ads (a cross-check, not an input)', 'USD', [0.001, 0.005, 0.03], 'high', `${REV} §7`, 'low'),
  'gp.iap.buyRate': row('installs whose grown-up buys "Remove ads"', 'share', [0.0005, 0.003, 0.015], 'high', `${REV} §4.3: SHREDD 0.02% of downloads (2015); all-IAP payers 1.5–3.5%; kids NOT FOUND`, 'very low'),
  'gp.iap.price': row('"Remove ads" price when money.removeAdsPrice is not set', 'EUR', [1.99, 2.99, 3.99], 'high', 'the team\'s rule', 'judgement'),
  'gp.iap.share': row('developer share of a Google Play purchase', 'share', [0.85, 0.85, 0.85], 'high', `${REV} §7.1: Google's fee is 15% on the first $1M a year`, 'high'),
};

// --- The design the model reads -----------------------------------------------------------------------------------

export interface RewardedPlacement {
  placement: string;
  kind: RewardedKind;
  /** How often it can be offered: once per run or level (at every break and at the session's end), or once a session */
  per: 'run' | 'level' | 'session';
}

/** What a roll of a loot table costs the player (money.loot[].cost): only earned or free rolls are allowed for money's sake */
export const LOOT_COSTS = ['earned', 'free', 'ad', 'purchase', 'bought'] as const;
export type LootCost = (typeof LOOT_COSTS)[number];

/** The `money` section of game.yaml, as written */
export interface MoneyInput {
  genre?: string;
  /** The genres of a second layer the game has (an idle base under an action raid: [idle]): their blocks fit too (W_GENRE_BLOCK) */
  hybrid?: string[];
  /** The game's random rolls (LootTable sources): what each costs and where its odds are shown (E_PAID_RANDOM, W_LOOT_ODDS) */
  loot?: { id: string; cost: LootCost; odds?: string }[];
  session?: { minutes?: number; breaks?: number; breaksAt?: string };
  rewarded?: { placement: string; kind: RewardedKind; gives: string; per?: 'run' | 'level' | 'session' }[];
  meta?: { minutes?: number };
  returns?: { kind: ReturnKind; what?: string };
  removeAdsPrice?: number;
}

export interface MoneyDesign {
  channel: string;
  audience: string;
  kit: string;
  genre: Genre;
  /** Target minutes per session */
  sessionMin: number;
  /** Natural breaks inside a session (where a midgame ad can go) */
  breaks: number;
  rewarded: RewardedPlacement[];
  /** Minutes of play until the progression is done; null: unknown */
  metaMin: number | null;
  returns: ReturnKind;
  /** The "Remove ads" purchase, when the game has one */
  removeAds: { price: number } | null;
  adsOn: boolean;
  rewardedOn: boolean;
  uploadMB: number | null;
  /** The upload gzipped (KB) and the estimated seconds to a tappable Play on a slow phone (gp build → upload/size.json) */
  uploadGzipKB: number | null;
  loadSec: number | null;
  /** The portal's originality odds come from this (gp uniqueness, or an estimate in idea mode) */
  uniqueness: { score: number; gate: string | null; from: string } | null;
  /**
   * The portal judged this game before and it goes in again (gp forecast reads publisher/results.yaml, or --resubmission):
   * after a Basic Launch stop or after a rejection. P(approval) is capped by the history (cg.resubmit.*)
   */
  resubmission?: Resubmission | null;
  /** Where each value came from, for the report */
  from: Record<string, string>;
}

export type Range = { low: number; mid: number; high: number };

/** A game the portal judged before, submitted again: after its Basic Launch was stopped, or after a rejection */
export const RESUBMISSIONS = ['after-stop', 'after-rejection'] as const;
export type Resubmission = (typeof RESUBMISSIONS)[number];
/** Its row in MONEY_TABLE */
export const RESUBMISSION_ROW: Record<Resubmission, string> = { 'after-stop': 'cg.resubmit.afterStop', 'after-rejection': 'cg.resubmit.afterReject' };
export type Scenario = 'pessimistic' | 'median' | 'optimistic';
export const SCENARIOS: readonly Scenario[] = ['pessimistic', 'median', 'optimistic'];

const clamp = (x: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, x));

/** × P(metrics at benchmark) for the load time: 1 up to okSec, `full` from slowSec on, linear between; 1 when unknown */
export function loadFactor(loadSec: number | null, okSec: number, slowSec: number, full: number): number {
  if (loadSec === null || loadSec <= okSec) return 1;
  return 1 - (1 - full) * clamp((loadSec - okSec) / Math.max(0.001, slowSec - okSec), 0, 1);
}

/** The kind of a rewarded placement from its id ("rise-again" → revive, "double" → x2) */
export function rewardedKindOf(placement: string): RewardedKind {
  // Words, not substrings: "retry" is not a trial, "surprise-box" not a revive. A word may carry a plural or a
  // verb ending (hints, revived, doubling); the boost's welcome / offline come first ("welcome-back" is not an undo)
  const p = placement.toLowerCase().replace(/[_\s]+/g, '-');
  const w = (words: string) => new RegExp(`(^|[^a-z0-9])(${words})(s|es|d|ed|ing)?($|[^a-z0-9])`).test(p);
  if (w('welcome|welcome-?back|offline|offline-?back|come-?back|boost|head-?start|power-?up|power|buff')) return 'boost';
  if (w('spin|wheel|lucky-?wheel|fortune|extra-?spin')) return 'spin';
  if (w('revive|reviv|rise|rise-?again|second-?chance|resurrect|extra-?life|respawn|one-?more-?life')) return 'revive';
  if (w('continue|keep-?going|resume|retry|try-?again|play-?on')) return 'continue';
  if (w('double|x2|triple|x3|multiply|multiplier|bonus-?coins|more-?gems')) return 'x2';
  if (w('restock|re-?stock|new-?stock|restock-?now|refresh-?shop|refresh-?stock')) return 'restock';
  if (w('reroll|re-?roll|shuffle|refresh')) return 'reroll';
  if (w('trial|try|try-?it|test-?drive|unlock-?once')) return 'trial';
  if (w('hint|clue|solve|reveal|peek')) return 'hint';
  if (w('undo|rewind|step-?back|go-?back|back|extra-?move|extra-?moves|moves')) return 'undo';
  if (w('gem|coin|cash|currency|free-?currency|diamond|gold|crystal|bucks')) return 'currency';
  return 'other';
}

/** The genre for the benchmarks, from listing tags and the kit (the first tag that names a genre) */
export function genreOf(kit: string, audience: string, tags: readonly string[] = []): { genre: Genre; from: string } {
  if (AUDIENCES[audience]?.child || kit === 'kids') return { genre: 'kids', from: 'the audience' };
  const map: [RegExp, Genre][] = [
    [/^(puzzle|logic|physics puzzle|sort|match|word|jigsaw|maze|brain)/i, 'puzzle'],
    [/^(idle|clicker|incremental|tycoon|merge)/i, 'idle'],
    [/^(shoot|shooter|fps|gun)/i, 'shooting'],
    [/^(tower defen[cs]e|strategy|td|defen[cs]e|card|deck)/i, 'strategy'],
    [/^(\.?io|multiplayer)$/i, 'io'],
    [/^(driving|racing|car)/i, 'driving'],
    [/^(action|roguelike|roguelite|adventure|platformer|survival|fighting|arcade action)/i, 'action'],
    [/^(hypercasual|casual|arcade|clicking)$/i, 'hypercasual'],
  ];
  for (const t of tags) for (const [re, g] of map) if (re.test(t.trim())) return { genre: g, from: `listing.tags "${t}"` };
  if (kit === 'casual') return { genre: 'hypercasual', from: 'kit casual (a score round)' };
  return { genre: 'other', from: 'no tag names a genre' };
}

// --- The model ----------------------------------------------------------------------------------------------------

/** What recorded results change (calibrate() in results.ts): probabilities and volumes pulled toward the outcomes */
export interface Calibration {
  approval?: (p: Range) => Range;
  fullLaunch?: (p: Range) => Range;
  plays?: (r: Range) => Range;
  perPlayScale?: Range;
  /** The cap on P(approval) for a resubmission, pulled toward the recorded resubmissions (from 3 of a kind) */
  resubmission?: Partial<Record<Resubmission, Range>>;
  notes: string[];
}

export interface Stage {
  name: string;
  days: Range | null;
  p: Range | null;
  revenue: boolean;
  note: string;
}

export interface Forecast {
  channel: string;
  earns: boolean;
  /** Why it can't earn (the channel has no ads, ads are off) */
  why: string | null;
  stages: Stage[];
  pApproval: Range;
  pFullLaunch: Range;
  /** Days from submission until revenue starts */
  revenueFromDay: Range;
  /** Per play (portal) or per active child per day (Google Play) */
  unit: { name: string; midgame: Range; rewarded: Range; eur: Range };
  /** plays/day (portal) or installs/day (Google Play) in the first revenue month */
  volume: { name: string; range: Range };
  /** Revenue per month in months 1–3 after submission, if it reaches the revenue stage */
  months: Record<Scenario, [number, number, number]>;
  total: Record<Scenario, number>;
  /** CrazyGames: revenue in a steady 30-day month on Full Launch (after the homepage week, before the monthly decline) — the
   * plain answer to "what does it earn if it gets there"; pessimistic / median / optimistic as low / mid / high */
  perMonth?: Range;
  /** Probability-weighted: P(approval) × P(Full Launch) × revenue, months 1–3 (low: the pessimistic end of all three) */
  expected: Range;
  /** Row ids the numbers came from */
  used: string[];
  notes: string[];
}

interface Ctx {
  sc: Scenario;
  used: Set<string>;
  v(id: string): number;
}

function ctxFor(sc: Scenario, used: Set<string>): Ctx {
  return {
    sc,
    used,
    v(id: string) {
      const r = MONEY_TABLE[id];
      if (!r) throw new Error(`money: no row ${id}`);
      used.add(id);
      if (sc === 'median') return r.mid;
      const good = r.better === 'high' ? r.high : r.low;
      const bad = r.better === 'high' ? r.low : r.high;
      return sc === 'optimistic' ? good : bad;
    },
  };
}

/** A row as a range (low = its low number, whichever end is good) */
const rowRange = (id: string, used: Set<string>): Range => {
  used.add(id);
  const r = MONEY_TABLE[id];
  return { low: r.low, mid: r.mid, high: r.high };
};
const at = (r: Range, sc: Scenario) => (sc === 'pessimistic' ? r.low : sc === 'optimistic' ? r.high : r.mid);

/**
 * Midgame ads a session lets through: the breaks, evenly spaced, run through the channel's ad policy (the runtime rule)
 * on the session's clock — the session starts at 0 s and each break comes at its time, so the policy's time rules
 * (noAdsAfterLaunchSec, firstAdAfterSec, minIntervalSec) apply as they do at runtime.
 */
export function midgameAds(policy: AdPolicy, sessionMin: number, breaks: number): number {
  if (!(breaks > 0) || !(sessionMin > 0) || !Number.isFinite(breaks) || !Number.isFinite(sessionMin)) return 0;
  const every = (sessionMin * 60) / (breaks + 1);
  if (!(every > 0)) return 0;
  const s = { sessionStartSec: 0, roundsThisSession: 0, roundsSinceAd: 0, lastAdSec: null as number | null };
  let shown = 0;
  for (let k = 1; k <= breaks; k++) {
    const t = k * every;
    s.roundsThisSession++;
    s.roundsSinceAd++;
    if (shouldShowAd(s, t, false, policy)) {
      shown++;
      s.lastAdSec = t;
      s.roundsSinceAd = 0;
    }
  }
  return shown;
}

/** The player's minutes: the genre's range, scaled by the design's target against the genre's average (×0.5 … ×1.5) */
function playerMinutes(c: Ctx, d: MoneyDesign): number {
  const id = `genre.${d.genre}.minutes`;
  const scale = clamp(d.sessionMin / MONEY_TABLE[id].mid, 0.5, 1.5);
  return c.v(id) * scale;
}

/** The breaks a player of `min` minutes meets, for a design with `breaks` in `sessionMin` */
function breaksMet(d: MoneyDesign, min: number): number {
  if (!(d.breaks > 0) || !(d.sessionMin > 0) || !Number.isFinite(d.breaks)) return 0;
  const every = d.sessionMin / (d.breaks + 1);
  if (!(every > 0)) return 0;
  return Math.max(0, Math.floor(min / every - 1e-9));
}

/** Rewarded views per play: each placement's offers × the share taken, capped per player-hour. Never for children. */
function rewardedViews(c: Ctx, d: MoneyDesign, min: number, breaks: number): number {
  const ch = CHANNELS[d.channel];
  if (!d.adsOn || !d.rewardedOn || !ch?.rewardedAds || AUDIENCES[d.audience]?.child) return 0;
  let views = 0;
  for (const p of d.rewarded) views += (p.per === 'session' ? 1 : breaks + 1) * c.v(`rewarded.take.${p.kind}`);
  return Math.min(views, (c.v('cg.rewarded.maxPerHour') * min) / 60);
}

/** The default `per` of a rewarded kind: a revive or continue once a session (CrazyGames), a trial once, a hint or undo per level */
export function defaultPer(kind: RewardedKind): RewardedPlacement['per'] {
  // A wheel's extra spin and the shop's currency are offered a few times a day: once a session, at the most
  return kind === 'revive' || kind === 'continue' || kind === 'trial' || kind === 'spin' || kind === 'currency' ? 'session' : kind === 'hint' || kind === 'undo' ? 'level' : 'run';
}

/** Revenue days inside month m (1-based, 30-day months) when revenue starts on day `from` */
const daysIn = (m: number, from: number) => clamp(30 * m - Math.max(from, 30 * (m - 1)), 0, 30);

function originalityRow(d: MoneyDesign): string {
  const u = d.uniqueness;
  if (!u) return 'cg.original.unknown';
  if (u.gate) return 'cg.original.0';
  return u.score >= 85 ? 'cg.original.85' : u.score >= 70 ? 'cg.original.70' : u.score >= 50 ? 'cg.original.50' : 'cg.original.0';
}

function zero(): Record<Scenario, [number, number, number]> {
  return { pessimistic: [0, 0, 0], median: [0, 0, 0], optimistic: [0, 0, 0] };
}

/** The forecast for a design. `calibration` (from publisher/results.yaml) narrows what recorded outcomes can narrow */
export function forecast(d: MoneyDesign, calibration: Calibration = { notes: [] }): Forecast {
  const used = new Set<string>();
  const ch = CHANNELS[d.channel];
  const notes: string[] = [];
  const zeroR: Range = { low: 0, mid: 0, high: 0 };
  const one: Range = { low: 1, mid: 1, high: 1 };
  const nothing = (why: string, stages: Stage[]): Forecast => ({
    channel: d.channel,
    earns: false,
    why,
    stages,
    pApproval: one,
    pFullLaunch: one,
    revenueFromDay: zeroR,
    unit: { name: 'play', midgame: zeroR, rewarded: zeroR, eur: zeroR },
    volume: { name: 'plays/day', range: zeroR },
    months: zero(),
    total: { pessimistic: 0, median: 0, optimistic: 0 },
    expected: zeroR,
    used: [],
    notes,
  });
  if (!ch) return nothing(`unknown channel ${d.channel}`, []);
  if (!ch.ads || ch.adsNeedConsent)
    return nothing(
      ch.ads ? `ads on ${ch.id} need a consent flow (UMP) the platform doesn't have yet: no revenue until it does` : `channel ${ch.id} has no ad provider in the platform yet: no revenue (publish on CrazyGames to earn)`,
      [{ name: ch.id === 'web' ? 'publish on your own site (no review)' : 'store review', days: null, p: null, revenue: false, note: 'no revenue on this channel yet' }],
    );
  if (!d.adsOn && !d.removeAds) return nothing('monetization.ads.enabled is false and there is no purchase: the game is not for money', []);

  if (ch.id === 'crazygames') {
    const byScenario = SCENARIOS.map((sc) => {
      const c = ctxFor(sc, used);
      const min = playerMinutes(c, d);
      const breaks = breaksMet(d, min);
      // Midgame: what the channel's policy lets through at the design's breaks, and no more than games achieve per hour
      // Rewarded counted in: midgame and rewarded together no more than the portal's 20 an hour (midgame gets what's left)
      const allowed = d.adsOn && ch.adPolicy ? midgameAds(ch.adPolicy, min, breaks) : 0;
      const rw = rewardedViews(c, d, min, breaks);
      const mid = Math.max(0, Math.min(allowed, (c.v('cg.midgame.perHour') * min) / 60, (c.v('cg.ads.maxPerHour') * min) / 60 - rw));
      const scale = calibration.perPlayScale ? at(calibration.perPlayScale, sc) : 1;
      const fx = c.v('fx.usdEur');
      const mob = c.v('cg.mobileShare');
      const ecpmMid = (mob * c.v('cg.midgame.ecpmMobile') + (1 - mob) * c.v('cg.midgame.ecpmDesktop')) * fx;
      const ecpmRw = c.v('cg.rewarded.ecpm') * fx;
      const eur = ((c.v('cg.share') * (mid * c.v('cg.midgame.fill') * ecpmMid + rw * c.v('cg.rewarded.fill') * ecpmRw)) / 1000) * scale;
      const from = c.v('cg.review.days') + c.v('cg.basic.days') + c.v('cg.full.days');
      // Plays: the launch week (48 h on the homepage), then the steady level, losing a share each month
      const steadyRow = rowRange('cg.plays.steady', used);
      const steady = at(calibration.plays ? calibration.plays(steadyRow) : steadyRow, sc);
      const week1 = Math.max(c.v('cg.plays.week1'), steady);
      const decay = c.v('cg.plays.decay');
      const playsOn = (day: number) => (day < 7 ? week1 : steady * (1 - decay) ** ((day - 7) / 30));
      const months: [number, number, number] = [0, 0, 0];
      for (let t = Math.ceil(from); t < 90; t++) months[Math.floor(t / 30)] += playsOn(t - from) * eur;
      // Probabilities: the review (pass rate × the uniqueness factor), then the Basic Launch metrics against the benchmarks
      const pA = clamp(c.v('cg.review.pass') * c.v(originalityRow(d)), 0, 0.95);
      const gate = c.v('cg.full.gateMin');
      const fSession = clamp(min / gate, 0.3, 1.2);
      const fGenre = clamp(c.v(`genre.${d.genre}.d1`) / c.v('cg.platform.d1'), 0.8, 1.25);
      const fReturn = d.returns === 'none' ? c.v('cg.full.returnNone') : d.returns === 'daily' ? c.v('cg.full.returnDaily') : 1;
      const fMeta = d.metaMin === null ? c.v('cg.full.metaUnknown') : d.metaMin < Math.max(gate, d.sessionMin) ? c.v('cg.full.metaShort') : 1;
      const fSize = d.uploadMB !== null && d.uploadMB > 20 ? c.v('cg.full.big') : 1;
      const fLoad = d.loadSec === null ? 1 : loadFactor(d.loadSec, ch.webLimits?.warnLoadSec ?? 3, c.v('cg.load.slowSec'), c.v('cg.full.slowLoad'));
      const meetAll = clamp(c.v('cg.full.meetAll') * fSession * fGenre * fReturn * fMeta * fSize * fLoad, 0, 0.95);
      const pFL = meetAll * c.v('cg.full.ifAll') + (1 - meetAll) * c.v('cg.full.someShare') * c.v('cg.full.ifSome');
      const plays = steady;
      return { min, breaks, mid, rw, eur, from, plays, months, pA, pFL };
    });
    const [pe, me, op] = byScenario;
    const pick = (f: (x: (typeof byScenario)[number]) => number): Range => ({ low: f(pe), mid: f(me), high: f(op) });
    let pApproval = (calibration.approval ?? ((p) => p))(pick((x) => x.pA));
    // A game judged before: no more likely than the recorded resubmissions of its kind (3 of 4 after a stop were rejected)
    if (d.resubmission) {
      const cap = calibration.resubmission?.[d.resubmission] ?? rowRange(RESUBMISSION_ROW[d.resubmission], used);
      used.add(RESUBMISSION_ROW[d.resubmission]);
      pApproval = { low: Math.min(pApproval.low, cap.low), mid: Math.min(pApproval.mid, cap.mid), high: Math.min(pApproval.high, cap.high) };
      notes.push(
        `a resubmission ${d.resubmission === 'after-stop' ? 'after a Basic Launch stop' : 'after a rejection'}: P(approval) at most ${Math.round(cap.low * 100)}–${Math.round(cap.high * 100)}% (mid ${Math.round(cap.mid * 100)}%) (${RESUBMISSION_ROW[d.resubmission]}, from the history in publisher/results.yaml). Send it again only with a change a reviewer sees in the first minute (CrazyGames judges the whole game anew), and say what changed`,
      );
    }
    const pFullLaunch = (calibration.fullLaunch ?? ((p) => p))(pick((x) => x.pFL));
    const months = { pessimistic: pe.months, median: me.months, optimistic: op.months };
    const total = { pessimistic: sum(pe.months), median: sum(me.months), optimistic: sum(op.months) };
    if (!d.adsOn) notes.push('ads are off (monetization.ads.enabled: false): no revenue');
    if (d.breaks === 0 && d.adsOn) notes.push('no natural break: no midgame ad can be shown');
    return {
      channel: d.channel,
      earns: total.optimistic > 0,
      why: total.optimistic > 0 ? null : 'no ad can be shown: no natural break and no rewarded offer',
      stages: [
        { name: 'QA review', days: rowRange('cg.review.days', used), p: pApproval, revenue: false, note: 'quality, compliance and originality (gp uniqueness)' },
        { name: 'Basic Launch', days: rowRange('cg.basic.days', used), p: pFullLaunch, revenue: false, note: 'ads off, no revenue; gates: 1-min conversion ≥ 80%, avg playtime ≥ 10 min, D1 10–15% — against other games' },
        { name: 'Full Launch', days: null, p: null, revenue: true, note: 'the SDK\'s ads: midgame at natural breaks (≤ 1 per 3 min), rewarded when the player chooses' },
      ],
      pApproval,
      pFullLaunch,
      revenueFromDay: { low: op.from, mid: me.from, high: pe.from },
      unit: { name: 'play', midgame: pick((x) => x.mid), rewarded: pick((x) => x.rw), eur: pick((x) => x.eur) },
      volume: { name: 'plays/day', range: pick((x) => x.plays) },
      months,
      total,
      perMonth: { low: pe.plays * pe.eur * 30, mid: me.plays * me.eur * 30, high: op.plays * op.eur * 30 },
      expected: { low: pApproval.low * pFullLaunch.low * total.pessimistic, mid: pApproval.mid * pFullLaunch.mid * total.median, high: pApproval.high * pFullLaunch.high * total.optimistic },
      used: [...used],
      notes,
    };
  }

  // Google Play (android-families): review → organic installs; interstitials in the Families policy, "Remove ads"
  const byScenario = SCENARIOS.map((sc) => {
    const c = ctxFor(sc, used);
    const min = playerMinutes(c, d);
    const breaks = breaksMet(d, min);
    // Interstitials: what the Families policy lets through at the design's rounds, and no more than kids apps achieve per day
    const perSession = d.adsOn && ch.adPolicy ? midgameAds(ch.adPolicy, min, breaks) : 0;
    const ads = Math.min(perSession * c.v('gp.sessionsPerDay'), c.v('gp.adsPerDau'));
    const perDau = (ads * c.v('gp.ecpm') * c.v('fx.usdEur') * c.v('gp.share')) / 1000;
    const from = c.v('gp.review.days');
    const installs = c.v('gp.installs.perMonth') / 30;
    const mult = [1, c.v('gp.installs.month2'), c.v('gp.installs.month3')];
    const active = c.v('gp.activeDays');
    const price = d.removeAds ? (d.removeAds.price || c.v('gp.iap.price')) : 0;
    const iapPerInstall = d.removeAds ? c.v('gp.iap.buyRate') * price * c.v('gp.iap.share') : 0;
    // DAU builds up over the first month (half of the steady state on average), then stays at installs × active days
    const months = [1, 2, 3].map((m) => {
      const days = daysIn(m, from);
      const inst = installs * mult[m - 1];
      const dau = inst * active * (m === 1 ? 0.5 : 1);
      return days * (dau * perDau + inst * iapPerInstall);
    }) as [number, number, number];
    return { ads, perDau, from, installs, months, pA: c.v('gp.review.pass') };
  });
  const [pe, me, op] = byScenario;
  const pick = (f: (x: (typeof byScenario)[number]) => number): Range => ({ low: f(pe), mid: f(me), high: f(op) });
  const pApproval = (calibration.approval ?? ((p) => p))(pick((x) => x.pA));
  const total = { pessimistic: sum(pe.months), median: sum(me.months), optimistic: sum(op.months) };
  if (d.rewarded.length) notes.push('rewarded placements are ignored: no ads a child can choose (Families; the validator refuses them)');
  return {
    channel: d.channel,
    earns: total.optimistic > 0,
    why: total.optimistic > 0 ? null : 'no ad or purchase can earn',
    stages: [
      { name: 'Google Play review', days: rowRange('gp.review.days', used), p: pApproval, revenue: false, note: 'Families policy, Data safety, Repetitive Content (not scored: own content, stickers, texts — AGENTS.md §2.3)' },
      { name: 'Organic installs', days: null, p: null, revenue: true, note: 'interstitials after rounds (Families limits), "Remove ads" behind the parent gate; no rewarded ads' },
    ],
    pApproval,
    pFullLaunch: one,
    revenueFromDay: { low: op.from, mid: me.from, high: pe.from },
    unit: { name: 'active child per day', midgame: pick((x) => x.ads), rewarded: zeroR, eur: pick((x) => x.perDau) },
    volume: { name: 'installs/day', range: pick((x) => x.installs) },
    months: { pessimistic: pe.months, median: me.months, optimistic: op.months },
    total,
    expected: { low: pApproval.low * total.pessimistic, mid: pApproval.mid * total.median, high: pApproval.high * total.optimistic },
    used: [...used],
    notes,
  };
}

const sum = (xs: readonly number[]) => xs.reduce((a, b) => a + b, 0);

// --- Levers: what changes the expected value most -------------------------------------------------------------------

export interface Lever {
  name: string;
  change: string;
  /** Expected value, months 1–3, after − before (mid) */
  delta: number;
  after: number;
}

/** The design changes the model knows, each tried on the design; the three that add the most expected value */
export function levers(d: MoneyDesign, calibration?: Calibration, top = 3): Lever[] {
  const base = forecast(d, calibration).expected.mid;
  const ch = CHANNELS[d.channel];
  const tries: { name: string; change: string; d: MoneyDesign }[] = [];
  const has = (k: RewardedKind) => d.rewarded.some((p) => p.kind === k);
  if (!ch?.ads || ch.adsNeedConsent) {
    tries.push({ name: 'Publish on CrazyGames', change: `channel ${d.channel} earns nothing in the platform today; CrazyGames pays a share of its ads (kit: code or casual, 13+)`, d: { ...d, channel: 'crazygames', audience: 'general', adsOn: true, rewardedOn: true } });
  } else if (ch.id === 'crazygames') {
    // The portal: the first midgame after the tutorial or 3–5 min of play, then ≤ 1 per 3 min. The platform's policy: never
    // in the first 3 min, the first at the 3rd break or after 5 min, whichever comes first, then one per 3 min at most —
    // a break every 2–3 min lets the most through
    const every = d.breaks > 0 ? d.sessionMin / (d.breaks + 1) : Infinity;
    const more = Math.max(d.breaks, Math.ceil(d.sessionMin / 2.5) - 1);
    if (more > d.breaks)
      tries.push({
        name: 'More natural breaks: one every 2–3 min',
        change: `${d.breaks} break(s) in ${d.sessionMin} min${Number.isFinite(every) ? ` (one every ${every.toFixed(1)} min)` : ''} → ${more}: the first midgame ad comes at the 3rd break or after 5 min (never in the first 3), then one per 3 min — every break after that can carry one; short levels, runs or days, host.adBreak() on the way into the next`,
        d: { ...d, breaks: more },
      });
    if (!has('revive') && !has('continue')) tries.push({ name: 'A rewarded revive (or continue)', change: 'once a session, on the death screen, with a same-size "No thanks"; the most-taken offer', d: { ...d, rewarded: [...d.rewarded, { placement: 'revive', kind: 'revive', per: 'session' }] } });
    if (!has('x2')) tries.push({ name: 'A rewarded ×2 on the results', change: 'double the run\'s currency on the results screen, never on the play screen', d: { ...d, rewarded: [...d.rewarded, { placement: 'double', kind: 'x2', per: 'run' }] } });
    if (d.genre === 'puzzle' && !has('hint')) tries.push({ name: 'A rewarded hint from a "Stuck?" panel', change: 'the best puzzle placement (camera icon, a cooldown), from a panel that pauses play', d: { ...d, rewarded: [...d.rewarded, { placement: 'hint', kind: 'hint', per: 'level' }] } });
    if (d.returns !== 'daily') tries.push({ name: 'D1: a daily reason to return', change: 'a daily seed / case / challenge and a calendar of solved days (never a loss-framed streak)', d: { ...d, returns: 'daily' } });
    if (d.sessionMin < 10) tries.push({ name: 'A session of 10+ minutes with a meta', change: `${d.sessionMin} min → 12 min: the Basic Launch playtime gate is 10 min`, d: { ...d, sessionMin: 12, breaks: Math.max(d.breaks, 2), metaMin: Math.max(d.metaMin ?? 0, 30) } });
    if (d.metaMin === null || d.metaMin < Math.max(10, d.sessionMin)) tries.push({ name: 'A meta that outlasts the first session', change: `meta ${d.metaMin === null ? 'unknown' : `${d.metaMin} min`} → 60+ min, measured by the balance bot (balance())`, d: { ...d, metaMin: Math.max(60, d.sessionMin * 3) } });
    if (!d.uniqueness || d.uniqueness.gate || d.uniqueness.score < 85) tries.push({ name: 'Uniqueness 85+', change: `${d.uniqueness ? `gp uniqueness ${d.uniqueness.score}${d.uniqueness.gate ? ` (gate: ${d.uniqueness.gate})` : ''}` : 'no concept scored yet'} → 85: the twist seen early, the game's own mechanic and progression (docs/guides/uniqueness.md)`, d: { ...d, uniqueness: { score: 85, gate: null, from: 'lever' } } });
    const okSec = ch.webLimits?.warnLoadSec ?? 3;
    if (d.loadSec !== null && d.loadSec > okSec)
      tries.push({ name: `A load under ${okSec} s on a slow phone`, change: `≈ ${d.loadSec.toFixed(1)} s → under ${okSec} s to a tappable Play (${d.uploadGzipKB !== null ? `${Math.round(d.uploadGzipKB)} KB gzipped now; ` : ''}gp build lists each npm package's share: a lighter engine, no unused imports, assets loaded after Play)`, d: { ...d, loadSec: okSec } });
    if (d.uploadMB !== null && d.uploadMB > 20) tries.push({ name: 'An upload under 20 MB', change: `${d.uploadMB.toFixed(1)} MB → under 20 MB (the mobile homepage)`, d: { ...d, uploadMB: 19 } });
  } else {
    if (!d.removeAds && ch.billing) tries.push({ name: 'A "Remove ads" purchase', change: 'one-time, behind the parent gate (monetization.removeAds)', d: { ...d, removeAds: { price: 0 } } });
    if (d.sessionMin < 6) tries.push({ name: 'Longer play per session', change: `${d.sessionMin} min → 8 min: more rounds, calm, no pressure (a sticker album, a garden that grows)`, d: { ...d, sessionMin: 8, breaks: Math.max(d.breaks, Math.round((8 * 60) / 45) - 1) } });
  }
  return tries
    .map((t) => {
      const after = forecast(t.d, calibration).expected.mid;
      return { name: t.name, change: t.change, delta: after - base, after };
    })
    .filter((l) => l.delta > 0.005)
    .sort((a, b) => b.delta - a.delta)
    .slice(0, top);
}

// --- Idea mode: a design from a few numbers, before any code ---------------------------------------------------------

export interface IdeaInput {
  channel: string;
  genre?: string;
  audience?: string;
  kit?: string;
  sessionMin?: number;
  breaks?: number;
  rewarded?: string[];
  metaMin?: number | null;
  returns?: string;
  uploadMB?: number | null;
  /** Seconds to a tappable Play on a slow phone (gp build prints it) */
  loadSec?: number | null;
  /** The pitch: checked against the taken concepts (what `gp uniqueness` costs a match) */
  pitch?: string;
  title?: string;
  /** A known uniqueness score (gp uniqueness) */
  unique?: number;
  removeAds?: boolean;
  removeAdsPrice?: number;
}

/** What `gp uniqueness` takes for taken concepts (packages/cli/src/uniqueness.ts): 15 each on the portal, 5 off it, 25 at most */
export const TAKEN_PENALTY = { portal: 15, offPortal: 5, max: 25 } as const;

/**
 * The uniqueness a concept on paper gets if the game is then built as described — 80: the twist seen early, its own
 * mechanic, the search written down, no story or own progression counted yet — minus what `gp uniqueness` takes for a
 * taken genre + theme (TAKEN_PENALTY: 15 each on the portal, 5 off it, 25 at most, as gp uniqueness does).
 */
export function ideaUniqueness(pitch: string, title = ''): { score: number; taken: string[] } {
  const taken = takenConceptsFor(conceptText(title, pitch, ''), title);
  const penalty = Math.min(TAKEN_PENALTY.max, taken.reduce((n, t) => n + (t.offPortal ? TAKEN_PENALTY.offPortal : TAKEN_PENALTY.portal), 0));
  const score = clamp(80 - penalty, 0, 100);
  return { score, taken: taken.map((t) => `${t.what} (${t.titles.slice(0, 2).join(', ')})`) };
}

/** Where a default break count came from: the genre's spacing, rounded to whole breaks in the session (the table prints the result) */
function breaksLabel(genre: string, every: number, breaks: number, sessionMin: number, extra = ''): string {
  return `the ${genre} default: about one every ${every} min, rounded to ${breaks} in ${Math.round(sessionMin * 100) / 100} min${extra ? `; ${extra}` : ''}`;
}

export function ideaDesign(i: IdeaInput): { design: MoneyDesign; issues: string[] } {
  const issues: string[] = [];
  const ch = CHANNELS[i.channel];
  if (!ch) issues.push(`unknown channel "${i.channel}" (${Object.keys(CHANNELS).join(', ')})`);
  const audience = i.audience ?? (ch?.childOnly ? 'ages-2-5' : 'general');
  // The same audience rules as gp validate (E_CHANNEL_AUDIENCE): an idea the validator would refuse gets no forecast
  const aud = AUDIENCES[audience];
  if (!aud) issues.push(`unknown audience "${audience}" (${Object.keys(AUDIENCES).join(', ')})`);
  else if (ch) {
    if (ch.childOnly && !aud.child) issues.push(`channel ${ch.id} is for child-directed games, not audience ${audience} (use --channel android for a general audience)`);
    else if (aud.child && ch.platform === 'android' && !ch.childOnly) issues.push(`audience ${audience} is child-directed: on Google Play it must use --channel android-families`);
    else if (ch.audiences && !ch.audiences.includes(audience)) issues.push(`channel ${ch.id} accepts audience ${ch.audiences.join(', ')}, not ${audience}`);
  }
  // The numbers: a session of 0 min or a fractional break count has no meaning (and a 0-min session would never end the loop)
  const num = (name: string, v: number | null | undefined, ok: (x: number) => boolean, what: string) => {
    if (v !== undefined && v !== null && !(Number.isFinite(v) && ok(v))) issues.push(`--${name} ${v}: ${what}`);
  };
  num('session', i.sessionMin, (x) => x > 0 && x <= 240, 'minutes per session, more than 0 and at most 240 (as money.session.minutes)');
  num('breaks', i.breaks, (x) => Number.isInteger(x) && x >= 0 && x <= 500, 'natural breaks per session, a whole number from 0 to 500 (as money.session.breaks)');
  num('meta', i.metaMin, (x) => x >= 0 && x <= 100_000, 'minutes until the progression is done, 0 or more');
  num('unique', i.unique, (x) => x >= 0 && x <= 100, 'a gp uniqueness score, 0–100');
  num('mb', i.uploadMB, (x) => x >= 0 && x <= 10_000, 'the upload in MB, 0 or more');
  num('load', i.loadSec, (x) => x >= 0 && x <= 600, 'seconds to a tappable Play on a slow phone, 0 or more');
  num('price', i.removeAdsPrice, (x) => x >= 0 && x <= 1000, 'the "Remove ads" price in EUR, 0 or more');
  const kit = i.kit ?? (AUDIENCES[audience]?.child ? 'kids' : 'code');
  let genre: Genre;
  const named = moneyGenre(i.genre);
  if (named) genre = named;
  else {
    if (i.genre) issues.push(`unknown genre "${i.genre}" (${GENRE_IDS.join(', ')})`);
    genre = genreOf(kit, audience).genre;
  }
  const from: Record<string, string> = {};
  const sessionMin = i.sessionMin ?? MONEY_TABLE[`genre.${genre}.minutes`].mid;
  from.session = i.sessionMin !== undefined ? '--session' : `the ${genre} average`;
  const breaks = i.breaks ?? Math.max(0, Math.round(sessionMin / MONEY_TABLE[`genre.${genre}.breakEvery`].mid) - 1);
  from.breaks = i.breaks !== undefined ? '--breaks' : breaksLabel(genre, MONEY_TABLE[`genre.${genre}.breakEvery`].mid, breaks, sessionMin);
  const rewarded: RewardedPlacement[] = (i.rewarded ?? []).filter(Boolean).map((p) => {
    const kind = (REWARDED_KINDS as readonly string[]).includes(p) ? (p as RewardedKind) : rewardedKindOf(p);
    return { placement: p, kind, per: defaultPer(kind) };
  });
  const returns = (RETURN_KINDS as readonly string[]).includes(i.returns ?? '') ? (i.returns as ReturnKind) : i.metaMin ? 'meta' : 'none';
  if (i.returns && !(RETURN_KINDS as readonly string[]).includes(i.returns)) issues.push(`unknown return reason "${i.returns}" (${RETURN_KINDS.join(', ')})`);
  let uniqueness: MoneyDesign['uniqueness'] = null;
  if (typeof i.unique === 'number') uniqueness = { score: clamp(i.unique, 0, 100), gate: null, from: '--unique' };
  else if (i.pitch) {
    const u = ideaUniqueness(i.pitch, i.title);
    uniqueness = { score: u.score, gate: null, from: u.taken.length ? `the pitch reads like ${u.taken.join('; ')}` : 'the pitch (no taken concept matched; 80 if built as described)' };
  }
  const billing = !!ch?.billing && (i.removeAds ?? true);
  return {
    design: {
      channel: i.channel,
      audience,
      kit,
      genre,
      sessionMin,
      breaks,
      rewarded,
      metaMin: i.metaMin ?? null,
      returns,
      removeAds: billing ? { price: i.removeAdsPrice ?? 0 } : null,
      adsOn: !!ch?.ads && !ch.adsNeedConsent,
      rewardedOn: !!ch?.rewardedAds,
      uploadMB: i.uploadMB ?? null,
      uploadGzipKB: null,
      loadSec: i.loadSec ?? null,
      uniqueness,
      from: {
        ...from,
        genre: i.genre ? '--genre' : 'the kit / audience',
        rewarded: rewarded.length ? '--rewarded' : 'none given (--rewarded revive,x2,…)',
        meta: i.metaMin ? '--meta' : 'unknown (--meta <minutes>)',
        returns: i.returns ? '--return' : i.metaMin ? 'the meta (--meta)' : 'none given (--return daily|meta|story|social)',
        uniqueness: uniqueness?.from ?? 'not scored (--pitch "…" or --unique <score>)',
        upload: [i.uploadMB ? '--mb' : '', i.loadSec ? '--load' : ''].filter(Boolean).join(', ') || 'not built (--mb <size>, --load <seconds>)',
      },
    },
    issues,
  };
}

// --- game.yaml: the `money` section's checks (resolve.ts calls this) ---------------------------------------------------

type Report = (code: string, path: (string | number)[], message: string, fix: string) => void;

/** A rewarded offer's `gives` that promises a spin or a random prize (W_REWARDED_RANDOM): words, not a reroll of run choices */
export const RANDOM_WORDS = /\b(spins?|wheel|random(ly)?|mystery|surprise|gacha|loot ?box(es)?|lottery|raffle|jackpot|lucky draw|chance to win|scratch ?cards?)\b/i;
const TODO = (x: unknown) => typeof x === 'string' && /^\s*TODO\b/i.test(x);

export interface MoneyCheckContext {
  channel: string;
  audience: string;
  kit: string;
  adsOn: boolean;
  rewardedOn: boolean;
  billing: boolean;
}

/**
 * What can be checked in the money design. Errors only where the design can't be what it says: TODOs, an unknown genre,
 * a rewarded offer where the channel or the audience has none (children: never), on CrazyGames no reason to return (D1
 * is one of the three Basic Launch scores: E_MONEY_RETURN), and a paying channel with ads on where
 * the game declares no natural break AND no rewarded offer — it cannot show a single ad, which is a decision to write
 * down (`monetization.ads.enabled: false`), not a default to ship. The rest are warnings: the design's numbers against
 * the channel's gates.
 */
export function checkMoney(m: MoneyInput | undefined, c: MoneyCheckContext, err: Report, warn: Report): void {
  const ch = CHANNELS[c.channel];
  const child = !!AUDIENCES[c.audience]?.child;
  if (!m) {
    if (ch?.conceptReview && c.kit === 'code')
      warn('W_MONEY_MISSING', ['money'], `channel ${c.channel}: game.yaml has no \`money\` section — gp forecast guesses the design from the genre and the code, and gp submission refuses to hand over without it`, 'Add `money: { genre, session: { minutes, breaks, breaksAt }, rewarded: [...], returns }` — `gp explain money`, `gp forecast`.');
    return;
  }
  const todo = [m.genre, m.session?.breaksAt, m.returns?.what, ...(m.rewarded ?? []).map((r) => r.gives)].some(TODO);
  if (todo) {
    err('E_MONEY', ['money'], 'money is still TODO: design where the game earns before building it', 'Write the genre, the session (minutes, breaks and where they are), each rewarded offer and what it gives, and the reason to return — then `gp forecast`.');
    return;
  }
  if (m.genre !== undefined && !moneyGenre(m.genre)) err('E_MONEY', ['money', 'genre'], `money.genre "${m.genre}" is not a genre the model has benchmarks for`, `Use one of: ${GENRES.join(', ')} — or a sub-genre: ${Object.entries(SUBGENRES).map(([k, v]) => `${k} (${v})`).join(', ')} (gp catalog genres).`);
  const ids = (m.rewarded ?? []).map((r) => r.placement);
  const dup = ids.find((p, i) => ids.indexOf(p) !== i);
  if (dup) err('E_MONEY', ['money', 'rewarded'], `rewarded placement "${dup}" is listed twice`, 'One entry per placement id (the id the game passes to host.rewarded()).');
  // A second layer's genres (money.hybrid): known ids, not the genre itself, never kids
  for (const h of m.hybrid ?? []) {
    const hg = moneyGenre(h);
    if (!hg || hg === 'kids' || hg === 'other')
      err('E_MONEY', ['money', 'hybrid'], `money.hybrid "${h}" is not a genre a layer can be`, `Name the genre of the game's second layer: ${GENRES.filter((g) => g !== 'kids' && g !== 'other').join(', ')} or a sub-genre (an idle base under an action game: hybrid: [idle]).`);
    else if (hg === moneyGenre(m.genre)) warn('W_MONEY_HYBRID', ['money', 'hybrid'], `money.hybrid "${h}" is the game's own genre (${m.genre}): it adds nothing`, 'Remove it, or name the genre of the other layer.');
  }
  // Paid randomness (PEGI from June 2026: a random item for money is PEGI 16, simulated gambling PEGI 18; CrazyGames: PEGI 12)
  const lootIds = (m.loot ?? []).map((l) => l.id);
  const dupLoot = lootIds.find((p, i) => lootIds.indexOf(p) !== i);
  if (dupLoot) err('E_MONEY', ['money', 'loot'], `loot "${dupLoot}" is listed twice`, 'One entry per LootTable source (the id the game rolls).');
  for (const l of m.loot ?? []) {
    if (l.cost === 'purchase' || l.cost === 'bought')
      err(
        'E_PAID_RANDOM',
        ['money', 'loot'],
        `loot "${l.id}" costs ${l.cost === 'purchase' ? 'real money' : 'a currency bought with real money'} and gives a random outcome — a paid random item is PEGI 16 from June 2026 (the portal takes PEGI 12)`,
        `Sell a known thing instead (the item itself, a guaranteed tier, a cosmetic shown before buying), and let the roll cost a currency earned in play: cost: earned.`,
      );
    else if (l.cost === 'ad')
      warn('W_REWARDED_RANDOM', ['money', 'loot'], `loot "${l.id}" is rolled for a rewarded ad: an ad that buys a spin`, 'A rewarded ad gives a guaranteed thing: a floor on a roll the player makes anyway (roll(source, { floor })), a second item, a reroll of run choices — never the roll itself. Make the roll cost: earned or free.');
    if (!l.odds || TODO(l.odds))
      warn('W_LOOT_ODDS', ['money', 'loot'], `loot "${l.id}" doesn't say where its odds are shown`, 'Show every tier\'s chance before each roll (LootTable.odds() / oddsText() on the screen with the roll button), and write where: odds: "the egg card lists each tier\'s chance".');
  }
  for (const r of m.rewarded ?? [])
    if (RANDOM_WORDS.test(r.gives))
      warn('W_REWARDED_RANDOM', ['money', 'rewarded'], `rewarded "${r.placement}" gives "${r.gives}": a rewarded ad that buys a spin, a random or a mystery reward`, 'Give a guaranteed thing the button can name ("a rare or better on your next egg", "a second chest", "×2 coins") — never a spin or a random prize.');
  const earning = !!ch?.ads && !ch.adsNeedConsent && c.adsOn;
  if ((m.rewarded ?? []).length) {
    if (child) err('E_REWARDED_UNSUPPORTED', ['money', 'rewarded'], `audience ${c.audience} is child-directed: no ads a child can choose, ever (Families; game-design.md)`, 'Remove money.rewarded; a kids game earns from interstitials after a round and the "Remove ads" purchase.');
    else if (!ch?.rewardedAds || !earning) err('E_REWARDED_UNSUPPORTED', ['money', 'rewarded'], `channel ${c.channel} has no rewarded ads${earning ? '' : ' (ads are off)'}`, 'Remove money.rewarded, or pick a channel that has them (`gp explain crazygames`).');
    else if (!c.rewardedOn) warn('W_MONEY_REWARDED_OFF', ['money', 'rewarded'], 'money.rewarded lists offers, but monetization.ads.rewarded is false: none can be shown', 'Remove `monetization.ads.rewarded: false`, or the offers.');
  }
  const minutes = m.session?.minutes;
  const breaks = m.session?.breaks;
  if (earning && breaks === 0 && Array.isArray(m.rewarded) && m.rewarded.length === 0)
    err('E_MONEY_NONE', ['money', 'session', 'breaks'], `channel ${c.channel} pays for ads, but the design has no natural break and no rewarded offer: not one ad can be shown`, 'Add a natural break (a level or run end → host.adBreak() on the way into the next) or a rewarded offer; or say the game is not for money: `monetization.ads.enabled: false`.');
  else if (earning && breaks === 0) warn('W_MONEY_BREAKS', ['money', 'session', 'breaks'], 'no natural break in a session: no midgame ad can be shown (only rewarded offers earn)', 'Give the session an end-of-level, end-of-run or end-of-day moment every 3–5 min, and call host.adBreak() on the way into the next.');
  if (earning && typeof minutes === 'number' && typeof breaks === 'number' && breaks > 0 && minutes / (breaks + 1) > 20)
    warn('W_MONEY_BREAK_GAP', ['money', 'session'], `a natural break only every ${Math.round(minutes / (breaks + 1))} min: at most one midgame ad per stretch (the channel allows one per ${Math.round((ch?.adPolicy?.minIntervalSec ?? 180) / 60)} min)`, 'Split the session into levels, runs or days of 3–5 min.');
  if (c.channel === 'crazygames' && typeof minutes === 'number' && minutes < 10)
    warn('W_MONEY_SESSION', ['money', 'session', 'minutes'], `a ${minutes}-min session: Basic Launch compares average playtime with other games (top games 10+ min) — Full Launch, where the revenue is, is unlikely`, 'Design a session of 10+ minutes: a meta that carries runs, levels with stars, a second track (docs/guides/game-design.md → Depth).');
  const meta = m.meta?.minutes;
  if (ch?.conceptReview && typeof meta === 'number' && meta < Math.max(10, minutes ?? 0))
    warn('W_MONEY_META', ['money', 'meta', 'minutes'], `the progression is done after ${meta} min${minutes ? `, within the first ${minutes}-min session` : ''}: nothing to come back for`, 'Make the meta last well past a session (10–180 min: docs/guides/upgrades.md), and check it with the balance bot.');
  // CrazyGames: D1 is one of the three Basic Launch metrics, and none of our launched games had a return at launch
  if (c.channel === 'crazygames' && (!m.returns || m.returns.kind === 'none'))
    err(
      'E_MONEY_RETURN',
      ['money', 'returns'],
      `channel crazygames: ${m.returns ? '`money.returns` is `kind: none`' : 'the money section names no `returns`'} — no reason to come back tomorrow, and D1 retention is one of the three Basic Launch scores (our launched games: 1.0–3.9 %, ≈ 4 % already scores 3)`,
      'Write `returns: { kind: daily | meta | story | social, what: "…" }`: a daily seed or case shown on the title (@gp/core/daily), a goal left at 60–80 % on the last screen, the next chapter — never a loss-framed streak (`gp explain E_MONEY_RETURN`).',
    );
  else if (ch?.conceptReview && m.returns?.kind === 'none')
    warn('W_MONEY_RETURN', ['money', 'returns'], 'no reason to come back tomorrow: Basic Launch reads D1 retention (strong games 10–15%)', 'A daily seed or case, a meta goal left at 80%, the next story chapter — something real, never a loss-framed streak.');
  if (m.removeAdsPrice !== undefined && !c.billing)
    warn('W_MONEY_IAP', ['money', 'removeAdsPrice'], `money.removeAdsPrice is set, but the game has no "Remove ads" purchase${ch?.billing ? '' : ` (channel ${c.channel} has no purchases)`}`, 'Remove money.removeAdsPrice, or enable monetization.removeAds.');
}

// --- game.yaml: the design from the section + what the platform knows about the game --------------------------------

export interface GameMoneyFacts {
  channel: string;
  audience: string;
  kit: string;
  tags: readonly string[];
  adsOn: boolean;
  rewardedOn: boolean;
  billing: boolean;
  /** The casual kit: a round's clock (s) */
  roundSec?: number | null;
  concept?: { progression?: string } | null;
  storyDepth?: string | null;
  /** From the code (the CLI reads it): rewarded placement ids, and whether the game calls host.adBreak() */
  code?: { rewarded: string[]; adBreak: boolean } | null;
  /** From balance(): minutes until the meta is done (the cheapest-first buyer) */
  balanceMetaMin?: number | null;
  /**
   * game.yaml balance.difficulty.winningRunMin is declared: a winning run's minutes (the bot's measured one, else the
   * declared range's middle) and where they came from — the session the forecast reads, in place of money.session.minutes
   */
  winningRun?: { minutes: number; from: string } | null;
  uploadMB?: number | null;
  /** From upload/size.json (gp build): gzipped KB and the estimated seconds to a tappable Play on a slow phone */
  uploadGzipKB?: number | null;
  loadSec?: number | null;
  uniqueness?: MoneyDesign['uniqueness'];
}

/** The design the forecast reads: the money section where written, the rest derived — and where each value came from */
export function moneyDesign(m: MoneyInput | null | undefined, f: GameMoneyFacts): MoneyDesign {
  const from: Record<string, string> = {};
  const mg = moneyGenre(m?.genre);
  const g = mg ? { genre: mg, from: mg === m?.genre ? 'money.genre' : `money.genre ${m?.genre} (a sub-genre of ${mg})` } : genreOf(f.kit, f.audience, f.tags);
  from.genre = g.from;
  const avg = MONEY_TABLE[`genre.${g.genre}.minutes`].mid;
  // A game whose whole is one run (a roguelite with balance.difficulty.winningRunMin): a session is a winning run
  const won = f.winningRun && f.winningRun.minutes > 0 ? f.winningRun : null;
  const sessionMin = won ? won.minutes : (m?.session?.minutes ?? avg);
  from.session = won
    ? `${won.from} — balance.difficulty.winningRunMin is declared, so a session is a winning run${m?.session?.minutes !== undefined && m.session.minutes !== won.minutes ? ` (in place of money.session.minutes ${m.session.minutes})` : ''}`
    : m?.session?.minutes !== undefined ? 'money.session.minutes' : `the ${g.genre} average on CrazyGames`;
  let breaks: number;
  if (m?.session?.breaks !== undefined && won && m.session.minutes !== undefined && m.session.minutes > 0 && m.session.minutes !== won.minutes) {
    // The breaks were written for the hand-entered session: as many a minute in a winning run
    breaks = Math.max(0, Math.round((m.session.breaks * won.minutes) / m.session.minutes));
    from.breaks = `money.session.breaks ${m.session.breaks} in ${m.session.minutes} min, scaled to the winning run's ${Math.round(won.minutes * 10) / 10} min`;
  } else if (m?.session?.breaks !== undefined) {
    breaks = m.session.breaks;
    from.breaks = 'money.session.breaks';
  } else if (f.kit === 'code' && f.code && !f.code.adBreak) {
    breaks = 0;
    from.breaks = 'the code calls no host.adBreak()';
  } else {
    const every = f.kit === 'casual' && f.roundSec ? (f.roundSec + 15) / 60 : MONEY_TABLE[`genre.${g.genre}.breakEvery`].mid;
    breaks = Math.max(0, Math.round(sessionMin / every) - 1);
    from.breaks = f.kit === 'casual' && f.roundSec ? `a ${f.roundSec}-s round + the score screen` : breaksLabel(g.genre, every, breaks, sessionMin, f.code?.adBreak ? 'the code calls host.adBreak()' : '');
  }
  let rewarded: RewardedPlacement[];
  if (m?.rewarded) {
    rewarded = m.rewarded.map((r) => ({ placement: r.placement, kind: r.kind, per: r.per ?? defaultPer(r.kind) }));
    from.rewarded = 'money.rewarded';
  } else if (f.code) {
    rewarded = [...new Set(f.code.rewarded)].map((p) => {
      const kind = rewardedKindOf(p);
      return { placement: p, kind, per: defaultPer(kind) };
    });
    from.rewarded = rewarded.length ? 'the code (host.rewarded / rewardedButton placements)' : 'the code has no rewarded placement';
  } else {
    rewarded = [];
    from.rewarded = f.kit === 'code' ? 'unknown (no money.rewarded)' : `the ${f.kit} kit has no rewarded buttons yet`;
  }
  let metaMin: number | null = null;
  if (typeof f.balanceMetaMin === 'number') {
    metaMin = f.balanceMetaMin;
    from.meta = 'balance(): the cheapest-first buyer finishes';
  } else if (m?.meta?.minutes !== undefined) {
    metaMin = m.meta.minutes;
    from.meta = 'money.meta.minutes';
  } else from.meta = f.kit === 'code' ? 'unknown (no balance() report, no money.meta)' : `the ${f.kit} kit has no meta progression`;
  if (metaMin === null && f.kit === 'casual') metaMin = 0;
  let returns: ReturnKind;
  if (m?.returns) {
    returns = m.returns.kind;
    from.returns = 'money.returns';
  } else if (f.storyDepth === 'chapters' || f.storyDepth === 'branching') {
    returns = 'story';
    from.returns = `story.depth ${f.storyDepth}`;
  } else if (f.concept?.progression || typeof f.balanceMetaMin === 'number') {
    returns = 'meta';
    from.returns = f.concept?.progression ? 'concept.progression' : 'balance()';
  } else if (f.kit === 'kids') {
    returns = 'meta';
    from.returns = 'the sticker album';
  } else {
    returns = 'none';
    from.returns = 'nothing declared';
  }
  const price = m?.removeAdsPrice ?? 0;
  from.upload = typeof f.loadSec === 'number' ? 'upload/size.json (gp build)' : typeof f.uploadMB === 'number' ? 'upload/index.html' : 'not built yet';
  from.uniqueness = f.uniqueness?.from ?? 'not scored';
  return {
    channel: f.channel,
    audience: f.audience,
    kit: f.kit,
    genre: g.genre,
    sessionMin,
    breaks,
    rewarded,
    metaMin,
    returns,
    removeAds: f.billing ? { price } : null,
    adsOn: f.adsOn,
    rewardedOn: f.rewardedOn,
    uploadMB: f.uploadMB ?? null,
    uploadGzipKB: f.uploadGzipKB ?? null,
    loadSec: f.loadSec ?? null,
    uniqueness: f.uniqueness ?? null,
    from,
  };
}
