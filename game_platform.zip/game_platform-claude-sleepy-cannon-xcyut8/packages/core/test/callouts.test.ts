import { describe, expect, it } from 'vitest';
import { callouts, type CalloutsOptions } from '../src/callouts.ts';

const LINES: CalloutsOptions['lines'] = {
  boss: { rank: 1 },
  lowHp: { rank: 1, every: 10 },
  power: { rank: 2 },
  jackpot: { rank: 2, duck: 0.6 },
  triple: { rank: 3, streak: 'kills' },
  rampage: { rank: 3, streak: 'kills' },
  double: { rank: 4, streak: 'kills' },
  headshot: { rank: 4, every: 3 },
};

function setup(voice: Record<string, number> = {}) {
  const log: string[] = [];
  const ducks: [number, number][] = [];
  const c = callouts({
    lines: LINES,
    play: (k) => (log.push(`play:${k}`), voice[k] ?? 0),
    show: (k, hold) => log.push(`show:${k}:${hold.toFixed(2)}`),
    hide: (k) => log.push(`hide:${k}`),
    cut: (k) => log.push(`cut:${k}`),
    mixer: { duck: (d = 0, s = 0) => void ducks.push([d, s]) },
  });
  const run = (sec: number) => {
    for (let i = 0; i < Math.round(sec * 60); i++) c.update(1 / 60);
  };
  return { c, log, ducks, run };
}

describe('callouts', () => {
  it('one line at a time: the next starts when the current one\'s hold (its voice + a beat, ≥ 1.1 s) is over', () => {
    const { c, log, run } = setup({ power: 2 });
    c.say('power');
    c.say('boss');
    expect(c.current?.key).toBe('power');
    expect(c.queue.map((q) => q.key)).toEqual(['boss']);
    expect(log).toContain('show:power:2.20');
    run(2.1);
    expect(c.current?.key).toBe('power');
    run(0.15);
    expect(c.current?.key).toBe('boss');
    expect(c.current?.hold).toBeCloseTo(1.1);
    expect(log.indexOf('hide:power')).toBeLessThan(log.indexOf('play:boss'));
  });

  it('waits by rank, not by arrival: the news first, then rewards, then combos (and a combo kept over 3 s is gone)', () => {
    const { c, run } = setup();
    c.say('power');
    c.say('triple');
    c.say('jackpot');
    c.say('boss');
    expect(c.queue.map((q) => q.key)).toEqual(['boss', 'jackpot', 'triple']);
    const order: (string | null)[] = [];
    for (let i = 0; i < 4; i++) {
      order.push(c.current?.key ?? null);
      run(1.15);
    }
    // The triple would start at 3.3 s after it was asked for: stale, dropped
    expect(order).toEqual(['power', 'boss', 'jackpot', null]);
  });

  it('a rank-1 line cuts a combo call off the air (its voice hushed), not a reward', () => {
    const { c, log } = setup({ triple: 3, power: 3 });
    c.say('triple');
    c.say('boss');
    expect(log).toContain('cut:triple');
    expect(c.current?.key).toBe('boss');
    const s = setup({ power: 3 });
    s.c.say('power');
    s.c.say('boss');
    expect(s.log.some((l) => l.startsWith('cut'))).toBe(false);
    expect(s.c.current?.key).toBe('power');
  });

  it('small talk only into silence: dropped while a line plays or waits, and for 1.5 s after one ended', () => {
    const { c, run } = setup();
    c.say('power');
    expect(c.say('headshot')).toBe(false);
    run(1.2);
    expect(c.current).toBeNull();
    expect(c.say('headshot')).toBe(false);
    run(1.5);
    expect(c.say('headshot')).toBe(true);
    expect(c.current?.key).toBe('headshot');
  });

  it('a streak keeps only its latest step while it waits', () => {
    const { c } = setup();
    c.say('power');
    c.say('triple');
    c.say('rampage');
    expect(c.queue.map((q) => q.key)).toEqual(['rampage']);
  });

  it('a line waiting over 3 s is dropped; the queue holds 3; cooldowns per line', () => {
    const { c, run } = setup({ power: 5 });
    c.say('power');
    c.say('jackpot');
    run(5.3);
    expect(c.current).toBeNull(); // jackpot waited 5.2 s: gone
    c.say('power');
    c.say('boss');
    c.say('jackpot');
    c.say('triple');
    c.say('lowHp');
    expect(c.queue.length).toBe(3);
    expect(c.queue.map((q) => q.key)).toEqual(['boss', 'lowHp', 'jackpot']);
    expect(c.say('lowHp')).toBe(false); // every 10 s
    run(10);
    expect(c.say('lowHp')).toBe(true);
  });

  it('the music ducks under each line for its hold, by rank or the line\'s own depth', () => {
    const { c, ducks, run } = setup({ boss: 2 });
    c.say('boss');
    run(2.3);
    c.say('jackpot');
    expect(ducks[0][0]).toBe(0.45);
    expect(ducks[0][1]).toBeCloseTo(2.2);
    expect(ducks[1]).toEqual([0.6, 1.1]);
  });

  it('the clock is the game\'s: without update() (paused) nothing moves on; clear() drops everything', () => {
    const { c, log, run } = setup();
    c.say('power');
    c.say('boss');
    expect(c.current?.key).toBe('power');
    // Paused for a long time: no update — still the same line, and the waiting one isn't stale
    expect(c.current?.key).toBe('power');
    run(1.2);
    expect(c.current?.key).toBe('boss');
    c.clear();
    expect(c.current).toBeNull();
    expect(c.queue).toEqual([]);
    expect(log).toContain('hide:boss');
    expect(c.say('nope')).toBe(false);
  });
});
