// How unique a game is, from every stage's signals — `gp uniqueness`, and the gate in `gp submission`.
// Portals reject concepts "quite close to existing titles" (Petri Panic); a finished build can't fix that, so the platform
// scores the concept on paper, the code (is the mechanic the game's own?) and play (does the declared twist happen early?)
// and says what to change. docs/guides/uniqueness.md
//
//   signal                                                   points
//   the difference is about play, not looks (W_CONCEPT_THEME)    20
//   no live genre + theme match (W_CONCEPT_TAKEN), −15 each (−5 off the portal) 25
//   the portal search written down (docs/concept.md)            10   (7 for a game without the notes file)
//   the twist declared and seen early in QA (qa/uniqueness.json) 20   (5 declared, not seen)
//   the mechanic's code is the game's own (W_MECHANIC_COPY)     20
//   an own premise (story.premise) and named characters          5   (a small signal: never enough to hide a copy)
//   the progression is the game's own (progressionShape)        +5 / 0 / −5 (the stock "+stat" level shop alone: −5)
//   the words are the game's own (borrowedVocabulary)           0 / −10…−25 per hit, −35 at most: another hit's signature
//                                                                terms in strings/en.yaml and the listing (Balatro's Mult,
//                                                                seals and editions; Minecraft's Creeper; car brands)
//   a concept that is missing or TODO (E_CONCEPT) scores 0; the total is capped at 0..100

import { existsSync, readdirSync, readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { TAKEN_PENALTY, VOCABULARY_PENALTY_MAX, borrowedVocabulary, conceptText, takenConceptsFor, vocabularyPenalty, type Issue, type ResolvedGame } from '@gp/spec';
import { loadStrings } from './i18n.ts';
import { ROOT, type GameLocation } from './paths.ts';
import { storyContentOf } from './story.ts';

export const UNIQUE_ENOUGH = 70;

// --- Code similarity: shared 6-token shingles of the code, comments and string contents left out ----------------

function tokens(src: string): string[] {
  const code = src
    .replace(/\/\*[\s\S]*?\*\//g, ' ')
    .replace(/\/\/[^\n]*/g, ' ')
    .replace(/(['"`])(?:\\.|(?!\1)[^\\])*\1/g, '""');
  return code.match(/[A-Za-z_$][\w$]*|\d+(?:\.\d+)?|[^\s\w]/g) ?? [];
}

function shingles(src: string, k = 6): Set<string> {
  const t = tokens(src);
  const out = new Set<string>();
  for (let i = 0; i + k <= t.length; i++) out.add(t.slice(i, i + k).join(' '));
  return out;
}

/** Share of `a`'s shingles that also occur in `b` (0..1): how much of the game's code is the other code */
export function containment(a: string, b: string): number {
  const A = shingles(a);
  if (!A.size) return 0;
  const B = shingles(b);
  let n = 0;
  for (const s of A) if (B.has(s)) n++;
  return n / A.size;
}

const read = (f: string) => (existsSync(f) ? readFileSync(f, 'utf8') : '');

/** The game's mechanic code against the platform's template and code example: the highest share, and where from */
export function mechanicCopy(loc: GameLocation): { share: number; of: string } | null {
  const own = (f: string) => /\.ts$/.test(f) && !f.endsWith('.test.ts') && !f.endsWith('.d.ts');
  const files = existsSync(loc.dir) ? readdirSync(loc.dir).filter(own) : [];
  if (!files.length) return null;
  const exampleDir = join(ROOT, 'docs/examples/code');
  const tplDir = join(ROOT, 'templates/game-repo/games/__ID__');
  if (loc.dir === exampleDir || loc.dir === tplDir) return { share: 0, of: 'itself (the platform\'s own example)' };
  // The rules: every file but main.ts against the template's sim.ts; main.ts against the example (its rules live there)
  // The rules are sim.ts when the game has one (the skeleton's shape; a balance bot and a data table may stay similar),
  // else every file but main.ts, else main.ts (a one-file game like the example)
  const sources: [string, string][] = [
    ['the template\'s rules (sim.ts)', read(join(tplDir, 'sim.ts'))],
    ['the code example (docs/examples/code)', read(join(exampleDir, 'main.ts'))],
  ];
  let best = { share: 0, of: '' };
  const rules = files.includes('sim.ts') ? ['sim.ts'] : files.filter((f) => f !== 'main.ts');
  const code = (rules.length ? rules : files).map((f) => read(join(loc.dir, f))).join('\n');
  for (const [of, src] of sources) {
    if (!src) continue;
    const share = containment(code, src);
    if (share > best.share) best = { share, of };
  }
  return best;
}

/** docs/concept.md of a game in its own repository (games/<id>/ → ../../docs/concept.md), when there is one */
export function conceptNotes(loc: GameLocation): { file: string; todo: boolean } | null {
  const file = join(dirname(dirname(loc.dir)), 'docs', 'concept.md');
  if (!existsSync(file)) return null;
  return { file, todo: /\bTODO\b/.test(readFileSync(file, 'utf8')) };
}

/** Warnings from the game's files (validate adds them): the mechanic copied, the search notes still TODO */
export function fileChecks(loc: GameLocation, game: ResolvedGame): Issue[] {
  const issues: Issue[] = [];
  if (game.kit.kit !== 'code') return issues;
  const copy = mechanicCopy(loc);
  if (copy && copy.share >= 0.6)
    issues.push({ code: 'W_MECHANIC_COPY', severity: 'warning', path: ['entry'], message: `${Math.round(copy.share * 100)}% of the game's rules code is ${copy.of}`, fix: 'Replace the rules with your own mechanic (sim.ts / the update loop); keep only the host wiring.' });
  const notes = conceptNotes(loc);
  if (notes?.todo) issues.push({ code: 'W_CONCEPT_NOTES', severity: 'warning', path: ['concept'], message: 'docs/concept.md (the portal search notes) is still TODO', fix: 'Write down the searches, the live titles found and why the chosen twist is not live.' });
  return issues;
}

// --- The progression: the stock level shop or the game's own shape ---------------------------------------------

/** The progression blocks of @gp/core (progression.ts) */
const PROGRESSION_BLOCKS = ['Roster', 'Tiers', 'PactTree', 'RunChoices'];

/**
 * The template's placeholder progression still in the game: its PLACEHOLDER marker, or its roster of targets
 * (templates/game-repo/games/__ID__/data.ts `TARGETS`) unchanged — a Roster, but not the game's own.
 */
function templateProgression(code: string): boolean {
  if (/\bPLACEHOLDER progression\b/.test(code)) return true;
  const tpl = read(join(ROOT, 'templates/game-repo/games/__ID__/data.ts')).match(/export const TARGETS = \[[\s\S]*?\] as const;/)?.[0];
  const flat = (s: string) => s.replace(/\s+/g, ' ');
  return !!tpl && flat(code).includes(flat(tpl));
}

/**
 * What the game's progression is, from its code: the platform's progression blocks, its own system (an UpgradeShop on
 * its own screen, the game's own unlock conditions, a progression screen with the QA contract), or only the stock
 * level shop — mountUpgradeShop of "+stat" levels, the shop every game of the template got (Germ Bait, Dread Throne's
 * first release, Starsilk's first Loom). A signal, not a gate: a level shop is right for idle and launch games.
 */
export function progressionShape(loc: GameLocation): { points: number; detail: string } {
  const own = (f: string) => /\.ts$/.test(f) && !f.endsWith('.test.ts') && !f.endsWith('.d.ts');
  const code = (existsSync(loc.dir) ? readdirSync(loc.dir).filter(own) : []).map((f) => read(join(loc.dir, f))).join('\n');
  const imports = [...code.matchAll(/import\s*(?:type\s*)?\{([^}]*)\}\s*from\s*['"]@gp\/core(?:\/progression)?['"]/g)].flatMap((m) => m[1].split(',').map((x) => x.trim().replace(/^type\s+/, '').split(/\s+as\s+/)[0]));
  const blocks = PROGRESSION_BLOCKS.filter((b) => imports.includes(b) && new RegExp(`new\\s+${b}\\b`).test(code));
  const stockScreen = /\bmountUpgradeShop\s*[(<]/.test(code);
  const levelShop = /new\s+UpgradeShop\b/.test(code);
  // The game's own conditions on the shop (Starsilk's depths, Brew & Banter's story) make it more than a list of stats
  const ownLocks = /new\s+UpgradeShop\b[\s\S]{0,400}?\block\s*:/.test(code);
  const ownScreen = /data-gp=["']?shop-screen|dataset\.gp\s*=\s*['"]shop-screen/.test(code);
  // Its own purchases: a price from the game's data paid out of its currency (Candle Crypt: `save.gems -= h.price`)
  const ownBuy = /-=\s*[\w.]+\.(?:price|cost)\b/.test(code);
  // The template's Roster of targets, untouched, is the skeleton's progression, not the game's
  const placeholder = blocks.includes('Roster') && templateProgression(code);
  const counted = placeholder ? blocks.filter((b) => b !== 'Roster') : blocks;
  if (counted.length) return { points: 5, detail: `the platform's progression blocks: ${counted.join(', ')}${stockScreen ? ' (and the level shop)' : ''}` };
  if (stockScreen && !ownLocks) return { points: -5, detail: 'only the stock level shop (mountUpgradeShop of "+stat" levels) — the shop every template game had' };
  if (stockScreen) return { points: 0, detail: 'the stock level shop with the game\'s own unlock conditions' };
  if (placeholder) return { points: 0, detail: 'the template\'s placeholder progression' };
  if (levelShop || ownScreen || ownBuy) return { points: 5, detail: `the game's own progression${ownScreen ? ' screen' : ''}${levelShop ? ' (UpgradeShop math)' : ''}${!levelShop && !ownScreen ? ' (its own purchases)' : ''}` };
  return { points: 0, detail: 'no progression found in the code (none, or one the check can\'t see)' };
}

// --- The words: another hit's signature vocabulary ---------------------------------------------------------------

/**
 * The game's texts a player reads against the hits' signature words (packages/spec/src/vocabulary.ts): English strings
 * (strings/en.yaml, or game.yaml's own texts), the listing and the concept's pitch. Velvet Domino Rogue scored 100 and was
 * rejected with Balatro's "Mult", "Chips", seals and foil / holographic / polychrome / negative editions in its texts.
 */
export function vocabularyOf(loc: GameLocation, game: ResolvedGame): { hit: string; terms: string[]; penalty: number }[] {
  const L = loadStrings(loc);
  const en = L.strings.en ?? {};
  const texts = [
    ...Object.values(en).map((v) => (typeof v === 'string' ? v : Object.values(v as Record<string, string>).join(' '))),
    game.listing.description ?? '',
    game.listing.controls ?? '',
    L.listing.en?.description ?? '',
    L.listing.en?.controls ?? '',
    game.concept?.pitch ?? '',
  ];
  return borrowedVocabulary(texts).map((h) => ({ ...h, penalty: vocabularyPenalty(h.terms.length) }));
}

// --- The report ------------------------------------------------------------------------------------------------

export interface UniquenessSignal {
  name: string;
  points: number;
  max: number;
  detail: string;
  /** What to change when it scores low */
  change?: string;
}

export interface UniquenessReport {
  score: number;
  verdict: 'unique enough' | 'risky' | 'too close';
  gate: string | null;
  signals: UniquenessSignal[];
  searches: string[];
  markdown: string;
}

const STOP = new Set('the a an and or of to in on at by for with from into through over under your you it its is are be as that this then than when while each every one two three game games player players play plays new more most not no only just like long can will what where which who them they their there here nothing yet never'.split(' '));

/** Ready portal searches from the concept's own words (and the genres it reads like) */
export function searchQueries(game: ResolvedGame): string[] {
  const c = game.concept;
  if (!c) return [];
  const words = `${c.pitch} ${c.different}`
    .toLowerCase()
    .replace(/todo:?/g, '')
    .match(/[a-z][a-z-]{3,}/g)
    ?.filter((w) => !STOP.has(w)) ?? [];
  const freq = new Map<string, number>();
  for (const w of words) freq.set(w, (freq.get(w) ?? 0) + 1);
  const top = [...freq.entries()].sort((a, b) => b[1] - a[1]).map(([w]) => w).slice(0, 6);
  const q: string[] = [];
  for (let i = 0; i + 1 < top.length && q.length < 3; i += 2) q.push(`site:crazygames.com ${top[i]} ${top[i + 1]}`);
  for (const t of takenConceptsFor(conceptText(game.title, c.pitch, c.different), game.title, game.id).slice(0, 2)) q.push(`site:crazygames.com ${t.what.replace(/^an? /, '').replace(/[^\w\s-]+/g, ' ').replace(/\s+/g, ' ').trim()}`);
  q.push(`site:crazygames.com ${game.title}`);
  return q;
}

export function uniquenessReport(loc: GameLocation, game: ResolvedGame, issues: Issue[]): UniquenessReport {
  const has = (code: string) => issues.filter((i) => i.code === code);
  const signals: UniquenessSignal[] = [];
  let gate: string | null = has('E_CONCEPT').length ? has('E_CONCEPT')[0].message : game.concept ? null : 'no concept';

  const looks = has('W_CONCEPT_THEME').length > 0;
  signals.push({
    name: 'The difference is about play',
    points: gate ? 0 : looks ? 0 : 20,
    max: 20,
    detail: gate ? '—' : looks ? has('W_CONCEPT_THEME')[0].message : 'concept.different names a rule, input or goal',
    change: 'Say what the player DOES differently — a new input, goal, rule or constraint; then make the game do it.',
  });

  const taken = game.concept ? takenConceptsFor(conceptText(game.title, game.concept.pitch, game.concept.different), game.title, game.id) : [];
  signals.push({
    name: 'No live genre + theme match',
    points: gate ? 0 : Math.max(0, TAKEN_PENALTY.max - taken.reduce((n, t) => n + (t.offPortal ? TAKEN_PENALTY.offPortal : TAKEN_PENALTY.portal), 0)),
    max: TAKEN_PENALTY.max,
    detail: taken.length ? taken.map((t) => `${t.what} (${t.titles.slice(0, 3).join(', ')}${t.offPortal ? '; off the portal: −5' : ''})`).join('; ') : 'no taken concept matched',
    change: 'Change the genre OR the theme fundamentally — a taken genre with a taken theme is a clone; a new skin is not enough.',
  });

  const notes = conceptNotes(loc);
  const closestOk = (game.concept?.closest ?? []).filter((x) => !/^\s*TODO/i.test(x)).length >= 3;
  signals.push({
    name: 'The portal search is written down',
    points: gate ? 0 : notes ? (notes.todo ? 0 : 10) : closestOk ? 7 : 0,
    max: 10,
    detail: notes ? (notes.todo ? 'docs/concept.md is still TODO' : 'docs/concept.md filled in') : closestOk ? '3 closest games named (no docs/concept.md to check)' : 'no search recorded',
    change: 'Search the portal for the genre and the theme (queries below) and fill docs/concept.md: ideas, live titles, verdict.',
  });

  const twist = game.concept?.twist;
  const qaFile = join(loc.dir, 'qa', 'uniqueness.json');
  const qa = existsSync(qaFile) ? (JSON.parse(readFileSync(qaFile, 'utf8')) as { event?: string; seenSec?: number | null; within?: number }) : null;
  const seen = !!twist && qa?.event === twist.event && typeof qa.seenSec === 'number';
  signals.push({
    name: 'The twist happens early in play',
    points: gate ? 0 : seen ? 20 : twist ? 5 : 0,
    max: 20,
    detail: !twist ? 'no concept.twist declared' : seen ? `"${twist.event}" after ${qa!.seenSec!.toFixed(1)} s (within ${twist.within ?? 30} s)` : qa ? `"${twist.event}" not seen in the last gp qa` : `"${twist.event}" declared; run gp qa to check it`,
    change: 'Declare concept.twist, call host.twist() when it happens, and bring it into the first 30 s (a new player must meet it).',
  });

  const copy = game.kit.kit === 'code' ? mechanicCopy(loc) : null;
  const placeholder = has('W_PLACEHOLDER').length > 0;
  const copied = (!!copy && copy.share >= 0.6) || placeholder;
  signals.push({
    name: "The mechanic's code is the game's own",
    points: gate ? 0 : game.kit.kit !== 'code' ? 10 : copied ? 0 : 20,
    max: 20,
    detail: game.kit.kit !== 'code' ? `a ${game.kit.kit}-kit game: the rules are the kit's (only its content and settings differ)` : `${placeholder ? 'the template\'s PLACEHOLDER is still in the code; ' : ''}${copy ? `${Math.round(copy.share * 100)}% shared with ${copy.of}` : 'nothing to compare'}`,
    change: 'Replace the template\'s / example\'s rules with the mechanic the concept describes.',
  });

  // The story: an own premise and characters make a game its own a little (AGENTS.md §2.3); a copied mechanic stays a gate
  const premise = game.story?.premise && !/\bTODO\b/.test(game.story.premise) ? game.story.premise : null;
  const cast = (storyContentOf(loc, game)?.cast ?? []).filter((n) => !/\bTODO\b/.test(n));
  signals.push({
    name: 'An own premise and characters',
    points: gate ? 0 : (premise ? 2 : 0) + (cast.length ? 3 : 0),
    max: 5,
    detail: [premise ? `premise: "${premise}"` : 'no story.premise', cast.length ? `characters: ${cast.slice(0, 4).join(', ')}` : 'no named characters in a story file'].join('; '),
    change: 'Give the game a one-line premise (story.premise) and a character with a name and a voice (`gp story`): the cheapest way to make it its own — on top of its own mechanic, never instead of it.',
  });
  if (game.kit.kit === 'code') {
    const p = progressionShape(loc);
    signals.push({
      name: 'The progression is the game\'s own',
      points: gate ? 0 : p.points,
      max: 5,
      detail: p.detail,
      change: 'Give the progression the shape the genre needs (docs/guides/upgrades.md): unlocks that change how you play, tiers, pacts with a cost, run choices — keep the "+stat" level shop for idle and launch games; name it in concept.progression.',
    });
  }

  // Another hit's words on the game read as that hit reskinned (Velvet Domino Rogue: Balatro's), whatever the rest says
  const borrowed = vocabularyOf(loc, game);
  signals.push({
    name: 'The words are the game\'s own',
    points: gate || !borrowed.length ? 0 : -Math.min(VOCABULARY_PENALTY_MAX, borrowed.reduce((n, h) => n + h.penalty, 0)),
    max: 0,
    detail: borrowed.length ? borrowed.map((h) => `${h.hit}: ${h.terms.join(', ')} (−${h.penalty})`).join('; ') : 'no other hit\'s signature words in the texts',
    change: `Name things in the game's own words: ${borrowed.length ? `the ${borrowed.map((h) => h.hit).join(', ')} words (${borrowed.flatMap((h) => h.terms).slice(0, 8).join(', ')})` : 'another hit\'s terms'} make a reviewer see that game reskinned — rename the scoring, the items and their editions after your own theme (a domino game's "pips" and "chains", not "Chips" and "Mult"); a brand is never yours to use (W_TRADEMARK_TEXT).`,
  });

  // The concept on paper can't make up for a mechanic that isn't the game's: that is a gate, not just points
  if (!gate && copied) gate = placeholder ? 'the template\'s placeholder mechanic is still the game' : `the rules are ${copy!.of}`;
  const score = Math.max(0, Math.min(100, signals.reduce((s, x) => s + x.points, 0)));
  const verdict = gate ? 'too close' : score >= UNIQUE_ENOUGH ? 'unique enough' : score >= 50 ? 'risky' : 'too close';
  const searches = searchQueries(game);
  const low = signals.filter((x) => x.points < x.max);
  const markdown = [
    `# ${game.title} — uniqueness`,
    '',
    `**Score ${score}/100 — ${verdict}** (${UNIQUE_ENOUGH}+ passes \`gp submission\`)${gate ? `. Gate: ${gate}` : ''}`,
    '',
    '| Signal | Points | Detail |',
    '|---|---|---|',
    ...signals.map((x) => `| ${x.name} | ${x.points}/${x.max} | ${x.detail.replace(/\|/g, '\\|')} |`),
    '',
    game.concept ? `**Concept:** ${game.concept.pitch}  \n**Different:** ${game.concept.different}  \n**Closest:** ${game.concept.closest.join(', ')}` : '',
    '',
    low.length ? '## What to change (the game, not only the text)' : '## Nothing to change',
    '',
    ...low.map((x) => `- **${x.name}:** ${x.change}`),
    '',
    low.length
      ? 'Twist levers: change the input (aim instead of move) · the goal (lure instead of kill) · a rule (the reward is also a risk) · add a constraint (one move per turn) · invert a role (you are the level) · combine two known mechanics in a way no live game does. Re-run `gp uniqueness` after the change.'
      : '',
    '',
    '## Search the portal (search results are not the catalogue)',
    '',
    ...searches.map((q) => `- \`${q}\``),
    '',
  ].join('\n');
  return { score, verdict, gate, signals, searches, markdown };
}
