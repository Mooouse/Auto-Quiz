import { describe, expect, it } from 'vitest';
import { firstOpenLevel, levelOpen, loadStars, recordStars, starsFromPar, starsFromShare, totalStars } from '../src/levels.ts';
import { UndoHistory } from '../src/undo.ts';

// The games' own formulas, copied as they shipped: the helpers must give the same stars
const nimbus = (moves: number, par: number) => (moves <= par ? 3 : moves <= par + Math.max(2, Math.ceil(par * 0.3)) ? 2 : 1);
const hang = (tilt: number, par: number) => (tilt <= par + 0.75 ? 3 : tilt <= par + 4 ? 2 : 1);
const germ = (hp: number) => (hp >= 0.75 ? 3 : hp >= 0.35 ? 2 : 1);
const dread = (hp: number, max: number) => (hp / max >= 0.9 ? 3 : hp / max >= 0.5 ? 2 : 1);

describe('level stars', () => {
  it('a saved array is made safe: one whole 0–3 per level', () => {
    expect(loadStars(undefined, 3)).toEqual([0, 0, 0]);
    expect(loadStars([3, 2.7, -1, 9, 'x', null], 4)).toEqual([3, 2, 0, 3]);
    expect(loadStars([1], 3)).toEqual([1, 0, 0]);
    expect(loadStars({ 0: 3 }, 2)).toEqual([0, 0]);
  });

  it('sequential unlock: the first level, after a starred one, or a starred one itself', () => {
    const s = [2, 0, 0, 1];
    expect([0, 1, 2, 3].map((i) => levelOpen(s, i))).toEqual([true, true, false, true]);
    expect(levelOpen([], 0)).toBe(true);
    expect(levelOpen([0, 0], 1)).toBe(false);
  });

  it('Play goes to the first level without a star, or the last one when all have one', () => {
    expect(firstOpenLevel([3, 1, 0, 0])).toBe(2);
    expect(firstOpenLevel([3, 3])).toBe(1);
    expect(firstOpenLevel([0, 0])).toBe(0);
    expect(firstOpenLevel([])).toBe(0);
    expect(totalStars([3, 1, 0, 2])).toBe(6);
  });

  it('recording keeps the best and pays only the new stars', () => {
    const s = [0, 0];
    expect(recordStars(s, 0, 2)).toEqual({ gained: 2, best: 2, firstClear: true });
    expect(recordStars(s, 0, 1)).toEqual({ gained: 0, best: 2, firstClear: false });
    expect(recordStars(s, 0, 3)).toEqual({ gained: 1, best: 3, firstClear: false });
    expect(recordStars(s, 1, 0)).toEqual({ gained: 0, best: 0, firstClear: false });
    expect(s).toEqual([3, 0]);
  });

  it('stars from par give what Nimbus Drift (swipes) and Hang the Moon (tilt) gave', () => {
    for (let par = 1; par <= 20; par++)
      for (let moves = par; moves <= 45; moves++) expect(starsFromPar(moves, par, { two: Math.max(2, Math.ceil(par * 0.3)) }), `${moves}/${par}`).toBe(nimbus(moves, par));
    for (const par of [0, 0.35, 1.43, 2.05])
      for (let tilt = par; tilt <= par + 10; tilt += 0.05) expect(starsFromPar(tilt, par, { three: 0.75, two: 4 })).toBe(hang(tilt, par));
  });

  it('stars from a share give what Germ Bait and Dread Throne gave (health left)', () => {
    for (let hp = 0; hp <= 100; hp++) {
      expect(starsFromShare(hp / 100, 0.75, 0.35)).toBe(germ(hp / 100));
      expect(starsFromShare(hp / 100, 0.9, 0.5)).toBe(dread(hp, 100));
    }
  });
});

describe('UndoHistory', () => {
  it('counts moves, undoes to the start and never past it', () => {
    const h = new UndoHistory({ x: 0 });
    expect([h.moves, h.canUndo, h.undo()]).toEqual([0, false, false]);
    h.push({ x: 1 });
    h.push({ x: 2 });
    expect([h.current.x, h.moves]).toEqual([2, 2]);
    expect(h.undo()).toBe(true);
    expect([h.current.x, h.moves]).toEqual([1, 1]);
    h.push({ x: 5 });
    expect(h.all().map((s) => s.x)).toEqual([0, 1, 5]);
    h.reset({ x: 9 });
    expect([h.current.x, h.moves, h.canUndo]).toEqual([9, 0, false]);
  });
});
