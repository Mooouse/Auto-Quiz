// gp review --first-look: the blind brief, the answers' parser, and the gate on CrazyGames; the scope warning W_SCOPE.

import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterAll, describe, expect, it } from 'vitest';
import { FIRST_LOOK_FILES, FIRST_LOOK_TIMES, firstLookAlarm, firstLookBrief, firstLookTemplate, frameName, parseFirstLook } from '../src/first-look.ts';
import { locateGame } from '../src/paths.ts';
import { firstLookProblems, firstLookSection, parseQuality, qaScreens, qualityGate, scopeIssues, SCOPE_MAX_SCREENS } from '../src/review.ts';
import { KEPT_REPORTS } from '@gp/qa';

const tmp = mkdtempSync(join(tmpdir(), 'gp-first-look-'));
afterAll(() => rmSync(tmp, { recursive: true, force: true }));

const answers = (o: { goal?: string; keep?: string } = {}) =>
  ['# First look', '', `- Goal: ${o.goal ?? 'Blast the green blobs before they reach the robot'}`, '- Controls: click or tap anywhere', '- Hook: the chain explosions', `- Keep playing: ${o.keep ?? '4/5 — it looks lively'}`, ''].join('\n');

describe('first-look.md: the format and its parser', () => {
  it('reads the four answers; the template is refused until it is filled', () => {
    const fl = parseFirstLook(answers());
    expect(fl).toMatchObject({ ok: true, goal: 'Blast the green blobs before they reach the robot', controls: 'click or tap anywhere', hook: 'the chain explosions', keep: 4, keepWhy: 'it looks lively', goalUnknown: false, unclear: null });
    const t = parseFirstLook(firstLookTemplate());
    expect(t.ok).toBe(false);
    expect(t.problems.map((p) => p.message).join(' ')).toMatch(/placeholder/);
    // The optional line's placeholder alone is not a problem
    expect(parseFirstLook(firstLookTemplate().replace(/<what the player is trying[^\n]*>/, 'x').replace(/<what the player presses[^\n]*>/, 'y').replace(/<what, if anything[^\n]*>/, 'z').replace('<1–5>/5 — <why>', '3/5 — fine')).ok).toBe(true);
  });

  it('a goal not told, a low score, bold labels and malformed scores', () => {
    for (const g of ["don't know", 'Do not know — maybe dodge?', 'unclear', '??', 'No idea'])
      expect(parseFirstLook(answers({ goal: g })).goalUnknown, g).toBe(true);
    expect(parseFirstLook(answers({ goal: 'Know when to jump' })).goalUnknown).toBe(false);
    expect(parseFirstLook(answers().replace('- Goal:', '- **Goal:**')).goal).toMatch(/^Blast/);
    expect(parseFirstLook(answers({ keep: '2 — dull' })).keep).toBe(2);
    expect(parseFirstLook(answers({ keep: '6/5 — wow' })).ok).toBe(false);
    expect(parseFirstLook(answers({ keep: '3/5' })).problems[0].message).toMatch(/say why/);
    expect(parseFirstLook('# First look\n- Goal: x\n').problems.map((p) => p.message)).toEqual(['no "- Controls: …" line', 'no "- Hook: …" line', 'no "- Keep playing: …" line']);
    expect(firstLookAlarm(parseFirstLook(answers()))).toBeNull();
    expect(firstLookAlarm(parseFirstLook(answers({ keep: '2/5 — dull', goal: "don't know" })))).toBe('the goal: "don\'t know", keep playing 2/5');
  });

  it('the brief is blind: frames and questions, no text of the game', () => {
    const frames = FIRST_LOOK_TIMES.map((t) => ({ t, file: `/g/qa/${frameName(t)}` }));
    const b = firstLookBrief(frames, '/g/qa/first-look.png', '/g/qa/first-look.md');
    expect(FIRST_LOOK_TIMES).toEqual([0, 3, 8, 15, 22, 30]);
    for (const t of FIRST_LOOK_TIMES) expect(b).toContain(`- ${t} s: /g/qa/first-look-${String(t).padStart(2, '0')}s.png`);
    expect(b).toContain(firstLookTemplate().trimEnd());
    expect(b).toMatch(/Do not open any other file/);
    expect(b).not.toMatch(/concept|pitch|twist|listing|REPORT\.md/i);
    // gp qa keeps them in its fresh folder
    for (const f of FIRST_LOOK_FILES) expect(KEPT_REPORTS).toContain(f);
  });
});

describe('the gate: on CrazyGames quality.md needs the first look, and its alarm as a [blocking] finding', () => {
  const quality = (findings: string[]) =>
    ['# Germ Dodge — quality review', '', '## Scores', '', '- title: 3/5 — ok', '- play-1: 3/5 — ok', '- play-2: 3/5 — ok', '- meta: 3/5 — ok', '', '## Findings', '', ...findings, ''].join('\n');
  const game = (name: string, q: string | null, fl: string | null) => {
    const dir = join(tmp, name);
    mkdirSync(join(dir, 'qa'), { recursive: true });
    writeFileSync(join(dir, 'game.yaml'), 'id: x\n');
    if (q) writeFileSync(join(dir, 'quality.md'), q);
    if (fl) writeFileSync(join(dir, 'qa', 'first-look.md'), fl);
    return locateGame(dir);
  };
  const cg = { title: 'Germ Dodge', channel: { id: 'crazygames' } } as never;

  it('missing or malformed first look: not ready; elsewhere not asked for', () => {
    const q = quality(['- [nice] the shop is plain → draw it']);
    expect(qualityGate(game('none', q, null), cg)).toMatchObject({ ok: false, detail: expect.stringMatching(/first-look\.md is missing — run `gp review \S+ --first-look`/) });
    expect(qualityGate(game('bad', q, '# First look\n'), cg)).toMatchObject({ ok: false, detail: expect.stringMatching(/first-look\.md is malformed/) });
    expect(qualityGate(game('fine', q, answers()), cg)).toMatchObject({ ok: true });
    expect(qualityGate(game('web', q, null), { title: 'Germ Dodge', channel: { id: 'web' } } as never).ok).toBe(true);
  });

  it('keep playing ≤ 2 or no goal must be a [blocking] finding that names the first look', () => {
    const low = answers({ keep: '2/5 — nothing happens' });
    const g = qualityGate(game('low', quality(['- [nice] the shop is plain → draw it']), low), cg);
    expect(g.ok).toBe(false);
    expect(g.report!.problems.map((p) => p.message).join(' ')).toMatch(/keep playing 2\/5: write it as a \[blocking\] finding that names "first look"/);
    const named = qualityGate(game('named', quality(['- [blocking] the first look: a stranger would stop after 30 s, nothing moves → open on the swarm']), low), cg);
    expect(named.report!.ok).toBe(true);
    expect(named.ok).toBe(false); // a [blocking] finding still stops the submission
    expect(firstLookProblems(parseFirstLook(answers({ goal: "don't know" })), parseQuality(quality(['- [blocking] blind first contact: no goal on screen → show it'])))).toEqual([]);
  });

  it('the main brief puts the stranger\'s goal beside the pitch, and asks for the [blocking] finding', () => {
    const concept = { pitch: 'Dodge germs on a petri dish', different: 'x', closest: [], twist: { event: 'split', explained: 'germs split' } } as never;
    const md = firstLookSection('germ', { concept }, parseFirstLook(answers({ keep: '1/5 — confusing' }))).join('\n');
    expect(md).toContain('| Goal | Blast the green blobs before they reach the robot | Dodge germs on a petri dish |');
    expect(md).toContain('| Hook | the chain explosions | germs split |');
    expect(md).toMatch(/\*\*\[blocking\] required:\*\* the first look says keep playing 1\/5/);
    expect(firstLookSection('germ', { concept }, null).join('\n')).toMatch(/gp review germ --first-look/);
  });
});

describe('W_SCOPE: a first CrazyGames submission with more than 15 screens (from the last gp qa)', () => {
  const withScreens = (name: string, n: number, how: 'shots' | 'checks') => {
    const dir = join(tmp, name);
    mkdirSync(join(dir, 'qa'), { recursive: true });
    writeFileSync(join(dir, 'game.yaml'), 'id: x\n');
    const names = Array.from({ length: n }, (_, i) => `s${i}`);
    if (how === 'shots') for (const s of names) writeFileSync(join(dir, 'qa', `screen-${s}-desktop-1280x720.png`), '');
    else writeFileSync(join(dir, 'qa', 'qa-results.json'), JSON.stringify({ checks: names.map((s) => ({ name: `"${s}" phone-portrait-360x800: buttons on screen and ≥ 48 px` })) }));
    writeFileSync(join(dir, 'qa', 'lang-de-title-desktop-1280x720.png'), '');
    return locateGame(dir);
  };
  const g = (over: object = {}) => ({ id: 'germ', title: 'Germ Dodge', channel: { id: 'crazygames' }, kit: { kit: 'code' }, ...over });

  it('counts the screens QA opened (its shots and its checks), and warns above 15 on a first submission only', () => {
    expect(SCOPE_MAX_SCREENS).toBe(15);
    expect(qaScreens(join(withScreens('q16', 16, 'checks').dir, 'qa'))).toHaveLength(16);
    expect(qaScreens(join(tmp, 'nowhere'))).toBeNull();
    const many = withScreens('s16', 16, 'shots');
    const [w] = scopeIssues(many, g(), []);
    expect(w).toMatchObject({ code: 'W_SCOPE', severity: 'warning', message: expect.stringMatching(/^a first CrazyGames submission with 16 screens/) });
    expect(scopeIssues(withScreens('s15', 15, 'shots'), g(), [])).toEqual([]);
    // Judged before (by id or title): not a first submission; another channel or kit: not asked
    expect(scopeIssues(many, g(), [{ game: 'germ', channel: 'crazygames' }])).toEqual([]);
    expect(scopeIssues(many, g(), [{ game: 'germ-old', title: 'Germ Dodge', channel: 'crazygames' }])).toEqual([]);
    expect(scopeIssues(many, g(), [{ game: 'germ', channel: 'playgama' }])).toHaveLength(1);
    expect(scopeIssues(many, g({ channel: { id: 'web' } }), [])).toEqual([]);
    expect(scopeIssues(many, g({ kit: { kit: 'casual' } }), [])).toEqual([]);
  });
});
