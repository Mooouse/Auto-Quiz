// Sticker album: one slot per sticker, unlocked ones show the sticker, locked ones are empty.
// Tapping a sticker makes it jump.

import { drawEmoji, drawIconButton, drawPanel, drawText, hitCircle, hitRect, margin, roundRect, topLeftButton, type ProbeTarget, type Rect, type Scene } from '@gp/core';
import type { KidsContext } from '../context.ts';

export class AlbumScene implements Scene {
  readonly id = 'album';
  cells: Rect[] = [];
  private pad = 0;
  private readonly wiggle = new Map<number, number>();

  constructor(private readonly ctx: KidsContext) {}

  private get app() {
    return this.ctx.app;
  }

  private get stickers(): readonly string[] {
    return this.ctx.kids.rewards.stickers;
  }

  probe(): ProbeTarget[] {
    this.layout();
    const h = topLeftButton(this.app);
    // The touch target of a cell is the whole cell including padding
    const p = this.pad;
    return [{ id: 'home', x: h.x - h.r, y: h.y - h.r, w: h.r * 2, h: h.r * 2 }, ...this.cells.map((c, i) => ({ id: `cell:${i}`, x: c.x - p, y: c.y - p, w: c.w + p * 2, h: c.h + p * 2 }))];
  }

  layout(): void {
    const { w, h, inset } = this.app;
    const m = margin(this.app);
    const home = topLeftButton(this.app);
    const top = home.y + home.r + m * 0.6;
    const left = inset.left + m;
    const areaW = w - inset.right - m - left;
    const areaH = h - inset.bottom - m - top;
    const n = this.stickers.length;
    // Pick the column count that gives the largest cells
    let best = { cols: 4, size: 0 };
    for (let cols = 3; cols <= 8; cols++) {
      const rows = Math.ceil(n / cols);
      const size = Math.min(areaW / cols, areaH / rows);
      if (size > best.size) best = { cols, size };
    }
    const { cols, size } = best;
    const rows = Math.ceil(n / cols);
    const x0 = left + (areaW - cols * size) / 2;
    const y0 = top + (areaH - rows * size) / 2;
    const pad = size * 0.08;
    this.pad = pad;
    this.cells = this.stickers.map((_, i) => ({
      x: x0 + (i % cols) * size + pad,
      y: y0 + Math.floor(i / cols) * size + pad,
      w: size - pad * 2,
      h: size - pad * 2,
    }));
  }

  pointer(x: number, y: number): void {
    if (hitCircle(topLeftButton(this.app), x, y)) {
      this.app.audio.tap();
      this.app.home();
      return;
    }
    this.layout();
    // The touch target is the whole cell including padding (≥ 64 dp even on small screens)
    const i = this.cells.findIndex((c) => hitRect({ x: c.x - this.pad, y: c.y - this.pad, w: c.w + this.pad * 2, h: c.h + this.pad * 2 }, x, y));
    if (i >= 0 && i < (this.app.save.stickers as number)) {
      this.wiggle.set(i, this.app.time);
      this.app.audio.sparkle();
    }
  }

  update(): void {}

  draw(g: CanvasRenderingContext2D): void {
    const { w, h, time } = this.app;
    this.ctx.theme.drawBackground(g, w, h, time);
    this.layout();
    const home = topLeftButton(this.app);
    drawIconButton(g, home.x, home.y, home.r, 'home', { icon: this.ctx.theme.ui.icon });
    // How many collected — digits only, no words
    drawText(g, `${this.app.save.stickers} / ${this.stickers.length}`, w / 2, home.y, home.r * 0.9, '#ffffff', this.ctx.theme.ui.textOutline);

    const got = this.app.save.stickers as number;
    this.cells.forEach((c, i) => {
      const cx = c.x + c.w / 2;
      const cy = c.y + c.h / 2;
      if (i < got) {
        const since = time - (this.wiggle.get(i) ?? -10);
        const jump = since < 0.5 ? Math.sin((since / 0.5) * Math.PI) * c.h * 0.15 : 0;
        drawPanel(g, c.x, c.y - jump, c.w, c.h, c.w * 0.18, '#ffffff', this.ctx.theme.ui.buttonShadow);
        // The newest sticker gently pulses
        const pulse = i === got - 1 ? 1 + Math.sin(time * 3) * 0.05 : 1;
        drawEmoji(g, this.stickers[i], cx, cy - jump, c.w * 0.62 * pulse);
      } else {
        g.fillStyle = this.ctx.theme.ui.slotEmpty;
        roundRect(g, c.x, c.y, c.w, c.h, c.w * 0.18);
        g.fill();
        drawText(g, '?', cx, cy, c.w * 0.4, 'rgba(255, 255, 255, 0.8)', null);
      }
    });
  }
}
