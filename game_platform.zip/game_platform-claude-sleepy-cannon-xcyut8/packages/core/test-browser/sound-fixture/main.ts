// Test page for createMusic on a real AudioContext (packages/core/test-browser/sound.test.ts): a host like GameHost's
// (no audio until the first tap; suspended while paused) and the music's level at its output, in each order of events.
import { createMixer, createMusic, musicTheme, type SoundHost } from '../../src/sound';

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/**
 * The music's loudness (RMS at the host's output, over 1.5 s) 3 s after the context runs.
 * - 'after': the context runs first, then the game sets its volume and plays (the reference)
 * - 'before': the game plays and sets its volume before the first tap (no context yet): Frankengun's title scene
 * - 'paused': as 'before', but the first tap comes while the host is paused (the context made suspended), resumed 1 s later
 */
async function level(order: 'after' | 'before' | 'paused'): Promise<number> {
  let audio: { ctx: AudioContext; out: GainNode } | null = null;
  let paused = order === 'paused';
  const resumeFns: (() => void)[] = [];
  const host: SoundHost = {
    get audio() {
      return audio;
    },
    get paused() {
      return paused;
    },
    portalMuted: false,
    onPause: () => {},
    onResume: (fn) => resumeFns.push(fn),
  };
  const mixer = createMixer(host, { music: 0.5 });
  const music = createMusic(mixer, { title: musicTheme('bright', 7) });
  if (order !== 'after') {
    music.play('title');
    mixer.setVolume('music', 0.9);
    await sleep(400);
  }
  // The first tap: the host makes its context (suspended if it is paused)
  const ctx = new AudioContext();
  const out = ctx.createGain();
  out.connect(ctx.destination);
  const meter = ctx.createAnalyser();
  meter.fftSize = 2048;
  out.connect(meter);
  if (paused) await ctx.suspend();
  audio = { ctx, out };
  if (order === 'after') {
    await ctx.resume();
    mixer.setVolume('music', 0.9);
    music.play('title');
  }
  if (order === 'paused') {
    await sleep(1000);
    paused = false;
    await ctx.resume();
    resumeFns.forEach((f) => f());
  }
  await sleep(3000);
  const buf = new Float32Array(meter.fftSize);
  let sum = 0;
  let n = 0;
  for (let k = 0; k < 30; k++) {
    meter.getFloatTimeDomainData(buf);
    for (const v of buf) sum += v * v;
    n += buf.length;
    await sleep(50);
  }
  music.play(null);
  await ctx.close();
  return Math.sqrt(sum / n);
}

(window as unknown as { __level: typeof level }).__level = level;
