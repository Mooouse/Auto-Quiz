// The season track: the season's tiers a page at a time (never a list to scroll: gp qa's one-screen rule), the XP to
// the next tier, the days left, what waits to be claimed. A modal over whatever is on screen, one screen at every size
// (360×800 to 1280×720 and a phone on its side), the platform's words in the player's language (gp.season.*). A
// reached tier is claimed by a tap on it, or all at once; the next tier to reach is marked, every K-th tier (the
// pass's rewardEvery) stands out. It shows what is waiting and what comes next, never what was missed (D56).
//
//   const pass = seasonPass(save, { seasons, reward, rewardEvery: 3, persist: () => host.save(save) });
//   mountSeasonTrack(ui, pass, {
//     host,
//     name: (s) => host.t(`season.${s.id}`),
//     // How a reward reads: an icon (drawn: iconImg() from @gp/art/dom, an image URL, an element) and a short label
//     view: (r) => (r.kind === 'coins' ? { icon: iconImg(coin, 28, { key: 'coin' }), label: `${r.n}` } : { icon: skinIcon(r.id), label: host.t(`skin.${r.id}`) }),
//     onClaim: (claims) => { for (const c of claims) pay(c.reward); host.save(save); },
//   });
//
// Themeable: screenTheme() for every platform screen at once, or --gp-season-bg, -ink, -muted, -card, -accent,
// -accent-ink, -major, -off, -radius, -font on #gp-season (the
// defaults have no specificity: a game's `#gp-season { --gp-season-bg: … }` wins wherever its style sheet is). The
// platform's own marks (claimed, locked, the big tiers, the pager) are drawn SVG, not glyphs.

import { cardOpened } from './cards.ts';
import type { GameHost } from './host.ts';
import { FONT_FALLBACK } from './i18n.ts';
import { icon, type IconName } from './icons.ts';
import type { SeasonClaim, SeasonDef, SeasonPass, SeasonState, SeasonTier } from './season.ts';
import { iconNode, type ShopIcon } from './shop-ui.ts';

/** How a reward reads on its tier: an icon and a short label ("120", "Neon paint") */
export interface SeasonRewardView {
  icon?: ShopIcon;
  label: string;
}

/** The screen's words (default: the platform's gp.season.* in the player's language) */
export interface SeasonTexts {
  title: string;
  tier: (n: number, max: number) => string;
  xp: (xp: string, need: string) => string;
  daysLeft: (n: number) => string;
  startsIn: (n: number) => string;
  ended: string;
  done: string;
  claim: string;
  claimAll: (n: number) => string;
  next: (name: string) => string;
  page: (n: number, max: number) => string;
  back: string;
}

export interface SeasonTrackOptions<R> {
  host: Pick<GameHost, 'minTouchPx' | 'screen' | 't'>;
  /** How each reward reads (an icon and a label) */
  view: (reward: R, tier: number) => SeasonRewardView;
  /** Tiers were claimed (a tap, or Claim all): pay them (and save) */
  onClaim(claims: SeasonClaim<R>[]): void;
  /** The screen was closed (Back, or a tap outside) */
  onClose?(): void;
  /** The season's name (default: the platform's "Season") */
  name?: (season: SeasonDef) => string;
  /** How an XP amount reads (default: whole numbers) */
  format?: (n: number) => string;
  texts?: Partial<SeasonTexts>;
}

/** The platform's marks on this screen, from the drawn set (@gp/core/icons): the same on every system (no emoji, no glyph) */
const MARKS = { check: 'check', lock: 'lock', star: 'star', prev: 'chevronLeft', next: 'chevronRight' } as const satisfies Record<string, IconName>;

/** A drawn mark: an inline SVG in currentColor (an icon of @gp/core/icons) */
export function seasonMark(name: keyof typeof MARKS, size = 18, filled = false): SVGSVGElement {
  const svg = icon(MARKS[name], { size, style: filled ? 'solid' : 'line', stroke: filled ? 1.5 : 2.6 });
  svg.dataset.mark = name;
  return svg;
}

// A tier card's smallest size: the grid shows as many as fit, the rest on pages
const CELL_W = 76;
const CELL_H = 92;
const GAP = 6;

const CSS = `
:where(#gp-season) { --gp-season-bg: var(--gp-theme-bg, #16213a); --gp-season-ink: var(--gp-theme-ink, #f2f6ff); --gp-season-muted: var(--gp-theme-muted, #a7b4cc);
  --gp-season-card: var(--gp-theme-panel, rgba(255, 255, 255, 0.07)); --gp-season-accent: var(--gp-theme-accent, #ffd166);
  --gp-season-accent-ink: var(--gp-theme-accent-ink, #1b2233); --gp-season-major: var(--gp-theme-accent2, #ff6bd6);
  --gp-season-off: var(--gp-theme-track, rgba(255, 255, 255, 0.16)); --gp-season-radius: var(--gp-theme-radius, 20px);
  --gp-season-font: var(--gp-theme-font, ${FONT_FALLBACK}); }
#gp-season-veil { position: fixed; inset: 0; z-index: 40; display: flex; align-items: center; justify-content: center; background: var(--gp-theme-backdrop, rgba(0, 0, 0, 0.5)); }
#gp-season { position: relative; box-sizing: border-box; width: min(96vw, 940px); height: min(96vh, 680px); display: flex; flex-direction: column;
  gap: 10px; padding: 14px; border-radius: var(--gp-season-radius); background: var(--gp-season-bg); color: var(--gp-season-ink);
  font: 600 15px var(--gp-season-font); font-variant-numeric: tabular-nums; text-align: left; pointer-events: auto; }
#gp-season [hidden] { display: none !important; }
#gp-season header { display: flex; align-items: baseline; gap: 10px; flex-wrap: wrap; }
#gp-season h2 { margin: 0; font-size: 24px; line-height: 1.15; flex: 1 1 auto; min-width: 0; font-family: var(--gp-theme-display, inherit); }
#gp-season .gp-se-when { font-size: 14px; color: var(--gp-season-muted); white-space: nowrap; }
#gp-season .gp-se-progress { display: grid; grid-template-columns: auto 1fr auto; align-items: center; gap: 4px 10px; }
#gp-season .gp-se-tier { font-weight: 800; font-size: 17px; white-space: nowrap; }
#gp-season .gp-se-xp { font-size: 13px; color: var(--gp-season-muted); white-space: nowrap; }
#gp-season .gp-se-bar { height: 10px; border-radius: 5px; background: var(--gp-season-off); overflow: hidden; }
#gp-season .gp-se-bar > i { display: block; height: 100%; background: var(--gp-season-accent); }
#gp-season .gp-se-track { flex: 1 1 0; min-height: 0; display: grid; gap: ${GAP}px; align-content: start; }
#gp-season button { font: inherit; border: 0; margin: 0; min-width: 0; box-shadow: none; text-transform: none; letter-spacing: normal;
  cursor: pointer; touch-action: manipulation; color: inherit; }
#gp-season .gp-se-cell { position: relative; box-sizing: border-box; min-width: 0; padding: 6px 4px; border-radius: 14px; background: var(--gp-season-card);
  border: 2px solid transparent; display: flex; flex-direction: column; align-items: center; justify-content: space-between; gap: 2px; text-align: center; overflow: hidden; }
#gp-season .gp-se-cell[data-state=locked] { cursor: default; }
#gp-season .gp-se-cell[data-state=locked] .gp-se-icon { opacity: 0.45; filter: grayscale(0.6); }
#gp-season .gp-se-cell[data-state=claimed] { cursor: default; opacity: 0.72; }
#gp-season .gp-se-cell[data-state=ready] { border-color: var(--gp-season-accent); }
#gp-season .gp-se-cell[data-next] { border-color: var(--gp-season-off); border-style: dashed; }
#gp-season .gp-se-cell[data-major] { background: color-mix(in srgb, var(--gp-season-major) 20%, var(--gp-season-card)); }
#gp-season .gp-se-n { font-size: 12px; color: var(--gp-season-muted); line-height: 1; display: flex; align-items: center; gap: 2px; }
#gp-season .gp-se-n svg { color: var(--gp-season-major); }
#gp-season .gp-se-icon { flex: 1 1 auto; min-height: 0; display: flex; align-items: center; justify-content: center; font-size: 26px; line-height: 1; }
#gp-season .gp-se-icon > img, #gp-season .gp-se-icon > svg, #gp-season .gp-se-icon > canvas { width: 36px; height: 36px; object-fit: contain; }
#gp-season .gp-se-label { font-size: 12px; line-height: 1.15; max-width: 100%; overflow: hidden; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow-wrap: anywhere; }
#gp-season .gp-se-state { font-size: 12px; line-height: 1; min-height: 16px; display: flex; align-items: center; gap: 3px; color: var(--gp-season-muted); }
#gp-season .gp-se-cell[data-state=ready] .gp-se-state { background: var(--gp-season-accent); color: var(--gp-season-accent-ink); border-radius: 999px; padding: 3px 8px; font-weight: 800; }
#gp-season .gp-se-cell[data-state=claimed] .gp-se-state { color: var(--gp-season-accent); }
#gp-season footer { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; justify-content: space-between; }
#gp-season .gp-se-pager { display: flex; align-items: center; gap: 6px; }
#gp-season .gp-se-page { border-radius: 999px; background: var(--gp-season-card); box-shadow: inset 0 0 0 2px var(--gp-season-off); display: inline-flex; align-items: center; justify-content: center; }
#gp-season .gp-se-page[aria-disabled=true] { opacity: 0.4; cursor: default; }
#gp-season .gp-se-pageno { font-size: 13px; color: var(--gp-season-muted); white-space: nowrap; }
#gp-season .gp-se-actions { display: flex; gap: 8px; margin-left: auto; }
#gp-season .gp-se-all { border-radius: 999px; padding: 0 18px; background: var(--gp-season-accent); color: var(--gp-season-accent-ink); font-weight: 800; font-family: var(--gp-theme-display, inherit); }
#gp-season .gp-se-back { border-radius: 999px; padding: 0 18px; background: var(--gp-season-ink); color: var(--gp-season-bg); font-weight: 800; }
#gp-season .gp-se-nextseason { font-size: 13px; color: var(--gp-season-muted); }
@media (max-height: 520px) {
  #gp-season { height: 98vh; padding: 8px 12px; gap: 6px; }
  #gp-season h2 { font-size: 19px; }
  #gp-season .gp-se-nextseason { display: none; }
}
@media (prefers-reduced-motion: no-preference) { #gp-season .gp-se-pop { animation: gp-se-pop 0.25s ease-out; } }
@keyframes gp-se-pop { 50% { transform: scale(1.1); } }
`;

/** The platform's words for the screen in the player's language */
export function seasonTexts(t: (key: string, params?: Record<string, string | number>) => string): SeasonTexts {
  return {
    title: t('gp.season.title'),
    tier: (n, max) => t('gp.season.tier', { n, max }),
    xp: (xp, need) => t('gp.season.xp', { xp, need }),
    daysLeft: (n) => t('gp.season.daysLeft', { n }),
    startsIn: (n) => t('gp.season.startsIn', { n }),
    ended: t('gp.season.ended'),
    done: t('gp.season.done'),
    claim: t('gp.season.claim'),
    claimAll: (n) => t('gp.season.claimAll', { n }),
    next: (name) => t('gp.season.next', { name }),
    page: (n, max) => t('gp.season.page', { n, max }),
    back: t('gp.back'),
  };
}

function el<K extends keyof HTMLElementTagNameMap>(tag: K, cls?: string, text?: string): HTMLElementTagNameMap[K] {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text !== undefined) e.textContent = text;
  return e;
}

/**
 * The season screen, open now in `root` (a modal veil; null: document.body). host.screen('season'). The first page
 * shown holds the first tier waiting to be claimed, else the next tier to reach. Returns close() and refresh() (after
 * XP came in while it is open); it closes itself on Back and a tap outside.
 */
export function mountSeasonTrack<R>(root: HTMLElement | null, pass: SeasonPass<R>, opts: SeasonTrackOptions<R>): { el: HTMLElement; close(): void; refresh(): void } {
  const { host } = opts;
  if (!document.getElementById('gp-season-css')) {
    const style = document.createElement('style');
    style.id = 'gp-season-css';
    style.textContent = CSS;
    document.head.append(style);
  }
  const words: SeasonTexts = { ...seasonTexts((k, p) => host.t(k, p)), ...opts.texts };
  const fmt = opts.format ?? ((n: number) => String(Math.floor(n)));
  const touch = `${host.minTouchPx}px`;

  document.getElementById('gp-season-veil')?.remove();
  const veil = el('div');
  veil.id = 'gp-season-veil';
  const box = el('section');
  box.id = 'gp-season';
  box.dataset.gp = 'season';
  box.setAttribute('role', 'dialog');
  box.setAttribute('aria-modal', 'true');

  const head = el('header');
  const h = el('h2');
  const when = el('span', 'gp-se-when');
  when.dataset.gp = 'season-when';
  head.append(h, when);
  const prog = el('div', 'gp-se-progress');
  const tierText = el('span', 'gp-se-tier');
  tierText.dataset.gp = 'season-tier';
  const bar = el('div', 'gp-se-bar');
  const fill = el('i');
  bar.append(fill);
  const xpText = el('span', 'gp-se-xp');
  xpText.dataset.gp = 'season-xp';
  prog.append(tierText, bar, xpText);
  const track = el('div', 'gp-se-track');
  track.dataset.gp = 'season-track';
  const nextSeason = el('div', 'gp-se-nextseason');

  const foot = el('footer');
  const pager = el('div', 'gp-se-pager');
  const prev = el('button', 'gp-se-page');
  prev.type = 'button';
  prev.dataset.gp = 'season-prev';
  prev.append(seasonMark('prev', 20));
  const next = el('button', 'gp-se-page');
  next.type = 'button';
  next.dataset.gp = 'season-next';
  next.append(seasonMark('next', 20));
  for (const b of [prev, next]) b.style.minWidth = b.style.minHeight = touch;
  const pageNo = el('span', 'gp-se-pageno');
  pager.append(prev, pageNo, next);
  const actions = el('div', 'gp-se-actions');
  const all = el('button', 'gp-se-all');
  all.type = 'button';
  all.dataset.gp = 'season-claim-all';
  const back = el('button', 'gp-se-back', words.back);
  back.type = 'button';
  back.dataset.gp = 'season-back';
  for (const b of [all, back]) b.style.minHeight = touch;
  actions.append(all, back);
  foot.append(pager, actions);
  box.append(head, prog, track, nextSeason, foot);
  veil.append(box);

  let page = -1;
  let per = 1;
  let st: SeasonState<R> = pass.state();

  const cell = (x: SeasonTier<R>): HTMLElement => {
    const c = el('button', 'gp-se-cell');
    c.type = 'button';
    c.dataset.gpTier = String(x.tier);
    c.dataset.state = x.state;
    if (x.major) c.dataset.major = '';
    if (x.next) c.dataset.next = '';
    if (x.state !== 'ready') c.setAttribute('aria-disabled', 'true');
    const n = el('span', 'gp-se-n');
    if (x.major) n.append(seasonMark('star', 12, true));
    n.append(document.createTextNode(String(x.tier)));
    const v = x.reward === null ? null : opts.view(x.reward, x.tier);
    const icon = el('span', 'gp-se-icon');
    if (v?.icon !== undefined) icon.append(iconNode(v.icon));
    const label = el('span', 'gp-se-label', v?.label ?? '');
    const state = el('span', 'gp-se-state');
    if (x.state === 'claimed') state.append(seasonMark('check', 16));
    else if (x.state === 'locked') state.append(seasonMark('lock', 14));
    else state.textContent = words.claim;
    c.setAttribute('aria-label', `${words.tier(x.tier, st.tiers)}${v ? `: ${v.label}` : ''}`);
    c.append(n, icon, label, state);
    c.addEventListener('click', () => {
      if (x.state !== 'ready') return;
      const r = pass.claim(x.tier);
      if (r === null) return;
      opts.onClaim([{ season: st.season.id, tier: x.tier, reward: r }]);
      draw();
      track.querySelector(`[data-gp-tier="${x.tier}"]`)?.classList.add('gp-se-pop');
    });
    return c;
  };

  /** How many tier cards fit the track now: columns × rows of at least CELL_W × CELL_H */
  const fit = (count: number) => {
    const w = track.clientWidth;
    const hh = track.clientHeight;
    const cols = Math.max(1, Math.floor((w + GAP) / (CELL_W + GAP)));
    const rows = Math.max(1, Math.floor((hh + GAP) / (CELL_H + GAP)));
    // The rows a page uses (all of them, or fewer when the whole track fits), each at most 1.6 × the smallest card
    const used = Math.min(rows, Math.max(1, Math.ceil(count / cols)));
    const rowH = Math.min(CELL_H * 1.6, (hh - GAP * (used - 1)) / used);
    track.style.gridTemplateColumns = `repeat(${cols}, minmax(0, 1fr))`;
    track.style.gridAutoRows = `${Math.max(CELL_H, Math.floor(rowH))}px`;
    return cols * rows;
  };

  const draw = () => {
    st = pass.state();
    h.textContent = opts.name ? opts.name(st.season) : words.title;
    box.setAttribute('aria-label', h.textContent);
    when.textContent = st.phase === 'running' ? words.daysLeft(st.daysLeft) : st.phase === 'ended' ? words.ended : words.startsIn(st.startsIn);
    tierText.textContent = words.tier(st.tier, st.tiers);
    fill.style.width = `${Math.round(st.share * 100)}%`;
    xpText.textContent = st.done ? words.done : words.xp(fmt(st.into), fmt(st.need));
    nextSeason.textContent = st.next && st.phase !== 'upcoming' ? words.next(opts.name ? opts.name(st.next) : st.next.id) : '';
    nextSeason.hidden = !nextSeason.textContent;
    // Everything around the track first (the footer wraps on a phone: its height is the track's to give), then the fit;
    // the pager hidden only when one page holds the track — hiding it only makes room
    // Two or more waiting, or one carried from an ended season (it has no card on this track to tap)
    all.hidden = st.claimable < 2 && st.carried === 0;
    all.textContent = words.claimAll(st.claimable);
    pager.hidden = false;
    const n = st.track.length;
    per = fit(n);
    if (n <= per) {
      pager.hidden = true;
      per = fit(n);
    }
    const pages = Math.max(1, Math.ceil(n / per));
    if (page < 0) {
      const focus = st.track.find((x) => x.state === 'ready') ?? st.track.find((x) => x.next) ?? st.track[st.track.length - 1];
      page = Math.floor((focus.tier - 1) / per);
    }
    page = Math.max(0, Math.min(pages - 1, page));
    track.replaceChildren(...st.track.slice(page * per, page * per + per).map(cell));
    pageNo.textContent = `${page + 1}/${pages}`;
    pageNo.setAttribute('aria-label', words.page(page + 1, pages));
    prev.setAttribute('aria-disabled', String(page === 0));
    next.setAttribute('aria-disabled', String(page === pages - 1));
  };

  prev.addEventListener('click', () => {
    if (page > 0) (page--, draw());
  });
  next.addEventListener('click', () => {
    page++;
    draw();
  });
  all.addEventListener('click', () => {
    const claims = pass.claimAll();
    if (claims.length) opts.onClaim(claims);
    draw();
  });

  let open = true;
  let closed = () => {};
  // The page holding the same first card after a resize (a phone turned), not the same page number
  const onResize = () => {
    const first = page * per;
    per = fit(st.track.length);
    page = Math.floor(first / per);
    draw();
  };
  const close = () => {
    if (!open) return;
    open = false;
    removeEventListener('resize', onResize);
    veil.remove();
    closed();
  };
  const dismiss = () => {
    close();
    opts.onClose?.();
  };
  back.addEventListener('click', dismiss);
  veil.addEventListener('click', (e) => {
    if (e.target === veil) dismiss();
  });
  addEventListener('resize', onResize);

  (root ?? document.body).append(veil);
  closed = cardOpened('season', veil); // one card at a time (cards.ts)
  draw();
  host.screen('season');
  return { el: box, close, refresh: draw };
}
