// gp story: forming a starting story file for a depth, never over an existing one, "no story needed" where none is;
// and the story checks gp validate adds once game.yaml declares a story file.

import { cpSync, existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { afterAll, describe, expect, it } from 'vitest';
import { validateStory } from '@gp/core/story';
import { loadYaml, type GameSpecInput } from '@gp/spec';
import { checkGame } from '../src/game.ts';
import { locateGame, ROOT } from '../src/paths.ts';
import { loadStoryFile, metaBlockIn, storyCommand, writeStoryStrings, type StoryCommandOptions } from '../src/story.ts';
import { uniquenessReport } from '../src/uniqueness.ts';

const tmp = mkdtempSync(join(tmpdir(), 'gp-story-'));
afterAll(() => rmSync(tmp, { recursive: true, force: true }));

/** The code example as a game of its own, with extra lines appended to its game.yaml */
function game(name: string, yamlExtra = '', tags?: string) {
  const dir = join(tmp, name);
  cpSync(join(ROOT, 'docs/examples/code'), dir, { recursive: true });
  rmSync(join(dir, 'qa'), { recursive: true, force: true });
  let yaml = readFileSync(join(dir, 'game.yaml'), 'utf8');
  if (tags) yaml = yaml.replace('tags: [Casual, Arcade]', `tags: [${tags}]`);
  writeFileSync(join(dir, 'game.yaml'), yaml.trimEnd() + '\n' + yamlExtra);
  return locateGame(dir);
}

const write = (file: string, text: string) => {
  mkdirSync(dirname(file), { recursive: true });
  writeFileSync(file, text);
};
function run(loc: ReturnType<typeof game>, o: StoryCommandOptions = {}) {
  const spec = loadYaml(readFileSync(loc.file, 'utf8')).data as GameSpecInput;
  const res = storyCommand(loc, spec, o, write);
  return { ...res, text: res.lines.join('\n') };
}

describe('gp story', () => {
  it('a game that needs no story is told so, and nothing is written', () => {
    const loc = game('plain');
    const r = run(loc);
    expect(r.code).toBe(0);
    expect(r.text).toMatch(/Recommended depth: premise or barks/);
    expect(r.text).toMatch(/No story needed for this game/);
    expect(r.wrote).toBeNull();
    expect(existsSync(join(loc.dir, 'story.ts'))).toBe(false);
  });
  it('depth none: "no story needed", exit 0, even with --write', () => {
    const loc = game('none', 'story: { depth: none }\n');
    const r = run(loc, { write: true });
    expect(r.code).toBe(0);
    expect(r.text).toMatch(/No story needed for this game \(depth none\)/);
    expect(r.wrote).toBeNull();
  });
  it('an idle game is told it gains from a story; --write forms chapters, the default there', () => {
    const loc = game('idle', '', 'Clicker, Idle');
    expect(run(loc).text).toMatch(/gains from a story/);
    const r = run(loc, { write: true });
    expect(r.wrote).toBe(join(loc.dir, 'story.ts'));
    expect(r.section).toEqual({ depth: 'chapters', premise: expect.stringMatching(/^TODO/), file: 'story.ts' });
    const loaded = loadStoryFile(join(loc.dir, 'story.ts'));
    expect('exports' in loaded).toBe(true);
    const def = (loaded as { exports: { STORY: Parameters<typeof validateStory>[0] } }).exports.STORY;
    expect(def.chapters).toHaveLength(6);
    expect(validateStory(def).filter((i) => i.severity === 'error')).toEqual([]);
    // What is left is the to-do list: TODO lines, and no error
    expect(r.text).toMatch(/To correct/);
    expect(r.text).toMatch(/W_STORY_TODO/);
    expect(r.code).toBe(0);
  });
  it('never overwrites an existing file without --force', () => {
    const loc = game('keep', 'story: { depth: barks, file: story.ts }\n');
    writeFileSync(join(loc.dir, 'story.ts'), "export const BARKS = { hit: ['Ow.'] };\n");
    const r = run(loc, { write: true });
    expect(r.code).toBe(1);
    expect(r.text).toMatch(/exists: not overwritten/);
    expect(readFileSync(join(loc.dir, 'story.ts'), 'utf8')).toBe("export const BARKS = { hit: ['Ow.'] };\n");
    expect(r.text).toMatch(/only 1 barks/); // the checks run on the file as it is
    const forced = run(loc, { write: true, force: true });
    expect(forced.wrote).toBe(join(loc.dir, 'story.ts'));
    expect(readFileSync(join(loc.dir, 'story.ts'), 'utf8')).toMatch(/export const BARKS = \{/);
  });
  it('--write --force reports on the file it wrote, not the one it replaced (no module cache)', () => {
    const loc = game('forced', 'story: { depth: barks, file: story.ts }\n');
    writeFileSync(join(loc.dir, 'story.ts'), "export const CAST = { mo: { name: 'Mo' } };\nexport const BARKS = { hit: ['Ow.', 'Hey.'] };\n");
    expect(run(loc).text).toMatch(/story\.ts: 2 barks/); // loaded once: it would stay cached
    const r = run(loc, { depth: 'chapters', write: true, force: true });
    expect(r.wrote).toBe(join(loc.dir, 'story.ts'));
    expect(r.text).toMatch(/story\.ts: 6 chapters/);
    expect(r.text).not.toMatch(/no StoryDef|W_STORY_FORMAT|only 0 chapters|cast: Mo/);
    // A file it imports is read fresh too
    writeFileSync(join(loc.dir, 'lines.ts'), "export const HIT = ['One.'];\n");
    writeFileSync(join(loc.dir, 'story.ts'), "import { HIT } from './lines';\nexport const BARKS = { hit: HIT };\n");
    expect((loadStoryFile(join(loc.dir, 'story.ts')) as { exports: { BARKS: { hit: string[] } } }).exports.BARKS.hit).toEqual(['One.']);
    writeFileSync(join(loc.dir, 'lines.ts'), "export const HIT = ['One.', 'Two.'];\n");
    expect((loadStoryFile(join(loc.dir, 'story.ts')) as { exports: { BARKS: { hit: string[] } } }).exports.BARKS.hit).toEqual(['One.', 'Two.']);
  });
  it('a declared depth whose file does not exist yet is formed without --write', () => {
    const loc = game('declared', 'story: { depth: barks, premise: "A cell swims home through a body at war.", file: story.ts }\n');
    const r = run(loc);
    expect(r.wrote).toBe(join(loc.dir, 'story.ts'));
    expect(r.section).toBeNull(); // game.yaml already says it
    const text = readFileSync(join(loc.dir, 'story.ts'), 'utf8');
    expect(text).toMatch(/new Bag\(BARKS\[event\]\.length\)/); // the Bag and cooldown wiring, as a comment
    expect(text).toMatch(/barkCooldown = 6/);
    expect(text).not.toMatch(/^import \{/m); // data only
  });
  it('branching: a flag and two endings; --out writes elsewhere and leaves game.yaml alone', () => {
    const loc = game('branch', '', 'Idle');
    const out = join(tmp, 'elsewhere', 'story.ts');
    const r = run(loc, { depth: 'branching', write: true, out });
    expect(r.wrote).toBe(out);
    expect(r.section).toBeNull();
    const content = JSON.parse(JSON.stringify(r.json)).content as { endings: string[]; consequences: string[] };
    expect(content.endings).toEqual(['together', 'alone']);
    expect(content.consequences).toEqual(['helped']);
    expect(r.text).not.toMatch(/W_STORY_THIN/);
  });
  it('an unknown depth is refused', () => {
    expect(run(game('bad'), { depth: 'saga' }).code).toBe(1);
  });
});

describe('gp validate reads the story file', () => {
  it('a missing file is an error; a formed one has only warnings', () => {
    const loc = game('validate', 'story: { depth: chapters, premise: "A cell swims home through a body at war.", file: story.ts }\n');
    expect(checkGame(loc, 'dev').issues.map((i) => i.code)).toContain('E_STORY_FILE');
    run(loc);
    const r = checkGame(loc, 'dev');
    expect(r.ok).toBe(true);
    const story = r.issues.filter((i) => i.path[0] === 'story');
    expect(story.map((i) => i.code)).toEqual(expect.arrayContaining(['W_STORY_TODO', 'W_STORY_DEPTH', 'W_STORY_SKIP'])); // no meta, no dialogue in the example
    expect(story.every((i) => i.line === readFileSync(loc.file, 'utf8').split('\n').findIndex((l) => l.startsWith('story:')) + 1)).toBe(true);
  });
  it('a story file that runs code on import is an error with the fix', () => {
    const loc = game('values', 'story: { depth: barks, file: story.ts }\n');
    writeFileSync(join(loc.dir, 'story.ts'), "import { nope } from './missing';\nexport const BARKS = { hit: [nope] };\n");
    const i = checkGame(loc, 'dev').issues.find((x) => x.code === 'E_STORY_FILE')!;
    expect(i.message).toMatch(/can't be loaded/);
    expect(i.fix).toMatch(/import type/);
  });
  it('gp story --strings: the lines, choices and barks become strings keys gp translate lists; validate keeps them in step', () => {
    const loc = game('strings', 'story: { depth: barks, file: story.ts }\n');
    writeFileSync(join(loc.dir, 'story.ts'), "export const BARKS = { hit: ['Ouch!', 'Not again!'], 'run-start': ['Here we go.'] };\n");
    const codes = () => checkGame(loc, 'dev').issues;
    // English only in a game of ten languages: told how
    expect(codes().find((i) => i.code === 'I_STORY_STRINGS')?.message).toMatch(/3 texts are English only/);
    const r = writeStoryStrings(loc, 'story.ts', write);
    expect(r).toMatchObject({ keys: 3 });
    const en = readFileSync(join(loc.dir, 'strings/en.yaml'), 'utf8');
    expect(en).toContain('bark.hit.2: Not again!');
    expect(en).toMatch(/^seconds:/m); // the game's own texts stay
    const after = codes();
    expect(after.map((i) => i.code)).not.toContain('I_STORY_STRINGS');
    expect(after.map((i) => i.code)).not.toContain('W_STORY_STRINGS');
    // The other languages now miss them: gp translate lists them
    expect(after.filter((i) => i.code === 'E_I18N_MISSING').map((i) => i.message).join('\n')).toMatch(/bark\.hit\.1/);
    // The story file changes, strings/en.yaml doesn't: out of step
    writeFileSync(join(loc.dir, 'story.ts'), "export const BARKS = { hit: ['Ouch!', 'Not again!', 'Ow!'], 'run-start': ['Off we go.'] };\n");
    const w = codes().find((i) => i.code === 'W_STORY_STRINGS')!;
    expect(w.message).toMatch(/1 missing \(bark\.hit\.3\); 1 changed \(bark\.run-start\.1\)/);
    // Run again: replaced, nothing doubled
    writeStoryStrings(loc, 'story.ts', write);
    expect(codes().map((i) => i.code)).not.toContain('W_STORY_STRINGS');
    expect(readFileSync(join(loc.dir, 'strings/en.yaml'), 'utf8').match(/bark\.hit\.1/g)).toHaveLength(1);
  });
  it('meta progression: the progression blocks count, a comment naming one does not', () => {
    const chapters = 'story: { depth: chapters, premise: "A cell swims home through a body at war.", file: story.ts }\n';
    const depthWarning = (loc: ReturnType<typeof game>) => checkGame(loc, 'dev').issues.filter((i) => i.code === 'W_STORY_DEPTH').map((i) => i.message);
    const noMeta = game('meta-none', chapters);
    run(noMeta);
    writeFileSync(join(noMeta.dir, 'notes.ts'), '// TODO: an UpgradeShop, a Roster or new Tiers() later\n/* new PactTree(...) */\nexport const X = 1;\n');
    expect(depthWarning(noMeta).join()).toMatch(/meta progression/);
    for (const [name, src] of [
      ['roster', "import { Roster } from '@gp/core';\nexport const R = new Roster<'a'>(['a']);\n"],
      ['tiers', "export const T = new Tiers(['a']);\n"],
      ['pact', "import { PactTree as Tree, type PactSave } from '@gp/core';\nexport const make = () => Tree;\n"],
      ['choices', "import { RunChoices } from '@gp/core';\n"],
    ]) {
      const loc = game(`meta-${name}`, chapters);
      run(loc);
      writeFileSync(join(loc.dir, 'progress-blocks.ts'), src);
      expect(depthWarning(loc).join(), name).not.toMatch(/meta progression/);
    }
    expect(metaBlockIn("import type { Roster } from '@gp/core';\nlet r: Roster<'a'>;\n")).toBeNull(); // a type is not a block in use
    expect(metaBlockIn("import { type Tiers, Bag } from '@gp/core';\n")).toBeNull();
    expect(metaBlockIn("const url = 'https://x.io'; const s = new UpgradeShop(defs);")).toBe('UpgradeShop');
    expect(metaBlockIn('mountUpgradeShop(root, opts);')).toBe('mountUpgradeShop');
  });
  it('an own premise and characters count a little toward uniqueness', () => {
    const loc = game('unique', 'story: { depth: barks, premise: "A cell swims home through a body at war.", file: story.ts }\n');
    writeFileSync(join(loc.dir, 'story.ts'), "export const CAST = { cell: { name: 'Cyto' } };\nexport const BARKS = { hit: ['Ow.'] };\n");
    const r = checkGame(loc, 'dev');
    const s = uniquenessReport(loc, r.game!, r.issues).signals.find((x) => x.name.startsWith('An own premise'))!;
    expect([s.points, s.max]).toEqual([5, 5]);
  });
});
