import { describe, expect, it } from 'vitest';
import { formatAmount, UpgradeShop } from '../src/upgrades.ts';

// All eight upgrades of Yeet the Gnome (QmaCyber/game4, data.ts), whose prices must be reproduced to the coin
const YEET = [
  { id: 'power', max: 12, baseCost: 9, growth: 1.5 },
  { id: 'bounce', max: 8, baseCost: 18, growth: 1.62 },
  { id: 'rocket', max: 8, baseCost: 19, growth: 1.8 },
  { id: 'aero', max: 8, baseCost: 28, growth: 1.66 },
  { id: 'wings', max: 6, baseCost: 71, growth: 1.85 },
  { id: 'thrust', max: 6, baseCost: 106, growth: 1.85, requires: 'rocket' },
  { id: 'magnet', max: 6, baseCost: 24, growth: 1.8 },
  { id: 'luck', max: 6, baseCost: 53, growth: 1.9 },
] as const;
type YId = (typeof YEET)[number]['id'];
const shop = new UpgradeShop<YId>(YEET);

describe('upgrade costs', () => {
  it('reproduce Yeet the Gnome to the coin: round(baseCost × growth^level)', () => {
    for (const u of YEET) for (let l = 0; l < u.max; l++) expect(shop.cost(u.id, l)).toBe(Math.round(u.baseCost * Math.pow(u.growth, l)));
  });
  it('strictly increase even where rounding would repeat a price', () => {
    const s = new UpgradeShop([{ id: 'x', max: 30, baseCost: 1, growth: 1.05 }]);
    const c = Array.from({ length: 30 }, (_, l) => s.cost('x', l)!);
    expect(c.slice(0, 5)).toEqual([1, 2, 3, 4, 5]);
    for (let l = 1; l < 30; l++) expect(c[l]).toBeGreaterThan(c[l - 1]);
    expect(s.cost('x', 30)).toBeNull();
  });
  it('never go below 1, and huge economies fail fast instead of losing precision', () => {
    expect(new UpgradeShop([{ id: 'x', max: 3, baseCost: 0.2, growth: 1 }]).cost('x', 0)).toBe(1);
    expect(() => new UpgradeShop([{ id: 'x', max: 400, baseCost: 10, growth: 1.15 }])).toThrow(/2\^53/);
  });
  it('bulk price = the sum of single prices, and "max" is really the most coins can buy', () => {
    const lv = shop.noLevels();
    expect(shop.costOf('power', 0, 3)).toBe(9 + 14 + 20);
    expect(shop.costOf('power', 10, 3)).toBeNull(); // past max 12
    for (const coins of [0, 8, 9, 22, 23, 43, 1000, 1e6]) {
      const n = shop.affordableCount('power', lv, coins);
      expect(shop.costOf('power', 0, n)!).toBeLessThanOrEqual(coins);
      if (n < 12) expect(shop.costOf('power', 0, n + 1)!).toBeGreaterThan(coins);
    }
    const ten = shop.buy('power', lv, 1e6, 10)!;
    let one = { levels: lv, coins: 1e6 };
    for (let i = 0; i < 10; i++) one = shop.buy('power', one.levels, one.coins)!;
    expect(ten.levels).toEqual(one.levels);
    expect(ten.coins).toBe(one.coins);
    expect(shop.buy('power', lv, 40, 10)).toBeNull(); // a fixed count buys exactly that many or nothing
    expect(shop.buy('power', lv, 43, 'max')!.bought).toBe(3);
  });
});

describe('states and saves', () => {
  it('locked until the requirement, affordable, too expensive, maxed', () => {
    const lv = shop.noLevels();
    expect(shop.state('thrust', lv, 1e9)).toBe('locked');
    expect(shop.affordableCount('thrust', lv, 1e9)).toBe(0);
    expect(shop.state('power', lv, 8)).toBe('too-expensive');
    expect(shop.state('power', lv, 9)).toBe('affordable');
    expect(shop.state('power', { ...lv, power: 12 }, 1e9)).toBe('maxed');
    expect(shop.state('thrust', { ...lv, rocket: 1 }, 106)).toBe('affordable');
  });
  it('a tampered or old save cannot make prices negative or skip levels', () => {
    const bad = { power: -3, bounce: 2.7, rocket: NaN, aero: 99, wings: '4' as unknown as number } as Record<YId, number>;
    expect(shop.sanitize(bad)).toEqual({ power: 0, bounce: 2, rocket: 0, aero: 8, wings: 0, thrust: 0, magnet: 0, luck: 0 });
    expect(shop.nextCost('power', bad)).toBe(9);
    expect(shop.state('aero', bad, 1e9)).toBe('maxed');
  });
  it('buy never changes its inputs', () => {
    const lv = shop.noLevels();
    const r = shop.buy('power', lv, 20)!;
    expect(r.levels.power).toBe(1);
    expect(r.coins).toBe(11);
    expect(lv.power).toBe(0);
  });
});

describe('the shop screen and bots', () => {
  const withValues = new UpgradeShop([
    { id: 'speed', max: 10, baseCost: 10, growth: 1.5, value: (l: number) => 21 + 3 * l },
    { id: 'drag', max: 8, baseCost: 30, growth: 1.66, value: (l: number) => 0.0042 * 0.86 ** l },
    { id: 'gold', max: 5, baseCost: 500, growth: 2, requires: 'speed' },
  ]);
  it('one row per upgrade with price, progress, now → next, runs to afford', () => {
    const rows = withValues.view({ speed: 2 }, 12, { incomePerRun: 5 });
    const speed = rows.find((r) => r.id === 'speed')!;
    expect(speed).toMatchObject({ level: 2, state: 'too-expensive', count: 1, cost: 23, canBuy: false, now: 27, next: 30, runsToAfford: 3 });
    expect(speed.progress).toBeCloseTo(12 / 23);
    expect(rows.find((r) => r.id === 'gold')).toMatchObject({ state: 'too-expensive', requires: 'speed' });
    expect(withValues.view({}, 1000).find((r) => r.id === 'gold')!.state).toBe('locked');
  });
  it('buy ×10 / Next / Max on the rows: the label is the total for that many', () => {
    const max = withValues.view({}, 100, { amount: 'max' }).find((r) => r.id === 'speed')!;
    expect(max.count).toBe(withValues.affordableCount('speed', {}, 100));
    expect(max.cost).toBe(withValues.costOf('speed', 0, max.count));
    expect(max.canBuy).toBe(true);
    const ten = withValues.view({}, 100, { amount: 10 }).find((r) => r.id === 'speed')!;
    expect(ten).toMatchObject({ count: 10, cost: withValues.costOf('speed', 0, 10), canBuy: false, state: 'affordable' });
    expect(ten.next).toBe(21 + 3 * 10);
  });
  it('"Next" buys up to the next milestone; refunds round-trip exactly', () => {
    const m = new UpgradeShop([{ id: 'stand', max: 100, baseCost: 4, growth: 1.07, milestones: [25, 50, 100] }, { id: 'x', max: 3, baseCost: 5, growth: 2, requires: 'stand' }]);
    expect(m.view({ stand: 20 }, 1e6, { amount: 'next' })[0].count).toBe(5);
    const b = m.buy('stand', { stand: 20 }, 1e6, 'next')!;
    expect(b.levels.stand).toBe(25);
    const back = m.refund('stand', b.levels, b.coins, 5)!;
    expect(back.levels.stand).toBe(20);
    expect(back.coins).toBe(1e6);
    // The last level of something another upgrade needs can't be refunded while that one is owned
    expect(m.refund('stand', { stand: 1, x: 1 }, 0)).toBeNull();
    const all = m.refundAll({ stand: 25, x: 2 }, 7);
    expect(all.levels).toEqual({ stand: 0, x: 0 });
    expect(all.coins).toBe(7 + m.costOf('stand', 0, 25)! + m.costOf('x', 0, 2)!);
    expect(m.affordableIds({}, 4)).toEqual(['stand']);
  });
  it('marks the best value for money among affordable rows', () => {
    const rows = withValues.view({}, 1000);
    expect(rows.filter((r) => r.best)).toHaveLength(1);
    // With the game's own score: the upgrade that adds most per coin
    const score = (l: Record<string, number>) => (l.speed ?? 0) * 1 + (l.drag ?? 0) * 100;
    expect(withValues.view({}, 1000, { score }).find((r) => r.best)!.id).toBe('drag');
  });
  it('bots: cheapest first vs best value first', () => {
    const cheap = shop.spendLikeAPlayer(shop.noLevels(), 60);
    expect(cheap.bought).toEqual(['power', 'power', 'bounce', 'rocket']); // 9 + 14 + 18 + 19 = 60
    expect(cheap.coins).toBe(0);
    const score = (l: Record<YId, number>) => 3 * l.power + 10 * l.rocket;
    const smart = shop.spendBestValue(shop.noLevels(), 60, score);
    expect(smart.bought[0]).toBe('rocket'); // 10 per 19 coins beats 3 per 9
    expect(shop.anyAffordable(cheap.levels, cheap.coins)).toBe(false);
  });
  it('totals for the balance plan', () => {
    expect(shop.progress(shop.noLevels())).toBe(0);
    expect(shop.progress(shop.sanitize({ power: 99, bounce: 99, rocket: 99, aero: 99, wings: 99, thrust: 99, magnet: 99, luck: 99 }))).toBe(1);
    expect(shop.totalCost()).toBe(YEET.reduce((s, u) => s + (shop.costOf(u.id, 0, u.max) ?? 0), 0));
  });
  it('bad definitions fail fast', () => {
    expect(() => new UpgradeShop([{ id: 'a', max: 0, baseCost: 1, growth: 1 }])).toThrow();
    expect(() => new UpgradeShop([{ id: 'a', max: 1.5, baseCost: 1, growth: 1 }])).toThrow();
    expect(() => new UpgradeShop([{ id: 'a', max: 1, baseCost: 1, growth: 0.9 }])).toThrow();
    expect(() => new UpgradeShop([{ id: 'a', max: 1, baseCost: 1, growth: 1, requires: 'b' }])).toThrow();
    expect(() => new UpgradeShop([{ id: 'a', max: 1, baseCost: 1, growth: 1 }, { id: 'a', max: 1, baseCost: 1, growth: 1 }])).toThrow();
  });
});

describe('formatAmount', () => {
  it('three significant digits with suffixes', () => {
    expect([0, 7, 999, 1000, 1234, 12345, 123456, 1234567, 1.5e9, 2e12].map((n) => formatAmount(n))).toEqual(['0', '7', '999', '1.00K', '1.23K', '12.3K', '123K', '1.23M', '1.50B', '2.00T']);
  });
  it('balances round down, prices round up — never "1.00K vs 1.00K" when you can\'t afford it', () => {
    expect(formatAmount(1000, 'down')).toBe('1.00K');
    expect(formatAmount(1005, 'up')).toBe('1.01K');
    expect(formatAmount(999.9, 'down')).toBe('999');
    expect(formatAmount(999_600, 'up')).toBe('1.00M');
    expect(formatAmount(999_600, 'down')).toBe('999K');
  });
  it('binary noise and huge numbers', () => {
    expect(formatAmount(1.23e6)).toBe('1.23M');
    expect(formatAmount(4.56e40)).toBe('4.56e40');
    expect(formatAmount(Infinity)).toBe('∞');
    expect(formatAmount(-1500)).toBe('−1.50K');
  });
  it("the game's own locks (story flags): locked with its reason, can't be bought until the game opens it", () => {
    const flags = { book: false };
    const shop = new UpgradeShop([{ id: 'golem', max: 3, baseCost: 10, growth: 2 }], { lock: (id) => (id === 'golem' && !flags.book ? 'Find the notebook' : null) });
    expect(shop.state('golem', {}, 1000)).toBe('locked');
    expect(shop.buy('golem', {}, 1000)).toBeNull();
    expect(shop.view({}, 1000)[0]).toMatchObject({ state: 'locked', lockReason: 'Find the notebook', canBuy: false });
    flags.book = true;
    expect(shop.state('golem', {}, 1000)).toBe('affordable');
    expect(shop.view({}, 1000)[0].lockReason).toBeUndefined();
  });
});
