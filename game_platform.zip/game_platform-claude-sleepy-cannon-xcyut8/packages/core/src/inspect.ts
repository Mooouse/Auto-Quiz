// Inspect plates: what a thing on the board does, without a rules page — a mouse hovers it, a finger holds it for
// 380 ms and a plate opens above the finger (where the finger doesn't cover it). The hold never picks or presses the
// thing; a short tap still does. Velvet Domino Rogue wrote it by hand (main.ts:2435-2510) for its bones, its table and
// the round's event, after the reviewers couldn't tell what a tile did on a phone.
//
//   const plates = inspect(canvas, (x, y) => {               // x, y: CSS px inside the target
//     const bone = boneAt(x, y);
//     return bone ? { title: host.t(`bone.${bone.id}`), text: host.t(`bone.${bone.id}.text`), kind: bone.rarity } : null;
//   }, { host, tips, onTap: (x, y) => pick(x, y) });          // a short tap: the game's own (a pick, a press)
//
// - A mouse: the plate after `hoverMs` (280) of resting on a thing, gone when the mouse moves off it or leaves.
// - A finger: held still (≤ 14 px) for `holdMs` (380), the plate opens above the finger and a short vibration says so
//   (`vibrate: false` turns it off); lifting the finger closes it, and that lift is not a tap: the pointerup and the click
//   that follow are kept from the game (and onTap isn't called). A tap shorter than the hold goes to onTap.
// - The plate stays on the screen: kept inside the viewport, beside the point, never under the finger.
// - The first time a touch player taps a thing that has a plate, a hint says "Hold to read" (once, via `tips`).
// Themeable: --gp-plate-bg, -ink, -muted, -accent, -radius, -font on #gp-plate (the shared --gp-theme-* first); a
// `kind` is data-kind on the plate (`#gp-plate[data-kind=rare] { --gp-plate-accent: … }`).

import type { Hints } from './hints.ts';
import type { GameHost } from './host.ts';
import { FONT_FALLBACK } from './i18n.ts';
import { iconOf, injectCss, type UiIcon } from './ui-kit.ts';

/** What a plate says */
export interface InspectInfo {
  title: string;
  text?: string;
  /** A tag for the plate's look (data-kind): a rarity, 'enemy', 'rule' */
  kind?: string;
  icon?: UiIcon;
  /** More of the game's own (a stat row, a small picture) under the text */
  extra?: HTMLElement[];
}

export interface InspectOptions {
  /** The platform's words (gp.inspect.hold) in the player's language */
  host?: Pick<GameHost, 't'>;
  /** The hints of the game: the first-time "Hold to read" goes through them (one hint at a time, learned once) */
  tips?: Hints;
  /** The words of that hint (default gp.inspect.hold); false: no hint */
  hint?: string | false;
  /** A finger's hold before the plate (default 380 ms) */
  holdMs?: number;
  /** A mouse's rest before the plate (default 280 ms) */
  hoverMs?: number;
  /** A short vibration when a held plate opens (default true; ms: 8) */
  vibrate?: boolean | number;
  /** A finger's short tap (not a hold): the game's pick or press, at the point inside the target */
  onTap?(x: number, y: number, e: PointerEvent): void;
  /** Plates only while this is true (default always): the game's play state */
  enabled?(): boolean;
  /** Where the plate goes (default document.body) */
  root?: HTMLElement;
}

export interface Inspector {
  /** The plate on screen (its info), or null */
  readonly open: InspectInfo | null;
  /** A finger is down and may become a hold: a game acting on pointerdown should wait for onTap */
  readonly pressing: boolean;
  close(): void;
  destroy(): void;
}

const CSS = `
:where(#gp-plate) { --gp-plate-bg: var(--gp-theme-bg, rgba(16, 22, 36, 0.96)); --gp-plate-ink: var(--gp-theme-ink, #f2f6ff); --gp-plate-muted: var(--gp-theme-muted, #b3bfd4);
  --gp-plate-accent: var(--gp-theme-accent, #ffd166); --gp-plate-radius: 14px; --gp-plate-font: var(--gp-theme-font, ${FONT_FALLBACK}); }
#gp-plate { position: fixed; z-index: 35; left: 0; top: 0; box-sizing: border-box; max-width: min(320px, calc(100vw - 16px)); padding: 10px 12px;
  border-radius: var(--gp-plate-radius); background: var(--gp-plate-bg); color: var(--gp-plate-ink); font: 600 14px/1.3 var(--gp-plate-font);
  border-top: 3px solid var(--gp-plate-accent); box-shadow: 0 8px 26px rgba(0, 0, 0, 0.45); pointer-events: none; text-align: left; }
#gp-plate .gp-pl-head { display: flex; align-items: center; gap: 8px; }
#gp-plate .gp-pl-head > img, #gp-plate .gp-pl-head > canvas, #gp-plate .gp-pl-head > svg { width: 28px; height: 28px; object-fit: contain; flex: none; }
#gp-plate b { font-size: 16px; color: var(--gp-plate-accent); }
#gp-plate p { margin: 4px 0 0; color: var(--gp-plate-ink); }
`;

const SLOP = 14;

/** Plates over `target` (a canvas, a board element): `at(x, y)` says what is there (x, y: CSS px inside the target) */
export function inspect(target: HTMLElement, at: (x: number, y: number, e: PointerEvent) => InspectInfo | null, opts: InspectOptions = {}): Inspector {
  injectCss('gp-plate-css', CSS);
  const holdMs = opts.holdMs ?? 380;
  const hoverMs = opts.hoverMs ?? 280;
  const enabled = () => opts.enabled?.() ?? true;
  const local = (e: PointerEvent) => {
    const r = target.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  };

  let plate: HTMLElement | null = null;
  let info: InspectInfo | null = null;
  let hoverTimer: ReturnType<typeof setTimeout> | null = null;
  let hold: { id: number; x: number; y: number; cx: number; cy: number; timer: ReturnType<typeof setTimeout>; shown: boolean } | null = null;
  /** A pointer whose lift belongs to a hold: its pointerup and click are kept from the game */
  let swallow: number | null = null;
  let swallowClickUntil = 0;
  let hinted = false;

  const close = () => {
    plate?.remove();
    plate = null;
    info = null;
  };

  /** The plate beside (cx, cy), inside the viewport; a finger's goes above it */
  const show = (cx: number, cy: number, i: InspectInfo, finger: boolean) => {
    close();
    const p = document.createElement('div');
    p.id = 'gp-plate';
    p.dataset.gp = 'plate';
    p.setAttribute('role', 'tooltip');
    if (i.kind) p.dataset.kind = i.kind;
    const head = document.createElement('div');
    head.className = 'gp-pl-head';
    if (i.icon !== undefined) head.append(iconOf(i.icon));
    const b = document.createElement('b');
    b.textContent = i.title;
    head.append(b);
    p.append(head);
    if (i.text) {
      const t = document.createElement('p');
      t.textContent = i.text;
      p.append(t);
    }
    for (const x of i.extra ?? []) p.append(x);
    (opts.root ?? document.body).append(p);
    const w = p.offsetWidth;
    const h = p.offsetHeight;
    const gap = finger ? 44 : 18;
    const left = Math.max(8, Math.min(innerWidth - w - 8, cx - w / 2));
    const above = cy - h - gap;
    const below = cy + gap;
    // A finger: above it if it fits, else below; a mouse: below the pointer if it fits, else above
    const top = finger ? (above >= 8 ? above : Math.min(innerHeight - h - 8, below)) : below + h <= innerHeight - 8 ? below : Math.max(8, above);
    p.style.left = `${Math.round(left)}px`;
    p.style.top = `${Math.round(Math.max(8, top))}px`;
    plate = p;
    info = i;
  };

  const hintOnce = () => {
    if (hinted || opts.hint === false || !opts.tips) return;
    hinted = true;
    opts.tips.show('gp-inspect-hold', opts.hint ?? opts.host?.t('gp.inspect.hold') ?? 'Hold to read');
  };

  const onMove = (e: PointerEvent) => {
    if (e.pointerType === 'mouse') {
      if (hoverTimer) clearTimeout(hoverTimer);
      hoverTimer = null;
      const { x, y } = local(e);
      const now = enabled() ? at(x, y, e) : null;
      if (plate && (!now || now.title !== info?.title)) close();
      if (!now || plate) return;
      const cx = e.clientX;
      const cy = e.clientY;
      hoverTimer = setTimeout(() => {
        hoverTimer = null;
        if (enabled()) show(cx, cy, now, false);
      }, hoverMs);
    } else if (hold && e.pointerId === hold.id && !hold.shown && Math.hypot(e.clientX - hold.cx, e.clientY - hold.cy) > SLOP) {
      // The finger moved: a drag or a swipe, the game's — no plate
      clearTimeout(hold.timer);
      hold = null;
    }
  };
  const onLeave = (e: PointerEvent) => {
    if (e.pointerType !== 'mouse') return;
    if (hoverTimer) clearTimeout(hoverTimer);
    hoverTimer = null;
    close();
  };
  const onDown = (e: PointerEvent) => {
    if (e.pointerType === 'mouse') {
      if (hoverTimer) clearTimeout(hoverTimer);
      hoverTimer = null;
      close();
      return;
    }
    close();
    if (hold) clearTimeout(hold.timer);
    if (!enabled()) return (hold = null), undefined;
    const { x, y } = local(e);
    const h = {
      id: e.pointerId,
      x,
      y,
      cx: e.clientX,
      cy: e.clientY,
      shown: false,
      timer: setTimeout(() => {
        if (hold !== h || !enabled()) return;
        const i = at(h.x, h.y, e);
        if (!i) return;
        h.shown = true;
        show(h.cx, h.cy, i, true);
        opts.tips?.done('gp-inspect-hold');
        hinted = true;
        const v = opts.vibrate ?? true;
        if (v) navigator.vibrate?.(typeof v === 'number' ? v : 8);
      }, holdMs),
    };
    hold = h;
  };
  // In the capture phase on the window: before the game's own listeners on the target
  const onUp = (e: PointerEvent) => {
    if (e.pointerType === 'mouse' || !hold || e.pointerId !== hold.id) return;
    const h = hold;
    hold = null;
    clearTimeout(h.timer);
    if (h.shown) {
      // The lift of a hold: not a tap — the game never hears it
      close();
      swallow = e.pointerId;
      swallowClickUntil = performance.now() + 600;
      e.stopPropagation();
      e.preventDefault();
      return;
    }
    if (e.type === 'pointercancel') return;
    if (enabled() && at(h.x, h.y, e)) hintOnce();
    opts.onTap?.(h.x, h.y, e);
  };
  const onClick = (e: MouseEvent) => {
    if (swallow === null || performance.now() > swallowClickUntil) return;
    if (!target.contains(e.target as Node)) return;
    swallow = null;
    e.stopPropagation();
    e.preventDefault();
  };
  const onContext = (e: Event) => {
    // A long press opens the browser's menu on some phones: never over the board
    if (hold || plate) e.preventDefault();
  };

  target.addEventListener('pointermove', onMove);
  target.addEventListener('pointerleave', onLeave);
  target.addEventListener('pointerdown', onDown);
  target.addEventListener('contextmenu', onContext);
  addEventListener('pointerup', onUp, true);
  addEventListener('pointercancel', onUp, true);
  addEventListener('click', onClick, true);

  return {
    get open() {
      return info;
    },
    get pressing() {
      return !!hold && !hold.shown;
    },
    close,
    destroy() {
      close();
      if (hoverTimer) clearTimeout(hoverTimer);
      if (hold) clearTimeout(hold.timer);
      target.removeEventListener('pointermove', onMove);
      target.removeEventListener('pointerleave', onLeave);
      target.removeEventListener('pointerdown', onDown);
      target.removeEventListener('contextmenu', onContext);
      removeEventListener('pointerup', onUp, true);
      removeEventListener('pointercancel', onUp, true);
      removeEventListener('click', onClick, true);
    },
  };
}
