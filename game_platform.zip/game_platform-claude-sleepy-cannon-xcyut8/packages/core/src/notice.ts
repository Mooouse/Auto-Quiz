// A plain full-window message over the game, for when it can't go on: it can't run in this browser (the player's boot),
// or its graphics are gone for good (a WebGL context loss nothing can recover: GameHost). No buttons; readable on any
// game background and in the portals' small frames (18 px text, light on an opaque dark panel). The text comes in the
// player's language (the host's i18n: gp.cantRun, gp.graphicsLost), so the font stack has every script's fonts.

import { FONT_FALLBACK } from './i18n.ts';

/** Show `text` over everything, centred; `id` goes into data-gp (QA finds it there). A second call with the same id replaces it */
export function showNotice(text: string, id: string): HTMLElement {
  document.querySelector(`[data-gp="${id}"]`)?.remove();
  const el = document.createElement('div');
  el.dataset.gp = id;
  el.setAttribute('role', 'alert');
  el.style.cssText = [
    'position:fixed',
    'inset:0',
    'z-index:2147483647',
    'display:flex',
    'align-items:center',
    'justify-content:center',
    'box-sizing:border-box',
    'padding:24px',
    'margin:0',
    'background:#10161c',
    'color:#f2f5f8',
    `font:600 18px/1.4 ${FONT_FALLBACK}`,
    'text-align:center',
    'pointer-events:auto',
  ].join(';');
  const p = document.createElement('p');
  p.style.cssText = 'margin:0;max-width:32em;overflow-wrap:anywhere';
  p.textContent = text;
  el.append(p);
  document.body.append(el);
  return el;
}
