// Test page for the engine adapters' contract (packages/core/test-browser/engines.test.ts): a host and one adapter on
// #game, with every requestAnimationFrame callback, step and frame counted. Not a game.
// ?engine=canvas (default): canvasAdapter. ?engine=webgl: the shared driver on a WebGL canvas with a recording engine
// part (the context-loss path every WebGL adapter takes). ?engine=pixi: pixiAdapter on a fake `pixi.js` (FakePixi
// below: the loop API Pixi 8 has — a Ticker.system that starts its own requestAnimationFrame loop, a renderer on a
// WebGL context, generateTexture — without installing Pixi in the platform). ?stopAt=<n>: the n-th step ends the run
// (from inside the step).
import { GameHost } from '../../src/index';
import { canvasAdapter } from '../../src/engines/canvas';
import { createDriver, type Engine } from '../../src/engines/driver';
import { pixiAdapter } from '../../src/engines/pixi';

const q = new URLSearchParams(location.search);
// Every callback the page's requestAnimationFrame runs (the adapter's loop included)
let rafCalls = 0;
const raf = window.requestAnimationFrame.bind(window);
window.requestAnimationFrame = (cb) =>
  raf((ts) => {
    rafCalls++;
    cb(ts);
  });

// Every AudioContext the page makes: the adapters must use the host's one
let audioContexts = 0;
const AC = window.AudioContext;
window.AudioContext = class extends AC {
  constructor(o?: AudioContextOptions) {
    super(o);
    audioContexts++;
  }
};

const canvas = document.getElementById('game') as HTMLCanvasElement;
const host = new GameHost({
  saveKey: 'engine-fixture',
  minTouchPx: 48,
  locale: 'en-US',
  ads: { policy: { noAdsAfterLaunchSec: 0, firstAdAfterRound: 0, everyRounds: 1, minIntervalSec: 0, maxAdWaitSec: 10, testAdCloseSec: 1 }, rewarded: true, admob: null },
  portal: null,
  keepEventLog: true,
  canvas,
  title: 'Engine Fixture',
});

const log: string[] = [];
const dts: number[] = [];
let frames = 0;
let renders = 0;
let eng: Engine;
/** What the fake Pixi saw: its own ticker's rAF callbacks, the adapter's updates of it, renders, textures redrawn */
const pixiLog = { tickerRaf: 0, tickerUpdates: 0, tickerStarted: true, renders: 0, textureRenders: 0 };
if (q.get('engine') === 'pixi') {
  // Pixi 8's shapes: Ticker.system autostarts its own rAF loop at import; autoDetectRenderer resolves a renderer that
  // draws the stage with render(container) and a texture with render({ container, target })
  const system = {
    autoStart: true,
    started: true,
    stop() {
      this.started = false;
    },
    update() {
      pixiLog.tickerUpdates++;
    },
  };
  const tick = () => {
    if (!system.started) return;
    pixiLog.tickerRaf++;
    raf(tick);
  };
  raf(tick);
  const FakePixi = {
    Ticker: { system },
    Container: class {
      children: object[] = [];
    },
    async autoDetectRenderer(o: { canvas: HTMLCanvasElement; preference: string | string[] }) {
      const gl = o.canvas.getContext('webgl2') ?? o.canvas.getContext('webgl');
      if (!gl) throw new Error('no WebGL');
      (window as unknown as Record<string, unknown>).__lose = gl.getExtension('WEBGL_lose_context');
      return {
        name: 'webgl',
        gl,
        render(what: { target?: unknown }) {
          if (what.target) pixiLog.textureRenders++;
          else {
            pixiLog.renders++;
            renders++;
            log.push(`render:lost=${gl.isContextLost()}`);
          }
        },
        resize: (w: number, h: number, res?: number) => {
          o.canvas.width = Math.round(w * (res ?? 1));
          o.canvas.height = Math.round(h * (res ?? 1));
        },
        generateTexture: (opts: object) => ({ texture: opts }),
      };
    },
  };
  const p = await pixiAdapter(host, canvas, FakePixi);
  p.texture({ shape: 'dot' }, { frame: { x: 0, y: 0, width: 12, height: 12 } });
  eng = p;
  pixiLog.tickerStarted = system.started;
} else if (q.get('engine') === 'webgl') {
  const gl = canvas.getContext('webgl')!;
  eng = createDriver(host, canvas, {}, (d) => {
    const loop = d.loop({ render: () => renders++ });
    return {
      ...loop,
      render: () => {
        renders++;
        log.push(`render:lost=${gl.isContextLost()}`);
      },
      resize: (s) => log.push(`resize:${s.width}x${s.height}@${s.dpr}`),
      webgl: true,
    };
  }).engine;
  (window as unknown as Record<string, unknown>).__lose = gl.getExtension('WEBGL_lose_context');
} else {
  const c = canvasAdapter(host, canvas);
  eng = c;
  c.onFrame(() => {
    const m = c.context.getTransform();
    log.push(`frame:scale=${m.a}`);
  });
}
const stopAt = Number(q.get('stopAt') ?? 0);
eng.onStep((dt) => {
  dts.push(dt);
  if (stopAt && dts.length === stopAt) eng.setRunning(false);
});
// A second listener: it must not run after the first one stopped the run in the same step
eng.onStep(() => log.push(`step2:${dts.length}`));
eng.onFrame(() => frames++);
eng.onResize((s) => log.push(`onResize:${s.width}x${s.height}@${s.dpr}`));

/** Play a hidden tab: headless Chromium is never hidden by itself */
function setHidden(hidden: boolean): void {
  Object.defineProperty(document, 'hidden', { configurable: true, get: () => hidden });
  Object.defineProperty(document, 'visibilityState', { configurable: true, get: () => (hidden ? 'hidden' : 'visible') });
  document.dispatchEvent(new Event('visibilitychange'));
}

(window as unknown as Record<string, unknown>).__t = {
  host,
  eng,
  log,
  dts,
  pixi: pixiLog,
  audioContexts: () => audioContexts,
  stats: () => ({ raf: rafCalls, steps: dts.length, frames, renders, running: eng.running, width: canvas.width, height: canvas.height }),
  setHidden,
};
