// A collection: the things a player has found (cars, pickaxes, fish, cards), shown as an album with silhouettes for the
// ones still missing — what Idle Garage Evolution (the car album: models × paint × rarity) and Craft Pickaxe Idle (the
// pickaxe collection: every material × level ever owned, +1 % damage each, kept through Reforge) wrote by hand. Any
// genre. Pure logic over a field of the game's own save; the screen is mountAlbum() (album-ui.ts).
//
//   const album = collection(save, {
//     entries: MATERIALS.flatMap((m) => LEVELS.map((l) => ({ id: `${m}:${l}`, group: 'picks', row: m, rarity: l > 6 ? 'epic' : 'common', bonus: 0.01 }))),
//     persist: () => host.save(save),
//   });
//   if (album.find(`${pick.m}:${pick.l}`)) banners.push({ title: host.t('album.new') });   // true: found for the first time
//   const damage = base * (1 + album.bonus());                                              // +1 % per entry, for good
//
// Found is for good: a reset (a prestige, a Reforge) never empties the album. A "new" mark stays until the player has
// seen the entry on the album's page (markSeen); entries the game removes are kept in the save, out of the count.

import type { Rarity } from './goals.ts';
import type { SaveHolder } from './streak.ts';

const record = (v: unknown): Record<string, unknown> => (v && typeof v === 'object' && !Array.isArray(v) ? (v as Record<string, unknown>) : {});

export interface CollectionEntry {
  id: string;
  /** Its page group (default: '' — one group) */
  group?: string;
  /** Its row inside the group (a material, a class): the album labels rows */
  row?: string;
  rarity?: Rarity;
  /** A permanent bonus once found (a share: 0.01 = +1 %): bonus() adds them up */
  bonus?: number;
  /** Not even its silhouette shows until found ("???") */
  secret?: boolean;
}

export interface CollectionGroup {
  id: string;
  /** Its rows in order (default: the order the entries name them) */
  rows?: readonly string[];
}

/** What the collection keeps in the save (`save.collection` by default) */
export interface CollectionLog {
  /** Found: id → when (ms since 1970) */
  found: Record<string, number>;
  /** Found entries the player has seen on the album (no "new" mark) */
  seen: string[];
}

export interface CollectionOptions {
  entries: readonly CollectionEntry[];
  groups?: readonly CollectionGroup[];
  /** The save field (default 'collection') */
  key?: string;
  now?: () => number;
  /** Called after a find or a markSeen: `() => host.save(save)` */
  persist?: () => void;
}

export interface CollectionCell {
  id: string;
  found: boolean;
  /** Found and not yet seen on the album */
  isNew: boolean;
  rarity: Rarity;
  bonus: number;
  /** Not found and secret: "???" */
  secret: boolean;
}

export interface CollectionRow {
  /** The row's id ('' for entries without one) */
  id: string;
  cells: CollectionCell[];
  found: number;
}

export interface CollectionGroupState {
  id: string;
  rows: CollectionRow[];
  found: number;
  total: number;
  newCount: number;
}

export interface CollectionState {
  found: number;
  total: number;
  /** 0 … 1 */
  share: number;
  newCount: number;
  /** The sum of the found entries' bonuses */
  bonus: number;
  groups: CollectionGroupState[];
}

export interface Collection {
  /** Found one: true when it is new (saved at once) */
  find(id: string): boolean;
  /** Several at once: the ids that are new */
  findAll(ids: Iterable<string>): string[];
  has(id: string): boolean;
  isNew(id: string): boolean;
  /** The player saw these (default: every found entry): their "new" marks go */
  markSeen(ids?: Iterable<string>): void;
  /** The permanent bonus of everything found (a share: 0.12 = +12 %) */
  bonus(): number;
  state(): CollectionState;
  readonly entries: readonly CollectionEntry[];
  readonly log: CollectionLog;
}

/** The saved collection made safe */
export function loadCollection(saved: unknown): CollectionLog {
  const s = record(saved);
  const found: Record<string, number> = {};
  // An older save may keep a plain list of ids (Craft Pickaxe's `codex: string[]`)
  if (Array.isArray(saved)) for (const id of saved) if (typeof id === 'string' && id) found[id] = 0;
  for (const [id, at] of Object.entries(record(s.found))) {
    const n = Number(at);
    if (id) found[id] = Number.isFinite(n) && n > 0 ? Math.floor(n) : 0;
  }
  // A list as the old save had it: everything in it seen already (no wall of "new" marks after an update)
  const seen = Array.isArray(saved) ? Object.keys(found) : Array.isArray(s.seen) ? [...new Set(s.seen.filter((x): x is string => typeof x === 'string' && x in found))] : [];
  return { found, seen };
}

/** A collection over `save[key]` */
export function collection(save: SaveHolder, opts: CollectionOptions): Collection {
  const ids = new Set<string>();
  for (const e of opts.entries) {
    if (!e.id || ids.has(e.id)) throw new Error(`collection: ${e.id ? `the id '${e.id}' twice` : 'an entry without an id'}`);
    ids.add(e.id);
  }
  const key = opts.key ?? 'collection';
  const holder = save as Record<string, unknown>;
  const log = loadCollection(holder[key]);
  holder[key] = log;
  const now = opts.now ?? Date.now;
  const persist = () => opts.persist?.();
  const byId = new Map(opts.entries.map((e) => [e.id, e]));
  const seen = new Set(log.seen);

  const addFound = (id: string) => {
    if (!byId.has(id) || id in log.found) return false;
    log.found[id] = now();
    return true;
  };

  const groupIds = (): string[] => {
    const out = (opts.groups ?? []).map((g) => g.id);
    for (const e of opts.entries) if (!out.includes(e.group ?? '')) out.push(e.group ?? '');
    return out;
  };

  const bonus = () => {
    let sum = 0;
    for (const id of Object.keys(log.found)) {
      const b = Number(byId.get(id)?.bonus ?? 0);
      if (Number.isFinite(b)) sum += b;
    }
    return sum;
  };

  return {
    entries: opts.entries,
    log,
    find(id) {
      const fresh = addFound(id);
      if (fresh) persist();
      return fresh;
    },
    findAll(list) {
      const fresh = [...list].filter(addFound);
      if (fresh.length) persist();
      return fresh;
    },
    has: (id) => id in log.found,
    isNew: (id) => id in log.found && !seen.has(id),
    markSeen(list) {
      let changed = false;
      for (const id of list ?? Object.keys(log.found))
        if (id in log.found && !seen.has(id)) {
          seen.add(id);
          changed = true;
        }
      if (!changed) return;
      log.seen = [...seen];
      persist();
    },
    bonus,
    state() {
      const groups = groupIds().map((gid): CollectionGroupState => {
        const def = opts.groups?.find((g) => g.id === gid);
        const mine = opts.entries.filter((e) => (e.group ?? '') === gid);
        const rowIds = [...(def?.rows ?? [])];
        for (const e of mine) if (!rowIds.includes(e.row ?? '')) rowIds.push(e.row ?? '');
        const rows = rowIds
          .map((rid): CollectionRow => {
            const cells = mine
              .filter((e) => (e.row ?? '') === rid)
              .map((e): CollectionCell => {
                const found = e.id in log.found;
                return { id: e.id, found, isNew: found && !seen.has(e.id), rarity: e.rarity ?? 'common', bonus: Number(e.bonus ?? 0) || 0, secret: !found && !!e.secret };
              });
            return { id: rid, cells, found: cells.filter((c) => c.found).length };
          })
          .filter((r) => r.cells.length > 0);
        const cells = rows.flatMap((r) => r.cells);
        return { id: gid, rows, found: cells.filter((c) => c.found).length, total: cells.length, newCount: cells.filter((c) => c.isNew).length };
      });
      const found = groups.reduce((a, g) => a + g.found, 0);
      const total = groups.reduce((a, g) => a + g.total, 0);
      return { found, total, share: total ? found / total : 0, newCount: groups.reduce((a, g) => a + g.newCount, 0), bonus: bonus(), groups };
    },
  };
}
