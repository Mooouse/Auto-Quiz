// @gp/core/boss — a boss as a pattern machine, pure and engine-free: phases that start at health thresholds, attacks
// that are telegraphed (a wind-up the player can read) before they land and followed by a rest (the window to hit
// back), drawn from a deck that never plays the same attack twice in a row; and bullet-pattern emitters (fan, ring,
// spiral, aimed with a lead, a sweeping wave) that return what to spawn, so the game's sim owns its bullets.
//
// From Candle Crypt's bosses.ts (game9: a pattern machine each, a new attack every few seconds, never the same twice,
// phase 2 below half health: faster, denser, one new attack) and Swarm Smash's bosses (game20: phases at 50 % and 25 %).
//
//   const boss = new BossPatterns({
//     attacks: { fan: { telegraph: 0.6, duration: 2.4 }, ring: { telegraph: 0.8, duration: 2.4 }, charge: { telegraph: 0.55, duration: 1.2, recover: 1 } },
//     phases: [{ at: 1, attacks: ['fan', 'ring'] }, { at: 0.5, attacks: ['fan', 'ring', 'charge'], speed: 1.3, opener: 'charge' }],
//     rng: run.rng,                                     // the run's seeded random: the same seed, the same fight
//   });
//   // each sim step:
//   for (const e of boss.step(dt, b.hp / b.maxHp)) if (e.type === 'telegraph') run.emit({ type: 'warn', … });
//   if (boss.is('fan') && boss.every(0.55 / boss.speed)) for (const s of fan(b, aimAt(b, player), 7, 1.1, 115)) run.bullet(s);
//
// The machine never moves the boss and never spawns: the game reads `state`, `attack`, `t`, `k` and `every()` and does
// what its attack means. Same seed and the same health at the same steps → the same attacks (a balance bot can fight it).

export type Rand = (() => number) | { random(): number };
const draw = (r: Rand): number => (typeof r === 'function' ? r() : r.random());

export interface BossAttackDef {
  /** Seconds of warning before it lands: the wind-up, the marks on the floor (0: none) */
  telegraph: number;
  /** Seconds it runs */
  duration: number;
  /** Seconds of rest after it, before the next telegraph (default 0.6): the window to hit back */
  recover?: number;
  /** How often it comes up in the deck (default 1; 2: twice per round of the deck) */
  weight?: number;
}

export interface BossAttack extends Required<BossAttackDef> {
  id: string;
}

export interface BossPhase {
  /** Starts when the boss's health share falls to this or below; the first phase has 1 */
  at: number;
  /** The attacks of this phase (ids in `attacks`) */
  attacks: readonly string[];
  /** Tempo: telegraphs, attacks and rests run this many times faster (default 1); read it for the attack's own cadence */
  speed?: number;
  /** Played first when the phase starts (a slam, a transformation): then the deck */
  opener?: string;
}

export type BossState = 'intro' | 'telegraph' | 'attack' | 'recover';

export type BossEvent =
  | { type: 'phase'; phase: number; from: number }
  | { type: 'telegraph'; attack: string; sec: number }
  | { type: 'attack'; attack: string; sec: number }
  | { type: 'recover'; attack: string | null; sec: number };

export interface BossOptions {
  attacks: Record<string, BossAttackDef>;
  /** From the first (at: 1) down; sorted by `at` for you */
  phases: readonly BossPhase[];
  rng: Rand;
  /** Seconds of entrance before the first telegraph (default 1) */
  intro?: number;
  /** Seconds of rest when a phase starts: the old attack is cut off (default 0.8; Candle Crypt's) */
  phaseRest?: number;
}

/** The pattern machine of one boss (one per boss in the fight; a new one per fight) */
export class BossPatterns {
  readonly attacks: Readonly<Record<string, BossAttack>>;
  readonly phases: readonly BossPhase[];
  /** The current phase (index into phases) */
  phase = 0;
  state: BossState = 'intro';
  /** The attack being telegraphed, run or rested after (null in the intro and the rest after a phase change) */
  attack: BossAttack | null = null;
  /** Seconds in the current state */
  t = 0;
  /** The current state's length, seconds */
  length: number;
  /** Every attack drawn so far, in order (a test reads it: never twice in a row) */
  readonly history: string[] = [];
  private deck: string[] = [];
  private ticks = 0;
  private readonly rng: Rand;
  private readonly phaseRest: number;

  constructor(o: BossOptions) {
    const attacks: Record<string, BossAttack> = {};
    for (const [id, a] of Object.entries(o.attacks)) attacks[id] = { id, telegraph: Math.max(0, a.telegraph), duration: Math.max(0.01, a.duration), recover: Math.max(0, a.recover ?? 0.6), weight: Math.max(1, Math.round(a.weight ?? 1)) };
    this.attacks = attacks;
    this.phases = [...o.phases].sort((a, b) => b.at - a.at);
    if (!this.phases.length) throw new Error('BossPatterns: no phases');
    for (const p of this.phases) for (const id of [...p.attacks, ...(p.opener ? [p.opener] : [])]) if (!attacks[id]) throw new Error(`BossPatterns: phase at ${p.at} names an unknown attack "${id}"`);
    if (this.phases.some((p) => !p.attacks.length)) throw new Error('BossPatterns: a phase without attacks');
    this.rng = o.rng;
    this.phaseRest = o.phaseRest ?? 0.8;
    this.length = Math.max(0, o.intro ?? 1);
  }

  /** The current phase's tempo */
  get speed(): number {
    return this.phases[this.phase].speed ?? 1;
  }
  /** 0…1 through the current state */
  get k(): number {
    return this.length > 0 ? Math.min(1, this.t / this.length) : 1;
  }
  /** Seconds left in the current state */
  get left(): number {
    return Math.max(0, this.length - this.t);
  }
  /** The current attack is `id` and it is landing (not its telegraph or rest) — or in that state, when given */
  is(id: string, state: BossState = 'attack'): boolean {
    return this.attack?.id === id && this.state === state;
  }

  /**
   * True once every `sec` of the current state (the first time `sec` after it began): a fan every 0.55 s of the attack.
   * Several in one long step count once per call; call it once per step per cadence
   */
  every(sec: number): boolean {
    if (sec <= 0) return false;
    const n = Math.floor(this.t / sec + 1e-9);
    if (n > this.ticks) {
      this.ticks = n;
      return true;
    }
    return false;
  }

  /** Advance by dt seconds at this health share (0…1). Returns what started in this step, in order */
  step(dt: number, hpShare: number): BossEvent[] {
    const out: BossEvent[] = [];
    // A phase threshold crossed: the attack is cut off, a short rest, then the phase's opener (or its deck)
    let next = this.phase;
    while (next + 1 < this.phases.length && hpShare <= this.phases[next + 1].at) next++;
    if (next !== this.phase) {
      for (let p = this.phase + 1; p <= next; p++) out.push({ type: 'phase', phase: p, from: p - 1 });
      this.phase = next;
      this.deck = [];
      const op = this.phases[next].opener;
      if (op) this.deck.push(op);
      this.enter('recover', null, this.phaseRest, out);
      return out;
    }
    this.t += Math.max(0, dt);
    // A long step can pass several states (a rest of 0, a telegraph of 0): at most a few, never a loop
    // (the same 1e-9 as every(): a state that ends at 3 s doesn't tick once more at 2.9999999)
    for (let guard = 0; guard < 8 && this.t >= this.length - 1e-9; guard++) {
      const over = Math.max(0, this.t - this.length);
      const sp = this.speed;
      if (this.state === 'telegraph' && this.attack) this.enter('attack', this.attack, this.attack.duration / sp, out);
      else if (this.state === 'attack' && this.attack) this.enter('recover', this.attack, this.attack.recover / sp, out);
      else {
        const a = this.attacks[this.drawNext()];
        this.history.push(a.id);
        this.enter('telegraph', a, a.telegraph / sp, out);
      }
      this.t = over;
    }
    return out;
  }

  private enter(state: BossState, attack: BossAttack | null, sec: number, out: BossEvent[]): void {
    this.state = state;
    this.attack = attack;
    this.length = Math.max(0, sec);
    this.t = 0;
    this.ticks = 0;
    if (state === 'recover') out.push({ type: 'recover', attack: attack?.id ?? null, sec });
    else if (state === 'telegraph') out.push({ type: 'telegraph', attack: attack!.id, sec });
    else if (state === 'attack') out.push({ type: 'attack', attack: attack!.id, sec });
  }

  /** The next attack from the deck: a shuffled round of the phase's attacks (by weight), never the last one again */
  private drawNext(): string {
    const last = this.history[this.history.length - 1];
    // An opener that is the attack the phase change cut off: straight to the deck
    if (this.deck.length === 1 && this.deck[0] === last && this.phases[this.phase].attacks.some((id) => id !== last)) this.deck = [];
    if (!this.deck.length) this.deck = this.round(last);
    return this.deck.shift()!;
  }

  /**
   * One round of the phase's deck: each attack `weight` times, in a random order where none follows itself — nor the
   * attack before the round. Each pick is random by the counts left, except when one attack has more than half of
   * what is left: it must go now, or it would end up twice in a row
   */
  private round(prev: string | undefined): string[] {
    const left = new Map<string, number>();
    for (const id of this.phases[this.phase].attacks) left.set(id, (left.get(id) ?? 0) + this.attacks[id].weight);
    let total = [...left.values()].reduce((a, b) => a + b, 0);
    const out: string[] = [];
    while (total > 0) {
      let cands = [...left].filter(([id, n]) => n > 0 && id !== prev);
      // Only the previous one is left (a phase of one attack): it repeats, there is nothing else
      if (!cands.length) cands = [...left].filter(([, n]) => n > 0);
      const top = cands.reduce((a, b) => (b[1] > a[1] ? b : a));
      let pick = top[0];
      if (top[1] * 2 <= total) {
        let r = draw(this.rng) * cands.reduce((a, [, n]) => a + n, 0);
        for (const [id, n] of cands) {
          pick = id;
          if ((r -= n) < 0) break;
        }
      }
      out.push(pick);
      left.set(pick, left.get(pick)! - 1);
      total--;
      prev = pick;
    }
    return out;
  }
}

// --- Bullet patterns: what to spawn -------------------------------------------------------------------------------

/** One bullet to spawn: where, its heading (radians, atan2(y, x)), its speed and velocity, and a delay (s) if any */
export interface Spawn {
  x: number;
  y: number;
  angle: number;
  speed: number;
  vx: number;
  vy: number;
  delay: number;
}

interface Point {
  x: number;
  y: number;
}

const spawn = (o: Point, angle: number, speed: number, delay = 0): Spawn => ({ x: o.x, y: o.y, angle, speed, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed, delay });

/** The heading from a point to another */
export const aimAt = (from: Point, to: Point): number => Math.atan2(to.y - from.y, to.x - from.x);

/** `count` bullets over `spread` radians (the whole arc), centred on `aim`; one bullet: straight at it */
export function fan(o: Point, aim: number, count: number, spread: number, speed: number): Spawn[] {
  const n = Math.max(1, Math.floor(count));
  if (n === 1) return [spawn(o, aim, speed)];
  return Array.from({ length: n }, (_, i) => spawn(o, aim - spread / 2 + (spread * i) / (n - 1), speed));
}

/** `count` bullets all round, the first at `offset` (alternate offset = π/count between rings: the gaps move) */
export function ring(o: Point, count: number, speed: number, offset = 0): Spawn[] {
  const n = Math.max(1, Math.floor(count));
  return Array.from({ length: n }, (_, i) => spawn(o, offset + (i / n) * Math.PI * 2, speed));
}

/**
 * The `shot`-th volley of a spiral: `arms` bullets evenly round, the whole turned by `turn` radians per shot (call it with
 * shot 0, 1, 2 … at the attack's cadence; a negative turn spins the other way)
 */
export function spiral(o: Point, shot: number, o2: { arms?: number; turn: number; speed: number; offset?: number }): Spawn[] {
  return ring(o, o2.arms ?? 1, o2.speed, (o2.offset ?? 0) + shot * o2.turn);
}

/**
 * The heading that meets a moving target: where it will be when a bullet at `speed` gets there (`lead` 1), where it is
 * (`lead` 0), or in between. A target too fast to catch: straight at where it is
 */
export function intercept(o: Point, target: { x: number; y: number; vx: number; vy: number }, speed: number, lead = 1): number {
  const dx = target.x - o.x;
  const dy = target.y - o.y;
  const vx = target.vx * lead;
  const vy = target.vy * lead;
  // |d + v t| = speed t → (v·v − s²) t² + 2 (d·v) t + d·d = 0, the smallest positive t
  const a = vx * vx + vy * vy - speed * speed;
  const b = 2 * (dx * vx + dy * vy);
  const c = dx * dx + dy * dy;
  let t = -1;
  if (Math.abs(a) < 1e-9) t = b < 0 ? -c / b : -1;
  else {
    const disc = b * b - 4 * a * c;
    if (disc >= 0) {
      const r = Math.sqrt(disc);
      const t1 = (-b - r) / (2 * a);
      const t2 = (-b + r) / (2 * a);
      t = Math.min(...[t1, t2].filter((x) => x > 0), Infinity);
      if (!Number.isFinite(t)) t = -1;
    }
  }
  return t > 0 ? Math.atan2(dy + vy * t, dx + vx * t) : Math.atan2(dy, dx);
}

/** Aimed with a lead (`intercept`): one bullet, or a fan of `count` over `spread` round the intercept */
export function aimed(o: Point, target: { x: number; y: number; vx: number; vy: number }, speed: number, opts: { lead?: number; count?: number; spread?: number } = {}): Spawn[] {
  return fan(o, intercept(o, target, speed, opts.lead ?? 1), opts.count ?? 1, opts.spread ?? 0, speed);
}

/**
 * A sweeping wave: at time `t` of the attack, a stream that swings across `arc` radians round `aim` and back every
 * `period` s (a hose sweeping the room); `count` > 1 fires a short fan of `spread` at the swing's angle
 */
export function wave(o: Point, aim: number, t: number, opts: { arc: number; period: number; speed: number; count?: number; spread?: number }): Spawn[] {
  const a = aim + Math.sin((t / Math.max(1e-6, opts.period)) * Math.PI * 2) * (opts.arc / 2);
  return fan(o, a, opts.count ?? 1, opts.spread ?? 0, opts.speed);
}
