// Test page for the physics block (@gp/physics) on the REAL Rapier (packages/physics/test-browser/rapier-real.test.ts):
// @dimforge/rapier2d-compat or -deterministic-compat at the versions game.yaml engine.physics is tested with, installed
// only in this folder (never in the platform). A host, an adapter (Canvas 2D or Pixi) and a world with a platform and
// a ball, drawn from the ball's body; every requestAnimationFrame counted; Rapier's WebAssembly memory read from its
// instance. Not a game. Not in tsconfig.json (CI type-checks before these packages are installed): Vite strips the types.
//   ?engine=canvas | pixi    ?pkg=compat | deterministic
import { GameHost, seededRng } from '../../src/index';
import type { Engine } from '../../src/engines/driver';
import { createPhysics, drawDebug, livePhysicsWorlds, physicsAfterInit } from '../../../physics/src/index';

const q = new URLSearchParams(location.search);
const which = q.get('engine') ?? 'canvas';

let rafCalls = 0;
const raf = window.requestAnimationFrame.bind(window);
window.requestAnimationFrame = (cb) =>
  raf((ts) => {
    rafCalls++;
    cb(ts);
  });

// Rapier's WebAssembly memory: its instance's exported memory (the block's leak check in bytes, not only in counts)
let memory: WebAssembly.Memory | null = null;
const instantiate = WebAssembly.instantiate.bind(WebAssembly);
(WebAssembly as { instantiate: unknown }).instantiate = async (...a: unknown[]) => {
  const r = await (instantiate as (...x: unknown[]) => Promise<unknown>)(...a);
  const inst = r instanceof WebAssembly.Instance ? r : (r as { instance: WebAssembly.Instance }).instance;
  for (const v of Object.values(inst.exports)) if (v instanceof WebAssembly.Memory) memory ??= v;
  return r;
};

const R = q.get('pkg') === 'deterministic' ? (await import('@dimforge/rapier2d-deterministic-compat')).default : (await import('@dimforge/rapier2d-compat')).default;

const canvas = document.getElementById('game') as HTMLCanvasElement;
const host = new GameHost({
  saveKey: 'physics-real',
  minTouchPx: 48,
  locale: 'en-US',
  ads: { policy: { noAdsAfterLaunchSec: 0, firstAdAfterRound: 0, everyRounds: 1, minIntervalSec: 0, maxAdWaitSec: 10, testAdCloseSec: 1 }, rewarded: true, admob: null },
  portal: null,
  keepEventLog: true,
  canvas,
  title: 'Physics Real',
});

const PLATFORM = { x: 320, y: 300, hw: 200, hh: 10 };
const BALL = { x: 320, y: 40, r: 12 };
let ball!: InstanceType<typeof R.RigidBody>;
const physics = await createPhysics(R, {
  gravity: { x: 0, y: 900 },
  lengthUnit: 20,
  host,
  setup(world) {
    world.createCollider(R.ColliderDesc.cuboid(PLATFORM.hw, PLATFORM.hh).setTranslation(PLATFORM.x, PLATFORM.y));
    ball = world.createRigidBody(R.RigidBodyDesc.dynamic().setTranslation(BALL.x, BALL.y));
    world.createCollider(R.ColliderDesc.ball(BALL.r).setRestitution(0.2), ball);
  },
});

let frames = 0;
/** Where the last frame drew the ball (the view's own numbers, not the body's) */
let drawn = { x: NaN, y: NaN };
let eng: Engine;
let extra: Record<string, () => unknown> = {};

if (which === 'pixi') {
  const PIXI = await import('pixi.js');
  const { pixiAdapter } = await import('../../src/engines/pixi');
  const p = await pixiAdapter(host, canvas, { autoDetectRenderer: PIXI.autoDetectRenderer, Container: PIXI.Container, Ticker: PIXI.Ticker }, { background: '#102230' });
  const plat = new PIXI.Graphics().rect(-PLATFORM.hw, -PLATFORM.hh, PLATFORM.hw * 2, PLATFORM.hh * 2).fill(0x7bdff2);
  plat.position.set(PLATFORM.x, PLATFORM.y);
  const dot = new PIXI.Graphics().circle(0, 0, BALL.r).fill(0xffd166);
  p.stage.addChild(plat, dot);
  p.onFrame(() => {
    const s = physics.pose(ball);
    dot.position.set(s.x, s.y);
    dot.rotation = s.angle;
    drawn = { x: dot.x, y: dot.y };
  });
  (window as unknown as Record<string, unknown>).__lose = (p.renderer as unknown as { gl: WebGLRenderingContext }).gl.getExtension('WEBGL_lose_context');
  eng = p;
  extra = { renderer: () => p.renderer.name };
} else {
  const { canvasAdapter } = await import('../../src/engines/canvas');
  const c = canvasAdapter(host, canvas);
  c.onFrame(() => {
    const g = c.context;
    g.fillStyle = '#102230';
    g.fillRect(0, 0, c.size.width, c.size.height);
    g.fillStyle = '#7bdff2';
    g.fillRect(PLATFORM.x - PLATFORM.hw, PLATFORM.y - PLATFORM.hh, PLATFORM.hw * 2, PLATFORM.hh * 2);
    const s = physics.pose(ball);
    g.fillStyle = '#ffd166';
    g.beginPath();
    g.arc(s.x, s.y, BALL.r, 0, Math.PI * 2);
    g.fill();
    drawn = { x: s.x, y: s.y };
    if (q.has('debug')) drawDebug(g, physics.world, { color: '#ff0000' });
  });
  eng = c;
  /** The canvas pixel at a CSS point: [r, g, b] */
  extra = {
    pixel: () => {
      const s = physics.pose(ball);
      const d = c.context.getImageData(Math.round(s.x * c.size.dpr), Math.round(s.y * c.size.dpr), 1, 1).data;
      return [d[0], d[1], d[2]];
    },
  };
}
eng.onFrame(() => frames++);
physics.attach(eng);

// ?stopAt=<n>: the n-th world step ends the run from inside the block's step listener (a run that ends in a collision)
const stopAt = Number(q.get('stopAt') ?? 0);
// ?stall=<ms>: the world step before stopAt blocks the main thread, so the next frame catches up with several steps
const stall = Number(q.get('stall') ?? 0);
/** The frame each world step ran in (the frames drawn before it): the steps of one frame share a number */
const stepLog: number[] = [];
physics.onStep(() => {
  stepLog.push(frames);
  if (stall && physics.stats.steps === Number(q.get('stallAt') ?? 0)) {
    const end = performance.now() + stall;
    while (performance.now() < end);
  }
  if (stopAt && physics.stats.steps === stopAt) eng.setRunning(false);
});

/** Play a hidden tab: headless Chromium is never hidden by itself */
function setHidden(hidden: boolean): void {
  Object.defineProperty(document, 'hidden', { configurable: true, get: () => hidden });
  Object.defineProperty(document, 'visibilityState', { configurable: true, get: () => (hidden ? 'hidden' : 'visible') });
  document.dispatchEvent(new Event('visibilitychange'));
}

/**
 * A seeded scene stepped `steps` times by its own block (not the page's): `n` boxes and balls dropped at positions from
 * seededRng(seed) onto the platform, a scripted push at step 60 (the input). Returns every body's position and angle,
 * rounded to nothing: the exact floats. `resets` replays it after that many resets of the same block
 */
function scene(seed: number, opts: { n?: number; steps?: number; resets?: number } = {}): number[] {
  const n = opts.n ?? 60;
  const bodies: InstanceType<typeof R.RigidBody>[] = [];
  const p = physicsAfterInit(R, {
    gravity: { x: 0, y: 900 },
    lengthUnit: 20,
    setup(world) {
      const rand = seededRng(seed);
      bodies.length = 0;
      world.createCollider(R.ColliderDesc.cuboid(PLATFORM.hw, PLATFORM.hh).setTranslation(PLATFORM.x, PLATFORM.y));
      for (let i = 0; i < n; i++) {
        const b = world.createRigidBody(R.RigidBodyDesc.dynamic().setTranslation(rand.range(140, 500), rand.range(-400, 200)).setRotation(rand.range(0, 3)));
        world.createCollider(i % 2 ? R.ColliderDesc.ball(rand.range(5, 12)) : R.ColliderDesc.cuboid(rand.range(5, 12), rand.range(5, 12)), b);
        bodies.push(b);
      }
    },
  });
  const run = () => {
    for (let s = 1; s <= (opts.steps ?? 240); s++) {
      if (s === 60) bodies[0].applyImpulse({ x: 400, y: -300 }, true);
      p.step();
    }
    return bodies.flatMap((b) => [b.translation().x, b.translation().y, b.rotation()]);
  };
  let out = run();
  for (let i = 0; i < (opts.resets ?? 0); i++) {
    p.reset();
    out = run();
  }
  p.destroy();
  return out;
}

/** `n` resets of a block whose setup builds `bodies` bodies, each world stepped 5 times: the memory and the counts */
function leak(n: number, bodies: number) {
  const p = physicsAfterInit(R, {
    gravity: { x: 0, y: 900 },
    setup(world) {
      for (let i = 0; i < bodies; i++) {
        const b = world.createRigidBody(R.RigidBodyDesc.dynamic().setTranslation((i % 40) * 15, Math.floor(i / 40) * 15));
        world.createCollider(R.ColliderDesc.ball(6).setActiveEvents(R.ActiveEvents.COLLISION_EVENTS), b);
      }
    },
  });
  // A kept object of its own on every world: a character controller (freed with the world by the block)
  const controller = () => p.keep(p.world.createCharacterController(0.1));
  controller();
  const bytes: number[] = [];
  for (let i = 0; i < n; i++) {
    for (let s = 0; s < 5; s++) p.step();
    p.reset();
    controller();
    bytes.push(memory!.buffer.byteLength);
  }
  const live = livePhysicsWorlds();
  const stats = { ...p.stats };
  p.destroy();
  return { bytes, stats, live, liveAfter: livePhysicsWorlds(), after: { ...p.stats } };
}

/** The control: `n` worlds of `bodies` bodies made and NOT freed — the same measure must see this grow */
function leakWithoutFree(n: number, bodies: number) {
  const before = memory!.buffer.byteLength;
  for (let i = 0; i < n; i++) {
    const w = new R.World({ x: 0, y: 900 });
    for (let j = 0; j < bodies; j++) w.createCollider(R.ColliderDesc.ball(6), w.createRigidBody(R.RigidBodyDesc.dynamic().setTranslation(j, 0)));
    w.step();
  }
  return { before, after: memory!.buffer.byteLength };
}

(window as unknown as Record<string, unknown>).__p = {
  host,
  eng,
  physics,
  version: R.version(),
  pose: () => physics.pose(ball),
  drawn: () => drawn,
  stats: () => ({ raf: rafCalls, frames, steps: physics.stats.steps, running: eng.running, droppedSec: physics.stats.droppedSec }),
  stepLog,
  extra: (k: string) => extra[k]?.(),
  memory: () => memory?.buffer.byteLength ?? null,
  setHidden,
  scene,
  leak,
  leakWithoutFree,
  livePhysicsWorlds,
};
