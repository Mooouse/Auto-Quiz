# __TITLE__ — concept and originality check

Write this BEFORE building (docs/guides/game-design.md → Originality in game_platform). The portal rejects games whose
concept is "quite close to existing titles"; a search takes about 10 minutes and saves the whole game.

## Ideas checked

Search the portal for the genre AND the theme: `site:crazygames.com <genre> <theme>`, its tag pages, the top of the category.
Search results are not the catalogue: say what you searched.

| Idea | Searches | What the portal has (title, date) | Verdict |
|---|---|---|---|
| A. TODO | TODO | TODO | too close / keep |
| B. TODO | | | |
| C. TODO | | | |

## The chosen idea

**One sentence:** TODO — what the player does and why it is fun.

**The twist:** TODO — what the player does that no live game on the portal has (a rule, an input, a goal).

| | __TITLE__ | closest game 1 | closest game 2 | closest game 3 |
|---|---|---|---|---|
| What the player does | | | | |
| How you win or lose | | | | |
| The risk in each action | | | | |

The first 30 seconds of play and the preview video must SHOW the twist.

## The progression

What a run's currency (or the run itself) buys, and why this shape fits the genre — pick it from
game_platform `docs/guides/upgrades.md` (unlocks that change how you play, tiers, pacts with a cost, run choices; a
level shop of "+stat" upgrades only for idle and launch-distance games). One line of it goes into `concept.progression`.

| | __TITLE__ | closest game 1 | closest game 2 | closest game 3 |
|---|---|---|---|---|
| What the currency buys | TODO | | | |
| What a new purchase changes in play | TODO | | | |
| The second track (collection, rank, story, zones) | TODO | | | |

The balance bot (`bot.ts` → `balance()`) answers when the first purchase comes, when each new thing arrives and how long
the whole meta lasts; `scripts/gp.sh balance` reads it against the portal's targets.

## Money

Decide where the game earns now, with the concept — not after it is built. Compare the ideas above first:
`scripts/gp.sh forecast --idea --genre <genre> --session <min> --breaks <n> --rewarded revive,x2 --pitch "<the pitch>"`
prints P(approval), P(Full Launch), revenue in months 1–3 and the expected value, each a range with its confidence.
Then write `money` in game.yaml and run `scripts/gp.sh forecast` (game_platform docs/guides/game-design.md → Design for money).

| | TODO the chosen idea | the runner-up |
|---|---|---|
| Genre (the benchmarks) and a session of … min | TODO | |
| Natural breaks: where, how often (a midgame ad only there; the platform: never in the first 3 min, the first at the 3rd break or after 5 min, whichever comes first) | TODO | |
| Rewarded offers: what each gives (revive once a session, ×2 on the results, a hint from a "Stuck?" panel) | TODO | |
| The meta: how long until it is done (the balance bot measures it) | TODO | |
| Why a player comes back tomorrow (D1) | TODO | |
| `forecast --idea`: expected value months 1–3 (range), the top lever | TODO | |

Basic Launch (7–21 days) has no ads: the game must work and be fun without them. Keep the upload under 20 MB (the mobile homepage).
