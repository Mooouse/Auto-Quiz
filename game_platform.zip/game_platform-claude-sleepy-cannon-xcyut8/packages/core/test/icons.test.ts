import { describe, expect, it } from 'vitest';
import { ICON_NAMES, ICONS, iconSvg, iconUrl } from '../src/icons.ts';

/** The runtime's sources as text (Vite's ?raw: the test runs in Node, typed as browser code) */
const SOURCES = import.meta.glob('../src/*.ts', { query: '?raw', import: 'default', eager: true }) as Record<string, string>;

// The icons the platform's screens and the task's list need (docs/guides/code-games.md → Drawn icons)
const NEEDED = [
  'close', 'check', 'lock', 'unlock', 'chevronLeft', 'chevronRight', 'chevronUp', 'chevronDown', 'arrowLeft', 'arrowRight', 'arrowUp', 'arrowDown',
  'play', 'pause', 'settings', 'sound', 'soundOff', 'music', 'musicOff', 'star', 'coin', 'gem', 'heart', 'shield', 'bolt', 'gift', 'chest', 'trophy',
  'clock', 'calendar', 'refresh', 'share', 'info', 'plus', 'minus', 'cart', 'mapPin', 'upgrade', 'video', 'globe', 'home', 'menu',
];

describe('@gp/core/icons', () => {
  it('has every icon the platform screens and games ask for, on one 24 grid', () => {
    for (const n of NEEDED) expect(ICON_NAMES, n).toContain(n);
    expect(ICON_NAMES.length).toBeGreaterThanOrEqual(70);
    // Every coordinate of every path stays on the 24-unit box (a little room for round caps)
    for (const [name, def] of Object.entries(ICONS)) {
      expect(def.length, name).toBeGreaterThan(0);
      for (const part of def) {
        const d = part[0] === 'F' || part[0] === 'D' ? part.slice(1) : part;
        expect(d, name).toMatch(/^M/);
        const abs = [...d.matchAll(/([ML])(-?[\d.]+)[ ,](-?[\d.]+)/g)].map((m) => [Number(m[2]), Number(m[3])]);
        for (const [x, y] of abs) {
          expect(x, `${name} x`).toBeGreaterThanOrEqual(0);
          expect(x, `${name} x`).toBeLessThanOrEqual(24);
          expect(y, `${name} y`).toBeGreaterThanOrEqual(0);
          expect(y, `${name} y`).toBeLessThanOrEqual(24);
        }
      }
    }
  });

  it('markup: currentColor, decorative by default, a label when given, styles fill the closed shapes', () => {
    const line = iconSvg('heart');
    expect(line).toContain('viewBox="0 0 24 24"');
    expect(line).toContain('stroke="currentColor"');
    expect(line).toContain('aria-hidden="true"');
    expect(line).toContain('data-icon="heart"');
    expect(line).toContain('fill="none"');
    const solid = iconSvg('heart', { style: 'solid', color: '#ff4f6d', size: 32, title: 'Lives' });
    expect(solid).toContain('fill="#ff4f6d"');
    expect(solid).toContain('width:32px');
    expect(solid).toContain('role="img" aria-label="Lives"');
    expect(iconSvg('coin', { style: 'duo' })).toContain('fill-opacity="0.3"');
    expect(iconSvg('coin', { style: 'solid', detail: '#5a3a00' })).toContain('stroke="#5a3a00"');
    expect(iconSvg('star', { glow: true, color: '#ffd166' })).toContain('drop-shadow(0 0 3px #ffd166)');
    // A game's own drawing takes the same path
    expect(iconSvg(['M4 4h16v16H4z'])).toContain('<path d="M4 4h16v16H4z"/>');
  });

  it('a data URL for CSS and <img>: a concrete colour, never currentColor', () => {
    const url = iconUrl('gift', { size: 28 });
    expect(url.startsWith('data:image/svg+xml,')).toBe(true);
    const svg = decodeURIComponent(url.slice('data:image/svg+xml,'.length));
    expect(svg).toContain('stroke="#ffffff"');
    expect(svg).toContain('width:28px');
  });

  it("the platform's own screens draw their marks: no 🔒 ✓ ◀ ▶ ● ○ 🪙 📍 × glyphs in their code", () => {
    const files = ['shop-ui.ts', 'sites-map.ts', 'streak-ui.ts', 'season-ui.ts', 'welcome.ts', 'results-ui.ts', 'rewarded-button.ts'];
    const GLYPH = /[🔒✓✔◀▶●○🪙📍⬆]|'×'/u;
    for (const f of files) {
      const code = SOURCES[`../src/${f}`]
        .replace(/\/\*[\s\S]*?\*\//g, '')
        .replace(/(^|[^:])\/\/.*$/gm, '$1')
        // the leading-▶ the rewarded button turns into its drawn mark
        .replace(/\[▶►▸⯈\]/g, '');
      expect(code.match(GLYPH)?.[0], f).toBeUndefined();
    }
  });
});
