// The physics block's own logic on a recording fake of Rapier: the fixed step and its accumulator, the cap per call, the
// host's pauses, the adapter's run, reset/destroy freeing everything once, the WebAssembly init once. The real Rapier
// (pauses in a browser, WASM memory over 100 resets, determinism, Canvas 2D and Pixi) is tested in
// packages/physics/test-browser/rapier-real.test.ts.

import { describe, expect, it, vi } from 'vitest';
import type { GameHost } from '@gp/core';
import type { Engine } from '@gp/core/engines/canvas';
import { createPhysics, initRapier, livePhysicsWorlds, physicsAfterInit, type PhysicsEngine, type PhysicsHost } from '../src/index.ts';

/** A Rapier module that records what the block does with it */
function fakeRapier() {
  const log: string[] = [];
  let worlds = 0;
  class World {
    id = ++worlds;
    timestep = 0;
    lengthUnit = 1;
    steps = 0;
    pending: [number, number, boolean][] = [];
    constructor(public gravity: { x: number; y: number }) {
      log.push(`world${this.id}`);
    }
    step(q?: EventQueue): void {
      this.steps++;
      if (q) q.events.push(...this.pending);
    }
    free(): void {
      log.push(`free world${this.id}`);
    }
  }
  class EventQueue {
    events: [number, number, boolean][] = [];
    constructor(public autoDrain: boolean) {
      log.push('queue');
    }
    drainCollisionEvents(f: (a: number, b: number, s: boolean) => void): void {
      const e = this.events;
      this.events = [];
      for (const [a, b, s] of e) f(a, b, s);
    }
    free(): void {
      log.push('free queue');
    }
  }
  const R = { init: vi.fn(async () => {}), World, EventQueue };
  return { R, log };
}

function fakeHost() {
  const pauses: ((r: string) => void)[] = [];
  const resumes: (() => void)[] = [];
  const h = {
    paused: false,
    onPause: (fn: (r: string) => void) => void pauses.push(fn),
    onResume: (fn: () => void) => void resumes.push(fn),
    pause(r = 'hidden') {
      h.paused = true;
      for (const f of pauses) f(r);
    },
    resume() {
      h.paused = false;
      for (const f of resumes) f();
    },
  };
  return h satisfies PhysicsHost;
}

function fakeEngine() {
  const fns: ((dt: number) => void)[] = [];
  const e = {
    running: true,
    onStep(fn: (dt: number) => void) {
      fns.push(fn);
      return () => void fns.splice(fns.indexOf(fn), 1);
    },
    /** The adapter's fixed step: like the driver, it stops calling listeners once the run stops */
    tick(dt: number) {
      for (const fn of [...fns]) {
        if (!e.running) return;
        fn(dt);
      }
    },
  };
  return e satisfies PhysicsEngine;
}

describe('the world', () => {
  it('is made after the WebAssembly init, with the fixed step, gravity and lengthUnit; setup() builds it', async () => {
    const { R, log } = fakeRapier();
    const setup = vi.fn();
    const p = await createPhysics(R, { gravity: { x: 0, y: 900 }, lengthUnit: 40, setup });
    expect(R.init).toHaveBeenCalledTimes(1);
    expect(log).toEqual(['world1', 'queue']);
    expect(p.world.timestep).toBeCloseTo(1 / 60, 12);
    expect(p.world.lengthUnit).toBe(40);
    expect(p.world.gravity).toEqual({ x: 0, y: 900 });
    expect(setup).toHaveBeenCalledWith(p.world, R);
    expect(p.events.autoDrain).toBe(true);
    p.destroy();
  });

  it('initialises a Rapier module once (the compat build decodes its base64 on every init call)', async () => {
    const { R } = fakeRapier();
    await Promise.all([initRapier(R), initRapier(R), createPhysics(R).then((p) => p.destroy())]);
    expect(R.init).toHaveBeenCalledTimes(1);
  });

  it('a failed init is a readable Error (the player shows "can\'t run"), and can be tried again', async () => {
    const { R } = fakeRapier();
    R.init.mockRejectedValueOnce(new Error('CompileError: bad module'));
    await expect(createPhysics(R)).rejects.toThrow(/physics \(WebAssembly\) could not start: CompileError/);
    await expect(createPhysics(R).then((p) => p.destroy())).resolves.toBeUndefined();
  });

  it('without WebAssembly: a readable Error before any init', async () => {
    const { R } = fakeRapier();
    vi.stubGlobal('WebAssembly', undefined);
    try {
      await expect(createPhysics(R)).rejects.toThrow('no WebAssembly in this browser');
    } finally {
      vi.unstubAllGlobals();
    }
    expect(R.init).not.toHaveBeenCalled();
  });

  it("takes the platform's own host and adapters as they are (types)", () => {
    // Compile-time: GameHost and every adapter's Engine fit what the block listens to
    const fits = (h: GameHost, e: Engine): [PhysicsHost, PhysicsEngine] => [h, e];
    expect(typeof fits).toBe('function');
  });

  it('refuses a step that is not a positive number', () => {
    expect(() => physicsAfterInit(fakeRapier().R, { dt: 0 })).toThrow(/dt/);
  });
});

describe('the fixed step', () => {
  it('advance(): whole steps of dt from an accumulator; the remainder waits for the next call', () => {
    const p = physicsAfterInit(fakeRapier().R, { dt: 1 / 60 });
    expect(p.advance(1 / 120)).toBe(0);
    expect(p.alpha).toBeCloseTo(0.5, 9);
    expect(p.advance(1 / 120)).toBe(1);
    expect(p.advance(0.05)).toBe(3);
    expect(p.world.steps).toBe(4);
    // 1/60 added sixty times: sixty steps, not fifty-nine (the rounding epsilon)
    let n = 0;
    for (let i = 0; i < 60; i++) n += p.advance(1 / 60);
    expect(n).toBe(60);
    p.destroy();
  });

  it('caps the steps of one call (maxSteps) and drops the rest: a slow frame plays slower, no burst later', () => {
    const p = physicsAfterInit(fakeRapier().R, { dt: 1 / 60, maxSteps: 4 });
    expect(p.advance(2)).toBe(4);
    expect(p.stats.droppedSec).toBeCloseTo(2 - 4 / 60, 9);
    expect(p.advance(1 / 60)).toBe(1);
    p.destroy();
  });

  it('nothing while the host is paused (every reason), and the paused time is never caught up', () => {
    const host = fakeHost();
    const p = physicsAfterInit(fakeRapier().R, { host });
    p.advance(1 / 120);
    for (const reason of ['hidden', 'ad', 'context']) {
      host.pause(reason);
      expect(p.advance(1)).toBe(0);
      host.resume();
      // The half step from before the pause is gone too: the first frame after it counts from zero
      expect(p.advance(1 / 120)).toBe(0);
      expect(p.advance(1 / 120)).toBe(1);
    }
    expect(p.world.steps).toBe(3);
    p.destroy();
  });

  it('attach(): one world step per adapter step of the same dt; nothing while the run is off', () => {
    const p = physicsAfterInit(fakeRapier().R, { dt: 1 / 60 });
    const eng = fakeEngine();
    const off = p.attach(eng);
    for (let i = 0; i < 10; i++) eng.tick(1 / 60);
    expect(p.world.steps).toBe(10);
    eng.running = false;
    expect(p.advance(1)).toBe(0);
    eng.running = true;
    // An adapter at 1/120: a world step every second call
    for (let i = 0; i < 10; i++) eng.tick(1 / 120);
    expect(p.world.steps).toBe(15);
    off();
    eng.tick(1 / 60);
    expect(p.world.steps).toBe(15);
    p.destroy();
  });

  it('a listener that stops the run (inside a collision or a step) stops the remaining steps and events at once', () => {
    const p = physicsAfterInit(fakeRapier().R, { dt: 1 / 60, maxSteps: 6 });
    const eng = fakeEngine();
    p.attach(eng);
    p.world.pending = [[1, 2, true], [3, 4, true]];
    const hits: number[] = [];
    p.onCollision((a) => {
      hits.push(a);
      eng.running = false;
    });
    const after = vi.fn();
    p.onStep(after);
    // A slow frame's catch-up: six steps due, the first one's first event ends the run
    expect(p.advance(6 / 60)).toBe(1);
    expect(hits).toEqual([1]);
    expect(after).not.toHaveBeenCalled();
    p.destroy();
  });

  it('collision events go to every listener, then the step listeners; unsubscribe works', () => {
    const p = physicsAfterInit(fakeRapier().R);
    p.world.pending = [[5, 6, true]];
    const order: string[] = [];
    const off = p.onCollision((a, b, s) => order.push(`hit ${a}-${b} ${s}`));
    p.onStep(() => order.push('step'));
    p.step();
    off();
    p.step();
    expect(order).toEqual(['hit 5-6 true', 'step', 'step']);
    p.destroy();
  });
});

describe('reset and destroy free everything, once', () => {
  it('reset(): kept objects, the queue, the world freed, in that order; a fresh world with setup() again', () => {
    const { R, log } = fakeRapier();
    const setup = vi.fn();
    const p = physicsAfterInit(R, { setup });
    const a = p.keep({ free: () => log.push('free a') });
    p.keep({ free: () => log.push('free b') });
    p.advance(1 / 120);
    log.length = 0;
    p.reset();
    expect(log).toEqual(['free b', 'free a', 'free queue', 'free world1', 'world2', 'queue']);
    expect(setup).toHaveBeenCalledTimes(2);
    expect(p.world.steps).toBe(0);
    // The accumulator started empty: half a step before the reset doesn't complete one after it
    expect(p.advance(1 / 120)).toBe(0);
    log.length = 0;
    p.reset();
    // a was freed with the first world: never twice
    expect(log).not.toContain('free a');
    p.free(p.keep(a));
    expect(log.filter((l) => l === 'free a')).toHaveLength(1);
    p.destroy();
  });

  it('100 resets: 101 worlds made, 101 freed after destroy(), nothing live; nothing works after destroy()', () => {
    const { R, log } = fakeRapier();
    const before = livePhysicsWorlds();
    const p = physicsAfterInit(R);
    for (let i = 0; i < 100; i++) {
      p.keep({ free: () => {} });
      p.advance(1 / 60);
      p.reset();
    }
    expect(p.stats).toMatchObject({ created: 101, freed: 100, live: 1, resets: 100, steps: 100 });
    expect(livePhysicsWorlds()).toBe(before + 1);
    p.destroy();
    p.destroy();
    expect(p.stats).toMatchObject({ created: 101, freed: 101, live: 0, freedObjects: 100 + 101 });
    expect(livePhysicsWorlds()).toBe(before);
    expect(log.filter((l) => l.startsWith('free world'))).toHaveLength(101);
    p.reset();
    p.step();
    expect(p.advance(1)).toBe(0);
    expect(p.stats.created).toBe(101);
    expect(() => p.keep({ free: () => {} })).toThrow(/after destroy/);
  });

  it('pose(): a body\'s position and angle for drawing', () => {
    const p = physicsAfterInit(fakeRapier().R);
    expect(p.pose({ translation: () => ({ x: 3, y: 4 }), rotation: () => 0.5 })).toEqual({ x: 3, y: 4, angle: 0.5 });
    p.destroy();
  });
});
