// Browser test of TwinStick / LookInput (@gp/core twin-stick.ts): first person under pointer lock ("Click to aim"
// removed on pointerlockchange, the click also fires, the lock lost → the game's pause, P pauses and Esc doesn't, a
// refused lock → drag to look), top-down aim (the mouse from the hero, the arrows fire, chorded right button, a
// debounced wheel), the touch layer (a floating stick and a look/aim half, drawn from the first frame, touch-size
// buttons) and the host's pause (an ad lets everything go and gives the lock back; nothing is read while paused).
// Runs with `npm run test:browser` (needs Playwright's Chromium).

import { fileURLToPath } from 'node:url';
import { chromium, type Browser, type Page } from 'playwright';
import { createServer, type ViteDevServer } from 'vite';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

let server: ViteDevServer;
let browser: Browser;
let base = '';

beforeAll(async () => {
  server = await createServer({ root: fileURLToPath(new URL('./twin-stick-fixture', import.meta.url)), configFile: false, logLevel: 'error', server: { port: 0 } });
  await server.listen();
  base = server.resolvedUrls!.local[0];
  browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
}, 60000);

afterAll(async () => {
  await browser?.close();
  await server?.close();
});

interface State {
  move: { x: number; y: number };
  fire: boolean;
  yaw: number;
  pitch: number;
  touch: boolean;
  locked: boolean;
  refused: boolean;
  layer: boolean;
  prompt: boolean | null;
  promptText: string | null;
  aim: { x: number; y: number } | null;
}
interface T {
  host: { adBreak(): Promise<void>; paused: boolean };
  input: { setActive(on: boolean): void; take(id: string): boolean; holding(id: string): boolean; lock(): void; takeLook(): { dx: number; dy: number }; yaw: number };
  log: string[];
  lockCalls: number[];
  grant(): void;
  setHidden(h: boolean): void;
  pointer(type: string, target: Element, x: number, y: number, id?: number, pointerType?: string): void;
  el(sel: string): Element;
  state(): State;
}
const t = <R>(page: Page, fn: (t: T) => R) => page.evaluate(`(${fn.toString()})(window.__t)`) as Promise<Awaited<R>>;
const until = (page: Page, fn: (t: T) => boolean) => page.waitForFunction(`(${fn.toString()})(window.__t)`, null, { timeout: 10000 });

async function open(query: string, opts: { touch?: boolean } = {}): Promise<Page> {
  const ctx = await browser.newContext({ viewport: { width: 640, height: 360 }, ...(opts.touch ? { hasTouch: true, isMobile: true } : {}) });
  const page = await ctx.newPage();
  const errors: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message));
  await page.goto(`${base}?${query}`);
  await page.waitForFunction('!!window.__t');
  (page as unknown as { errors: string[] }).errors = errors;
  return page;
}
const errorsOf = (page: Page) => (page as unknown as { errors: string[] }).errors;
/** A mouse move with movement (the locked pointer's), dispatched on the window */
const look = (page: Page, mx: number, my: number, buttons = 0) => page.evaluate(([mx, my, b]) => window.dispatchEvent(new MouseEvent('mousemove', { movementX: mx, movementY: my, clientX: 320, clientY: 180, buttons: b })), [mx, my, buttons]);

describe('LookInput (first person, a desktop)', () => {
  it('"Click to aim" while active; the click takes the lock and fires; the prompt goes when the lock comes (not in the click)', async () => {
    const page = await open('mode=look&hold=1');
    expect(await t(page, (x) => x.state())).toMatchObject({ prompt: false, layer: false, touch: false });
    await t(page, (x) => x.input.setActive(true));
    expect(await t(page, (x) => x.state())).toMatchObject({ prompt: true, promptText: 'Click to aim', layer: false });
    await page.mouse.move(320, 180);
    await page.mouse.down();
    // The lock is asked for in the click and granted later: the prompt is still there, fire is held already
    expect(await t(page, (x) => ({ ...x.state(), calls: x.lockCalls.length }))).toMatchObject({ calls: 1, locked: false, prompt: true, fire: true });
    await t(page, (x) => x.grant());
    await until(page, (x) => x.state().locked);
    expect(await t(page, (x) => x.state())).toMatchObject({ prompt: false, fire: true });
    await page.mouse.up();
    expect(await t(page, (x) => x.state().fire)).toBe(false);
    expect(await t(page, (x) => x.log)).toEqual(['first:fire', 'lock']);
    expect(errorsOf(page)).toEqual([]);
    await page.context().close();
  });

  it('the locked mouse looks (one huge jump clamped, pitch limited); WASD and the arrows move; the look delta is taken once', async () => {
    const page = await open('mode=look');
    await t(page, (x) => x.input.setActive(true));
    await page.mouse.click(320, 180);
    await until(page, (x) => x.state().locked);
    await look(page, 100, 0);
    expect(await t(page, (x) => x.state().yaw)).toBeCloseTo(0.22);
    await look(page, 5000, 0);
    expect(await t(page, (x) => x.state().yaw)).toBeCloseTo(0.22 + 0.44);
    for (let i = 0; i < 10; i++) await look(page, 0, -200);
    expect(await t(page, (x) => x.state().pitch)).toBeCloseTo(1.25);
    expect(await t(page, (x) => x.input.takeLook())).toEqual({ dx: 300, dy: -2000 });
    expect(await t(page, (x) => x.input.takeLook())).toEqual({ dx: 0, dy: 0 });
    await page.keyboard.down('KeyW');
    await page.keyboard.down('ArrowRight');
    const m = await t(page, (x) => x.state().move);
    expect(m.x).toBeCloseTo(Math.SQRT1_2);
    expect(m.y).toBeCloseTo(-Math.SQRT1_2);
    await page.keyboard.up('KeyW');
    await page.keyboard.up('ArrowRight');
    await page.keyboard.press('Space');
    expect(await t(page, (x) => [x.input.take('dash'), x.input.take('dash')])).toEqual([true, false]);
    await page.context().close();
  });

  it('losing the lock in play pauses; P pauses, Esc does not; not active: nothing', async () => {
    const page = await open('mode=look');
    await t(page, (x) => x.input.setActive(true));
    await page.mouse.click(320, 180);
    await until(page, (x) => x.state().locked);
    await page.keyboard.press('Escape');
    expect(await t(page, (x) => x.log.filter((l) => l.startsWith('pause')))).toEqual([]);
    await page.evaluate(() => document.exitPointerLock());
    expect(await t(page, (x) => x.log.filter((l) => l.startsWith('pause')))).toEqual(['pause:lock']);
    // The prompt is back while active and unlocked
    expect(await t(page, (x) => x.state().prompt)).toBe(true);
    await page.keyboard.press('KeyP');
    expect(await t(page, (x) => x.log.filter((l) => l.startsWith('pause')))).toEqual(['pause:lock', 'pause:key']);
    await t(page, (x) => x.input.setActive(false));
    await page.keyboard.press('KeyP');
    expect(await t(page, (x) => x.log.filter((l) => l.startsWith('pause')).length)).toBe(2);
    expect(await t(page, (x) => x.state().prompt)).toBe(false);
    await page.context().close();
  });

  it('a refused lock: drag to look instead, the prompt says so and goes after the first drag', async () => {
    const page = await open('mode=look&refuse=1');
    await t(page, (x) => x.input.setActive(true));
    await page.mouse.move(320, 180);
    await page.mouse.down();
    await until(page, (x) => x.state().refused);
    expect(await t(page, (x) => x.state())).toMatchObject({ locked: false, promptText: 'Drag to look', prompt: true });
    await look(page, 50, 0, 1);
    expect(await t(page, (x) => x.state())).toMatchObject({ prompt: false });
    expect(await t(page, (x) => x.state().yaw)).toBeCloseTo(0.11);
    await page.mouse.up();
    // Without a button held the unlocked mouse doesn't look
    await look(page, 50, 0, 0);
    expect(await t(page, (x) => x.state().yaw)).toBeCloseTo(0.11);
    await page.context().close();
  });

  it("the host's pause (an ad) lets everything go, gives the lock back (the game pauses on it), and reads nothing until it ends", async () => {
    const page = await open('mode=look');
    await t(page, (x) => x.input.setActive(true));
    await page.mouse.click(320, 180);
    await until(page, (x) => x.state().locked);
    await page.keyboard.down('KeyD');
    await page.mouse.down();
    expect(await t(page, (x) => x.state())).toMatchObject({ fire: true, move: { x: 1, y: 0 } });
    await t(page, (x) => void x.host.adBreak());
    await until(page, (x) => x.host.paused);
    expect(await t(page, (x) => ({ ...x.state(), log: x.log }))).toMatchObject({ fire: false, move: { x: 0, y: 0 }, locked: false, prompt: false, log: ['first:fire', 'lock', 'pause:lock'] });
    await page.keyboard.down('KeyW');
    await look(page, 100, 0);
    expect(await t(page, (x) => x.state())).toMatchObject({ move: { x: 0, y: 0 }, yaw: 0 });
    await until(page, (x) => !x.host.paused);
    // Held keys were let go: still nothing until pressed again
    expect(await t(page, (x) => x.state().move)).toEqual({ x: 0, y: 0 });
    await page.keyboard.up('KeyW');
    await page.keyboard.up('KeyD');
    await page.mouse.up();
    expect(errorsOf(page)).toEqual([]);
    await page.context().close();
  });
});

describe('TwinStick (top-down, a desktop)', () => {
  it('the mouse aims from the hero, the left button fires, the right button and the wheel are buttons; arrows fire, WASD moves', async () => {
    const page = await open('mode=aim');
    await t(page, (x) => x.input.setActive(true));
    expect(await t(page, (x) => x.state())).toMatchObject({ prompt: null, aim: null, fire: false });
    await page.mouse.move(420, 180);
    const a = await t(page, (x) => x.state().aim);
    expect(a!.x).toBeCloseTo(1);
    await page.mouse.down();
    expect(await t(page, (x) => x.state().fire)).toBe(true);
    // A right press while the left is held (chorded: it arrives as a move with both buttons)
    await page.mouse.down({ button: 'right' });
    expect(await t(page, (x) => [x.input.take('skill'), x.input.take('skill')])).toEqual([true, false]);
    await page.mouse.up({ button: 'right' });
    await page.mouse.up();
    expect(await t(page, (x) => x.state().fire)).toBe(false);
    for (let i = 0; i < 5; i++) await page.mouse.wheel(0, 40);
    expect(await t(page, (x) => [x.input.take('swap'), x.input.take('swap')])).toEqual([true, false]);
    await page.keyboard.down('ArrowUp');
    expect(await t(page, (x) => x.state())).toMatchObject({ fire: true, aim: { x: 0, y: -1 }, move: { x: 0, y: 0 } });
    await page.keyboard.up('ArrowUp');
    await page.keyboard.down('KeyA');
    expect(await t(page, (x) => x.state().move)).toEqual({ x: -1, y: 0 });
    await page.keyboard.up('KeyA');
    expect(errorsOf(page)).toEqual([]);
    await page.context().close();
  });
});

describe('the touch layer (a phone)', () => {
  it('drawn from the first frame of play at touch size; hidden on menus; a floating move stick under the left thumb', async () => {
    const page = await open('mode=look', { touch: true });
    expect(await t(page, (x) => x.state())).toMatchObject({ touch: true, layer: false });
    await t(page, (x) => x.input.setActive(true));
    expect(await t(page, (x) => x.state())).toMatchObject({ layer: true, prompt: false });
    const controls = await page.evaluate(() =>
      [...document.querySelectorAll<HTMLElement>('[data-gp-touch]')].map((e) => {
        const r = (e.classList.contains('gp-ts-move') ? e.querySelector('.gp-ts-base')! : e).getBoundingClientRect();
        return { id: e.dataset.gpTouch, w: Math.round(r.width), h: Math.round(r.height), on: r.left >= 0 && r.right <= innerWidth && r.top >= 0 && r.bottom <= innerHeight };
      }),
    );
    expect(controls.map((c) => c.id)).toEqual(['move', 'look', 'fire', 'dash']);
    for (const c of controls) {
      expect(c.on, c.id).toBe(true);
      expect(Math.min(c.w, c.h), c.id).toBeGreaterThanOrEqual(48);
    }
    // The stick: down at (100, 200), drag right and up
    await t(page, (x) => {
      const pad = x.el('.gp-ts-move');
      x.pointer('pointerdown', pad, 100, 200, 3);
      x.pointer('pointermove', pad, 152, 200, 3);
    });
    const m = await t(page, (x) => x.state().move);
    expect(m.x).toBeCloseTo(1);
    const knob = await page.evaluate(() => (document.querySelector('.gp-ts-knob') as HTMLElement).style.transform);
    expect(knob).toBe('translate(52px, 0px)');
    await t(page, (x) => x.pointer('pointerup', x.el('.gp-ts-move'), 152, 200, 3));
    expect(await t(page, (x) => x.state().move)).toEqual({ x: 0, y: 0 });
    expect(await t(page, (x) => x.log)).toEqual(['first:move']);
    await t(page, (x) => x.input.setActive(false));
    expect(await t(page, (x) => x.state().layer)).toBe(false);
    await page.context().close();
  });

  it('first person: a drag on the right half looks (×1.6), Fire fires and is a look surface too; the stick and a look drag at once', async () => {
    const page = await open('mode=look', { touch: true });
    await t(page, (x) => x.input.setActive(true));
    await t(page, (x) => {
      x.pointer('pointerdown', x.el('.gp-ts-move'), 100, 200, 3);
      x.pointer('pointermove', x.el('.gp-ts-move'), 100, 150, 3);
      const pad = x.el('.gp-ts-look');
      x.pointer('pointerdown', pad, 450, 150, 4);
      x.pointer('pointermove', pad, 500, 150, 4);
    });
    const s = await t(page, (x) => x.state());
    expect(s.yaw).toBeCloseTo(50 * 0.0022 * 1.6);
    expect(s.move.y).toBeCloseTo(-50 / 52);
    expect(s.fire).toBe(false);
    await t(page, (x) => {
      const fire = x.el('[data-gp-touch=fire]');
      const r = fire.getBoundingClientRect();
      x.pointer('pointerdown', fire, r.x + 10, r.y + 10, 5);
      x.pointer('pointermove', fire, r.x + 30, r.y + 10, 5);
    });
    const f = await t(page, (x) => x.state());
    expect(f.fire).toBe(true);
    expect(f.yaw).toBeCloseTo(70 * 0.0022 * 1.6);
    await t(page, (x) => x.pointer('pointerup', x.el('[data-gp-touch=fire]'), 0, 0, 5));
    expect(await t(page, (x) => x.state().fire)).toBe(false);
    await page.context().close();
  });

  it('top-down: a drag on the right half aims and fires; no drag: aim() is null (auto-aim)', async () => {
    const page = await open('mode=aim', { touch: true });
    await t(page, (x) => x.input.setActive(true));
    expect(await t(page, (x) => x.state())).toMatchObject({ aim: null, fire: false });
    await t(page, (x) => {
      const pad = x.el('.gp-ts-look');
      x.pointer('pointerdown', pad, 450, 150, 4);
      x.pointer('pointermove', pad, 450, 100, 4);
    });
    expect(await t(page, (x) => x.state())).toMatchObject({ aim: { x: 0, y: -1 }, fire: true });
    await t(page, (x) => x.pointer('pointerup', x.el('.gp-ts-look'), 450, 100, 4));
    expect(await t(page, (x) => x.state())).toMatchObject({ aim: null, fire: false });
    // Paused (a hidden tab): no drag is read, the layer is down
    await t(page, (x) => x.setHidden(true));
    await t(page, (x) => {
      const pad = x.el('.gp-ts-look');
      x.pointer('pointerdown', pad, 450, 150, 6);
      x.pointer('pointermove', pad, 450, 100, 6);
    });
    expect(await t(page, (x) => x.state())).toMatchObject({ aim: null, fire: false, layer: false });
    await t(page, (x) => x.setHidden(false));
    expect(await t(page, (x) => x.state().layer)).toBe(true);
    expect(errorsOf(page)).toEqual([]);
    await page.context().close();
  });
});
