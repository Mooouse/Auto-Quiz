// The subset of JSON Schema the platform uses to describe game.yaml sections.
// Every building block declares the schema of its own settings; the validator, the editor schema
// (game.schema.json) and the reference docs are all generated from these declarations.

export interface JsonSchema {
  type?: 'object' | 'array' | 'string' | 'number' | 'integer' | 'boolean';
  title?: string;
  description?: string;
  enum?: readonly (string | number | boolean)[];
  const?: string | number | boolean;
  properties?: Record<string, JsonSchema>;
  required?: readonly string[];
  additionalProperties?: boolean | JsonSchema;
  items?: JsonSchema;
  minItems?: number;
  maxItems?: number;
  minimum?: number;
  maximum?: number;
  exclusiveMinimum?: number;
  minLength?: number;
  maxLength?: number;
  pattern?: string;
  default?: unknown;
  examples?: readonly unknown[];
  oneOf?: readonly JsonSchema[];
  /** Platform extension: the value is the id of a catalog entry of this kind (checked, with "did you mean") */
  'x-gp-ref'?: 'theme' | 'content' | 'mechanic' | 'trajectory' | 'kit' | 'stickers';
}
