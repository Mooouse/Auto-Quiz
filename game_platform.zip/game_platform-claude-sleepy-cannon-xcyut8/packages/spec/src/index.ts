// @gp/spec — GameSpec: parse, check and resolve game.yaml.

import { CATALOG, type CatalogKind } from './catalog.ts';
import { checkSchema } from './check-schema.ts';
import type { Issue } from './errors.ts';
import { loadYaml } from './load.ts';
import { resolveGame, type ResolveOptions } from './resolve.ts';
import { gameSchema } from './schema.ts';
import type { GameSpecInput, ResolvedGame } from './types.ts';

export { AUDIENCES, CHANNELS, FAMILIES_AD_POLICY, ADMOB_TEST_IDS, type AudienceProfile, type ChannelProfile } from './profiles.ts';
export {
  SLOW_PHONE,
  LOAD_MODEL,
  budgetFor,
  embeddedDataBytes,
  estimateLoad,
  overBudget,
  type Budget,
  type LoadEstimate,
  type PackageShare,
  type SizeReport,
  type UploadBytes,
} from './budget.ts';
export { ERRORS, formatPath, SCOPE_MAX_SCREENS, suggest, type Issue, type ErrorInfo, type Severity } from './errors.ts';
export { ENGINES, UNSUPPORTED_ENGINES, PHYSICS, PHYSICS_PACKAGES_INSTEAD, engineSupports, parseVersion, type EngineInfo, type PhysicsInfo } from './engines.ts';
export { GAME_SCHEMA, SPEC_VERSION, gameSchema } from './schema.ts';
export { CATALOG, catalogEntries, catalogIds, type CatalogKind, type CatalogEntry } from './catalog.ts';
export { loadYaml } from './load.ts';
export { explain, allFields, schemaAt, schemaVariants } from './explain.ts';
export { resolveGame, type ResolveOptions } from './resolve.ts';
export type { GameSpecInput, ResolvedGame, ModeInput, Publisher } from './types.ts';

const REF_KIND: Record<string, CatalogKind> = { theme: 'theme', content: 'content', stickers: 'stickers', mechanic: 'mechanic', trajectory: 'trajectory', kit: 'kit' };

export interface ValidateResult {
  game: ResolvedGame | null;
  issues: Issue[];
  ok: boolean;
}

/** The whole check: YAML → schema → rules + resolve. Issues get line numbers. */
export function validateText(text: string, opts: ResolveOptions): ValidateResult {
  const loaded = loadYaml(text);
  if (loaded.issues.length) return { game: null, issues: loaded.issues, ok: false };
  // Pick the kit's sections and the mechanic's round schema; unknown ids fall back to the defaults and get reported
  const d = (loaded.data ?? {}) as { kit?: unknown; round?: { mechanic?: unknown } };
  const kit = typeof d.kit === 'string' && d.kit in CATALOG.kit ? d.kit : 'kids';
  const mech = typeof d.round?.mechanic === 'string' && d.round.mechanic in CATALOG.mechanic ? d.round.mechanic : 'tap-collect';
  let issues = checkSchema(loaded.data, gameSchema(kit, mech), (kind) => Object.keys(CATALOG[REF_KIND[kind]]));
  // A kit/mechanic mismatch first: otherwise it shows up as a pile of "unknown field" errors in round
  const kitMechanics = (CATALOG.kit[kit as keyof typeof CATALOG.kit] as { mechanics: readonly string[] }).mechanics;
  if (kitMechanics.length && typeof d.round?.mechanic === 'string' && d.round.mechanic in CATALOG.mechanic && !kitMechanics.includes(d.round.mechanic))
    issues.unshift({
      code: 'E_MECHANIC_KIT',
      severity: 'error',
      path: ['round', 'mechanic'],
      message: `kit ${kit} works with mechanic ${kitMechanics.join(', ')}, not ${d.round.mechanic} (the round fields below are checked against ${d.round.mechanic})`,
      fix: `Set round.mechanic: ${kitMechanics[0]}, or pick the kit that fits the mechanic (gp explain ${kit}).`,
    });
  let game: ResolvedGame | null = null;
  if (!issues.some((i) => i.severity === 'error')) {
    const r = resolveGame(loaded.data as GameSpecInput, opts);
    issues = r.issues;
    game = r.game;
  }
  for (const i of issues) if (i.line === undefined && i.path[0] !== '(publisher.yaml)') i.line = loaded.lineOf(i.path);
  return { game, issues, ok: !issues.some((i) => i.severity === 'error') };
}
export { conceptText, TAKEN_CONCEPTS, takenConceptsFor, type TakenConcept } from './taken.ts';
export {
  DEPTH_COUNTS,
  DEPTH_INFO,
  STORY_DEPTHS,
  STORY_FITS,
  STORY_GENRES,
  allowedDepths,
  checkStoryContent,
  checkStorySection,
  contentDepth,
  depthOrder,
  describeContent,
  fitTable,
  isStoryDef,
  limitsFor,
  metaWarning,
  readStoryExports,
  storyFit,
  storyGenre,
  type StoryContent,
  type StoryDepth,
  type StoryFit,
  type StoryGenre,
  type StoryInput,
} from './story-depth.ts';
export {
  GENRES,
  GENRE_IDS,
  SUBGENRES,
  moneyGenre,
  type SubGenre,
  MONEY_CHECKED,
  MONEY_TABLE,
  RESUBMISSIONS,
  RESUBMISSION_ROW,
  RETURN_KINDS,
  REWARDED_KINDS,
  LOOT_COSTS,
  RANDOM_WORDS,
  type LootCost,
  SCENARIOS,
  TAKEN_PENALTY,
  checkMoney,
  defaultPer,
  forecast,
  genreOf,
  ideaDesign,
  ideaUniqueness,
  levers,
  loadFactor,
  midgameAds,
  moneyDesign,
  rewardedKindOf,
  type Calibration,
  type Confidence,
  type Forecast,
  type GameMoneyFacts,
  type Genre,
  type IdeaInput,
  type Lever,
  type MoneyDesign,
  type MoneyInput,
  type MoneyRow,
  type Range,
  type Resubmission,
  type ReturnKind,
  type RewardedKind,
  type Scenario,
  type Stage,
} from './money.ts';
export { BASIC_LAUNCH, deviceTotal, scoresLine, type BasicLaunchScores, type DeviceScores, type MetricScore } from './results.ts';
export { MIN_PER_PLAY, MIN_RESULTS, PER_PLAY_SCALE, PRIOR_WEIGHT, RESULTS_SCHEMA, blend, calibrate, checkResults, resubmissionOf, resubmissions, revenuePerDay, type CalibrationReport, type Comparison, type RecordedResult } from './results.ts';
export { MUSIC_REQUIRED_CHANNELS, hasMusic, musicIssues, sourceHasMusic } from './sound.ts';
export { GENRE_PHRASES, HOOK_WORDS, SUBGENRE_PHRASES, hooksFor, scoreTitle, suggestTitles, type HookWord, type TitleScore } from './naming.ts';
export { BRAND_NAMES, CAR_BRANDS, PROTECTED_NAMES, SIGNATURE_VOCABULARY, VOCABULARY_PENALTY_MAX, borrowedVocabulary, brandsIn, vocabularyPenalty, type SignatureVocabulary } from './vocabulary.ts';
export {
  GENERAL_BLOCKS,
  GENRE_BLOCKS,
  GENRE_INFO,
  SUBGENRE_INFO,
  blocksFor,
  expectationsFor,
  explainGenre,
  gameGenre,
  genreChecks,
  lootChecks,
  genreRows,
  genreTopic,
  importedBlocks,
  subGenresOf,
  type Expectation,
  type GenreBlock,
  type GenreInfo,
  type SubGenreInfo,
} from './genres.ts';
