import { describe, expect, it } from 'vitest';
import { BEAT, beatTimes, LAND_HOLD, landSize, previewScore, PITCH, ROLL, ScoreSequencer, tallySteps, type LandEvent, type ScoreStep, type StepEvent } from '../src/sequencer';

/** A chain of n steps, each at its own point (or all at one) */
const chain = (n: number, same = false): ScoreStep[] => Array.from({ length: n }, (_, i) => ({ kind: 'card', at: same ? { x: 100, y: 100 } : { x: 40 * i, y: 200 }, add: 10, ...(i % 3 === 2 ? { mult: 1 } : {}) }));

/** Drive it with a fixed frame and log every hook with its time */
function run(steps: ScoreStep[], o: { target?: number; dt?: number; until?: number; host?: { paused: boolean } } = {}) {
  const log: { t: number; what: string; e?: StepEvent | LandEvent | { k: number; sec: number } | number }[] = [];
  let t = 0;
  const seq = new ScoreSequencer({
    host: o.host,
    onStep: (e) => log.push({ t, what: 'step', e }),
    onRoll: (e) => log.push({ t, what: 'roll', e }),
    onLand: (e) => log.push({ t, what: 'land', e }),
    onDone: (total) => log.push({ t, what: 'done', e: total }),
  });
  seq.play(steps, { target: o.target });
  const dt = o.dt ?? 1 / 240;
  while (t < (o.until ?? 10) && seq.state !== 'done') {
    seq.update(dt);
    t += dt;
  }
  return { log, seq };
}

describe('ScoreSequencer: the score as a trace', () => {
  it('tallies add × mult × times step by step, and the preview is the result before it is played', () => {
    const steps: ScoreStep[] = [{ kind: 'combo', add: 30, mult: 4 }, { kind: 'card', add: 11 }, { kind: 'relic', times: 2 }, { kind: 'joint', mult: 2 }];
    const t = tallySteps(steps, { mult: 0 });
    expect(t.map((x) => x.total)).toEqual([120, 164, 328, 492]);
    expect(previewScore(steps, { mult: 0 })).toEqual({ add: 41, mult: 6, times: 2, total: 492 });
    // A results screen or offline earnings: only adds (mult stays 1)
    expect(previewScore([{ kind: 'coins', add: 120 }, { kind: 'bonus', add: 30 }]).total).toBe(150);
    expect(previewScore([]).total).toBe(0);
    const seq = new ScoreSequencer();
    seq.play(steps, { base: { mult: 0 } });
    expect(seq.preview().total).toBe(492);
  });
});

describe('ScoreSequencer: timing', () => {
  it('beats quicken from 0.28 s by 0.018 s a beat to the 0.09 s floor', () => {
    const b = beatTimes(16);
    expect(b[0]).toBeCloseTo(0.28);
    expect(b[1]).toBeCloseTo(0.262);
    for (let i = 1; i < b.length; i++) expect(b[i]).toBeLessThanOrEqual(b[i - 1]);
    expect(Math.min(...b)).toBeCloseTo(BEAT.min);
    expect(b[11]).toBeCloseTo(0.09);
  });
  it('plays each step on its beat, then lands after the last beat and is done LAND_HOLD later', () => {
    const { log } = run(chain(5));
    const steps = log.filter((l) => l.what === 'step');
    expect(steps).toHaveLength(5);
    const at = steps.map((s) => s.t);
    const gaps = at.slice(1).map((x, i) => x - at[i]);
    beatTimes(5)
      .slice(0, 4)
      .forEach((b, i) => expect(gaps[i]).toBeCloseTo(b, 2));
    const land = log.find((l) => l.what === 'land')!;
    expect(land.t - at[4]).toBeCloseTo(beatTimes(5)[4], 2);
    const done = log.find((l) => l.what === 'done')!;
    expect(done.t - land.t).toBeCloseTo(LAND_HOLD, 2);
    expect(done.e).toBe(previewScore(chain(5)).total);
  });
  it('the pitch climbs a semitone a beat and stops at its cap', () => {
    const { log } = run(chain(24));
    const p = log.filter((l) => l.what === 'step').map((l) => (l.e as StepEvent).pitch);
    expect(p[0]).toBe(1);
    expect(p[12]).toBeCloseTo(2);
    expect(p[PITCH.cap]).toBeCloseTo(p[23]);
    for (let i = 1; i <= PITCH.cap; i++) expect(p[i]).toBeGreaterThan(p[i - 1]);
  });
  it('a long chain rolls once, at its 7th beat, for the rest of its length; a short one never', () => {
    const long = run(chain(20)).log;
    const rolls = long.filter((l) => l.what === 'roll');
    expect(rolls).toHaveLength(1);
    const stepsBefore = long.slice(0, long.indexOf(rolls[0])).filter((l) => l.what === 'step');
    expect(stepsBefore).toHaveLength(ROLL.at + 1);
    const r = rolls[0].e as { k: number; sec: number };
    expect(r.k).toBeCloseTo(20 / 30);
    expect(r.sec).toBeCloseTo(beatTimes(20).slice(ROLL.at).reduce((a, b) => a + b, 0));
    expect(run(chain(ROLL.after)).log.some((l) => l.what === 'roll')).toBe(false);
  });
  it('a slow frame fires the beats it covered, in order, never skipping one', () => {
    const { log } = run(chain(8), { dt: 0.25 });
    expect(log.filter((l) => l.what === 'step').map((l) => (l.e as StepEvent).index)).toEqual([0, 1, 2, 3, 4, 5, 6, 7]);
  });
  it('the count-up eases to each beat\'s tally and shows the total once landed', () => {
    const seq = new ScoreSequencer();
    seq.play([{ kind: 'a', add: 100 }, { kind: 'b', add: 100 }]);
    seq.update(0);
    expect(seq.shown.total).toBe(0);
    seq.update(0.05);
    const mid = seq.shown.total;
    expect(mid).toBeGreaterThan(0);
    expect(mid).toBeLessThan(100);
    seq.update(0.2);
    expect(seq.shown.total).toBeCloseTo(100);
    seq.update(0.2);
    seq.update(0.2);
    expect(seq.state).toBe('land');
    expect(seq.shown.total).toBe(200);
  });
});

describe('ScoreSequencer: the land, the tap, the pause', () => {
  it('the land is sized by log(total / target): a quarter 0.3, the target 0.9, far over it 1; no target 0.5', () => {
    expect(landSize(25, 100)).toBeCloseTo(0.3);
    expect(landSize(100, 100)).toBeCloseTo(0.902, 2);
    expect(landSize(1000, 100)).toBe(1);
    expect(landSize(1, 1000)).toBe(0);
    expect(landSize(50)).toBe(0.5);
    const { log } = run(chain(3), { target: 30 });
    expect((log.find((l) => l.what === 'land')!.e as LandEvent).big).toBeCloseTo(landSize(previewScore(chain(3)).total, 30));
  });
  it('a tap fast-forwards: the steps left apply at once (fast), the total lands; a second tap ends the land', () => {
    const fired: StepEvent[] = [];
    let landed: LandEvent | null = null;
    let done = -1;
    const seq = new ScoreSequencer({ onStep: (e) => fired.push(e), onLand: (e) => (landed = e), onDone: (t) => (done = t) });
    const steps = chain(10);
    seq.play(steps);
    seq.update(0);
    seq.update(0.15);
    seq.update(0.15);
    expect(fired).toHaveLength(2);
    seq.skip();
    expect(fired).toHaveLength(10);
    expect(fired.slice(2).every((e) => e.fast)).toBe(true);
    expect(fired.slice(0, 2).every((e) => !e.fast)).toBe(true);
    expect(landed!.fast).toBe(true);
    expect(landed!.total).toBe(previewScore(steps).total);
    expect(seq.state).toBe('land');
    seq.skip();
    expect(seq.state).toBe('done');
    expect(done).toBe(previewScore(steps).total);
  });
  it('stands still while the host is paused (an ad, a hidden tab) and while held', () => {
    const host = { paused: false };
    const fired: number[] = [];
    const seq = new ScoreSequencer({ host, onStep: (e) => fired.push(e.index) });
    seq.play(chain(6));
    seq.update(0);
    host.paused = true;
    for (let i = 0; i < 100; i++) seq.update(0.1);
    expect(fired).toEqual([0]);
    host.paused = false;
    seq.update(0.15);
    seq.update(0.15);
    expect(fired).toEqual([0, 1]);
    seq.pause(true);
    seq.update(5);
    expect(fired).toEqual([0, 1]);
    seq.pause(false);
    for (let i = 0; i < 6; i++) seq.update(0.2);
    expect(seq.beat).toBe(6);
  });
  it('a new play finishes the one still playing first (its onDone fires with its total)', () => {
    const done: number[] = [];
    const seq = new ScoreSequencer({ onDone: (t) => done.push(t) });
    seq.play([{ kind: 'a', add: 5 }]);
    seq.play([{ kind: 'b', add: 7 }]);
    expect(done).toEqual([5]);
    for (let i = 0; i < 100; i++) seq.update(0.05);
    expect(done).toEqual([5, 7]);
  });
  it('the game\'s own total wins over add × mult × times', () => {
    const { log } = run([{ kind: 'a', add: 3, mult: 2 }]);
    expect(log.find((l) => l.what === 'done')!.e).toBe(9);
    let total = 0;
    const seq = new ScoreSequencer({ onDone: (t) => (total = t) });
    seq.play([{ kind: 'a', add: 3, mult: 2 }], { total: 42 });
    seq.finish();
    expect(total).toBe(42);
  });
});

describe('ScoreSequencer: labels', () => {
  const overlap = (a: { x: number; y: number; w: number; h: number }, b: typeof a) => Math.abs(a.x - b.x) * 2 < a.w + b.w && Math.abs(a.y - b.y) * 2 < a.h + b.h;
  it('labels of steps at one spot never overlap: each moves clear of the ones still showing', () => {
    const seq = new ScoreSequencer();
    seq.play(chain(12, true).map((s, i) => ({ ...s, times: i % 4 === 3 ? 2 : undefined })));
    let worst = 0;
    for (let i = 0; i < 400 && seq.state === 'beats'; i++) {
      seq.update(1 / 60);
      const L = seq.labels();
      worst = Math.max(worst, L.length);
      // Compare where they were placed (before the drift, which moves them all alike over their life)
      for (let a = 0; a < L.length; a++) for (let b = a + 1; b < L.length; b++) if (Math.abs(L[a].age - L[b].age) < 1e-9) expect(overlap(L[a], L[b])).toBe(false);
    }
    expect(worst).toBeGreaterThan(2);
  });
  it('labels show the numbers by kind, or the step\'s own words, and fade in their last third', () => {
    const seq = new ScoreSequencer();
    seq.play([{ kind: 'x', at: { x: 0, y: 0 }, add: 12, mult: 3, times: 1.5 }, { kind: 'y', at: { x: 300, y: 0 }, label: 'Echo!' }]);
    seq.update(0);
    expect(seq.labels().map((l) => [l.text, l.kind])).toEqual([['+12', 'add'], ['+3', 'mult'], ['×1.5', 'times']]);
    seq.update(0.15);
    seq.update(0.15);
    expect(seq.labels().at(-1)!.text).toBe('Echo!');
    seq.update(0.25);
    seq.update(0.25);
    const old = seq.labels()[0];
    expect(old.alpha).toBeLessThan(1);
    seq.update(0.25);
    seq.update(0.25);
    expect(seq.labels().some((l) => l.text === '+12')).toBe(false);
  });
  it('labels stay inside the bounds given', () => {
    const seq = new ScoreSequencer({ labels: { bounds: { w: 200, h: 100 } } });
    seq.play([{ kind: 'edge', at: { x: 199, y: 2 }, add: 123456 }]);
    seq.update(0);
    const l = seq.labels()[0];
    expect(l.x + l.w / 2).toBeLessThanOrEqual(200);
    expect(l.y - l.h / 2).toBeGreaterThanOrEqual(0);
  });
});
