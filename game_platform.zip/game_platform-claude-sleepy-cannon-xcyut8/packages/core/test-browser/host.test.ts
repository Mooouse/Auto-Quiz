// Browser test of GameHost's pause reasons (kit: code): a hidden tab, an ad and a lost WebGL context, alone and together.
// The repros come from the engine lab (QmaCyber/game12 REPORT.md): onPause fired only for the first reason, so a tab
// hidden during an ad never paused the game; adPending was still true in onResume; nothing handled a WebGL context loss.
// Runs with `npm run test:browser` (needs Playwright's Chromium). The fixture page logs what a game would see.

import { fileURLToPath } from 'node:url';
import { chromium, type Browser, type Page } from 'playwright';
import { createServer, type ViteDevServer } from 'vite';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

let server: ViteDevServer;
let browser: Browser;
let base = '';

beforeAll(async () => {
  server = await createServer({ root: fileURLToPath(new URL('./host-fixture', import.meta.url)), configFile: false, logLevel: 'error', server: { port: 0 } });
  await server.listen();
  base = server.resolvedUrls!.local[0];
  browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
}, 60000);

afterAll(async () => {
  await browser?.close();
  await server?.close();
});

interface T {
  host: { adBreak(): Promise<void>; gameplay(on: boolean): void; paused: boolean; adPending: boolean; playing: boolean };
  log: string[];
  webgl: boolean;
  setHidden(h: boolean): void;
  reasons(): string;
  events(): string[];
  loseContext(): void;
  restoreContext(): void;
}
const t = <R>(page: Page, fn: (t: T) => R) => page.evaluate(`(${fn.toString()})(window.__t)`) as Promise<Awaited<R>>;
const until = (page: Page, fn: (t: T) => boolean) => page.waitForFunction(`(${fn.toString()})(window.__t)`, null, { timeout: 10000 });

async function open(query = ''): Promise<Page> {
  const page = await browser.newPage({ viewport: { width: 640, height: 360 } });
  const errors: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message));
  await page.goto(`${base}${query}`);
  await page.waitForFunction('!!window.__t');
  (page as unknown as { errors: string[] }).errors = errors;
  return page;
}
const errorsOf = (page: Page) => (page as unknown as { errors: string[] }).errors;

describe('pause reasons: each one is heard, the game resumes when all are gone', () => {
  it('a tab hidden during an ad: onPause("ad"), then onPause("hidden") with both; the ad ending does not resume; the tab coming back does, once', async () => {
    const page = await open();
    await t(page, (x) => void x.host.adBreak());
    await until(page, (x) => x.log.length === 1);
    await t(page, (x) => x.setHidden(true));
    expect(await t(page, (x) => x.log.slice())).toEqual(['pause:ad:[ad]:pending=true', 'pause:hidden:[ad,hidden]:pending=true']);
    // The same reason again (a second visibilitychange) is not a new pause
    await t(page, (x) => x.setHidden(true));
    await until(page, (x) => x.events().includes('ad:end'));
    expect(await t(page, (x) => ({ log: x.log.length, paused: x.host.paused, reasons: x.reasons() }))).toEqual({ log: 2, paused: true, reasons: 'hidden' });
    await t(page, (x) => x.setHidden(false));
    expect(await t(page, (x) => x.log.slice(2))).toEqual(['resume:pending=false:paused=false:lost=false']);
    expect(errorsOf(page)).toEqual([]);
    await page.close();
  });

  it('an ad that starts in a hidden tab: "hidden", then "ad" with both; resume once after both', async () => {
    const page = await open();
    await t(page, (x) => x.setHidden(true));
    await t(page, (x) => void x.host.adBreak());
    await until(page, (x) => x.log.length === 2);
    await t(page, (x) => x.setHidden(false));
    await until(page, (x) => x.events().includes('ad:end'));
    expect(await t(page, (x) => x.log.slice())).toEqual(['pause:hidden:[hidden]:pending=false', 'pause:ad:[ad,hidden]:pending=true', 'resume:pending=false:paused=false:lost=false']);
    await page.close();
  });

  it('a game with a one-argument onPause (written before the reasons set) still gets each reason', async () => {
    const page = await open('?legacy=1');
    await t(page, (x) => void x.host.adBreak());
    await until(page, (x) => x.log.length === 1);
    await t(page, (x) => x.setHidden(true));
    expect(await t(page, (x) => x.log.slice())).toEqual(['pause:ad', 'pause:hidden']);
    await page.close();
  });
});

describe('adPending is false when onResume runs', () => {
  for (const [name, query] of [['a shown ad', ''], ['a failed ad', '?ads=fail']] as const) {
    it(`${name}: a game re-enabling its buttons on resume sees no ad pending`, async () => {
      const page = await open(query);
      await t(page, (x) => x.host.adBreak());
      expect(await t(page, (x) => x.log.slice())).toEqual(['pause:ad:[ad]:pending=true', 'resume:pending=false:paused=false:lost=false']);
      await page.close();
    });
  }
});

describe('WebGL context loss on #game', () => {
  it('an engine that wants its context back: paused ("context"), gameplay stops, no resume while lost (a hidden tab coming back neither); restored → the engine first, then onResume', async () => {
    const page = await open('?engine=rebuilds');
    expect(await t(page, (x) => x.webgl)).toBe(true);
    await t(page, (x) => x.host.gameplay(true));
    expect(await t(page, (x) => x.host.playing)).toBe(true);
    await t(page, (x) => x.loseContext());
    await until(page, (x) => x.log.includes('engine:lost'));
    expect(await t(page, (x) => ({ log: x.log.slice(), paused: x.host.paused, playing: x.host.playing, ev: x.events() }))).toMatchObject({
      log: expect.arrayContaining(['pause:context:[context]:pending=false', 'engine:lost']),
      paused: true,
      playing: false,
      ev: expect.arrayContaining(['context:lost']),
    });
    await page.waitForTimeout(100);
    expect(await page.locator('[data-gp=reload]').count()).toBe(0);
    // While the context is lost, nothing else resumes the game
    await t(page, (x) => x.setHidden(true));
    await t(page, (x) => x.setHidden(false));
    expect(await t(page, (x) => ({ paused: x.host.paused, reasons: x.reasons(), resumed: x.log.some((l) => l.startsWith('resume')) }))).toEqual({ paused: true, reasons: 'context', resumed: false });
    await t(page, (x) => x.restoreContext());
    await until(page, (x) => x.log.some((l) => l.startsWith('resume')));
    const log = await t(page, (x) => x.log.slice());
    expect(log.indexOf('engine:restored')).toBeGreaterThan(-1);
    expect(log.indexOf('engine:restored')).toBeLessThan(log.indexOf('resume:pending=false:paused=false:lost=false'));
    expect(log.filter((l) => l.startsWith('resume'))).toHaveLength(1);
    expect(await t(page, (x) => ({ playing: x.host.playing, ev: x.events().filter((e) => e.startsWith('context')) }))).toEqual({ playing: true, ev: ['context:lost', 'context:restored'] });
    expect(errorsOf(page)).toEqual([]);
    await page.close();
  });

  it('restored while the tab is hidden: onResume waits for the tab', async () => {
    const page = await open('?engine=rebuilds');
    await t(page, (x) => x.loseContext());
    await until(page, (x) => x.log.includes('engine:lost'));
    await t(page, (x) => x.setHidden(true));
    await t(page, (x) => x.restoreContext());
    await until(page, (x) => x.events().includes('context:restored'));
    expect(await t(page, (x) => ({ reasons: x.reasons(), resumed: x.log.some((l) => l.startsWith('resume')) }))).toEqual({ reasons: 'hidden', resumed: false });
    await t(page, (x) => x.setHidden(false));
    expect(await t(page, (x) => x.log.filter((l) => l.startsWith('resume')))).toEqual(['resume:pending=false:paused=false:lost=false']);
    await page.close();
  });

  it('nobody called preventDefault() (the context never comes back): the "reload" screen, and the game stays paused', async () => {
    const page = await open();
    await t(page, (x) => x.host.gameplay(true));
    await t(page, (x) => x.loseContext());
    await page.waitForSelector('[data-gp=reload]', { timeout: 5000 });
    expect(await page.locator('[data-gp=reload]').innerText()).toBe('Host Fixture: the graphics stopped working. Reload the page to go on.');
    expect(await t(page, (x) => ({ paused: x.host.paused, playing: x.host.playing, ev: x.events().filter((e) => e.startsWith('context')), log: x.log.slice() }))).toEqual({
      paused: true,
      playing: false,
      ev: ['context:lost', 'context:gone'],
      log: ['pause:context:[context]:pending=false'],
    });
    // Over everything, and readable
    const r = await page.locator('[data-gp=reload]').boundingBox();
    expect(r).toEqual({ x: 0, y: 0, width: 640, height: 360 });
    expect(errorsOf(page)).toEqual([]);
    await page.close();
  });
});
