// Reward screen ("Well done!"): three stars one by one, a new sticker, Next and Home buttons.

import {
  buttonRadius,
  drawEmoji,
  drawIconButton,
  drawPanel,
  drawStar,
  drawText,
  easeOutBack,
  fitTextSize,
  hitCircle,
  Particles,
  rng,
  type Circle,
  type ProbeTarget,
  type Scene,
} from '@gp/core';
import type { KidsContext } from '../context.ts';
import type { KidsMode } from '../index.meta.ts';

const STAR_AT = [0.5, 0.9, 1.3];
const STICKER_AT = 1.8;
const BUTTONS_AT = 2.2;
/** Buttons become active after a delay so ongoing balloon taps don't skip the screen */
const BUTTONS_ACTIVE_AT = 2.5;

export class RewardScene implements Scene {
  readonly id = 'reward';
  private t = 0;
  private starsShown = 0;
  private stickerShown = false;
  private readonly particles = new Particles();
  private readonly praise: string;
  private readonly sticker: string;
  next: Circle = { x: 0, y: 0, r: 0 };
  home: Circle = { x: 0, y: 0, r: 0 };

  /** sticker — index of the new sticker, or -1 if the album is already complete */
  constructor(
    private readonly ctx: KidsContext,
    private readonly mode: KidsMode,
    sticker: number,
  ) {
    this.praise = rng.pick(ctx.kids.rewards.praise);
    const stickers = ctx.kids.rewards.stickers;
    const index = sticker >= 0 ? sticker : rng.int(stickers.length);
    this.sticker = stickers[index];
  }

  private get app() {
    return this.ctx.app;
  }

  enter(): void {
    this.app.audio.speak(this.praise);
    this.particles.rain(this.app.w, this.ctx.theme.palette, 60, this.app.u * 0.03);
  }

  layout(): { titleY: number; starsY: number; starR: number; sx: number; sy: number; card: number } {
    const { w, h, u, inset } = this.app;
    const landscape = w > h;
    const r = buttonRadius(this.app, 0.1);
    const starR = u * 0.075;
    const titleY = inset.top + h * 0.12;
    const starsY = titleY + u * 0.19;
    if (landscape) {
      const sy = starsY + starR + (h - inset.bottom - starsY - starR) / 2;
      const card = Math.min(u * 0.42, (h - inset.bottom - starsY - starR) * 0.8);
      this.home = { x: inset.left + w * 0.16, y: sy, r };
      this.next = { x: w - inset.right - w * 0.16, y: sy, r };
      return { titleY, starsY, starR, sx: w / 2, sy, card };
    }
    // Portrait: buttons at the bottom under the thumb; the sticker between the stars and the buttons
    const card = Math.min(u * 0.55, h * 0.3);
    const by = h - inset.bottom - Math.max(h * 0.16, r * 1.8);
    const sy = (starsY + starR + by - r) / 2;
    this.home = { x: w * 0.3, y: by, r };
    this.next = { x: w * 0.7, y: by, r };
    return { titleY, starsY, starR, sx: w / 2, sy, card };
  }

  probe(): ProbeTarget[] {
    this.layout();
    return [this.home, this.next].map((c, i) => ({ id: i ? 'next' : 'home', x: c.x - c.r, y: c.y - c.r, w: c.r * 2, h: c.r * 2 }));
  }

  pointer(x: number, y: number): void {
    if (this.t < BUTTONS_ACTIVE_AT) return;
    this.layout();
    if (hitCircle(this.next, x, y)) {
      this.app.audio.tap();
      this.app.go(this.ctx.play(this.mode));
    } else if (hitCircle(this.home, x, y)) {
      this.app.audio.tap();
      this.app.home();
    }
  }

  update(dt: number): void {
    this.t += dt;
    while (this.starsShown < 3 && this.t >= STAR_AT[this.starsShown]) {
      this.app.audio.star(this.starsShown);
      this.starsShown++;
    }
    if (!this.stickerShown && this.t >= STICKER_AT) {
      this.stickerShown = true;
      this.app.audio.sparkle();
    }
    this.particles.update(dt, this.app.h);
  }

  draw(g: CanvasRenderingContext2D): void {
    const { w, h, u, time } = this.app;
    this.ctx.theme.drawBackground(g, w, h, time);
    this.particles.draw(g);
    const L = this.layout();

    const titleScale = easeOutBack(this.t / 0.4);
    const size = fitTextSize(g, this.praise, u * 0.14, w * 0.9) * titleScale;
    if (size > 1) drawText(g, this.praise, w / 2, L.titleY, size, '#ffffff', this.ctx.theme.ui.textOutline);

    for (let i = 0; i < 3; i++) {
      const x = w / 2 + (i - 1) * L.starR * 2.6;
      const y = L.starsY + (i === 1 ? -L.starR * 0.3 : 0);
      drawStar(g, x, y, L.starR, false);
      const k = easeOutBack((this.t - STAR_AT[i]) / 0.35);
      if (k > 0.01) drawStar(g, x, y, L.starR * k, true);
    }

    const k = easeOutBack((this.t - STICKER_AT) / 0.45);
    if (k > 0.01) {
      const s = L.card * k;
      // Soft rays behind the sticker (slowly rotating, no flashing)
      g.save();
      g.translate(L.sx, L.sy);
      g.rotate(time * 0.25);
      g.fillStyle = 'rgba(255, 255, 255, 0.28)';
      for (let i = 0; i < 12; i++) {
        g.rotate(Math.PI / 6);
        g.beginPath();
        g.moveTo(0, 0);
        g.lineTo(s * 0.95, -s * 0.12);
        g.lineTo(s * 0.95, s * 0.12);
        g.closePath();
        g.fill();
      }
      g.restore();
      drawPanel(g, L.sx - s / 2, L.sy - s / 2, s, s, s * 0.18, '#ffffff', this.ctx.theme.ui.buttonShadow);
      drawEmoji(g, this.sticker, L.sx, L.sy, s * 0.66);
    }

    const bk = easeOutBack((this.t - BUTTONS_AT) / 0.35);
    drawIconButton(g, this.home.x, this.home.y, this.home.r, 'home', { scale: bk, icon: this.ctx.theme.ui.icon });
    drawIconButton(g, this.next.x, this.next.y, this.next.r, 'next', { scale: bk, fill: '#45c74a', icon: '#ffffff' });
  }
}
