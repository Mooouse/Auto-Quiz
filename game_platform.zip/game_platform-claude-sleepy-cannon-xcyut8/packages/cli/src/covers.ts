// `gp covers`: the store / portal graphics of a game, rendered from the game itself in the dev build, then checked at
// the size players see them (docs/guides/covers.md).
//
// A code game with a cover hook — host.qa({ cover: { scene, hero, front, title } }) — draws only the key art, in layers;
// the platform's composer (@gp/art/cover) lays out each size, lights the hero's rim, darkens behind the title, adds the
// vignette and letters the title, fitted to its zone. `--variants n` renders up to three compositions (hero / action /
// close-up) for A/B tests on the portal. Without a hook: the game's own `?cover` frame (body[data-cover=ready],
// convention from Yeet the Gnome), else the first screen (the block kits' title or menu).
// Every cover is then scored by the click-through check (cover-check.ts) at 200 px wide, and a preview strip of the
// thumbnails (colour and grayscale) is written next to them: CrazyGames players decide at that size (target CTR 2–4 %).

import { createHash } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { basename, dirname, join } from 'node:path';
import { CHANNELS, type ResolvedGame } from '@gp/spec';
import type { Browser, Page } from 'playwright';
import { COVER_THRESHOLDS, THUMB_W, formatVerdict, judgeCover, measureCover, packMask, unpackMask, type CoverFacts, type CoverMetrics, type CoverVerdict, type ThumbMasks } from './cover-check.ts';
import { ROOT, type GameLocation } from './paths.ts';

/** The compositions, in the order `--variants n` takes them (the same list as @gp/art/cover's COVER_VARIANTS) */
export const VARIANTS = ['hero', 'action', 'closeup'] as const;
export type Variant = (typeof VARIANTS)[number];

export const META_FILE = 'covers.json';
export const PREVIEW_FILE = 'cover-preview-200.png';
export const CHECK_FILE = 'cover-check.md';

export interface CoverScore {
  file: string;
  variant: string;
  verdict: CoverVerdict;
  metrics: CoverMetrics;
}

export interface CoversResult {
  outDir: string;
  files: string[];
  /** false: the game drew no cover (no hook, no ?cover frame): its first screen was used */
  staged: boolean;
  /** How the covers were made: the platform's composer on the game's hook, the game's own frame, or its first screen */
  mode: 'hook' | 'frame' | 'first-screen';
  scores: CoverScore[];
  /** The 200 px preview strips, one per composition */
  previews: string[];
  notes: string[];
}

export interface CoversOptions {
  /** 1–3 compositions (needs a cover hook for more than one) */
  variants?: number;
}

/** What the composer knew about one cover, kept for a later `--check` (masks at thumbnail size, packed) */
interface CoverMeta {
  sha1: string;
  variant: string;
  facts: CoverFacts;
  thumb: { w: number; h: number };
  masks: { title?: string; titleFill?: string; hero?: string };
}

interface StageResult {
  mode: CoversResult['mode'];
  /** The composed cover as a PNG data URL (mode 'hook') */
  png?: string;
  facts?: CoverFacts;
  masks?: { title: number[]; titleFill: number[]; hero: number[] | null };
  thumb?: { w: number; h: number };
}

/**
 * Stage the cover on a page already at `?cover=1`: wait for the game's hook or its own frame; with a hook, compose the
 * cover in the page (the platform's composer, served by the dev server) and lay it over the page, so a screenshot is the
 * cover (gp video opens on it). `pw`×`ph` are the cover's pixels (viewport × device pixel ratio)
 */
export async function stageCover(page: Page, o: { pw: number; ph: number; variant: string; title: string }): Promise<StageResult> {
  const found = await page
    .waitForFunction(
      () => {
        const d = (window as unknown as { __gp?: { host?: { qaDriver?: { cover?: unknown } } } }).__gp?.host?.qaDriver;
        if (d?.cover) return 'hook';
        return document.body.dataset.cover === 'ready' ? 'frame' : false;
      },
      null,
      { timeout: 8000 },
    )
    .then((h) => h.jsonValue() as Promise<string>)
    .catch(() => null);
  if (!found) {
    await page.waitForTimeout(2500); // the first screen settles (title / menu animations)
    return { mode: 'first-screen' };
  }
  const hook = await page.evaluate(() => !!(window as unknown as { __gp?: { host?: { qaDriver?: { cover?: unknown } } } }).__gp?.host?.qaDriver?.cover);
  if (!hook) return { mode: 'frame' };
  const mod = `/@fs${ROOT.replace(/\\/g, '/')}/packages/art/src/cover.ts`;
  return page.evaluate(
    async ({ mod, pw, ph, variant, title, tw }) => {
      const m = (await import(/* @vite-ignore */ mod)) as ComposerModule;
      const art = (window as unknown as { __gp: { host: { qaDriver: { cover: unknown } } } }).__gp.host.qaDriver.cover;
      const r = await m.composeCover(art, { w: pw, h: ph, variant, title });
      const th = Math.round((ph * tw) / pw);
      const masks = {
        title: Array.from(m.maskAt(r.title.layer, tw, th)),
        titleFill: Array.from(m.maskAt(r.title.fillMask, tw, th)),
        hero: r.heroLayer ? Array.from(m.maskAt(r.heroLayer, tw, th)) : null,
      };
      r.canvas.style.cssText = 'position:fixed;inset:0;width:100vw;height:100vh;z-index:2147483647;pointer-events:none';
      document.body.append(r.canvas);
      document.body.dataset.cover = 'ready';
      const text = r.style.upper ? r.style.text.toUpperCase() : r.style.text;
      return {
        mode: 'hook' as const,
        png: r.canvas.toDataURL('image/png'),
        facts: { titleText: text, titleLines: r.title.lines.length, letterPx: (r.title.cap * tw) / pw },
        masks,
        thumb: { w: tw, h: th },
      };
    },
    { mod, pw: o.pw, ph: o.ph, variant: o.variant, title: o.title, tw: THUMB_W },
  );
}

/** The part of @gp/art/cover this file calls in the page (browser code: the Node type checker doesn't load it) */
interface ComposerModule {
  composeCover(art: unknown, o: { w: number; h: number; variant: string; title: string }): Promise<{
    canvas: HTMLCanvasElement;
    title: { layer: HTMLCanvasElement; fillMask: HTMLCanvasElement; lines: string[]; cap: number };
    heroLayer: HTMLCanvasElement | null;
    style: { text: string; upper: boolean };
  }>;
  maskAt(c: HTMLCanvasElement, tw: number, th: number): Uint8Array;
}

const sha1 = (file: string) => createHash('sha1').update(readFileSync(file)).digest('hex');

export async function renderCovers(loc: GameLocation, game: ResolvedGame, outDir = join(loc.dir, 'store'), opts: CoversOptions = {}): Promise<CoversResult> {
  const sizes = CHANNELS[game.channel.id]?.covers ?? [];
  if (!sizes.length) throw new Error(`channel ${game.channel.id} has no cover sizes`);
  const { chromium } = await import('playwright');
  const { startDev } = await import('./vite.ts');
  mkdirSync(outDir, { recursive: true });
  const server = await startDev(loc, undefined, { frozen: true });
  const url = server.resolvedUrls?.local[0] ?? 'http://localhost:5173/';
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const want = Math.max(1, Math.min(VARIANTS.length, Math.round(opts.variants ?? 1)));
  const files: string[] = [];
  const notes: string[] = [];
  const meta: Record<string, CoverMeta> = {};
  let mode: CoversResult['mode'] = 'hook';
  const sets: { variant: string; dir: string; files: string[] }[] = [];
  try {
    for (let vi = 0; vi < want; vi++) {
      const variant = VARIANTS[vi]!;
      const dir = vi === 0 ? outDir : join(outDir, 'variants', variant);
      mkdirSync(dir, { recursive: true });
      const set = { variant, dir, files: [] as string[] };
      for (const s of sizes) {
        // Device pixel ratio 1: the page is exactly the cover size
        const page = await browser.newPage({ viewport: { width: s.width, height: s.height }, deviceScaleFactor: 1 });
        const errors: string[] = [];
        page.on('pageerror', (e) => errors.push(e.message));
        await page.goto(`${url}?seed=1&cover=1&variant=${variant}`);
        const st = await stageCover(page, { pw: s.width, ph: s.height, variant, title: game.title });
        const problem = coverProblem(s.name, (await page.$('[data-gp="cant-run"]')) !== null, errors);
        if (problem) throw new Error(problem);
        if (vi === 0) mode = st.mode;
        const file = join(dir, `${s.name}.png`);
        if (st.png) {
          writeFileSync(file, Buffer.from(st.png.slice(st.png.indexOf(',') + 1), 'base64'));
          meta[relKey(outDir, file)] = {
            sha1: sha1(file),
            variant,
            facts: st.facts ?? {},
            thumb: st.thumb!,
            masks: { title: packMask(Uint8Array.from(st.masks!.title)), titleFill: packMask(Uint8Array.from(st.masks!.titleFill)), hero: st.masks!.hero ? packMask(Uint8Array.from(st.masks!.hero)) : undefined },
          };
        } else await page.screenshot({ path: file });
        files.push(file);
        set.files.push(file);
        await page.close();
      }
      sets.push(set);
      if (mode !== 'hook') {
        if (want > 1) notes.push('--variants needs a cover hook (host.qa({ cover })): without one the game draws one cover frame, so one set was rendered');
        break;
      }
    }
    // The widest cover as a portal thumbnail (kept: the review brief and the docs point at it)
    const wide = [...sizes].sort((a, b) => b.width / b.height - a.width / a.height)[0]!;
    const thumb = await browser.newPage({ viewport: { width: 200, height: 112 }, deviceScaleFactor: 1 });
    const data = readFileSync(join(outDir, `${wide.name}.png`)).toString('base64');
    await thumb.setContent(`<body style="margin:0;background:#000"><img src="data:image/png;base64,${data}" style="width:200px;height:112px;object-fit:cover"></body>`);
    const tfile = join(outDir, 'cover-thumbnail-200x112.png');
    await thumb.screenshot({ path: tfile });
    files.push(tfile);
    writeMeta(outDir, meta);
    const checked = await checkSets(browser, outDir, sets);
    files.push(...checked.previews);
    return { outDir, files, staged: mode !== 'first-screen', mode, scores: checked.scores, previews: checked.previews, notes };
  } finally {
    await browser.close();
    await server.close();
  }
}

const relKey = (outDir: string, file: string) => file.slice(outDir.length + 1).replace(/\\/g, '/');

function readMeta(outDir: string): Record<string, CoverMeta> {
  const f = join(outDir, META_FILE);
  if (!existsSync(f)) return {};
  try {
    return JSON.parse(readFileSync(f, 'utf8')) as Record<string, CoverMeta>;
  } catch {
    return {};
  }
}

/** Merge into covers.json: a render of one set leaves the other sets' entries */
function writeMeta(outDir: string, add: Record<string, CoverMeta>): void {
  const all = { ...readMeta(outDir), ...add };
  for (const k of Object.keys(all)) if (!existsSync(join(outDir, k))) delete all[k];
  writeFileSync(join(outDir, META_FILE), `${JSON.stringify(all)}\n`);
}

/** The cover sets already in a store folder: the main one and each variants/<name>/ */
export function findCoverSets(outDir: string): { variant: string; dir: string; files: string[] }[] {
  const covers = (d: string) => (existsSync(d) ? readdirSync(d).filter((f) => /^(cover|feature-graphic)-\d+x\d+\.png$/.test(f)).sort().map((f) => join(d, f)) : []);
  const meta = readMeta(outDir);
  const first = covers(outDir);
  const sets: { variant: string; dir: string; files: string[] }[] = [];
  if (first.length) sets.push({ variant: first.map((f) => meta[relKey(outDir, f)]?.variant).find(Boolean) ?? 'current', dir: outDir, files: first });
  const vdir = join(outDir, 'variants');
  if (existsSync(vdir)) for (const v of readdirSync(vdir).sort()) if (covers(join(vdir, v)).length) sets.push({ variant: v, dir: join(vdir, v), files: covers(join(vdir, v)) });
  return sets;
}

/** `gp covers --check`: score the covers already rendered (no dev server) */
export async function checkCovers(outDir: string): Promise<{ scores: CoverScore[]; previews: string[] }> {
  const sets = findCoverSets(outDir);
  if (!sets.length) throw new Error(`no covers in ${outDir}: run gp covers first`);
  const { chromium } = await import('playwright');
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  try {
    return await checkSets(browser, outDir, sets);
  } finally {
    await browser.close();
  }
}

interface Shrunk {
  w: number;
  h: number;
  rgba: number[];
}

/** Each cover at 200 px wide, as the browser scales it (high-quality smoothing, like a portal's <img>) */
async function shrink(page: Page, file: string): Promise<Shrunk> {
  const data = readFileSync(file).toString('base64');
  return page.evaluate(
    async ({ data, tw }) => {
      const img = new Image();
      img.src = `data:image/png;base64,${data}`;
      await img.decode();
      const th = Math.round((img.naturalHeight * tw) / img.naturalWidth);
      const c = Object.assign(document.createElement('canvas'), { width: tw, height: th });
      const g = c.getContext('2d')!;
      g.imageSmoothingQuality = 'high';
      g.drawImage(img, 0, 0, tw, th);
      return { w: tw, h: th, rgba: Array.from(g.getImageData(0, 0, tw, th).data) };
    },
    { data, tw: THUMB_W },
  );
}

async function checkSets(browser: Browser, outDir: string, sets: { variant: string; dir: string; files: string[] }[]): Promise<{ scores: CoverScore[]; previews: string[] }> {
  const meta = readMeta(outDir);
  const page = await browser.newPage();
  const scores: CoverScore[] = [];
  const previews: string[] = [];
  try {
    for (const set of sets) {
      const tiles: { name: string; score: number; partial: boolean; data: string }[] = [];
      for (const file of set.files) {
        const t = await shrink(page, file);
        const m = meta[relKey(outDir, file)];
        // The masks only count while the file is the one the composer wrote
        const fresh = m && m.sha1 === sha1(file) && m.thumb.w === t.w && m.thumb.h === t.h;
        const n = t.w * t.h;
        const masks: ThumbMasks = fresh
          ? { title: m.masks.title ? unpackMask(m.masks.title, n) : undefined, titleFill: m.masks.titleFill ? unpackMask(m.masks.titleFill, n) : undefined, hero: m.masks.hero ? unpackMask(m.masks.hero, n) : undefined }
          : {};
        const metrics = measureCover({ w: t.w, h: t.h, rgba: Uint8Array.from(t.rgba) }, masks, fresh ? m.facts : {});
        const verdict = judgeCover(metrics);
        scores.push({ file, variant: set.variant, verdict, metrics });
        tiles.push({ name: basename(file, '.png'), score: verdict.score, partial: verdict.partial, data: readFileSync(file).toString('base64') });
      }
      const pfile = join(set.dir, PREVIEW_FILE);
      await previewStrip(page, tiles, pfile, set.variant);
      previews.push(pfile);
    }
    writeFileSync(join(outDir, CHECK_FILE), checkReport(outDir, scores));
  } finally {
    await page.close();
  }
  return { scores, previews };
}

/** The thumbnails side by side as players see them (top row) and in grayscale (value check), with their scores */
async function previewStrip(page: Page, tiles: { name: string; score: number; partial: boolean; data: string }[], file: string, variant: string): Promise<void> {
  const size = await page.evaluate(
    async ({ tiles, tw, variant }) => {
      const imgs = await Promise.all(
        tiles.map(async (t) => {
          const img = new Image();
          img.src = `data:image/png;base64,${t.data}`;
          await img.decode();
          return { ...t, img, th: Math.round((img.naturalHeight * tw) / img.naturalWidth) };
        }),
      );
      const pad = 20;
      const gap = 16;
      const label = 30;
      const rowH = Math.max(...imgs.map((i) => i.th));
      const W = pad * 2 + imgs.length * tw + (imgs.length - 1) * gap;
      const H = pad + label + rowH + gap + rowH + pad + 18;
      const c = Object.assign(document.createElement('canvas'), { width: W, height: H });
      const g = c.getContext('2d')!;
      g.fillStyle = '#10111d';
      g.fillRect(0, 0, W, H);
      g.imageSmoothingQuality = 'high';
      g.font = '600 12px system-ui, sans-serif';
      imgs.forEach((t, i) => {
        const x = pad + i * (tw + gap);
        g.fillStyle = t.score >= 70 && !t.partial ? '#9dfcb0' : '#ffcf6a';
        g.fillText(`${t.name.replace(/^cover-/, '')} · ${t.partial ? `${t.score}, picture only` : `${t.score}/100`}`, x, pad + 14);
        const r = 8;
        const clip = (y: number) => {
          g.save();
          g.beginPath();
          g.roundRect(x, y, tw, t.th, r);
          g.clip();
        };
        clip(pad + label);
        g.drawImage(t.img, x, pad + label, tw, t.th);
        g.restore();
        clip(pad + label + rowH + gap);
        g.filter = 'grayscale(1)';
        g.drawImage(t.img, x, pad + label + rowH + gap, tw, t.th);
        g.filter = 'none';
        g.restore();
      });
      g.fillStyle = '#8a8fb0';
      g.fillText(`${variant} · 200 px wide, as on the portal's grid · bottom row: grayscale (value contrast)`, pad, H - pad + 4);
      document.body.style.margin = '0';
      document.body.replaceChildren(c);
      return { W, H };
    },
    { tiles, tw: THUMB_W, variant },
  );
  await page.setViewportSize({ width: size.W, height: size.H });
  mkdirSync(dirname(file), { recursive: true });
  await page.locator('canvas').screenshot({ path: file });
}

/** cover-check.md: the scores and the fixes, for the game maker, the reviewer and the owner */
export function checkReport(outDir: string, scores: CoverScore[]): string {
  const L = ['# Cover check', '', `What players see: each cover at ${THUMB_W} px wide (\`${PREVIEW_FILE}\`). A score under ${COVER_THRESHOLDS.score} is a warning, never a refusal: the measures are proxies for click-through (docs/guides/covers.md#the-check).`, ''];
  const variants = [...new Set(scores.map((s) => s.variant))];
  if (variants.length > 1) {
    L.push('| Composition | ' + scores.filter((s) => s.variant === variants[0]).map((s) => basename(s.file, '.png')).join(' | ') + ' | Mean |', '|---|' + scores.filter((s) => s.variant === variants[0]).map(() => '---|').join('') + '---|');
    for (const v of variants) {
      const row = scores.filter((s) => s.variant === v);
      L.push(`| ${v} | ${row.map((s) => s.verdict.score).join(' | ')} | ${Math.round(row.reduce((a, s) => a + s.verdict.score, 0) / row.length)} |`);
    }
    L.push('');
  }
  for (const s of scores) {
    L.push('```', ...formatVerdict(s.file.slice(outDir.length + 1), s.verdict), '```', '');
  }
  return L.join('\n');
}

/** A cover must show the game: the player's can't-run screen (a script error, Kettlebot's TDZ in coverFrame) is a failure */
export function coverProblem(name: string, cantRun: boolean, errors: string[]): string | null {
  if (!cantRun) return null;
  const why = errors.length ? `: ${errors[0]}` : '';
  return `cover ${name}: the page shows the "can't run" screen instead of the game${why} — fix the error (open ?cover=1 in gp dev) and run gp covers again`;
}
