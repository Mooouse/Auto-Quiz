import { describe, expect, it } from 'vitest';
import { analyzeSound, answeredBy, CLIP_MAX, exactRepeats, fingerprints, integratedLufs, longestSilence, QUANTUM, REPEAT_STREAK, soundEvents, soundVerdict, type MeterRow, type SoundSession } from '../src/sound.ts';

const RATE = 48000;
const Q = QUANTUM / RATE;

/** Meter rows for `sec` seconds: each input's amplitude (a stereo sine: Σ over both channels of the mean square = a²) and zero crossings per quantum */
function rows(sec: number, f: (t: number) => { mix?: number; sfx?: number; bed?: number; zc?: number; clip?: number }, from = 0): MeterRow[] {
  const out: MeterRow[] = [];
  for (let i = 0; i < Math.round(sec / Q); i++) {
    const t = from + i * Q;
    const v = f(t);
    const e = (a = 0) => a * a * QUANTUM;
    out.push([Math.round(t * RATE), e(v.mix), v.mix ?? 0, v.clip ?? 0, v.zc ?? 0, e(v.sfx), v.sfx ?? 0, 0, v.zc ?? 0, e(v.bed), v.bed ?? 0, 0, 0]);
  }
  return out;
}

describe('integratedLufs: BS.1770-style gated loudness of the meter rows', () => {
  it('a steady tone of amplitude a reads −0.691 + 20 log10(a); silence between sounds is gated out', () => {
    expect(integratedLufs(rows(3, () => ({ mix: 0.1 })), RATE, 0)).toBeCloseTo(-20.7, 1);
    // A sound half the time: the silent blocks fall under the gates (not −23.7, its plain average), the blocks across an edge stay
    const half = integratedLufs(rows(4, (t) => ({ mix: t % 1 < 0.5 ? 0.1 : 0 })), RATE, 0)!;
    expect(half).toBeGreaterThan(-23.5);
    expect(half).toBeLessThan(-20.7);
    expect(integratedLufs(rows(3, () => ({ mix: 0 })), RATE, 0)).toBeNull();
    // Each input on its own
    const r = rows(3, () => ({ mix: 0.2, sfx: 0.1, bed: 0.05 }));
    expect(integratedLufs(r, RATE, 1)).toBeCloseTo(-20.7, 1);
    expect(integratedLufs(r, RATE, 2)).toBeCloseTo(-26.7, 1);
  });
});

describe('the session measures', () => {
  it('answeredBy: an effect within [lo, hi] of each action', () => {
    expect(answeredBy([1, 2, 3], [1.05, 2.2, 3.149], -0.01, 0.15)).toEqual({ n: 3, hit: 2 });
    expect(answeredBy([1], [0.995], -0.01, 0.15).hit).toBe(1);
    expect(answeredBy([], [1], -0.01, 0.15)).toEqual({ n: 0, hit: 0 });
  });
  it('soundEvents: sources starting together are one sound', () => {
    expect(soundEvents([1, 1.005, 1.01, 2, 2.3, 2.305])).toEqual([1, 2, 2.3]);
  });
  it('longestSilence: the longest quiet stretch inside play only', () => {
    const r = rows(20, (t) => ({ mix: t > 4 && t < 11 ? 0 : 0.1 }));
    expect(longestSilence(r, RATE, [[0, 20]]).sec).toBeCloseTo(7, 0);
    expect(longestSilence(r, RATE, [[0, 4], [11, 20]]).sec).toBe(0);
  });
  it('exactRepeats: the same sound exactly is a streak; a pitch, length or level change breaks it', () => {
    const fp = (t: number, zcr = 0.02, len = 0.1, level = -20) => ({ t, level, len, zcr });
    const same = Array.from({ length: 8 }, (_, i) => fp(i));
    expect(exactRepeats(same).streak).toBe(8);
    // ±6 % pitch each time: never the same twice
    const varied = Array.from({ length: 8 }, (_, i) => fp(i, 0.02 * (1 + ((i % 3) - 1) * 0.05)));
    expect(exactRepeats(varied).streak).toBe(1);
    // Another sound between them doesn't break a streak of one sound
    const mixed = Array.from({ length: 10 }, (_, i) => (i % 2 ? fp(i, 0.2, 0.4, -10) : fp(i)));
    expect(exactRepeats(mixed).streak).toBe(5);
  });
  it('fingerprints: the level, the length and the crossings of each sound on the effects bus', () => {
    // Two blips of 50 ms at 1 s and 2 s, the second an octave up (twice the crossings)
    const r = rows(3, (t) => {
      const on1 = t >= 1 && t < 1.05;
      const on2 = t >= 2 && t < 2.05;
      return { sfx: on1 || on2 ? 0.1 : 0, zc: on1 ? 10 : on2 ? 20 : 0 };
    });
    const [a, b] = fingerprints([1, 2], r, RATE, 1);
    expect(a.len).toBeCloseTo(0.05, 2);
    expect(a.level).toBeCloseTo(-20, 0);
    expect(b.zcr / a.zcr).toBeCloseTo(2, 1);
  });
});

/** A session: music under play, an effect at each tap */
function session(o: { clip?: boolean; quietEffects?: boolean; silentTaps?: boolean; repeat?: boolean; nothing?: boolean } = {}): SoundSession {
  const taps = Array.from({ length: 12 }, (_, i) => 2 + i * 0.8);
  const effects = o.silentTaps ? [] : taps.map((t) => t + 0.02);
  const r = rows(14, (t) => {
    if (o.nothing) return {};
    const fx = effects.some((e) => t >= e && t < e + 0.08);
    // Each effect a little different (its pitch), unless it repeats exactly
    const k = effects.findIndex((e) => t >= e && t < e + 0.08);
    const sfx = fx ? (o.quietEffects ? 0.01 : 0.2) : 0;
    const bed = 0.05;
    return { mix: Math.min(1, sfx + bed), sfx, bed, zc: fx ? (o.repeat ? 12 : 12 + k) : 3, clip: o.clip && fx ? 4 : 0 };
  });
  return { rate: RATE, rows: r, buses: { sfx: true, bed: true }, effects, actions: [{ t: 1, kind: 'ui' }, ...taps.map((t) => ({ t, kind: 'tap' as const }))], moments: [{ t: 13, kind: 'round:end' }], play: [[1.5, 12.5]] };
}

describe('soundVerdict: warnings first, two checks', () => {
  it('a game with music and answered taps passes with no warning but the unanswered UI click and the silent results', () => {
    const v = soundVerdict(analyzeSound(session()));
    expect(v.checks.every((c) => c.ok)).toBe(true);
    expect(v.warnings.map((w) => w.name).join('\n')).not.toMatch(/player actions|repeats|silence|drown|music heard/);
    expect(v.warnings.map((w) => w.name).join('\n')).toMatch(/button clicks/);
    expect(v.warnings.map((w) => w.name).join('\n')).toMatch(/round:end/);
    expect(v.infos.find((i) => i.name === 'sound: effects against the music')!.details).toMatch(/LU/);
  });
  it('fails on clipping and on a silent game, never on taste', () => {
    const clip = soundVerdict(analyzeSound(session({ clip: true })));
    expect(clip.checks.find((c) => /clipping/.test(c.name))!.ok).toBe(false);
    expect(analyzeSound(session({ clip: true })).clipped.samples).toBeGreaterThan(CLIP_MAX);
    const silent = soundVerdict(analyzeSound(session({ nothing: true })));
    expect(silent.checks.find((c) => /makes a sound/.test(c.name))!.ok).toBe(false);
    const flat = soundVerdict(analyzeSound(session({ silentTaps: true, quietEffects: true })));
    expect(flat.checks.every((c) => c.ok)).toBe(true);
    expect(flat.warnings.some((w) => /player actions/.test(w.name))).toBe(true);
  });
  it('warns when the effects drown in the music, and when one sound repeats exactly', () => {
    expect(soundVerdict(analyzeSound(session({ quietEffects: true }))).warnings.some((w) => /effects over the music/.test(w.name))).toBe(true);
    const rep = analyzeSound(session({ repeat: true }));
    expect(rep.repeats.streak).toBeGreaterThanOrEqual(REPEAT_STREAK);
    expect(soundVerdict(rep).warnings.some((w) => /repeats exactly/.test(w.name))).toBe(true);
    expect(analyzeSound(session()).repeats.streak).toBeLessThan(REPEAT_STREAK);
  });
});
