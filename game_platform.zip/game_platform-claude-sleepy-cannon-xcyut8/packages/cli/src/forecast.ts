// `gp forecast`: what a game (or an idea, before any code) can earn, on the path its channel takes — estimates with the
// confidence of their inputs, as ranges, never one number. The model and its one table of inputs are pure data and code
// in @gp/spec (money.ts); this file reads what the platform knows about a game (the money section, its code, its balance
// report, its upload, `gp uniqueness`) and the recorded results (publisher/results.yaml), and writes the report.

import { existsSync, readdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import {
  CHANNELS,
  MONEY_TABLE,
  calibrate,
  checkResults,
  forecast,
  formatPath,
  levers,
  loadYaml,
  moneyDesign,
  resubmissionOf,
  resubmissions,
  revenuePerDay,
  type CalibrationReport,
  type Forecast,
  type Issue,
  type Lever,
  type MoneyDesign,
  type RecordedResult,
  type ResolvedGame,
  type Resubmission,
} from '@gp/spec';
import { winningRunMin } from '@gp/core/balance';
import type { BalanceRun } from './balance.ts';
import { uploadFacts } from './size.ts';
import { ROOT, type GameLocation } from './paths.ts';

export const RESULTS_FILE = join(ROOT, 'publisher/results.yaml');

// --- What the code says ---------------------------------------------------------------------------------------------

function sources(dir: string, depth = 0): string[] {
  if (!existsSync(dir) || depth > 2) return [];
  const out: string[] = [];
  for (const e of readdirSync(dir, { withFileTypes: true })) {
    if (e.isDirectory()) {
      if (!['node_modules', 'dist', 'upload', 'qa', 'store', 'submission', 'android', 'tools', 'standalone'].includes(e.name) && !e.name.startsWith('.')) out.push(...sources(join(dir, e.name), depth + 1));
    } else if (/\.(ts|mjs|js)$/.test(e.name) && !/\.(test|d)\.ts$/.test(e.name) && e.name !== 'video.mjs') out.push(join(dir, e.name));
  }
  return out;
}

/**
 * Rewarded placements and natural breaks in a code game: `host.rewarded('x')`, `rewardedButton({ placement: 'x' })`,
 * and calls of the game's own wrapper around it (`const offer = (placement: string, …)` → `offer('hint', …)`);
 * whether it calls `host.adBreak()` at all.
 */
export function codeFacts(loc: GameLocation): { rewarded: string[]; adBreak: boolean } {
  const code = sources(loc.dir).map((f) => readFileSync(f, 'utf8')).join('\n');
  const found = new Set<string>();
  for (const m of code.matchAll(/\.rewarded\(\s*['"`]([a-z][\w-]*)['"`]/g)) found.add(m[1]);
  for (const m of code.matchAll(/\bplacement\s*:\s*['"`]([a-z][\w-]*)['"`]/g)) found.add(m[1]);
  const wrappers = [...code.matchAll(/(?:const|let|function)\s+(\w+)\s*=?\s*(?:async\s*)?\(\s*placement\b/g)].map((m) => m[1]);
  for (const w of wrappers) for (const m of code.matchAll(new RegExp(`\\b${w}\\(\\s*['"\`]([a-z][\\w-]*)['"\`]`, 'g'))) found.add(m[1]);
  return { rewarded: [...found], adBreak: /\.adBreak\s*\(/.test(code) };
}

// --- Recorded results -----------------------------------------------------------------------------------------------

export function loadResults(file = RESULTS_FILE): { results: RecordedResult[]; issues: Issue[]; file: string } {
  if (!existsSync(file)) return { results: [], issues: [], file };
  const text = readFileSync(file, 'utf8');
  const loaded = loadYaml(text);
  if (loaded.issues.length) return { results: [], issues: loaded.issues, file };
  const issues = checkResults(loaded.data);
  for (const i of issues) i.line = loaded.lineOf(i.path);
  return { results: issues.some((i) => i.severity === 'error') ? [] : ((loaded.data as { results: RecordedResult[] }).results ?? []), issues, file };
}

// --- A game's forecast ------------------------------------------------------------------------------------------------

export interface GameForecast {
  design: MoneyDesign;
  forecast: Forecast;
  levers: Lever[];
  calibration: CalibrationReport;
  balance: string | null;
}

/**
 * A game's forecast. A code game's meta length comes from its balance() report: run here, or — `opts.balanceRun` — the
 * run the caller already has (gp qa: its balance section ran it; null: the game exports none; an Error: it failed), so
 * the qa line and forecast.md read the same design. `balance: false` leaves it out (the meta then counts as unknown).
 */
export async function gameForecast(
  loc: GameLocation,
  game: ResolvedGame,
  issues: Issue[],
  opts: { balance?: boolean; balanceRun?: BalanceRun | Error | null; resubmission?: Resubmission | 'none' } = {},
): Promise<GameForecast> {
  const ch = CHANNELS[game.channel.id];
  const code = game.kit.kit === 'code' ? codeFacts(loc) : null;
  let balanceMetaMin: number | null = null;
  let balance: string | null = null;
  let report: BalanceRun['report'] | null = null;
  if (game.kit.kit === 'code' && opts.balance !== false) {
    let run: BalanceRun | Error | null;
    if (opts.balanceRun !== undefined) run = opts.balanceRun;
    else {
      try {
        const { balanceDesign, runBalance } = await import('./balance.ts');
        run = await runBalance(loc, game.channel.id, { design: balanceDesign(game) });
      } catch (e) {
        run = e as Error;
      }
    }
    if (run instanceof Error) balance = `balance() failed: ${String(run.message).split('\n')[0]}`;
    else if (run) {
      if (run.source === 'bot') report = run.report;
      const m = run.report.cheap?.finishMin;
      if (typeof m === 'number') balanceMetaMin = m;
      balance = typeof m === 'number' ? `balance(): the meta is done at ${m.toFixed(0)} min` : 'balance(): the meta is not finished within the bot\'s runs';
    }
  }
  let uniqueness: MoneyDesign['uniqueness'] = null;
  if (ch?.conceptReview) {
    const { uniquenessReport } = await import('./uniqueness.ts');
    const rep = uniquenessReport(loc, game, issues);
    uniqueness = { score: rep.score, gate: rep.gate, from: `gp uniqueness ${rep.score}/100 (${rep.verdict})` };
  }
  // A declared winning run (balance.difficulty.winningRunMin) is the session: the bot's measured one, else the range's middle
  const range = game.kit.kit === 'code' ? game.kit.difficulty?.winningRunMin : undefined;
  let winningRun: { minutes: number; from: string } | null = null;
  if (range) {
    const w = report ? winningRunMin(report) : null;
    winningRun = w
      ? { minutes: w.minutes, from: `balance(): the ${w.skill} bot's winning run, ${w.minutes.toFixed(1)} min (median; declared ${range[0]}–${range[1]})` }
      : { minutes: (range[0] + range[1]) / 2, from: `balance.difficulty.winningRunMin ${range[0]}–${range[1]} min, its middle (no winning run measured by balance())` };
  }
  const round = game.round as { goal?: { time?: number } } | null;
  const upload = uploadFacts(loc);
  const design = moneyDesign(game.money, {
    channel: game.channel.id,
    audience: game.audience.id,
    kit: game.kit.kit,
    tags: game.listing.tags,
    adsOn: !!game.ads,
    rewardedOn: !!game.ads?.rewarded,
    billing: !!game.billing,
    roundSec: typeof round?.goal?.time === 'number' ? round.goal.time : null,
    concept: game.concept,
    storyDepth: game.story?.depth ?? null,
    code,
    balanceMetaMin,
    winningRun,
    uploadMB: upload?.mb ?? null,
    // The size and load budget of `gp build` (upload/size.json): the load time is in P(Full Launch)
    uploadGzipKB: upload?.gzipKB ?? null,
    loadSec: upload?.loadSec ?? null,
    uniqueness,
  });
  const { results } = loadResults();
  // The game judged before: its latest record in publisher/results.yaml (or --resubmission) makes this a resubmission
  const hist = resubmissionOf(results, loc.id, game.channel.id);
  design.resubmission = opts.resubmission === 'none' ? null : (opts.resubmission ?? hist?.kind ?? null);
  design.from.resubmission = opts.resubmission
    ? `--resubmission ${opts.resubmission}`
    : hist
      ? `publisher/results.yaml: ${loc.id}'s latest record${hist.last.review?.date ? ` (${hist.last.review.date})` : ''} — ${hist.kind === 'after-stop' ? 'Basic Launch stopped' : `rejected${hist.last.review?.reason ? `: "${hist.last.review.reason}"` : ''}`}`
      : `no earlier record of ${loc.id} in publisher/results.yaml`;
  const cal = calibrate(results, game.channel.id);
  return { design, forecast: forecast(design, cal.calibration), levers: levers(design, cal.calibration), calibration: cal, balance };
}

// --- The report -------------------------------------------------------------------------------------------------------

export function eur(x: number): string {
  if (x === 0) return '€0';
  if (Math.abs(x) < 10) return `€${x.toFixed(x < 1 ? 2 : 1)}`;
  return `€${Math.round(x).toLocaleString('en-US')}`;
}
const pct = (p: number) => `${Math.round(p * 100)}%`;
const num = (x: number) => (Math.abs(x) >= 100 ? Math.round(x).toLocaleString('en-US') : String(Math.round(x * 100) / 100));

/** One line for `gp qa` and the terminal */
export function forecastLine(f: Forecast): string {
  if (!f.earns) return `money: no revenue — ${f.why}`;
  const p = f.channel === 'crazygames' ? `P(approval) ${pct(f.pApproval.low)}–${pct(f.pApproval.high)} · P(Full Launch) ${pct(f.pFullLaunch.low)}–${pct(f.pFullLaunch.high)}` : `P(approval) ${pct(f.pApproval.low)}–${pct(f.pApproval.high)}`;
  const pm = f.perMonth ? ` · on Full Launch ${eur(f.perMonth.mid)}/month (${eur(f.perMonth.low)}–${eur(f.perMonth.high)})` : '';
  return `money (estimates): ${p}${pm} · months 1–3 if it launches ${eur(f.total.pessimistic)} / ${eur(f.total.median)} / ${eur(f.total.optimistic)} · expected ${eur(f.expected.mid)} (range ${eur(f.expected.low)}–${eur(f.expected.high)}) — gp forecast`;
}

const CONF_ORDER = ['high', 'medium', 'low', 'very low', 'judgement'] as const;

export function forecastMarkdown(title: string, d: MoneyDesign, f: Forecast, lv: Lever[], cal: CalibrationReport | null, opts: { idea?: boolean; balance?: string | null; full?: boolean; id?: string } = {}): string {
  const L: string[] = [];
  L.push(`# ${title} — money forecast (${d.channel})`, '');
  L.push(
    `**Estimates, not promises.** Every number is a range from inputs with the confidence shown below — most are low or judgement: the market numbers are search snippets, CrazyGames publishes no pass rates, eCPM or plays. Pessimistic takes every input at its worse end, optimistic at its better end (the true range is narrower). Inputs: \`MONEY_TABLE\` in packages/spec/src/money.ts (checked ${Object.values(MONEY_TABLE)[0].checked}; docs/research/revenue-2026-09.md).`,
    '',
  );
  if (!f.earns) {
    L.push(`**No revenue:** ${f.why}.`, '');
  } else {
    const path = f.stages
      .map((s) => {
        const bits = [s.days && `${num(s.days.low)}–${num(s.days.high)} days`, s.p && `${pct(s.p.low)}–${pct(s.p.high)} get through, mid ${pct(s.p.mid)}`, s.revenue && 'revenue'].filter(Boolean);
        return `${s.name}${bits.length ? ` (${bits.join('; ')})` : ''}`;
      })
      .join(' → ');
    L.push(`**The path:** ${path}. Revenue from day ${num(f.revenueFromDay.low)}–${num(f.revenueFromDay.high)} after submission (mid ${num(f.revenueFromDay.mid)}).`, '');
    for (const s of f.stages) L.push(`- **${s.name}:** ${s.note}`);
    L.push('');
    if (f.perMonth)
      L.push(
        `**On Full Launch: about ${eur(f.perMonth.mid)} a month** (${eur(f.perMonth.low)}–${eur(f.perMonth.high)}): a steady month after the homepage week, ${num(f.volume.range.mid)} plays a day (${num(f.volume.range.low)}–${num(f.volume.range.high)}) × ${eur(f.unit.eur.mid * 1000)} per 1,000 plays. Only if the game gets there — the expected value below weighs that in.`,
        '',
      );
    const stage = d.channel === 'crazygames' ? 'if it reaches Full Launch' : 'if it is approved';
    L.push(`| Revenue ${stage} | Pessimistic | Median | Optimistic |`, '|---|---|---|---|');
    for (const m of [0, 1, 2]) L.push(`| Month ${m + 1} after submission | ${eur(f.months.pessimistic[m])} | ${eur(f.months.median[m])} | ${eur(f.months.optimistic[m])} |`);
    L.push(`| **Months 1–3** | ${eur(f.total.pessimistic)} | ${eur(f.total.median)} | ${eur(f.total.optimistic)} |`);
    const pw = d.channel === 'crazygames' ? 'P(approval) × P(Full Launch)' : 'P(approval)';
    L.push(`| **Expected value** (× ${pw}) | ${eur(f.expected.low)} | **${eur(f.expected.mid)}** | ${eur(f.expected.high)} |`, '');
    const u = f.unit;
    if (d.channel === 'crazygames') {
      const per1000 = MONEY_TABLE['cg.check.per1000'];
      L.push(
        `Per play: ${num(u.midgame.low)}–${num(u.midgame.high)} midgame ads (mid ${num(u.midgame.mid)}), ${num(u.rewarded.low)}–${num(u.rewarded.high)} rewarded views (mid ${num(u.rewarded.mid)}) → ${eur(u.eur.mid * 1000)} per 1,000 plays (range ${eur(u.eur.low * 1000)}–${eur(u.eur.high * 1000)}; the research's cross-check: ${eur(per1000.low)} · ${eur(per1000.mid)} · ${eur(per1000.high)}). Plays/day after the launch week: ${num(f.volume.range.low)}–${num(f.volume.range.high)} (mid ${num(f.volume.range.mid)}).`,
        '',
      );
    } else {
      const arpdau = MONEY_TABLE['gp.check.arpdau'];
      L.push(
        `Per active child per day: ${num(u.midgame.low)}–${num(u.midgame.high)} interstitials → ARPDAU ${eur(u.eur.low)}–${eur(u.eur.high)} (mid ${eur(u.eur.mid)}; the research's cross-check $${arpdau.low}–$${arpdau.high}). Installs/day: ${num(f.volume.range.low)}–${num(f.volume.range.high)} (mid ${num(f.volume.range.mid)}).`,
        '',
      );
    }
  }
  for (const n of f.notes) L.push(`- ${n}`);
  if (f.notes.length) L.push('');

  L.push('## The design it read', '', '| | Value | From |', '|---|---|---|');
  L.push(`| Genre | ${d.genre} | ${d.from.genre} |`);
  L.push(`| Session | ${num(d.sessionMin)} min target | ${d.from.session} |`);
  const every = d.breaks > 0 ? ` (one every ${num(d.sessionMin / (d.breaks + 1))} min)` : '';
  L.push(`| Natural breaks | ${d.breaks} per session${every} | ${d.from.breaks} |`);
  L.push(`| Rewarded offers | ${d.rewarded.length ? d.rewarded.map((r) => `${r.placement} (${r.kind}, per ${r.per})`).join(', ') : 'none'} | ${d.from.rewarded} |`);
  L.push(`| Meta length | ${d.metaMin === null ? 'unknown' : `${num(d.metaMin)} min`} | ${d.from.meta}${opts.balance ? ` — ${opts.balance}` : ''} |`);
  L.push(`| Reason to return | ${d.returns} | ${d.from.returns} |`);
  if (d.channel === 'crazygames') {
    const again = d.resubmission === 'after-stop' ? 'a resubmission after a Basic Launch stop' : d.resubmission === 'after-rejection' ? 'a resubmission after a rejection' : 'a new submission';
    L.push(`| Submission | ${again} | ${d.from.resubmission ?? 'not read (idea mode)'} |`);
    L.push(`| Uniqueness | ${d.uniqueness ? `${d.uniqueness.score}/100${d.uniqueness.gate ? `, gate: ${d.uniqueness.gate}` : ''}` : 'not scored'} | ${d.from.uniqueness} |`);
    const load = d.loadSec !== null ? `, ≈ ${d.loadSec.toFixed(1)} s to a tappable Play on a slow phone` : '';
    L.push(`| Upload | ${d.uploadMB === null ? (d.loadSec !== null ? `≈ ${d.loadSec.toFixed(1)} s to a tappable Play` : 'not built') : `${d.uploadMB.toFixed(2)} MB${d.uploadGzipKB !== null ? `, ${Math.round(d.uploadGzipKB).toLocaleString('en-US')} KB gzipped` : ''}${load}`} | ${d.from.upload} |`);
  }
  if (d.removeAds) L.push(`| "Remove ads" | ${d.removeAds.price ? eur(d.removeAds.price) : 'the default price'} | monetization.removeAds |`);
  L.push(`| Ads | ${d.adsOn ? `on${d.rewardedOn ? ', rewarded on' : ''}` : 'off'} | monetization, channel ${d.channel} |`, '');

  L.push('## Levers: what adds the most expected value', '');
  if (lv.length) lv.forEach((l, i) => L.push(`${i + 1}. **${l.name}** — ${eur(l.delta)} more expected in months 1–3 (${eur(l.after)} instead of ${eur(f.expected.mid)}): ${l.change}.`));
  else L.push(f.earns ? '- No design lever left in the model: the rest is the game being good — 80%+ past the first minute, 10+ min of play, D1 10–15% (Basic Launch reads them).' : '- None the model knows.');
  L.push('');
  L.push('Not in the model: conversion in the first minute (gameplay within 10 s, no text tutorial), the thumbnail\'s click rate, updates after launch (Liquid Swarm grew with them), the exclusivity bonus (+50% for 2 months), a hit.', '');

  const used = f.used.map((id) => [id, MONEY_TABLE[id]] as const).filter(([, r]) => r);
  const count = CONF_ORDER.map((c) => [c, used.filter(([, r]) => r.confidence === c).length] as const).filter(([, n]) => n);
  L.push('## Assumptions', '', `${used.length} inputs: ${count.map(([c, n]) => `${n} ${c}`).join(', ')}.`, '');
  if (opts.full === false) {
    for (const [c] of count) L.push(`- **${c}:** ${used.filter(([, r]) => r.confidence === c).map(([id]) => `\`${id}\``).join(', ')}`);
    L.push('', 'Each input with its low · mid · high and source: the report file, or `MONEY_TABLE` in packages/spec/src/money.ts.', '');
  } else if (used.length) {
    L.push('| Input | Low | Mid | High | Unit | Confidence | Source |', '|---|---|---|---|---|---|---|');
    for (const [id, r] of used.sort((a, b) => CONF_ORDER.indexOf(a[1].confidence) - CONF_ORDER.indexOf(b[1].confidence) || a[0].localeCompare(b[0])))
      L.push(`| \`${id}\` ${r.what} | ${r.low} | ${r.mid} | ${r.high} | ${r.unit} | ${r.confidence} | ${r.source.replace(/\|/g, '\\|')} |`);
    L.push('');
  }
  if (cal) L.push('## Calibration: the model against real results', '', cal.markdown);
  if (!opts.idea && f.earns) {
    // EUR/day in the revenue stage: month 2 ÷ 30 per scenario, whatever the channel (Google Play: active days and "Remove ads" in)
    const pd = revenuePerDay(f);
    const perDay = [pd.low, pd.mid, pd.high].map((x) => Math.round(x * 100) / 100);
    L.push(
      '## Record the outcome',
      '',
      'When the portal or the store answers, add the game to publisher/results.yaml (the model compares itself with it and narrows its ranges from 3 results of a kind — docs/guides/game-design.md → Design for money):',
      '',
      '```yaml',
      `  - game: ${opts.id ?? title.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`,
      `    channel: ${d.channel}`,
      `    genre: ${d.genre}`,
      ...(d.uniqueness ? [`    uniqueness: ${d.uniqueness.score}`] : []),
      `    sessionMin: ${Math.round(d.sessionMin * 100) / 100}`,
      `    breaks: ${d.breaks}`,
      ...(d.rewarded.length ? [`    rewarded: [${d.rewarded.map((r) => r.kind).join(', ')}]`] : []),
      '    submitted: "YYYY-MM-DD"',
      `    predicted: { pApproval: ${f.pApproval.mid.toFixed(2)}${d.channel === 'crazygames' ? `, pFullLaunch: ${f.pFullLaunch.mid.toFixed(2)}` : ''}, revenuePerDay: [${perDay.join(', ')}] }`,
      '    review: { verdict: pending }',
      '```',
      '',
    );
  }
  return L.join('\n');
}

/**
 * `gp submission --full`: what the history says about sending a judged game again — one line, a warning, never a
 * refusal (3 of 4 resubmissions after a Basic Launch stop were rejected, as of 2026-10-19)
 */
export function resubmissionWarning(results: readonly RecordedResult[], d: MoneyDesign, f: Forecast, channel: string): string {
  const all = resubmissions(results, channel).filter((x) => x.verdict !== 'pending');
  const of = (k: Resubmission) => {
    const xs = all.filter((x) => x.kind === k);
    return `${xs.filter((x) => x.verdict === 'approved').length} of ${xs.length}`;
  };
  const history = `recorded: ${of('after-stop')} approved after a Basic Launch stop, ${of('after-rejection')} after a rejection`;
  if (d.resubmission)
    return `a resubmission ${d.resubmission === 'after-stop' ? 'after a Basic Launch stop' : 'after a rejection'}: P(approval) ${pct(f.pApproval.low)}–${pct(f.pApproval.high)} (mid ${pct(f.pApproval.mid)}; ${history}). Send it only with a change a reviewer sees in the first minute, and say in listing.md what changed`;
  return `--full but publisher/results.yaml has no stop or rejection for this game: if CrazyGames judged it before, record that (or gp forecast --resubmission after-stop|after-rejection) — resubmissions are rejected more often (${history})`;
}

/** Schema problems in results.yaml, as lines */
export function formatResultIssues(issues: Issue[]): string[] {
  return issues.map((i) => `publisher/results.yaml${i.line ? `:${i.line}` : ''}  ${i.severity} ${i.code}  ${i.message} (${formatPath(i.path)})\n    fix: ${i.fix}`);
}
