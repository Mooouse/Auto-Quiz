// The code kit's sound section: QA plays a run as a player does, and listens (docs/guides/code-games.md → Sound).
// Reviewers never heard our games and judged them flat ("simple and dull"); the owner heard a hiss under the music and a
// deafening start. A real-time meter in front of the page's destination (@gp/qa/audio-tap audioMeter) and the probe's
// log of every sound started give: the share of taps, keys and button clicks an effect answers within 150 ms (and of the
// game's moments: a celebrated one, a fail, the results), the effects' loudness against the music's (the mixer's buses
// metered apart), clipping, long silences in play, and one sound repeated exactly many times in a row
// (@gp/qa/sound). Fails only on clipping or a silent game; the rest are warnings, listed first in qa/report.md.

import { writeFileSync } from 'node:fs';
import { join } from 'node:path';
import type { Page } from 'playwright';
import type { QaContext } from '@gp/qa';
import { audioMeter, connectMeter, takeMeter } from '@gp/qa/audio-tap';
import { installProbe } from '@gp/qa/probe';
import { analyzeSound, soundVerdict, type SoundSession } from '@gp/qa/sound';

/* eslint-disable @typescript-eslint/no-explicit-any */

const S = 'sound';
/** Seconds of play QA listens to */
export const SOUND_PLAY_SEC = 20;
const VIEW = { width: 1280, height: 720 };
const KEYS = ['Space', 'ArrowUp', 'ArrowLeft', 'ArrowRight', 'ArrowDown', 'KeyW', 'KeyA', 'KeyD'];
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/** In the page: the player's inputs, the game's moments, and the clocks (performance.now ↔ the context's time) */
const soundLog = (): void => {
  const L: { inputs: { t: number; kind: string }[]; moments: { t: number; kind: string }[]; samples: { t: number; ct: number | null; play: boolean }[]; hooked: boolean } = { inputs: [], moments: [], samples: [], hooked: false };
  (window as any).__gpSoundLog = L;
  addEventListener(
    'pointerdown',
    (e) => {
      if (e.isTrusted) L.inputs.push({ t: performance.now(), kind: e.target instanceof HTMLCanvasElement ? 'tap' : (e.target as Element)?.closest?.('button, [role=button], a, input, select') ? 'ui' : 'tap' });
    },
    true,
  );
  addEventListener(
    'keydown',
    (e) => {
      if (e.isTrusted && !e.repeat) L.inputs.push({ t: performance.now(), kind: 'key' });
    },
    true,
  );
  setInterval(() => {
    const gp = (window as any).__gp;
    const h = gp?.host;
    if (!h) return;
    if (!L.hooked && gp.events?.on) {
      L.hooked = true;
      gp.events.on((e: { type: string }) => {
        if (['highlight', 'fail', 'round:end', 'twist'].includes(e.type)) L.moments.push({ t: performance.now(), kind: e.type });
      });
    }
    const a = h.audio as { ctx: AudioContext } | null;
    L.samples.push({ t: performance.now(), ct: a && a.ctx.state === 'running' ? a.ctx.currentTime : null, play: !!h.isPlaying && !h.paused });
  }, 100);
};

/** The page's half of the session: inputs, moments, play stretches and effect starts, all on the context's clock */
async function pageSession(page: Page): Promise<Omit<SoundSession, 'rate' | 'rows' | 'buses'>> {
  return page.evaluate(() => {
    const L = (window as any).__gpSoundLog;
    const p = (window as any).__gpProbe;
    const ctx = (window as any).__gp?.host?.audio?.ctx as AudioContext | undefined;
    // performance.now (ms) → the context's seconds: the median offset over the samples
    const offs = (L.samples as { t: number; ct: number | null }[]).filter((s) => s.ct !== null).map((s) => s.t / 1000 - s.ct!).sort((a, b) => a - b);
    const off = offs.length ? offs[offs.length >> 1] : 0;
    const ct = (t: number) => t / 1000 - off;
    const play: [number, number][] = [];
    let from: number | null = null;
    for (const s of L.samples as { t: number; play: boolean }[]) {
      if (s.play && from === null) from = ct(s.t);
      if (!s.play && from !== null) {
        play.push([from, ct(s.t)]);
        from = null;
      }
    }
    if (from !== null) play.push([from, ct(performance.now())]);
    // Each effect from the moment its start() was called (plus how far ahead it was scheduled), on the same conversion as
    // the inputs: the first click's sound counts too, though the context's clock stood at 0 until it ran
    const effects = ((p?.sources ?? []) as { node: AudioNode; t: number; when: number; now: number; bus: string | null }[])
      .filter((s) => s.node.context === ctx && s.bus !== 'music' && s.bus !== 'ambient')
      .map((s) => ct(s.t) + Math.max(0, (s.when || 0) - s.now));
    return {
      effects,
      actions: (L.inputs as { t: number; kind: 'tap' | 'key' | 'ui' }[]).map((i) => ({ t: ct(i.t), kind: i.kind })),
      moments: (L.moments as { t: number; kind: string }[]).map((m) => ({ t: ct(m.t), kind: m.kind })),
      play,
    };
  });
}

const playing = (page: Page) => page.evaluate(() => !!(window as any).__gp?.host?.isPlaying && !(window as any).__gp?.host?.paused);

/** A point on the game's canvas with nothing of the UI on top (null: none found) */
async function canvasPoint(page: Page, rnd: () => number): Promise<{ x: number; y: number } | null> {
  for (let i = 0; i < 6; i++) {
    const x = Math.round(VIEW.width * (0.2 + rnd() * 0.6));
    const y = Math.round(VIEW.height * (0.25 + rnd() * 0.55));
    const ok = await page.evaluate(([px, py]) => document.elementFromPoint(px, py) instanceof HTMLCanvasElement, [x, y] as const);
    if (ok) return { x, y };
  }
  return null;
}

/** Play a run as a player and listen: Play, the demo bot (if any), QA's own taps and keys, the results */
export async function runSound(ctx: QaContext): Promise<void> {
  const context = await ctx.browser.newContext({ viewport: VIEW });
  // The meter first: the probe wraps the metered context and sees the meter's bus reach the speakers
  await context.addInitScript(audioMeter);
  await context.addInitScript(installProbe);
  await context.addInitScript(soundLog);
  const page = await context.newPage();
  try {
    await page.goto(`${ctx.url}?seed=7`);
    await page.waitForFunction(() => (window as any).__gp?.host && (window as any).__portal?.calls.some((c: { fn: string }) => c.fn === 'loadingStop'), null, { timeout: 20000 });
    await sleep(400);
    if (!(await page.evaluate(() => typeof (window as any).__gp.host.qaDriver?.play === 'function'))) {
      ctx.info(S, 'sound', 'not checked: no host.qa({ play }) (the viewport sections say so)');
      return;
    }
    // Into a run the player's way: Play's click unlocks the sound (and is a button click QA listens for)
    const play = page.locator('[data-gp=play]').first();
    if (await play.isVisible().catch(() => false)) await play.click();
    else {
      await page.mouse.click(VIEW.width / 2, VIEW.height / 2);
      await page.evaluate(() => (window as any).__gp.host.qaDriver.play());
    }
    await page.waitForFunction(() => (window as any).__gp.host.isPlaying, null, { timeout: 5000 }).catch(() => {});
    await page.locator('[data-gp=dialog-skip]:visible').first().click({ timeout: 500 }).catch(() => {});
    const demo = await page.evaluate(() => {
      const d = (window as any).__gp.host.qaDriver;
      if (typeof d.demo !== 'function') return false;
      d.demo();
      return true;
    });
    await sleep(500);
    await connectMeter(page);
    // QA's own hands: a tap on the game or a key every 0.6–0.9 s, alternately; a run that ends starts again
    let seed = 7;
    const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
    const end = Date.now() + SOUND_PLAY_SEC * 1000;
    let k = 0;
    let restarts = 0;
    while (Date.now() < end) {
      if (!(await playing(page))) {
        // Let a death's or a land's sound finish, then the next run, as the results' big button does
        await sleep(700);
        if (!(await playing(page)) && restarts < 6) {
          restarts++;
          await page.evaluate(() => (window as any).__gp.host.qaDriver.play());
          await sleep(400);
          if (demo) await page.evaluate(() => (window as any).__gp.host.qaDriver.demo?.());
        }
        continue;
      }
      if (k % 2 === 0) {
        const p = await canvasPoint(page, rnd);
        if (p) await page.mouse.click(p.x, p.y);
      } else {
        // No button keeps the focus (Space would press it)
        await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur?.());
        const key = KEYS[Math.floor(rnd() * KEYS.length)];
        await page.keyboard.down(key);
        await sleep(120);
        await page.keyboard.up(key);
      }
      k++;
      if (k === 4) await connectMeter(page);
      await sleep(600 + Math.round(rnd() * 300));
    }
    // The results: the round's end and what sounds there
    await page.evaluate(() => (window as any).__gp.host.qaDriver.end());
    await sleep(1800);
    const buses = await connectMeter(page);
    const meter = await takeMeter(page);
    const half = await pageSession(page);
    if (meter.error || !meter.rate || meter.rows.length < 100) {
      ctx.info(S, 'sound: what QA heard', `not measured: ${meter.error || (meter.rate ? `the AudioContext ran ${((meter.rows.length * 128) / meter.rate).toFixed(1)} s` : 'no AudioContext')} in this browser`);
      return;
    }
    const report = analyzeSound({ ...half, rate: meter.rate, rows: meter.rows, buses });
    writeFileSync(join(ctx.outDir, 'sound.json'), JSON.stringify({ at: new Date().toISOString(), demo, ...report }, null, 2));
    const v = soundVerdict(report, { musicDeclared: ctx.game.sound?.music !== false });
    // Warnings first: what to fix; the run fails only on the checks
    for (const w of v.warnings) (ctx.warn ?? ctx.info)(S, w.name, w.details);
    for (const c of v.checks) ctx.check(S, c.name, c.ok, c.details);
    for (const i of v.infos) ctx.info(S, i.name, `${i.details}${i.name === 'sound: what QA heard' ? ` (${demo ? 'the demo bot playing, ' : ''}QA's taps and keys, ${SOUND_PLAY_SEC} s of play at ${VIEW.width}×${VIEW.height}; qa/sound.json)` : ''}`);
  } finally {
    await context.close();
  }
}
