// The kids kit flow: menu → round → (break) → reward → next round or menu; album; gate → settings.

import type { App, Flow, RoundResult, Theme } from '@gp/core';
import { TapCollectRound, type TapCollectConfig } from '@gp/blocks';
import type { KidsContext } from './context.ts';
import type { KidsConfig, KidsMode } from './index.meta.ts';
import { AlbumScene } from './scenes/album.ts';
import { MenuScene } from './scenes/menu.ts';
import { ParentGateScene, SettingsScene } from './scenes/parent.ts';
import { RewardScene } from './scenes/reward.ts';

export function createKidsFlow(app: App, theme: Theme, kids: KidsConfig, round: TapCollectConfig): Flow {
  const ctx: KidsContext = {
    app,
    theme,
    kids,
    round,
    menu: () => new MenuScene(ctx),
    play: (mode) => new TapCollectRound(app, theme, round, mode),
    reward: (mode, sticker) => new RewardScene(ctx, mode, sticker),
    album: () => new AlbumScene(ctx),
    gate: () => new ParentGateScene(ctx),
    settings: () => new SettingsScene(ctx),
  };
  const modeById = new Map<string, KidsMode>(kids.modes.map((m) => [m.id, m]));
  return {
    home: () => ctx.menu(),
    roundEnded(result: RoundResult) {
      // One sticker per round, in order; after the last one the reward screen shows a random collected one
      const total = kids.rewards.stickers.length;
      const have = app.save.stickers as number;
      const sticker = have < total ? have : -1;
      if (sticker >= 0) app.save.stickers = have + 1;
      const mode = modeById.get(result.mode) ?? kids.modes[0];
      return () => ctx.reward(mode, sticker);
    },
  };
}
