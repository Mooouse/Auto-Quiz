// Test page for the first-minute blocks (packages/core/test-browser/first-minute.test.ts): a GameHost with a portal that
// records its calls, and the hints, the results screen, the welcome-back card and the daily reward card on the page's #ui.
// ?hold=1: the host holds gameplay until loaded() (as the player's boot does). ?save=<json>: a save before the host starts.
import { dailyStreak, GameHost, hints, LANGUAGE_CODES, mountResults, mountStreakCard, screenTheme, welcomeBack, type Portal } from '../../src/index';

const q = new URLSearchParams(location.search);
const KEY = 'fm-fixture';
if (q.has('save')) localStorage.setItem(KEY, q.get('save')!);
const calls: string[] = [];
const portal: Portal = {
  name: 'test',
  init: async () => {},
  loadingStart: () => void calls.push('loadingStart'),
  loadingStop: () => void calls.push('loadingStop'),
  gameplayStart: () => void calls.push('gameplayStart'),
  gameplayStop: () => void calls.push('gameplayStop'),
  happytime: () => {},
  adProvider: () => null,
  storage: () => null,
  muted: () => false,
  onMuteChange: () => {},
  locale: () => null,
};
const host = new GameHost({
  saveKey: KEY,
  minTouchPx: 48,
  locale: 'en-US',
  // English unless ?lang= (the streak card's test plays every language)
  languages: LANGUAGE_CODES,
  ads: null,
  portal,
  keepEventLog: true,
  holdGameplayUntilLoaded: q.get('hold') === '1',
});
const ui = document.getElementById('ui')!;
const log: string[] = [];
(window as unknown as Record<string, unknown>).__t = {
  host,
  calls,
  log,
  funnel: () => host.events.log.filter((e) => e.type === 'funnel').map((e) => e.data.step),
  hints,
  screenTheme,
  ui,
  results: (o: Record<string, unknown> = {}, root: HTMLElement = ui) =>
    mountResults(root, {
      host,
      title: 'New best!',
      lines: ['Score: 12'],
      primary: 'again',
      onPrimary: () => log.push('primary'),
      onMenu: () => log.push('menu'),
      goal: { label: 'Star', progress: 0.82, detail: '9 coins to go' },
      ...o,
    }),
  // A streak on day `day` of its week (claimed every day before it), the player has played once
  streak: (day = 3, o: Record<string, unknown> = {}, f: { played?: boolean; claimToday?: boolean } = {}) => {
    const save: Record<string, unknown> = {};
    const c = { t: new Date(2026, 9, 1, 12).getTime() };
    const s = dailyStreak(save, { reward: (d) => (d === 7 ? 1500 : 50 * d), now: () => c.t });
    if (f.played !== false) s.played();
    for (let d = 1; d < day; d++) {
      s.claim();
      c.t += 86400000;
    }
    if (f.claimToday) s.claim();
    return mountStreakCard(ui, s, { host, onClaim: (n) => log.push(`claim ${n}`), onClose: () => log.push('close'), ...o });
  },
  welcome: (o: Record<string, unknown> = {}) => welcomeBack({ host, daily: { done: false }, goal: { label: 'Star', progress: 0.5 }, onContinue: () => log.push('continue'), onClose: () => log.push('close'), ...o }),
};
