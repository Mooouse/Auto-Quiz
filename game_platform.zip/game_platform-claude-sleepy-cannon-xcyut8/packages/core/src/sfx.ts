// @gp/core/sound — sound effects: createSfx(mixer, sounds) plays bundled files and procedural recipes on the mixer's
// effects bus. Re-exported from sound.ts (import it from '@gp/core/sound').
//
//   import coinUrl from './sfx/coin.mp3?inline';              // a data: URL in the one-file upload
//   const sfx = createSfx(mixer, {
//     coin: coinUrl,                                           // a file: decoded once the AudioContext exists
//     hit: sfxRecipe('hit'),                                   // no file: a recipe synthesized on the spot
//     ping: sfxRecipe('glass', { hz: 1568 }),                  // a struck material (marble wood glass metal bell porcelain)
//     boom: { src: sfxRecipe('boom'), vol: 0.8, gap: 0.08 },   // per-sound settings
//     intro: { src: lineUrl, voice: true },                    // a voice line: say('intro')
//   });
//   sfx.load();                                                // on the first tap (Play): decode the files now
//   sfx.play('coin', { rate: 1 + combo * 0.06 });              // ±6 % pitch by itself; the same sound within 40 ms: once
//   sfx.listener({ x: hero.x, y: hero.y, range: 600 });        // where the player is: far sounds quieter, panned
//   sfx.play('hit', { at: enemy });                            // …so this one comes from the enemy's side
//   sfx.say('intro');                                          // one line at a time, the music ducks under it
//   sfx.hush();                                                // the pause screen, a scene change: everything fades out
//
// What it keeps for you (Frankengun's audio.ts, Candle Crypt's and Swarm Smash's sound.ts wrote it by hand): every sound
// on the mixer's sfx bus (its slider), through host.audio.out (the portal's mute and the ad pause silence it); nothing
// starts while the mixer is silent (muted, paused, no running context); a little pitch variation on every play, so a
// hundred hits aren't one sound a hundred times (gp qa warns about exact repeats); a throttle per sound and a cap on
// voices, so twelve pellets are one hit and a swarm doesn't clip; every sound starts and ends on an envelope.

import type { Mixer } from './sound';

// --- Recipes -------------------------------------------------------------------------------------------------------

/** The procedural sounds: a game without files still has good ones (all synthesized, a few hundred bytes each) */
export type RecipeKind = 'coin' | 'hit' | 'shot' | 'deny' | 'click' | 'whoosh' | 'pop' | 'thud' | 'boom';
/** Struck things: a short tick and a few inharmonic partials, each decaying at its own rate (Velvet's modal tables) */
export type Material = 'marble' | 'wood' | 'glass' | 'metal' | 'bell' | 'porcelain';
export const RECIPES: readonly RecipeKind[] = ['coin', 'hit', 'shot', 'deny', 'click', 'whoosh', 'pop', 'thud', 'boom'];

/** One partial of a struck body: [frequency ratio, gain, decay in seconds] */
export type Mode = readonly [number, number, number];

/** The partials of each material, and its fundamental (Hz) when the recipe names none */
export const MATERIALS: Record<Material, { hz: number; modes: readonly Mode[] }> = {
  /** Polished marble: a hard, very short glassy ping */
  marble: { hz: 2900, modes: [[1, 1, 0.03], [2.7, 0.4, 0.02], [5.1, 0.15, 0.012]] },
  /** A wooden bar (a marimba key): one round note, the overtones gone at once */
  wood: { hz: 392, modes: [[1, 1, 0.35], [3.93, 0.25, 0.08], [9.2, 0.08, 0.03]] },
  /** A glass chime: thin and bright */
  glass: { hz: 1568, modes: [[1, 1, 0.5], [2.74, 0.4, 0.25], [5.2, 0.18, 0.12]] },
  /** An anvil: a dull iron ring, heavily damped */
  metal: { hz: 330, modes: [[1, 1, 0.7], [2.76, 0.6, 0.45], [5.4, 0.35, 0.25], [8.93, 0.15, 0.12]] },
  /** A small brass bell: a hum below, a minor third and a fifth inside the ring */
  bell: { hz: 880, modes: [[0.5, 0.25, 1.6], [1, 1, 1.3], [1.19, 0.35, 1], [1.5, 0.3, 0.8], [2, 0.45, 0.7], [2.51, 0.2, 0.4], [3.01, 0.15, 0.3]] },
  /** A porcelain cup: a clear ring with bright, quick upper partials */
  porcelain: { hz: 1250, modes: [[1, 1, 0.9], [2.32, 0.55, 0.55], [4.25, 0.3, 0.3], [6.63, 0.16, 0.18]] },
};

export interface RecipeOptions {
  /** × every frequency of the recipe (1 as designed, 2 an octave up); a play's `rate` multiplies it again */
  pitch?: number;
  /** × its level (default 1) */
  vol?: number;
  /** × its lengths (default 1): 0.5 a tighter hit, 2 a longer ring */
  decay?: number;
  /** A material's fundamental, Hz (default the material's own) */
  hz?: number;
}

/** A sound made of code, for createSfx */
export interface SfxRecipe {
  readonly recipe: RecipeKind | Material;
  readonly opts: RecipeOptions;
  /** Its length at rate 1, seconds (the envelope's end) */
  readonly length: number;
}

const isMaterial = (k: string): k is Material => k in MATERIALS;

/** A recipe: `sfxRecipe('coin')`, `sfxRecipe('hit', { pitch: 0.8 })`, `sfxRecipe('glass', { hz: 1568 })` */
export function sfxRecipe(kind: RecipeKind | Material, opts: RecipeOptions = {}): SfxRecipe {
  if (!RECIPES.includes(kind as RecipeKind) && !isMaterial(kind)) throw new Error(`sfxRecipe: no recipe '${kind}' (${[...RECIPES, ...Object.keys(MATERIALS)].join(', ')})`);
  const d = opts.decay ?? 1;
  const length = isMaterial(kind) ? Math.max(...MATERIALS[kind].modes.map((m) => m[2])) * d + 0.01 : RECIPE_LENGTH[kind as RecipeKind] * d;
  return { recipe: kind, opts, length };
}

const RECIPE_LENGTH: Record<RecipeKind, number> = { coin: 0.27, hit: 0.06, shot: 0.1, deny: 0.2, click: 0.03, whoosh: 0.18, pop: 0.15, thud: 0.4, boom: 0.62 };

/** What a recipe draws with: one context's noise buffer, and the voice's own output */
interface Kit {
  ctx: BaseAudioContext;
  out: AudioNode;
  noise: AudioBuffer;
  /** The latest end time of anything scheduled */
  end: number;
}

/** A tone on a percussive envelope, gliding f0 → f1 */
function tone(k: Kit, t: number, f0: number, f1: number, dur: number, vol: number, type: OscillatorType = 'sine', lp = 0): void {
  const nyq = k.ctx.sampleRate / 2 - 200;
  if (f0 >= nyq || vol <= 0) return;
  const o = k.ctx.createOscillator();
  o.type = type;
  o.frequency.setValueAtTime(f0, t);
  if (f1 !== f0) o.frequency.exponentialRampToValueAtTime(Math.min(nyq, Math.max(20, f1)), t + dur);
  let src: AudioNode = o;
  if (lp) {
    const f = k.ctx.createBiquadFilter();
    f.type = 'lowpass';
    f.frequency.value = Math.min(nyq, lp);
    src = o.connect(f);
  }
  src.connect(env(k, t, vol, dur));
  o.start(t);
  o.stop(t + dur + 0.03);
  k.end = Math.max(k.end, t + dur + 0.03);
}

/** Noise through a filter whose frequency sweeps f0 → f1 */
function hiss(k: Kit, t: number, type: BiquadFilterType, f0: number, f1: number, q: number, dur: number, vol: number, attack = 0.002): void {
  const nyq = k.ctx.sampleRate / 2 - 200;
  const s = k.ctx.createBufferSource();
  s.buffer = k.noise;
  s.loop = true;
  const f = k.ctx.createBiquadFilter();
  f.type = type;
  f.Q.value = q;
  f.frequency.setValueAtTime(Math.min(nyq, f0), t);
  if (f1 !== f0) f.frequency.exponentialRampToValueAtTime(Math.min(nyq, Math.max(20, f1)), t + dur);
  s.connect(f).connect(env(k, t, vol, dur, attack));
  // A different stretch of the noise each time: noise sounds never repeat sample for sample
  s.start(t, Math.random() * Math.max(0, k.noise.duration - dur - 0.05));
  s.stop(t + dur + 0.03);
  k.end = Math.max(k.end, t + dur + 0.03);
}

/** A quick attack and an exponential decay, from silence to silence */
function env(k: Kit, t: number, peak: number, dur: number, attack = 0.002): GainNode {
  const g = k.ctx.createGain();
  const a = Math.min(attack, dur * 0.5);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(Math.max(0.0002, peak), t + a);
  g.gain.exponentialRampToValueAtTime(0.0001, t + Math.max(a + 0.004, dur));
  g.connect(k.out);
  return g;
}

/** A struck body: the excitation's tick, then its partials ringing together */
function ring(k: Kit, t: number, f: number, modes: readonly Mode[], vol: number, decay: number): void {
  hiss(k, t, 'highpass', 5000, 5000, 0.7, 0.006, vol * 0.6, 0.001);
  for (const [r, g, d] of modes) tone(k, t, f * r, f * r, d * decay, vol * g, 'sine');
}

/** The recipes: frequencies × p, lengths × d, levels × v (each sits well under the music at v = 1) */
function playRecipe(k: Kit, r: SfxRecipe, t: number, rate: number, vol: number): void {
  const p = (r.opts.pitch ?? 1) * rate;
  const d = r.opts.decay ?? 1;
  const v = (r.opts.vol ?? 1) * vol;
  if (isMaterial(r.recipe)) {
    const m = MATERIALS[r.recipe];
    ring(k, t, (r.opts.hz ?? m.hz) * p, m.modes, 0.16 * v, d);
    return;
  }
  switch (r.recipe) {
    case 'coin':
      // Two bright notes a fourth apart, a glint on the second (B5 → E6)
      tone(k, t, 988 * p, 988 * p, 0.07 * d, 0.13 * v, 'square', 5000);
      tone(k, t + 0.07 * d, 1319 * p, 1319 * p, 0.2 * d, 0.13 * v, 'square', 5000);
      tone(k, t + 0.07 * d, 2638 * p, 2638 * p, 0.12 * d, 0.04 * v, 'sine');
      break;
    case 'hit':
      // A body blow: a falling knock and a short crack
      tone(k, t, 300 * p, 120 * p, 0.05 * d, 0.3 * v, 'triangle');
      hiss(k, t, 'bandpass', 2500 * p, 1500 * p, 0.8, 0.025 * d, 0.22 * v);
      break;
    case 'shot':
      // A laser-ish snap: a square falling fast through a lowpass, a burst of noise
      tone(k, t, 900 * p, 240 * p, 0.09 * d, 0.22 * v, 'square', 4000);
      hiss(k, t, 'bandpass', 3000 * p, 1500 * p, 0.8, 0.03 * d, 0.16 * v);
      break;
    case 'deny':
      // Two muted knocks on a locked wooden drawer: not allowed, never harsh
      for (let i = 0; i < 2; i++) {
        const ti = t + i * 0.11 * d;
        tone(k, ti, 210 * p, 130 * p, 0.07 * d, 0.2 * v * (1 - i * 0.25), 'sine');
        hiss(k, ti, 'bandpass', 420 * p, 400 * p, 3, 0.05 * d, 0.14 * v * (1 - i * 0.25));
      }
      break;
    case 'click':
      // A UI tick: short and dry
      tone(k, t, 1500 * p, 1200 * p, 0.025 * d, 0.12 * v, 'square', 5000);
      hiss(k, t, 'highpass', 6000, 6000, 0.7, 0.006, 0.06 * v, 0.001);
      break;
    case 'whoosh':
      // Air: a band of noise sweeping up (a swing, a dash, a card flying in)
      hiss(k, t, 'bandpass', 600 * p, 3000 * p, 2, 0.16 * d, 0.35 * v, 0.04 * d);
      break;
    case 'pop':
      // A bubble or a balloon: a soft puff and a short low thump
      hiss(k, t, 'bandpass', 1400 * p, 1400 * p, 0.9, 0.14 * d, 0.4 * v, 0.004);
      tone(k, t, 260 * p, 70 * p, 0.13 * d, 0.3 * v, 'sine');
      break;
    case 'thud':
      // A heavy landing: a deep falling sine and its muffled body (a total landing, a crate down)
      tone(k, t, 105 * p, 42 * p, 0.38 * d, 0.32 * v, 'sine');
      hiss(k, t, 'lowpass', 700 * p, 160 * p, 0.7, 0.22 * d, 0.2 * v);
      hiss(k, t, 'bandpass', 1400 * p, 1400 * p, 3, 0.03 * d, 0.08 * v);
      break;
    case 'boom':
      // An explosion: a noise burst falling through a lowpass, a sub thump, a crack on top
      hiss(k, t, 'lowpass', 3000 * p, 90 * p, 0.6, 0.6 * d, 0.32 * v);
      tone(k, t, 120 * p, 30 * p, 0.55 * d, 0.32 * v, 'sine');
      hiss(k, t, 'bandpass', 5000 * p, 1000 * p, 0.8, 0.15 * d, 0.1 * v);
      break;
  }
}

// --- createSfx -----------------------------------------------------------------------------------------------------

/** A sound: a file (a URL, a data: URL, or its bytes) or a recipe */
export type SfxSource = string | ArrayBuffer | SfxRecipe;

export interface SfxDef {
  src: SfxSource;
  /** Its level, 0–1+ (default 1) */
  vol?: number;
  /** Pitch variation, ± share (default 0.06: ±6 %); 0 for a jingle that must stay in tune */
  vary?: number;
  /** The same sound again within this many seconds is skipped (default 0.04) */
  gap?: number;
  /** At most this many of it ringing at once (default 6) */
  max?: number;
}

export interface SfxPlayOptions {
  /** × its level */
  vol?: number;
  /** × its pitch and speed (1.06 a semitone up): a combo that climbs, a bigger thing deeper */
  rate?: number;
  /** This play's pitch variation instead of the sound's own */
  vary?: number;
  /** Where it happens (the listener's units): quieter far away, panned to its side */
  at?: { x: number; y: number };
  /** −1 left … 1 right, instead of the one from `at` */
  pan?: number;
  /** Seconds from now */
  delay?: number;
}

/**
 * Where the player hears from. `range`: half as loud at this distance (default 600: px of a 2D screen). `yaw`: where the
 * listener faces, rad clockwise from up the screen (0: up, −y — a 2D game's default, its right ear toward +x; π/2: facing
 * +x) — a first-person game passes its heading; the right ear points along (cos yaw, sin yaw)
 */
export interface SfxListener {
  x: number;
  y: number;
  yaw?: number;
  range?: number;
}

export interface Sfx {
  /** Play a sound now (false: skipped — silent mixer, throttled, too many voices, not decoded yet, unknown) */
  play(name: string, o?: SfxPlayOptions): boolean;
  /** A voice line: one at a time (it cuts the last one), the music and the ambience ducked by `duck` under it. Its length, s (0: not played) */
  say(name: string, o?: { duck?: number; vol?: number }): number;
  /** Everything playing fades out in 60 ms: a voice line, the effects still ringing */
  hush(): void;
  /** Where the player hears from (a 2D game: the hero or the screen's centre, `range` ≈ half the screen) */
  listener(l: Partial<SfxListener>): void;
  /** Decode the files now (call it on the first tap): plays before it is done are skipped */
  load(): Promise<void>;
  /** Decoded and playable (a recipe always is); no name: every sound */
  ready(name?: string): boolean;
  /** Seconds a sound lasts at rate 1 (0 until a file is decoded) */
  duration(name: string): number;
  readonly names: readonly string[];
}

/** Voices of all sounds at once, at most: past it new ones are skipped (a swarm can't clip the bus) */
export const SFX_MAX_VOICES = 32;
const FADE_OUT = 0.06;

interface Playing {
  name: string;
  gain: GainNode;
  end: number;
  stop(at: number): void;
}

export function createSfx(mixer: Mixer, sounds: Record<string, SfxSource | SfxDef>): Sfx {
  const defs = new Map<string, Required<Omit<SfxDef, 'src'>> & { src: SfxSource }>();
  for (const [name, s] of Object.entries(sounds)) {
    const d: SfxDef = typeof s === 'object' && s !== null && 'src' in s ? s : { src: s as SfxSource };
    defs.set(name, { src: d.src, vol: d.vol ?? 1, vary: d.vary ?? 0.06, gap: d.gap ?? 0.04, max: d.max ?? 6 });
  }
  const buffers = new Map<string, AudioBuffer>();
  let loadedFor: BaseAudioContext | null = null;
  let loading: Promise<void> | null = null;
  let noise: AudioBuffer | null = null;
  const last = new Map<string, number>();
  let playing: Playing[] = [];
  let voice: Playing | null = null;
  const lis: Required<SfxListener> = { x: 0, y: 0, yaw: 0, range: 600 };
  /** The effects' own output on the bus: a soft limiter, so a burst of booms can't clip (one per context) */
  let head: { ctx: BaseAudioContext; bus: AudioNode; node: AudioNode } | null = null;
  mixer.onPause(() => api.hush());

  function output(ctx: BaseAudioContext, bus: AudioNode): AudioNode {
    if (head && head.ctx === ctx && head.bus === bus) return head.node;
    let node: AudioNode = bus;
    // A soft ceiling at 0.9 after the compressor: its attack lets a transient through, and WebAudio's compressor adds
    // its own make-up gain — the curve is a straight line up to 0.6, then bends smoothly toward 0.9
    if (typeof ctx.createWaveShaper === 'function') {
      const clip = ctx.createWaveShaper();
      const curve = new Float32Array(1025);
      for (let i = 0; i < curve.length; i++) {
        const x = (i / (curve.length - 1)) * 4 - 2;
        const a = Math.abs(x);
        curve[i] = Math.sign(x) * (a <= 0.6 ? a : 0.6 + 0.3 * Math.tanh((a - 0.6) / 0.3));
      }
      clip.curve = curve;
      clip.oversample = '2x';
      // The curve spans −2…2: the input scaled in half and the curve's x doubled back
      const pre = ctx.createGain();
      pre.gain.value = 0.5;
      pre.connect(clip).connect(bus);
      node = pre;
    }
    if (typeof ctx.createDynamicsCompressor === 'function') {
      const lim = ctx.createDynamicsCompressor();
      lim.threshold.value = -10;
      lim.knee.value = 6;
      lim.ratio.value = 12;
      lim.attack.value = 0.002;
      lim.release.value = 0.12;
      lim.connect(node);
      node = lim;
    }
    head = { ctx, bus, node };
    return node;
  }

  const isRecipe = (s: SfxSource): s is SfxRecipe => typeof s === 'object' && s !== null && 'recipe' in s;

  function load(): Promise<void> {
    const ctx = mixer.ctx();
    if (!ctx) return Promise.resolve();
    // A new context (the old one closed): decode again
    if (loadedFor !== ctx) {
      loadedFor = ctx;
      buffers.clear();
      loading = Promise.all(
        [...defs].map(async ([name, d]) => {
          if (isRecipe(d.src)) return;
          try {
            const bytes = typeof d.src === 'string' ? await (await fetch(d.src)).arrayBuffer() : d.src.slice(0);
            buffers.set(name, await ctx.decodeAudioData(bytes));
          } catch {
            // A file the browser can't decode (a codec it lacks): that sound stays silent, the rest play
          }
        }),
      ).then(() => undefined);
    }
    return loading ?? Promise.resolve();
  }

  /** Room for one more voice of `name` (the ended ones dropped) */
  function room(name: string, max: number, now: number): boolean {
    playing = playing.filter((p) => p.end > now);
    return playing.length < SFX_MAX_VOICES && playing.filter((p) => p.name === name).length < max;
  }

  /** The sound's level and pan from where it is */
  function place(o: SfxPlayOptions): { vol: number; pan: number } {
    let vol = 1;
    let pan = 0;
    if (o.at) {
      const dx = o.at.x - lis.x;
      const dy = o.at.y - lis.y;
      const d = Math.hypot(dx, dy);
      vol = 1 / (1 + d / Math.max(1e-6, lis.range));
      // To the listener's right (cos yaw, sin yaw): positive. Near the listener a sound stays in the middle
      const side = dx * Math.cos(lis.yaw) + dy * Math.sin(lis.yaw);
      pan = Math.max(-0.8, Math.min(0.8, side / (d + lis.range * 0.25)));
    }
    if (typeof o.pan === 'number') pan = Math.max(-1, Math.min(1, o.pan));
    return { vol, pan };
  }

  /** One play into the sfx bus; null when it can't play now */
  function start(name: string, o: SfxPlayOptions, asVoice: boolean): Playing | null {
    const d = defs.get(name);
    if (!d || mixer.silent()) return null;
    const ctx = mixer.ctx();
    const bus = mixer.bus('sfx');
    if (!ctx || !bus) return null;
    if (loadedFor !== ctx) void load();
    const now = ctx.currentTime;
    if (!asVoice) {
      if (now - (last.get(name) ?? -Infinity) < d.gap) return null;
      if (!room(name, d.max, now)) return null;
    }
    const recipe = isRecipe(d.src) ? d.src : null;
    const buf = recipe ? null : buffers.get(name);
    if (!recipe && !buf) return null;
    last.set(name, now);
    const vary = o.vary ?? (asVoice ? 0 : d.vary);
    const rate = Math.max(0.05, (o.rate ?? 1) * (1 + (Math.random() * 2 - 1) * vary));
    const where = place(o);
    const t = now + Math.max(0, o.delay ?? 0) + 0.005;
    const gain = ctx.createGain();
    gain.gain.value = Math.max(0, d.vol * (o.vol ?? 1) * where.vol);
    let tail: AudioNode = gain;
    if (Math.abs(where.pan) > 0.01 && typeof ctx.createStereoPanner === 'function') {
      const p = ctx.createStereoPanner();
      p.pan.value = where.pan;
      tail = gain.connect(p);
    }
    tail.connect(output(ctx, bus));
    let end: number;
    let stop: (at: number) => void;
    if (recipe) {
      if (!noise || noise.sampleRate !== ctx.sampleRate) noise = noiseBuffer(ctx);
      const kit: Kit = { ctx, out: gain, noise, end: t };
      playRecipe(kit, recipe, t, rate, 1);
      end = kit.end;
      stop = () => {};
    } else {
      const src = ctx.createBufferSource();
      src.buffer = buf!;
      src.playbackRate.value = rate;
      src.connect(gain);
      src.start(t);
      end = t + buf!.duration / rate;
      stop = (at) => src.stop(at);
    }
    const p: Playing = { name, gain, end, stop };
    // Unhook the nodes once it has rung out (a long session must not grow the graph)
    setTimeout(() => gain.disconnect(), Math.max(0, (end - now + 0.2) * 1000));
    playing.push(p);
    return p;
  }

  function fade(p: Playing, ctx: BaseAudioContext): void {
    const at = ctx.currentTime;
    p.gain.gain.cancelScheduledValues(at);
    p.gain.gain.setValueAtTime(p.gain.gain.value, at);
    p.gain.gain.linearRampToValueAtTime(0, at + FADE_OUT);
    try {
      p.stop(at + FADE_OUT + 0.02);
    } catch {
      // already stopped
    }
    p.end = Math.min(p.end, at + FADE_OUT + 0.02);
  }

  const api: Sfx = {
    play: (name, o = {}) => start(name, o, false) !== null,
    say(name, o = {}) {
      const ctx = mixer.ctx();
      if (!ctx || mixer.silent()) return 0;
      if (voice && voice.end > ctx.currentTime) fade(voice, ctx);
      const p = start(name, { vol: o.vol }, true);
      if (!p) return 0;
      const sec = p.end - ctx.currentTime;
      const duck = o.duck ?? 0.45;
      if (duck > 0) mixer.duck(duck, sec + 0.3);
      voice = p;
      return sec;
    },
    hush() {
      const ctx = mixer.ctx();
      if (!ctx) return;
      for (const p of playing) if (p.end > ctx.currentTime) fade(p, ctx);
      voice = null;
    },
    listener(l) {
      Object.assign(lis, Object.fromEntries(Object.entries(l).filter(([, v]) => typeof v === 'number' && Number.isFinite(v))));
    },
    load,
    ready(name) {
      const ok = (n: string) => {
        const d = defs.get(n);
        return !!d && (isRecipe(d.src) || buffers.has(n));
      };
      return name === undefined ? [...defs.keys()].every(ok) : ok(name);
    },
    duration(name) {
      const d = defs.get(name);
      if (!d) return 0;
      return isRecipe(d.src) ? d.src.length : (buffers.get(name)?.duration ?? 0);
    },
    names: [...defs.keys()],
  };
  return api;
}

function noiseBuffer(c: BaseAudioContext): AudioBuffer {
  const b = c.createBuffer(1, Math.floor(c.sampleRate * 1.5), c.sampleRate);
  const ch = b.getChannelData(0);
  for (let i = 0; i < ch.length; i++) ch[i] = Math.random() * 2 - 1;
  return b;
}
