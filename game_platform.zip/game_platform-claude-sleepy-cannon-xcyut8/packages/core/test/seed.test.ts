// Run seeds a player sees, copies and types back (@gp/core/seed; the owner, 2026-10-10)

import { describe, expect, it } from 'vitest';
import { seededRng } from '../src/rng';
import { dailyRunSeed, newRunSeed, normalizeSeedText, runSeedFrom, runSeedOf, seedLabel } from '../src/seed';

describe('run seeds', () => {
  it('a fresh seed is an 8-character code in two groups, with no letters that misread', () => {
    const r = newRunSeed();
    expect(r.code).toMatch(/^[0-9A-HJKMNP-TV-Z]{4}-[0-9A-HJKMNP-TV-Z]{4}$/);
    expect(r.custom).toBe(false);
    expect(r.seed).toBeGreaterThanOrEqual(0);
    expect(r.seed).toBeLessThan(2 ** 32);
  });

  it('typing the code back, however it is typed, gives the same seed and the same run', () => {
    const r = newRunSeed(() => 0.37);
    for (const typed of [r.code, r.code.toLowerCase(), r.code.replace('-', ' '), r.code.replace('-', '')]) {
      const back = runSeedFrom(typed)!;
      expect(back.code).toBe(r.code);
      expect(back.seed).toBe(r.seed);
      expect(back.custom).toBe(true);
    }
    expect(seededRng(runSeedOf(r.code)!.seed).int(1000)).toBe(seededRng(r.seed).int(1000));
    expect(normalizeSeedText('o-il')).toBe('011');
  });

  it('any word is a seed too, the same every time, and different words differ', () => {
    const a = runSeedFrom('CANDLE')!;
    expect(runSeedFrom(' candle ')!.code).toBe(a.code);
    expect(runSeedFrom('SWARM')!.code).not.toBe(a.code);
    expect(runSeedFrom('   ')).toBeNull();
  });

  it('distinct codes give distinct seeds (no collisions over 2000 random codes)', () => {
    let x = 1;
    const rand = () => ((x = (x * 48271) % 2147483647) / 2147483647);
    const seeds = new Set<number>();
    for (let i = 0; i < 2000; i++) seeds.add(newRunSeed(rand).seed);
    expect(seeds.size).toBe(2000);
  });

  it("the daily seed is the same for everyone on a day, differs by day and by game", () => {
    expect(dailyRunSeed('candle-crypt', '2026-10-10').code).toBe(dailyRunSeed('candle-crypt', '2026-10-10').code);
    expect(dailyRunSeed('candle-crypt', '2026-10-11').code).not.toBe(dailyRunSeed('candle-crypt', '2026-10-10').code);
    expect(dailyRunSeed('swarm-smash', '2026-10-10').code).not.toBe(dailyRunSeed('candle-crypt', '2026-10-10').code);
  });

  it('the label marks a custom seed', () => {
    const t = (k: string) => ({ 'gp.seed': 'Seed', 'gp.seed.custom': 'custom' })[k] ?? k;
    const r = runSeedFrom('CANDLE')!;
    expect(seedLabel(r, t)).toBe(`Seed ${r.code} · custom`);
    expect(seedLabel({ ...r, custom: false }, t)).toBe(`Seed ${r.code}`);
  });
});
