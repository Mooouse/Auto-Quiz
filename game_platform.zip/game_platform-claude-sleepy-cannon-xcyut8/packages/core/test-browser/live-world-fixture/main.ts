// The live world's DOM and canvas parts in a real browser: the restock countdown (mountRestockTimer) on a clock the
// test moves, and the daily table's share card (drawShareCard). ?lang=de for the platform's words in another language.

import { worldClock } from '../../src/clock.ts';
import { dailyTable, drawShareCard, shareText } from '../../src/daily-table.ts';
import { byLanguage, createI18n } from '../../src/i18n.ts';
import { PLATFORM_STRINGS } from '../../src/i18n-platform.ts';
import { mountRestockTimer } from '../../src/restock-ui.ts';
import { restockShop } from '../../src/restock.ts';

const q = new URLSearchParams(location.search);
const i18n = createI18n({ strings: byLanguage(PLATFORM_STRINGS), lang: q.get('lang') ?? 'en' });
const t = (key: string, params?: Record<string, string | number>) => i18n.t(key, params);
const w = window as unknown as { __t: number; __live: Record<string, unknown> };
w.__t = Date.UTC(2026, 9, 19, 18, 3, 12);
if (q.get('theme')) document.documentElement.style.setProperty('--gp-theme-accent', 'rgb(1, 2, 3)');

const clock = worldClock({ salt: 'fixture', now: () => w.__t });
const shop = restockShop({}, {
  clock,
  slots: 3,
  pool: [
    { id: 'quartz', weight: 4, price: 10 },
    { id: 'amber', weight: 3, price: 20 },
    { id: 'jade', weight: 2, price: 50 },
    { id: 'opal', weight: 1, price: 200 },
  ],
});
let restocks = 0;
const timer = mountRestockTimer(document.getElementById('panel')!, shop, { host: { t }, onRestock: () => restocks++, tickMs: 200 });

const table = dailyTable({}, { salt: 'fixture', bands: [{ id: 'bronze', at: 100 }, { id: 'silver', at: 250 }, { id: 'gold', at: 400 }], now: () => w.__t });
table.record(388);
const card = table.card(null, { title: 'Fixture Game', t });
const canvas = drawShareCard(document.createElement('canvas'), card, { bg: '#18263a', accent: '#ffd166' });
canvas.id = 'card';
document.body.append(canvas);

w.__live = {
  restocks: () => restocks,
  own: () => {
    shop.restockNow();
    timer.update();
  },
  destroy: () => timer.destroy(),
  text: shareText(card),
};
