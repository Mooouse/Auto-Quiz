// QA runner: opens the game in headless Chromium, runs the kit's check suite, writes a report.
// A suite gets `check(scope, name, ok, details)` and a `shot(name)` helper; the runner does the rest.

import { execFileSync } from 'node:child_process';
import { availableParallelism } from 'node:os';
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { dirname, join, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import type { ResolvedGame } from '@gp/spec';
import type { CanvasUiRect } from './probe.ts';

export interface QaCheck {
  scope: string;
  name: string;
  ok: boolean;
  details: string;
  /** The suite's section that made it (runSections), when the suite runs in sections: what `gp qa --failed` re-runs */
  section?: string;
}

export interface QaContext {
  url: string;
  game: ResolvedGame;
  outDir: string;
  /** --quick: one screen size (phone portrait) + the special checks — for iterating; the full run is the gate */
  quick: boolean;
  check(scope: string, name: string, ok: boolean, details?: string): void;
  /** Note that is not a pass/fail (e.g. a check skipped because the game has no ads) */
  info(scope: string, name: string, details: string): void;
  /** Something to fix that doesn't fail the run (the sound section's flat feedback): listed before the notes. Unset: an info */
  warn?(scope: string, name: string, details: string): void;
  browser: import('playwright').Browser;
  /**
   * What a code game declared it draws on the canvas (host.qa canvasUi), read in the dev build at the portal's frame sizes:
   * key `<frame name>:title` / `<frame name>:play`. The production run (no test hooks there) checks those rects' pixels
   */
  canvasUi: Record<string, CanvasUiRect[]>;
  /** How many sections run at once (runSections); 1 or unset: one after the other */
  jobs?: number;
  /** `gp qa --failed`: only these sections run (the rest keep their results from the last run); unset: all */
  only?: ReadonlySet<string> | null;
  /** The runner's hook: the checks reported inside `replay` belong to `section` */
  inSection?(section: string, replay: () => void): void;
  /** The runner's own sections (the production build, the balance bot): a suite with sections runs them in its pool */
  extra?: QaSection[];
  /** The runner's hook: how long a section took (qa-results.json `timing`) */
  timed?(section: string, seconds: number): void;
  /**
   * What one section measured for another to show beside its own, shared by every section (the runner makes it): the
   * first minute's first celebrated moment (s after Play) and the balance model's first reward (s of play). The section
   * that ends second shows both
   */
  notes?: { modelFirstRewardSec?: number | null; firstHighlightSec?: number | null };
}

export interface QaSection {
  name: string;
  run(ctx: QaContext): Promise<void>;
  /** Sections of the same list it reads the results of: it starts when they are done */
  after?: string[];
}

/**
 * Runs a suite's sections, `jobs` at a time (default ctx.jobs): each on its own pages, so they don't share state. Their
 * checks are buffered and reported in the list's order, a section as soon as it and every one before it are done, so the
 * report reads the same at any `jobs`. A section that throws fails one check of its own and the others go on. Sections
 * not in ctx.only are skipped (`gp qa --failed`).
 */
export async function runSections(ctx: QaContext, sections: QaSection[], jobs = ctx.jobs ?? 1): Promise<void> {
  const list = sections.filter((s) => !ctx.only || ctx.only.has(s.name));
  type Line = { kind: 'check'; a: [string, string, boolean, string?] } | { kind: 'info' | 'warn'; a: [string, string, string] };
  const buffers: Line[][] = list.map(() => []);
  const done: boolean[] = list.map(() => false);
  let flushed = 0;
  const flush = () => {
    while (flushed < list.length && done[flushed]) {
      const lines = buffers[flushed];
      const replay = () => {
        for (const l of lines) {
          if (l.kind === 'check') ctx.check(...l.a);
          else if (l.kind === 'warn') (ctx.warn ?? ctx.info)(...l.a);
          else ctx.info(...l.a);
        }
      };
      if (ctx.inSection) ctx.inSection(list[flushed].name, replay);
      else replay();
      flushed++;
    }
  };
  const finished = list.map(() => {
    let resolve!: () => void;
    return { promise: new Promise<void>((r) => (resolve = r)), resolve };
  });
  const index = new Map(list.map((s, i) => [s.name, i]));
  let next = 0;
  const worker = async () => {
    while (next < list.length) {
      const i = next++;
      const buf = buffers[i];
      for (const a of list[i].after ?? []) {
        const j = index.get(a);
        if (j !== undefined && j !== i) await finished[j].promise;
      }
      const sub: QaContext = {
        ...ctx,
        check: (scope, name, ok, details = '') => void buf.push({ kind: 'check', a: [scope, name, ok, details] }),
        info: (scope, name, details) => void buf.push({ kind: 'info', a: [scope, name, details] }),
        warn: (scope, name, details) => void buf.push({ kind: 'warn', a: [scope, name, details] }),
      };
      const t0 = Date.now();
      try {
        await list[i].run(sub);
      } catch (e) {
        buf.push({ kind: 'check', a: [list[i].name, 'section finished without an exception', false, String((e as Error).stack ?? e)] });
      }
      ctx.timed?.(list[i].name, Math.round((Date.now() - t0) / 100) / 10);
      done[i] = true;
      finished[i].resolve();
      flush();
    }
  };
  await Promise.all(Array.from({ length: Math.max(1, Math.min(jobs, list.length)) }, worker));
}

export interface QaSuite {
  kit: string;
  run(ctx: QaContext): Promise<void>;
  /**
   * What must run on a quiet machine (frame rate, a twist timed in seconds), after everything else when sections run in
   * parallel (ctx.jobs > 1); with jobs 1, run() does it in place and this is not called
   */
  quiet?(ctx: QaContext): Promise<void>;
  /** The suite reports through runSections, so `gp qa --failed` can re-run the sections that failed */
  sections?: boolean;
  /** Sections a re-run section needs run with it (it reads what they measure), for `gp qa --failed` */
  needs?: Record<string, string[]>;
  /** How to play the PRODUCTION build (no test hooks: real taps only), for the portal checks */
  prod?: {
    /** From the first screen to gameplay */
    play(page: import('playwright').Page): Promise<void>;
    /** Until the round is over (optional: then saves are checked too) */
    finish?(page: import('playwright').Page): Promise<void>;
  };
}

export interface QaOptions {
  url: string;
  game: ResolvedGame;
  outDir: string;
  headed?: boolean;
  quick?: boolean;
  /** The production build, served (games on a portal): the portal checks run against it */
  prodUrl?: string;
  /** More checks from the caller, after the suite (gp qa: the game's balance report for code games) */
  after?(ctx: QaContext): Promise<void>;
  /** Sections at once (default: defaultJobs()); --headed runs one */
  jobs?: number;
  /**
   * Re-run only the sections that failed in the last run (qa-results.json) and keep the others' results. The re-run
   * takes the last run's size: after a --quick run it is quick too (`quick` is then ignored), after a full one full
   */
  failed?: boolean;
}

/** Sections at once by default: GP_QA_JOBS, else one fewer than the CPUs, at most 3 (a software rasterizer per page) */
export function defaultJobs(): number {
  const env = Number(process.env.GP_QA_JOBS);
  if (Number.isInteger(env) && env >= 1) return env;
  return Math.max(1, Math.min(3, availableParallelism() - 1));
}

export interface QaResults {
  game: string;
  date: string;
  platform: string | null;
  /** full: every check (the gate) · quick: one screen size · failed: the failed sections re-run on top of `base` */
  mode?: 'full' | 'quick' | 'failed';
  jobs?: number;
  seconds?: number;
  /** Seconds per section (sections in parallel overlap) */
  timing?: Record<string, number>;
  /** mode failed: the run whose other results were kept, and the sections re-run */
  base?: string;
  rerun?: string[];
  /** mode failed: its base was a --quick run, so it re-ran quick too (one screen size) */
  quick?: boolean;
  passed: number;
  failed: number;
  checks: QaCheck[];
  /** Notes; `warn`: something to fix that doesn't fail the run (listed first in report.md) */
  infos: { scope: string; name: string; details: string; section?: string; warn?: boolean }[];
}

/** The three slowest sections, for the report's first line */
function slowest(timing: Record<string, number>): string {
  const top = Object.entries(timing).sort((a, b) => b[1] - a[1]).slice(0, 3);
  return top.length ? ` (slowest: ${top.map(([k, v]) => `${k} ${v} s`).join(', ')})` : '';
}

/** The last run was a --quick one (or a --failed re-run on top of one): its results are one screen size's */
export function quickResults(prev: QaResults): boolean {
  return prev.mode === 'quick' || (prev.mode === 'failed' && !!prev.quick);
}

/**
 * Which sections `gp qa --failed` re-runs, from the last results: the sections with a failed check, and whether the run
 * they come from was quick (the re-run is then quick too: a quick run has the same sections at one screen size). With
 * why instead when it can't: no results, results from before sections, or a failure outside any section.
 */
export function failedSections(prev: QaResults | null): { sections: string[]; quick: boolean } | { why: string } {
  if (!prev) return { why: 'no earlier results (qa/qa-results.json)' };
  if (!prev.mode) return { why: 'the last run was made before sections existed' };
  const bad = prev.checks.filter((c) => !c.ok);
  if (bad.some((c) => !c.section)) return { why: `a failure outside the suite's sections (${bad.find((c) => !c.section)!.name})` };
  return { sections: [...new Set(bad.map((c) => c.section!))], quick: quickResults(prev) };
}

const PLATFORM_ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '../../..');

/**
 * The platform checkout's commit, `<short hash> <commit date>`, or null outside git. A game repository runs `gp` from
 * whatever checkout `scripts/setup.sh` cloned: Echoflies' 116/116 came from one older than the checks that landed the
 * same morning, and nothing in its report said so. The report names it now.
 */
export function platformCommit(root = PLATFORM_ROOT): string | null {
  try {
    const out = execFileSync('git', ['-C', root, 'log', '-1', '--format=%h %cs'], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim();
    return /^[0-9a-f]{7,} \d{4}-\d{2}-\d{2}$/.test(out) ? out : null;
  } catch {
    return null;
  }
}

/**
 * Written into qa/ by other commands (gp forecast, gp uniqueness, gp balance, gp translate, gp review): a QA run keeps them —
 * the reviewer may start on the brief while the full run is going. Not uniqueness.json: QA writes it
 */
export const KEPT_REPORTS = [
  'forecast.md',
  'uniqueness.md',
  'balance.md',
  'translate-brief.md',
  'review-brief.md',
  // gp review --first-look: the blind agent's brief, frames and answers (gp review --check reads first-look.md)
  'first-look-brief.md',
  'first-look.md',
  'first-look.png',
  ...[0, 3, 8, 15, 22, 30].map((t) => `first-look-${String(t).padStart(2, '0')}s.png`),
];

export async function runQa(opts: QaOptions): Promise<{ passed: number; failed: number; report: string }> {
  const { chromium } = await import('playwright');
  const suites: Record<string, () => Promise<QaSuite>> = {
    kids: async () => (await import('@gp/kit-kids/qa')).suite,
    casual: async () => (await import('@gp/kit-casual/qa')).suite,
    code: async () => (await import('@gp/kit-code/qa')).suite,
  };
  const load = suites[opts.game.kit.kit];
  if (!load) throw new Error(`No QA suite for kit "${opts.game.kit.kit}"`);
  const suite = await load();
  const jobs = opts.headed ? 1 : Math.max(1, Math.floor(opts.jobs ?? defaultJobs()));
  const resultsFile = join(opts.outDir, 'qa-results.json');
  const report = join(opts.outDir, 'report.md');
  const platform = platformCommit();
  let prev: QaResults | null = null;
  try {
    prev = JSON.parse(readFileSync(resultsFile, 'utf8')) as QaResults;
  } catch {
    prev = null;
  }
  let only: Set<string> | null = null;
  let quick = !!opts.quick;
  if (opts.failed) {
    if (!suite.sections) throw new Error(`gp qa --failed: kit "${suite.kit}"'s QA runs as a whole (no sections) — run gp qa`);
    const f = failedSections(prev);
    if ('why' in f) throw new Error(`gp qa --failed can't re-run only what failed: ${f.why} — run the full gp qa`);
    if (prev!.platform !== platform) throw new Error(`gp qa --failed: the platform changed since the last run (${prev!.platform ?? '?'} → ${platform ?? '?'}), so its checks did too — run the full gp qa`);
    if (!f.sections.length) {
      console.log(`nothing failed in the last ${f.quick ? 'quick ' : ''}run (${prev!.date}): ${prev!.passed} passed. Report: ${relative(process.cwd(), report)}`);
      return { passed: prev!.passed, failed: 0, report };
    }
    // The re-run takes the size of the run it completes: a quick run's sections quick, a full run's full
    if (quick && !f.quick) console.log('--quick ignored: the last run was a full one, and its failed sections re-run full');
    quick = f.quick;
    only = new Set(f.sections);
    // A section that reads what another one measured runs with it (production reads the canvas UI rects of the frames)
    for (const [s, needs] of Object.entries(suite.needs ?? {})) if (only.has(s)) for (const n of needs) only.add(n);
    console.log(`re-running the sections that failed on ${prev!.date}${quick ? ' (a --quick run: quick again, one screen size)' : ''}: ${[...only].join(', ')} (the rest keep their results)`);
  } else {
    // A fresh folder for this run, but the reports other gp commands write here survive it
    const kept = KEPT_REPORTS.map((f) => [f, join(opts.outDir, f)] as const).filter(([, p]) => existsSync(p)).map(([f, p]) => [f, readFileSync(p)] as const);
    rmSync(opts.outDir, { recursive: true, force: true });
    mkdirSync(opts.outDir, { recursive: true });
    for (const [f, data] of kept) writeFileSync(join(opts.outDir, f), data);
  }

  const checks: QaCheck[] = [];
  const infos: QaResults['infos'] = [];
  let section: string | undefined;
  const timing: Record<string, number> = {};
  const browser = await chromium.launch({ headless: !opts.headed, executablePath: process.env.CHROMIUM_PATH || undefined });
  const started = new Date();
  const ctx: QaContext = {
    url: opts.url,
    game: opts.game,
    outDir: opts.outDir,
    quick,
    browser,
    canvasUi: {},
    notes: {},
    jobs,
    only,
    check(scope, name, ok, details = '') {
      checks.push({ scope, name, ok, details, ...(section ? { section } : {}) });
      console.log(`${ok ? 'OK  ' : 'FAIL'} [${scope}] ${name} ${details}`);
    },
    info(scope, name, details) {
      infos.push({ scope, name, details, ...(section ? { section } : {}) });
      console.log(`INFO [${scope}] ${name} ${details}`);
    },
    warn(scope, name, details) {
      infos.push({ scope, name, details, warn: true, ...(section ? { section } : {}) });
      console.log(`WARN [${scope}] ${name} ${details}`);
    },
    timed(name, sec) {
      timing[name] = sec;
    },
    inSection(name, replay) {
      section = name;
      try {
        replay();
      } finally {
        section = undefined;
      }
    },
  };
  try {
    // The production build and the caller's checks share no pages with the suite: in its pool when it has sections.
    // `after` must not block the event loop (gp qa runs the balance bot in a worker thread: on the main thread its
    // ≈ 190 s of Dread Throne held every page's awaits, and ads and screens took 211 and 245 s)
    const extra: QaSection[] = [];
    // The balance bot from the start, beside the pool (it takes a core, not a browser slot); reported when it ends
    const after = opts.after;
    const balance = after && (ctx.jobs ?? 1) > 1 ? runSections(ctx, [{ name: 'balance', run: after }], 1) : null;
    if (after && !balance) extra.push({ name: 'balance', run: after });
    if (opts.prodUrl) {
      const prodUrl = opts.prodUrl;
      extra.push({ name: 'production', after: suite.needs?.production, run: async (c) => (await import('./portal-suite.ts')).runPortalChecks(c, suite, prodUrl) });
    }
    if (suite.sections) ctx.extra = extra;
    await suite.run(ctx);
    if (!suite.sections) await runSections(ctx, extra);
    await balance;
    // Frame rate and the timed twist last, alone on the machine
    if (jobs > 1) await suite.quiet?.(ctx);
  } catch (e) {
    checks.push({ scope: 'runner', name: 'suite finished without an exception', ok: false, details: String((e as Error).stack ?? e) });
    console.error(e);
  } finally {
    await browser.close();
  }
  const seconds = Math.round((Date.now() - started.getTime()) / 1000);
  let all = checks;
  let allInfos = infos;
  if (only && prev) {
    // The kept sections' results in their places, the re-run ones replaced
    const order = [...new Set([...prev.checks, ...checks].map((c) => c.section ?? ''))];
    const pick = <T extends { section?: string }>(old: T[], fresh: T[]) => order.flatMap((sec) => (only!.has(sec) ? fresh : old).filter((c) => (c.section ?? '') === sec));
    all = pick(prev.checks, checks);
    allInfos = pick(prev.infos ?? [], infos);
  }
  const failed = all.filter((c) => !c.ok).length;
  const warnings = allInfos.filter((c) => c.warn).length;
  const mode: QaResults['mode'] = only ? 'failed' : quick ? 'quick' : 'full';
  const results: QaResults = {
    game: opts.game.id,
    date: started.toISOString(),
    platform,
    mode,
    jobs,
    seconds,
    timing,
    ...(only && prev ? { base: prev.mode === 'failed' && prev.base ? prev.base : prev.date, rerun: [...only], ...(quick ? { quick: true } : {}) } : {}),
    passed: all.length - failed,
    failed,
    checks: all,
    infos: allInfos,
  };
  writeFileSync(resultsFile, JSON.stringify(results, null, 2));
  const how =
    mode === 'full'
      ? `Full run, ${jobs} section(s) at a time, ${seconds} s${slowest(timing)}.`
      : mode === 'quick'
        ? `**Quick run** (one screen size), ${seconds} s — not the gate: run the full \`gp qa\`.`
        : `**Re-run of the failed sections** (${results.rerun!.join(', ')})${quick ? ' of a **quick run** (one screen size)' : ''}, ${seconds} s; the other results are from the ${quick ? 'quick ' : ''}run of ${results.base} — the gate is a full \`gp qa\`.`;
  const md = [
    `# QA report: ${opts.game.title} (${opts.game.id})`,
    '',
    `${started.toISOString()} — **${all.length - failed} passed, ${failed} failed**${warnings ? `, **${warnings} warning(s)**` : ''}. ${how} Suite: kit "${suite.kit}". Platform: game_platform ${platform ?? '(not a git checkout)'}. Screenshots are in this folder.`,
    '',
    // Warnings first (⚠️: they don't fail the run — fix them or say in the report why not), then the checks, then the notes
    '| | Scope | Check | Details |',
    '|---|---|---|---|',
    ...allInfos.filter((c) => c.warn).map((c) => `| ⚠️ | ${c.scope} | ${c.name} | ${c.details.replace(/\|/g, '\\|')} |`),
    ...all.map((c) => `| ${c.ok ? '✅' : '❌'} | ${c.scope} | ${c.name} | ${c.details.replace(/\|/g, '\\|').replace(/\n/g, ' ')} |`),
    ...allInfos.filter((c) => !c.warn).map((c) => `| ℹ️ | ${c.scope} | ${c.name} | ${c.details.replace(/\|/g, '\\|')} |`),
    '',
  ].join('\n');
  writeFileSync(report, md);
  console.log(`report: ${relative(process.cwd(), report)}${platform ? ` (game_platform ${platform})` : ''}`);
  return { passed: all.length - failed, failed, report };
}
