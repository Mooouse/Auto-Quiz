// Browser test of the ready dialogue sheet (mountDialogue) against docs/research/story-2026-09.md §3.4 and §3.7.
// Runs with `npm run test:browser` (needs Playwright's Chromium). The fixture page carries a game's hostile CSS.

import { fileURLToPath } from 'node:url';
import { chromium, type Browser, type Page } from 'playwright';
import { createServer, type ViteDevServer } from 'vite';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import type { DialogueView } from '../src/dialogue-ui';

let server: ViteDevServer;
let browser: Browser;
let base = '';

beforeAll(async () => {
  server = await createServer({ root: fileURLToPath(new URL('./dialogue-fixture', import.meta.url)), configFile: false, logLevel: 'error', server: { port: 0 } });
  await server.listen();
  base = server.resolvedUrls!.local[0];
  browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
}, 60000);

afterAll(async () => {
  await browser?.close();
  await server?.close();
});

type Dlg = { log: string[]; portraits: string[]; show(v: DialogueView, ...then: DialogueView[]): void; hide(): void; typing(): boolean };

async function open(query = '', viewport = { width: 360, height: 800 }, reducedMotion: 'reduce' | 'no-preference' = 'no-preference'): Promise<Page> {
  const page = await browser.newPage({ viewport, hasTouch: true, reducedMotion });
  await page.goto(`${base}?${query}`);
  await page.waitForFunction(() => '__dlg' in window);
  return page;
}
const show = (page: Page, ...views: DialogueView[]) =>
  page.evaluate((vs) => (window as unknown as { __dlg: Dlg }).__dlg.show(vs[0], ...vs.slice(1)), views);
/** Calls the game got, without the talking blips */
const log = (page: Page) => page.evaluate(() => (window as unknown as { __dlg: Dlg }).__dlg.log.filter((x) => x !== 'blip'));
const typing = (page: Page) => page.evaluate(() => (window as unknown as { __dlg: Dlg }).__dlg.typing());
const typed = (page: Page) => page.evaluate(() => document.querySelector('#gp-dialog .gp-typed')!.textContent);
/** Past the 250 ms guard after a line appears or completes */
const settle = (page: Page) => page.waitForTimeout(320);

const MIRA = { id: 'mira', name: 'Mira', color: '#7a2a8a' };
const LONG = 'The kettle has been bubbling since dawn, and nobody in the village remembers who lit the fire under it.';
const CHOICES = [
  { id: 'a', text: 'Ask Mira about the kettle and its fire' },
  { id: 'b', text: 'Stir the kettle three times, just in case' },
  { id: 'c', text: 'Leave it and go back to the shop for now' },
];

describe('mountDialogue', () => {
  it('types the line; a tap completes it at once, and the next tap goes on', async () => {
    const page = await open();
    await show(page, { speaker: MIRA, text: LONG });
    await page.waitForTimeout(150);
    expect(await typing(page)).toBe(true);
    expect((await typed(page))!.length).toBeLessThan(LONG.length);
    await page.tap('#gp-dialog .gp-text');
    expect(await typing(page)).toBe(false);
    expect(await typed(page)).toBe(LONG);
    expect(await log(page)).toEqual([]);
    await settle(page);
    await page.tap('#gp-dialog .gp-text');
    expect(await log(page)).toEqual(['next']);
    expect(await page.evaluate(() => (window as unknown as { __dlg: Dlg }).__dlg.log.includes('blip'))).toBe(true);
    await page.close();
  });

  it('types on by itself at typeCps; the full line is laid out from the start, so the buttons don\'t move', async () => {
    const page = await open('cps=100');
    const line = 'Sixty characters or so, typed at one hundred a second, then.';
    await show(page, { speaker: MIRA, text: line });
    await page.waitForTimeout(250); // past the sheet's slide-in
    expect(await typing(page)).toBe(true);
    const before = await page.locator('[data-gp=dialog-next]').boundingBox();
    await page.waitForTimeout(700);
    expect(await typing(page)).toBe(false);
    expect(await typed(page)).toBe(line);
    expect(await page.locator('[data-gp=dialog-next]').boundingBox()).toEqual(before);
    await page.close();
  });

  it('one fast double tap can\'t both complete the line and go on', async () => {
    const page = await open();
    await show(page, { speaker: MIRA, text: LONG });
    await page.tap('[data-gp=dialog-next]');
    await page.tap('[data-gp=dialog-next]');
    expect(await typing(page)).toBe(false);
    expect(await log(page)).toEqual([]);
    await settle(page);
    await page.tap('[data-gp=dialog-next]');
    expect(await log(page)).toEqual(['next']);
    await page.close();
  });

  it('instant lines: a double tap on Next can\'t pick the choice that appears under the finger', async () => {
    const page = await open('cps=0');
    await show(page, { speaker: MIRA, text: 'Hello.' }, { speaker: MIRA, text: 'Well?', choices: [{ id: 'a', text: 'Yes' }] });
    await settle(page);
    const next = (await page.locator('[data-gp=dialog-next]').boundingBox())!;
    await page.mouse.dblclick(next.x + next.width / 2, next.y + next.height / 2);
    await page.touchscreen.tap(next.x + next.width / 2, next.y + next.height / 2);
    expect(await log(page)).toEqual(['next']);
    expect(await page.locator('[data-gp=dialog-choice]').count()).toBe(1);
    await settle(page);
    await page.tap('[data-gp=dialog-choice][data-gp-choice=a]');
    expect(await log(page)).toEqual(['next', 'choose:a']);
    await page.close();
  });

  for (const vp of [{ width: 360, height: 800 }, { width: 800, height: 360 }, { width: 1280, height: 720 }])
    it(`three choices fit ${vp.width}×${vp.height}: on screen, ≥ 48 px, text ≥ 12 px (the line ≥ 16 px), the game still visible, hostile CSS loses`, async () => {
      const page = await open('portrait=1', vp);
      await show(page, { speaker: MIRA, mood: 'curious', text: LONG, choices: CHOICES, badge: 'Chapter 1 · The Bubbling Kettle', id: 'c1-l3' });
      await page.tap('#gp-dialog .gp-text');
      const r = await page.evaluate(() => {
        const sheet = document.getElementById('gp-dialog')!;
        const buttons = [...sheet.querySelectorAll<HTMLElement>('button')].filter((b) => !b.hidden);
        const bad = buttons
          .map((b) => ({ t: b.textContent, r: b.getBoundingClientRect(), s: getComputedStyle(b) }))
          .filter((x) => x.r.left < 0 || x.r.top < 0 || x.r.right > innerWidth || x.r.bottom > innerHeight || x.r.height < 48 || x.r.width < 48
            || x.s.backgroundColor === 'rgb(255, 0, 255)' || x.s.textTransform === 'uppercase')
          .map((x) => `${x.t} ${Math.round(x.r.width)}×${Math.round(x.r.height)} @${Math.round(x.r.left)},${Math.round(x.r.top)} ${x.s.backgroundColor}`);
        const small = [...sheet.querySelectorAll<HTMLElement>('*')]
          .filter((e) => e.getClientRects().length && [...e.childNodes].some((n) => n.nodeType === 3 && n.textContent!.trim()))
          .filter((e) => !e.closest('.gp-live') && parseFloat(getComputedStyle(e).fontSize) < 12)
          .map((e) => `${e.className}: ${e.textContent!.trim().slice(0, 16)} ${getComputedStyle(e).fontSize}`);
        const top = Math.min(...[sheet, ...sheet.querySelectorAll<HTMLElement>('.gp-plate, .gp-badge')].map((e) => e.getBoundingClientRect().top));
        return {
          bad,
          small,
          line: parseFloat(getComputedStyle(sheet.querySelector('.gp-typed')!).fontSize),
          cover: (innerHeight - top) / innerHeight,
          sheetRight: sheet.getBoundingClientRect().right,
          overflow: sheet.dataset.gpOverflow,
          next: sheet.querySelectorAll('[data-gp=dialog-next]:not([hidden])').length,
          choices: [...sheet.querySelectorAll<HTMLElement>('[data-gp=dialog-choice]')].map((b) => b.dataset.gpChoice),
        };
      });
      await page.screenshot({ path: `${process.env.DIALOG_SHOTS ?? '/tmp'}/dialog-${vp.width}x${vp.height}.png` });
      expect(r.choices).toEqual(['a', 'b', 'c']);
      expect(r.next).toBe(0);
      expect(r.bad).toEqual([]);
      expect(r.small).toEqual([]);
      expect(r.line).toBeGreaterThanOrEqual(16);
      expect(r.sheetRight).toBeLessThanOrEqual(vp.width);
      expect(r.overflow).toBe('false');
      expect(r.cover).toBeLessThanOrEqual(vp.height < 520 ? 0.45 : 0.5);
      // keys 1–3 choose, once the guard has passed
      await settle(page);
      await page.keyboard.press('2');
      expect(await log(page)).toEqual(['choose:b']);
      await page.close();
    });

  it('keys: Space completes, Enter goes on, 1–3 only for choices that exist, Esc is left to the game', async () => {
    const page = await open();
    await show(page, { speaker: MIRA, text: LONG }, { speaker: null, text: 'Two ways lead out of the village, and both of them are muddy.', choices: CHOICES.slice(0, 2) });
    await page.keyboard.press(' ');
    expect(await typing(page)).toBe(false);
    await page.keyboard.press('Escape');
    await page.keyboard.press('1');
    await settle(page);
    await page.keyboard.press('Enter');
    expect(await log(page)).toEqual(['next']);
    await page.keyboard.press('3'); // there are two choices
    await page.keyboard.press('1'); // still typing: completes the line
    expect(await typing(page)).toBe(false);
    expect(await log(page)).toEqual(['next']);
    await page.keyboard.press('Enter'); // a choice point: Enter doesn't pick one
    await settle(page);
    await page.keyboard.press('1');
    expect(await log(page)).toEqual(['next', 'choose:a']);
    await page.close();
  });

  it('Skip is always there — while typing, on a finished line and at a choice — and always answers', async () => {
    const page = await open();
    const skipOk = () =>
      page.evaluate(() => {
        const s = document.querySelector<HTMLElement>('[data-gp=dialog-skip]')!;
        const r = s.getBoundingClientRect();
        return !s.hidden && r.height >= 48 && r.bottom <= innerHeight && r.top >= 0;
      });
    await show(page, { speaker: MIRA, text: LONG });
    expect(await skipOk()).toBe(true);
    await page.tap('[data-gp=dialog-skip]');
    expect(await log(page)).toEqual(['skip']);
    await page.keyboard.press(' '); // the tap didn't leave focus on Skip: Space completes the line, it doesn't skip again
    expect(await typing(page)).toBe(false);
    expect(await log(page)).toEqual(['skip']);
    expect(await skipOk()).toBe(true);
    await show(page, { speaker: MIRA, text: 'Choose.', choices: CHOICES });
    expect(await skipOk()).toBe(true);
    await page.tap('[data-gp=dialog-skip]');
    expect(await log(page)).toEqual(['skip', 'skip']);
    await page.close();
  });

  it('instant mode (typeCps 0) and prefers-reduced-motion show the whole line at once', async () => {
    for (const page of [await open('cps=0'), await open('', undefined, 'reduce')]) {
      await show(page, { speaker: MIRA, text: LONG });
      expect(await typing(page)).toBe(false);
      expect(await typed(page)).toBe(LONG);
      await page.evaluate(() => document.querySelector<HTMLElement>('#gp-dialog .gp-text')!.click()); // inside the guard: nothing
      expect(await log(page)).toEqual([]);
      await settle(page);
      await page.tap('#gp-dialog .gp-text');
      expect(await log(page)).toEqual(['next']);
      await page.close();
    }
  });

  it('speaker: plate in their colour, portrait drawn with the mood; narrator: italic, no plate, no portrait; aria-live and QA hooks', async () => {
    const page = await open('portrait=1');
    await show(page, { speaker: MIRA, mood: 'happy', text: 'Hi!', id: 'l1' });
    const s = await page.evaluate(() => {
      const d = document.getElementById('gp-dialog')!;
      const plate = d.querySelector<HTMLElement>('.gp-plate')!;
      return {
        plate: plate.textContent, bg: getComputedStyle(plate).backgroundColor, face: !d.querySelector<HTMLElement>('.gp-face')!.hidden,
        speaker: d.dataset.gpSpeaker, line: d.dataset.gpLine, live: d.querySelector('[aria-live=polite]')!.textContent,
      };
    });
    expect(s).toEqual({ plate: 'Mira', bg: 'rgb(122, 42, 138)', face: true, speaker: 'mira', line: 'l1', live: 'Mira: Hi!' });
    expect(await page.evaluate(() => (window as unknown as { __dlg: Dlg }).__dlg.portraits)).toEqual(['mira:happy']);
    await show(page, { speaker: null, text: 'Night falls.' });
    const n = await page.evaluate(() => {
      const d = document.getElementById('gp-dialog')!;
      return {
        plate: d.querySelector<HTMLElement>('.gp-plate')!.getClientRects().length, face: d.querySelector<HTMLElement>('.gp-face')!.getClientRects().length,
        italic: getComputedStyle(d.querySelector('.gp-text')!).fontStyle, speaker: d.dataset.gpSpeaker ?? null, live: d.querySelector('[aria-live=polite]')!.textContent,
      };
    });
    expect(n).toEqual({ plate: 0, face: 0, italic: 'italic', speaker: null, live: 'Night falls.' });
    await page.close();
  });

  it('a disabled choice is shown but can\'t be picked; hide() takes the sheet and its keys away', async () => {
    const page = await open('cps=0');
    await show(page, { speaker: MIRA, text: 'Pay?', choices: [{ id: 'pay', text: 'Pay 50 gold (you have 20)', disabled: true }, { id: 'no', text: 'Not now' }] });
    await settle(page);
    expect(await page.getAttribute('[data-gp-choice=pay]', 'aria-disabled')).toBe('true');
    await page.tap('[data-gp-choice=pay]', { force: true }); // aria-disabled still takes taps: they do nothing
    await page.keyboard.press('1');
    expect(await log(page)).toEqual([]);
    await page.keyboard.press('2');
    expect(await log(page)).toEqual(['choose:no']);
    await page.evaluate(() => (window as unknown as { __dlg: Dlg }).__dlg.hide());
    expect(await page.isVisible('[data-gp=dialog]')).toBe(false);
    await page.keyboard.press('Enter');
    await page.keyboard.press('1');
    expect(await log(page)).toEqual(['choose:no']);
    await page.close();
  });
});
