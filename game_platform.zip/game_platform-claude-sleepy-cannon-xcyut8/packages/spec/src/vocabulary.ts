// Words that are someone else's: names others own (a title must not use them: E_TITLE_GENERIC; a text that a player reads
// should not either: W_TRADEMARK_TEXT) and the signature vocabulary of hits (`gp uniqueness` lowers the score for it).
// Velvet Domino Rogue was rejected for quality with "Mult", "Chips", foil / holographic / polychrome / negative editions
// and seals all over its texts: Balatro's words on a domino game read as a reskin of Balatro (the roguelite survey,
// 2026-10-19). Pure data and string functions: Node reads it.

/** Names others own (use needs the IP holder's licence) — a short list of the ones game makers reach for */
export const PROTECTED_NAMES: readonly string[] = [
  // Only names that are unambiguous in a title (not "uno", "sonic", "marvel": ordinary words too)
  'tetris', 'scrabble', 'monopoly', 'pac-man', 'pacman', 'flappy bird', 'angry birds', 'candy crush', 'minecraft', 'roblox', 'fortnite',
  'among us', 'pokemon', 'pokémon', 'super mario', 'zelda', 'sonic the hedgehog', 'wordle', 'subway surfers', 'geometry dash', 'slither.io', 'agar.io',
  'vampire survivors', 'clash of clans', 'fruit ninja', 'cut the rope', 'temple run', 'stumble guys', 'fall guys', 'bloons', 'lego',
  'barbie', 'disney', 'star wars', 'harry potter', 'hello kitty', 'peppa pig', 'paw patrol',
];

/**
 * Car makers' names: a car game's texts reach for them ("a Ferrari-red coupé"); the brands are trademarks and portals
 * refuse their use without a licence. Only names that are no ordinary word (not Jaguar, Mustang, Beetle, Dodge, Mini,
 * Jeep, Ford, Tesla — a Tesla coil is a weapon)
 */
export const CAR_BRANDS: readonly string[] = [
  'ferrari', 'lamborghini', 'porsche', 'bmw', 'mercedes', 'mercedes-benz', 'audi', 'toyota', 'bugatti', 'mclaren', 'nissan', 'chevrolet',
  'chevy', 'volkswagen', 'aston martin', 'maserati', 'rolls-royce', 'bentley', 'subaru', 'mitsubishi', 'hyundai', 'koenigsegg', 'pagani',
  'alfa romeo', 'land rover', 'range rover', 'lexus', 'cadillac', 'peugeot', 'renault', 'citroën', 'citroen', 'škoda', 'skoda', 'honda',
  'lancia', 'datsun', 'suzuki', 'kawasaki', 'harley-davidson',
];

/** Other brands a game's text must not name (platforms, makers) */
const OTHER_BRANDS: readonly string[] = ['nintendo', 'playstation', 'xbox', 'mojang', 'balatro', 'steam deck', 'coca-cola', "mcdonald's"];

/** Every name W_TRADEMARK_TEXT looks for in the texts a player reads */
export const BRAND_NAMES: readonly string[] = [...new Set([...PROTECTED_NAMES, ...CAR_BRANDS, ...OTHER_BRANDS])];

/** A hit's signature words: one strong term, or WEAK_ENOUGH weak ones, and the texts read like that game */
export interface SignatureVocabulary {
  hit: string;
  /** Terms that are that game's own (Balatro's "Mult", Minecraft's "Creeper") */
  strong: readonly string[];
  /** Words that are ordinary alone and that game's together (chips, joker, blind, seal …) */
  weak: readonly string[];
}

export const SIGNATURE_VOCABULARY: readonly SignatureVocabulary[] = [
  {
    hit: 'Balatro',
    strong: ['mult', 'polychrome', 'boss blind', 'small blind', 'big blind', 'planet card', 'spectral card', 'tarot card', 'gold seal', 'red seal', 'blue seal', 'purple seal', 'chips × mult', 'chips x mult'],
    weak: ['chips', 'joker', 'blind', 'tarot', 'foil', 'holographic', 'negative', 'seal', 'ante', 'edition', 'spectral'],
  },
  {
    hit: 'Vampire Survivors',
    strong: ['king bible', 'runetracer', 'empty tome', 'hollow heart', 'magic wand', 'death spiral', 'unholy vespers', 'bloody tear', 'soul eater', 'heaven sword'],
    weak: ['garlic', 'whip', 'bible', 'clover', 'spinach', 'tome', 'arcana', 'reaper', 'candelabrador', 'evolution'],
  },
  {
    hit: 'Minecraft (Mojang)',
    strong: ['creeper', 'nether', 'ender', 'enderman', 'ender pearl', 'redstone', 'netherite', 'elytra', 'mojang', 'minecraft', 'piglin', 'zombie pigman', 'wither skeleton', 'nether portal'],
    weak: ['obsidian', 'biome', 'villager', 'crafting table', 'wither', 'spawner'],
  },
  { hit: 'Tetris', strong: ['tetromino', 'tetrimino', 'tetris'], weak: [] },
  { hit: 'Pac-Man', strong: ['pac-man', 'pacman', 'power pellet'], weak: [] },
  { hit: 'Among Us', strong: ['emergency meeting', 'crewmate'], weak: ['impostor', 'sus', 'vent'] },
  { hit: 'car brands', strong: CAR_BRANDS, weak: [] },
];

const esc = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
/** A term as a word (or words) of the text: letters or digits may not touch it; a plural -s / -es is the same word */
function termRe(term: string): RegExp {
  return new RegExp(`(?<![\\p{L}\\p{N}])${esc(term).replace(/\s+/g, '\\s+')}(?:s|es)?(?![\\p{L}\\p{N}])`, 'iu');
}
const cache = new Map<string, RegExp>();
const has = (text: string, term: string) => {
  let re = cache.get(term);
  if (!re) cache.set(term, (re = termRe(term)));
  return re.test(text);
};

/** The brand names in a text (lower case, as listed) */
export function brandsIn(text: string): string[] {
  return BRAND_NAMES.filter((n) => has(text, n));
}

/** Weak words of one hit that together read as it (a poker table alone has chips, a blind and a seal: three) */
export const WEAK_ENOUGH = 4;

/** The hits whose signature vocabulary the texts use: one strong term or WEAK_ENOUGH weak ones; each with the words found */
export function borrowedVocabulary(texts: readonly string[]): { hit: string; terms: string[] }[] {
  const all = texts.join('\n');
  const out: { hit: string; terms: string[] }[] = [];
  for (const v of SIGNATURE_VOCABULARY) {
    const strong = v.strong.filter((t) => has(all, t));
    const weak = v.weak.filter((t) => has(all, t));
    if (strong.length || weak.length >= WEAK_ENOUGH) out.push({ hit: v.hit, terms: [...strong, ...weak] });
  }
  return out;
}

/** What `gp uniqueness` takes off for one hit's words: 10, and 5 more for each further term (at most 25) */
export function vocabularyPenalty(terms: number): number {
  return Math.min(25, 10 + 5 * Math.max(0, terms - 1));
}
/** …and for all of them together, at most */
export const VOCABULARY_PENALTY_MAX = 35;
