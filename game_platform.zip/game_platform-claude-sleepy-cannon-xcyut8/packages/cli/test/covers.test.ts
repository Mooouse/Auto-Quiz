// gp covers refuses a page that shows the player's can't-run screen (Kettlebot: a TDZ error in coverFrame gave a ✓)

import { describe, expect, it } from 'vitest';
import { coverProblem } from '../src/covers.ts';

describe('coverProblem', () => {
  it('passes a page that shows the game', () => {
    expect(coverProblem('landscape', false, [])).toBeNull();
  });
  it('fails the can\'t-run screen and names the error', () => {
    const p = coverProblem('landscape', true, ["Cannot access 'LANES' before initialization"]);
    expect(p).toContain("can't run");
    expect(p).toContain('LANES');
  });
});
