// Sameness across the account: the look of a screen (colour histogram + layout edge map), the thresholds, the brief.

import { describe, expect, it } from 'vitest';
import { CLOSE, LOOK_H, LOOK_W, VERY_CLOSE, closeness, compareLooks, lookFeatures, lookSimilarity, samenessSection, type OtherShot } from '../src/sameness.ts';

/** A LOOK_W×LOOK_H picture: a background colour and rectangles on it */
function picture(bg: [number, number, number], rects: { x: number; y: number; w: number; h: number; c: [number, number, number] }[] = []): number[] {
  const px: number[] = [];
  for (let y = 0; y < LOOK_H; y++)
    for (let x = 0; x < LOOK_W; x++) {
      const r = rects.find((q) => x >= q.x && x < q.x + q.w && y >= q.y && y < q.y + q.h);
      px.push(...(r?.c ?? bg), 255);
    }
  return px;
}
const navy: [number, number, number] = [20, 26, 40];
/** The platform's stock language sheet: a slate panel of 3×4 buttons, centred, one yellow */
const sheet = (bg: [number, number, number]) =>
  picture(bg, [
    { x: 16, y: 10, w: 32, h: 18, c: [30, 42, 56] },
    ...[0, 1, 2].flatMap((col) => [0, 1, 2].map((row) => ({ x: 18 + col * 10, y: 13 + row * 5, w: 8, h: 3, c: (col === 0 && row === 0 ? [255, 210, 110] : [44, 60, 78]) as [number, number, number] }))),
  ]);

describe('the look of a screen', () => {
  it('features: a 64-bin histogram that sums to 1 and a 16×9 edge map', () => {
    const f = lookFeatures(sheet(navy));
    expect(f.hist).toHaveLength(64);
    expect(f.hist.reduce((s, x) => s + x, 0)).toBeCloseTo(1);
    expect(f.edges).toHaveLength(16 * 9);
  });

  it('the stock sheet over two games\' backdrops is very close; another layout or palette is not', () => {
    const a = lookFeatures(sheet(navy));
    const b = lookFeatures(sheet([28, 22, 36]));
    expect(lookSimilarity(a, a)).toEqual({ colour: 1, layout: 1 });
    expect(closeness(lookSimilarity(a, b))).toBe('very close');
    // The game's own title: warm, a big logo on the left, a character on the right
    const own = lookFeatures(picture([200, 120, 60], [{ x: 4, y: 4, w: 30, h: 8, c: [255, 240, 200] }, { x: 44, y: 10, w: 14, h: 22, c: [40, 160, 90] }]));
    expect(closeness(lookSimilarity(a, own))).toBeNull();
    // The same colours, the panel moved and reshaped: the layout tells them apart
    const moved = lookFeatures(picture(navy, [{ x: 2, y: 24, w: 60, h: 10, c: [30, 42, 56] }, { x: 4, y: 26, w: 8, h: 3, c: [255, 210, 110] }]));
    expect(lookSimilarity(a, moved).layout).toBeLessThan(VERY_CLOSE.layout);
    // Flat pictures: the same layout as each other, none like a laid-out one
    expect(lookSimilarity(lookFeatures(picture(navy)), lookFeatures(picture([0, 0, 0]))).layout).toBe(1);
    expect(lookSimilarity(lookFeatures(picture(navy)), a).layout).toBe(0);
  });

  it('the thresholds, from the calibration on our previews (2026-10-19)', () => {
    expect(VERY_CLOSE).toEqual({ colour: 0.85, layout: 0.85 });
    expect(CLOSE).toEqual({ colour: 0.7, layout: 0.7 });
    // The stock language sheet, pair by pair across 17 games: 0.98–1.00 on both
    expect(closeness({ colour: 0.98, layout: 0.98 })).toBe('very close');
    // The two closest different titles (Firefly Rush, Starsilk: centred dark menus, their own art): close, no warning
    expect(closeness({ colour: 0.82, layout: 0.8 })).toBe('close');
    expect(closeness({ colour: 0.94, layout: 0.79 })).toBe('close');
    // Two titles at the 90th percentile, and a dark game against another dark game laid out differently
    expect(closeness({ colour: 0.44, layout: 0.44 })).toBeNull();
    expect(closeness({ colour: 0.95, layout: 0.4 })).toBeNull();
  });
});

describe('the comparison and the brief', () => {
  const shot = (game: string, screen: OtherShot['screen']): OtherShot => ({ game, title: game.toUpperCase(), screen, file: `/looks/${game}-${screen}.png`, source: 'previews abc1234' });
  it('the closest per screen, every very close pair, and the row of titles closest first', () => {
    const others = [
      { shot: shot('kettlebot', 'language'), look: lookFeatures(sheet([10, 30, 40])) },
      { shot: shot('kettlebot', 'title'), look: lookFeatures(picture([0, 0, 0], [{ x: 20, y: 5, w: 24, h: 6, c: [90, 200, 220] }])) },
      { shot: shot('starsilk', 'title'), look: lookFeatures(picture(navy, [{ x: 16, y: 10, w: 32, h: 18, c: [30, 42, 56] }])) },
    ];
    const own = [
      { screen: 'title' as const, file: '/qa/title.png', look: lookFeatures(picture([200, 120, 60], [{ x: 4, y: 4, w: 30, h: 8, c: [255, 240, 200] }])) },
      { screen: 'language' as const, file: '/qa/lang.png', look: lookFeatures(sheet(navy)) },
    ];
    const c = compareLooks(own, others);
    expect(c.closest.map((m) => [m.screen, m.other.game, m.other.screen])).toEqual([
      ['title', expect.any(String), expect.any(String)],
      ['language', 'kettlebot', 'language'],
    ]);
    expect(c.veryClose.map((m) => `${m.screen}≈${m.other.game}:${m.other.screen}`)[0]).toBe('language≈kettlebot:language');
    expect(c.veryClose.every((m) => m.screen === 'language')).toBe(true);
    expect(c.row.map((r) => r.other.game)).toEqual(['starsilk', 'kettlebot']);
    const md = samenessSection({ screens: own, compared: 3, games: 2, ...c, problems: [] }).join('\n');
    expect(md).toMatch(/Compared with 3 shots of 2 other games/);
    expect(md).toMatch(/\*\*⚠ Very close to another of our games\*\*.*this game's language ≈ KETTLEBOT's language/);
    expect(md).toMatch(/\[blocking\]/);
    expect(samenessSection({ screens: [], compared: 0, games: 0, closest: [], veryClose: [], row: [], problems: [] }).join('\n')).toMatch(/Not compared/);
  });
});
