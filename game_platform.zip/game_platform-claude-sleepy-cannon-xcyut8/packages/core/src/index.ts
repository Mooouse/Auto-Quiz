// @gp/core — the genre-neutral runtime every game on the platform runs on.

export { App, type AppOptions, type Flow, type RoundResult } from './app';
export type { Scene, ProbeTarget } from './scene';
export { EventBus, type GameEvent, type GameEventType } from './events';
export { rng, seedRandom, seededRng, Bag, type SeededRng } from './rng';
export { newRunSeed, runSeedFrom, runSeedOf, dailyRunSeed, normalizeSeedText, seedLabel, copySeed, seedField, type RunSeed } from './seed';
export { loadSave, writeSave, loadJson, mergeShape, CORE_SAVE_DEFAULTS, type CoreSave, type GameSave, type SaveData, type SaveValue, type KeyValueStore } from './save';
export { GameAudio, type AudioSettings } from './audio';
export * from './draw';
export * from './layout';
export type { Theme, ThemeUi } from './theme';
export { AdManager, REWARDED_INPUT_WINDOW_SEC, shouldShowAd, createAdProvider, type AdPolicy, type AdState, type AdProvider, type AdHooks, type AdMobConfig, type AdsOptions } from './ads';
export { createBilling, type BillingProvider, type BillingOptions, type PurchaseResult } from './billing';
export { isNative, openExternal, keepAwake, minimizeApp } from './native';
export { createPortal, deferPortal, PORTAL_SOFT_WAIT_MS, type DeferredPortal, type Portal, type PortalId } from './portal';
export { GameHost, FUNNEL_STEPS, type FunnelStep, type HostOptions, type PauseReason, type QaDriver, type CanvasUiRect, type CoverArt, type CoverLayout, type CoverRect, type CoverTitleStyle, type CoverVariant, type GameContext, type GameInfo, type StartGame } from './host';
export { showNotice } from './notice';
export { MoveInput, type MoveInputOptions, type InputHost } from './input';
export { TwinStick, LookInput, type TwinStickOptions, type TwinStickButton, type TwinStickHost } from './twin-stick';
export { aimAssist, type AimOptions, type AimResult, type AimCandidate } from './aim';
import * as steerModule from './steer';
/** 2D steering for enemies (also `@gp/core/steer`): seek, arrive, pursue, separation, avoid, slot, flank, integrate */
export const steer = steerModule;
export { BossPatterns, type BossAttackDef, type BossAttack, type BossPhase, type BossState, type BossEvent, type BossOptions, type Spawn } from './boss';
export { callouts, type Callouts, type CalloutsOptions, type CalloutDef, type CalloutLine, type CalloutRank } from './callouts';
export { QualityLadder, deviceTier, gpuRenderer, isSoftwareGpu, startLevel, qualityPin, type QualityOptions, type DeviceTier, type DeviceInfo } from './quality';
export { loadStars, levelOpen, firstOpenLevel, totalStars, recordStars, starsFromPar, starsFromShare, type StarCount, type StarsRecord } from './levels';
export { UndoHistory } from './undo';
export { Zones, type ZonesDef, type ZonesState, type ZoneDraw, type ZonePlace, type MarketDef } from './zones';
export {
  Board,
  polyomino,
  orient,
  orientPos,
  orientations,
  posKey,
  keyPos,
  POLYOMINOES,
  SQUARE_DIRS,
  SQUARE_DIAGONALS,
  HEX_DIRS,
  OFF as BOARD_OFF,
  type BoardDef,
  type BoardState,
  type Piece,
  type Pos,
  type XY,
  type GridKind,
  type ShapeDef,
  type Oriented,
  type CellView,
  type Pattern,
  type PatternMatch,
  type PlaceProblem,
} from './board';
export { Dice, slotRules, sumIs, oddsOf, sumOdds, D6, EXACT_ODDS_MAX, type Die, type DiceState, type Face, type SlotDef, type SlotRule } from './dice';
export { Automa, best, AUTOMA_MAX_WORDS, type AutomaRule, type AutomaLevel, type AutomaOptions, type AutomaState, type Intent } from './automa';
export { dayKey, daySeed, loadDaily, recordDaily, dailyDone, recordVisit, DAILY_KEEP, type DailyLog, type Visit, type VisitLog } from './daily';
export { hints, HINT_MAX_WORDS, type Hints, type HintsOptions, type HintShowOptions } from './hints';
export { mountResults, goalFromSnapshot, type ResultsGoal, type ResultsOptions, type ResultsScreen } from './results-ui';
export { welcomeBack, type WelcomeBackOptions } from './welcome';
export { dailyStreak, dailyOrder, loadStreak, loadOrder, type DailyStreak, type StreakLog, type StreakOptions, type StreakState, type StreakDot, type DailyOrder, type OrderGoal, type OrderLog, type OrderOptions, type OrderState, type SaveHolder } from './streak';
export { mountStreakCard, streakTexts, type StreakCardOptions, type StreakTexts } from './streak-ui';
export { seasonPass, weeklyEvent, weekKey, daysBetween, checkSeasons, loadSeason, loadWeek, type SeasonPass, type SeasonDef, type SeasonOptions, type SeasonState, type SeasonTier, type SeasonClaim, type SeasonGain, type SeasonLog, type WeeklyEvent, type WeeklyOptions, type WeeklyState, type WeekLog } from './season';
export { mountSeasonTrack, seasonTexts, seasonMark, type SeasonTrackOptions, type SeasonTexts, type SeasonRewardView } from './season-ui';
export { worldClock, durationMs, formatClock, clockShift, checkSchedule, type WorldClock, type WorldClockOptions, type Duration, type ClockSlot, type ClockEventDef, type ClockOccurrence, type Schedule, type ScheduleState, type Weather, type WeatherOptions, type WeatherStateDef, type WeatherSpan, type WeatherNow } from './clock';
export { restockShop, loadRestock, type RestockShop, type RestockOptions, type RestockState, type RestockLog, type StockDef, type StockOffer } from './restock';
export { mountRestockTimer, type RestockTimer, type RestockTimerOptions } from './restock-ui';
export { LootTable, loadLoot, formatOdds, type LootTier, type LootItem, type LootSource, type LootOptions, type LootOdds, type LootRoll, type LootLog, type RollOptions } from './loot';
export { variants, type Variants, type VariantDef, type VariantsOptions, type VariantItem } from './variants';
export { dailyTable, loadTable, shareText, drawShareCard, type DailyTable, type DailyTableOptions, type DailySetup, type ScoreBand, type BandResult, type TableLog, type TableRecord, type ShareCard, type ShareCardStyle } from './daily-table';
export { shareCode, type ShareCodec, type ShareCodeOptions, type ShareDecode, type ShareLayout, type ShareShape } from './share';
export { rivals, rivalNameProblem, type Rivals, type RivalsOptions, type RivalDef, type Rival, type BoardEntry } from './rivals';
export { dailyQuests, achievements, dayShuffle, checkQuests, loadQuests, loadAchievements, RARITIES, type Rarity, type DailyQuests, type QuestDef, type QuestLog, type QuestsOptions, type QuestRow, type QuestClaim, type QuestsState, type Achievements, type AchievementDef, type AchievementLog, type AchievementsOptions, type AchievementRow, type AchievementsState } from './goals';
export { mountGoals, goalBanners, goalsTexts, type GoalsOptions, type GoalsScreen, type GoalsTexts, type GoalClaim, type GoalRewardView, type GoalBanner, type GoalBanners, type GoalBannersOptions } from './goals-ui';
export { coachHand, coachPoint, type CoachHand, type CoachHandOptions, type CoachGesture, type CoachPoint } from './coach';
export { inspect, type Inspector, type InspectInfo, type InspectOptions } from './inspect';
export { collection, loadCollection, type Collection, type CollectionEntry, type CollectionGroup, type CollectionLog, type CollectionOptions, type CollectionCell, type CollectionRow, type CollectionGroupState, type CollectionState } from './collection';
export { mountAlbum, albumTexts, type AlbumOptions, type AlbumScreen, type AlbumTexts } from './album-ui';
export { playtimeGifts, luckyWheel, dailyOffers, timedBoost, loadGifts, loadWheel, loadOffers, loadBoost, type PlaytimeGifts, type GiftDef, type GiftLog, type GiftsOptions, type GiftRow, type GiftsState, type LuckyWheel, type WheelSlice, type WheelLog, type WheelOptions, type WheelState, type SpinKind, type DailyOffers, type OfferDef, type OfferLog, type OffersOptions, type OfferRow, type OffersState, type TimedBoost, type BoostLog, type BoostOptions } from './rewards';
export { mountRewardsHub, rewardsTexts, sliceColor, type RewardsHub, type RewardsHubOptions, type RewardsTexts, type RewardView, type RewardSource } from './rewards-ui';
export { cards, cardQueue, cardOpened, cardOnScreen, anyModalOpen, type CardQueue, type CardHandle, type CardOfferOptions } from './cards';
export type { UiIcon } from './ui-kit';
export { offlineEarnings, stampOffline, loadOffline, measuringOffline, inOfflineMeasure, OFFLINE_GENRES, type OfflineLog, type OfflineOptions, type OfflinePay } from './offline';
export { Prestige, prestigeModel, PRESTIGE_GENRES, type PrestigeSave, type PrestigeOptions, type PrestigeLife } from './prestige';
export { readingSec, readableText, READING_CPS, NOTICE_SEC, MAX_READING_SEC } from './reading';
export { mountUpgradeShop, shopBadge, markSeen, shopTexts, SHOP_TEXTS_EN, type ShopItemText, type ShopIcon, type ShopTexts, type ShopUiOptions } from './shop-ui';
export { rewardedButton, rewardedOffer, type RewardedButtonOptions, type RewardedOffer, type RewardedOfferOptions } from './rewarded-button';
export { screenTheme, screenThemeVars, screenThemeCss, SCREEN_THEME_VARS, type ScreenTheme } from './screen-theme';
export { icon, iconSvg, iconUrl, drawIcon, ICONS, ICON_NAMES, type IconName, type IconDef, type IconOptions } from './icons';
export { screenIcon, DEFAULT_CURRENCY, type ScreenIcon } from './screen-icon';
export { ScoreSequencer, previewScore, tallySteps, landSize, beatTimes, drawScoreLabels, BEAT, ROLL, PITCH, LAND_HOLD, type ScoreStep, type ScoreTally, type ScoreBase, type ScoreLabel, type ScoreSequencerOptions, type StepEvent, type LandEvent, type PlayOptions } from './sequencer';
export {
  createI18n,
  detectLanguage,
  matchLanguage,
  languageInfo,
  formatNumber,
  pluralCategories,
  byLanguage,
  mergeStrings,
  checkStrings,
  charsetOf,
  LANGUAGES,
  LANGUAGE_CODES,
  TOP_LANGUAGES,
  BASE_LANGUAGE,
  FONT_FALLBACK,
  type I18n,
  type I18nOptions,
  type Strings,
  type LanguageStrings,
  type StringTable,
  type StringValue,
  type PluralForms,
  type PluralCategory,
  type Params,
  type LanguageInfo,
  type FlagId,
} from './i18n';
export { PLATFORM_STRINGS } from './i18n-platform';
export { languagePicker, openLanguageSheet, flagSvg, type LanguagePickerOptions } from './lang-picker';
export { signInButton, autoSignIn, type SignInHost } from './sign-in';
export { mountDialogue, type DialogueView, type DialogueSpeaker, type DialogueChoice, type DialogueOptions, type DialogueUi } from './dialogue-ui';
export { UpgradeShop, formatAmount, type UpgradeDef, type Levels, type UpgradeState, type BuyAmount, type ShopRow } from './upgrades';
export { Sites, SITES_GENRES, type SiteDef, type SiteSave, type SitesSave, type SingleSiteSave, type SiteState, type SiteRow, type SitesOffline, type SitesOptions } from './sites';
export {
  mountSitesMap,
  MapCamera,
  layoutMapPins,
  MAP_PIN_EDGE,
  type MapPinBox,
  type MapPinPlace,
  sitesMapTexts,
  SITES_MAP_TEXTS_EN,
  type MapPoint,
  type MapCameraOptions,
  type MapCameraInfo,
  type SitesMap,
  type SitesMapItem,
  type SitesMapOptions,
  type SitesMapTexts,
  type SitesMapView,
} from './sites-map';
export {
  Roster,
  Tiers,
  PactTree,
  RunChoices,
  countsOf,
  type Rand,
  type RosterEntry,
  type RosterSave,
  type RosterState,
  type RosterRow,
  type RosterOptions,
  type TierDef,
  type TierView,
  type TiersOptions,
  type Mods,
  type PactDef,
  type PactSide,
  type PactSave,
  type PactState,
  type PactRow,
  type PactTreeOptions,
  type RunChoiceDef,
  type ChoicesState,
  type RunChoicesOptions,
} from './progression';
export {
  evaluateBalance, balanceTargets, meanCurve, offerLog, choiceLog, pickRates, buildCore, buildDiversity, skillSummary, stageStats, winningRunMin, decisionsMarkdown, pickRatesCsv, BALANCE_TARGETS, BOT_SKILLS,
  type BalanceReport, type OfferStage, type BuyerCurve, type BalanceTargets, type BalanceRow, type BalanceStatus, type BalanceVerdict, type BalanceDesignInput,
  type BotSkill, type BotRun, type SkillRuns, type SkillSummary, type StagePlay, type StageStat, type DifficultyTarget, type ChoiceRecord, type PickRate,
} from './balance';
export {
  solveModel, walkModel, runAt, winChance, fitWinCurve, compareToBot, curve, modelMarkdown, modelCsv, modelFromCampaign, MODEL_TARGETS,
  type BalanceModel, type ModelStage, type ModelItem, type ModelResult, type ModelRun, type ModelTargets, type ModelShape, type ModelRunRow, type ModelRunShape,
  type CampaignLog, type CampaignStage, type CampaignBuy, type FromCampaignOptions,
} from './balance-model';
export { createMixer, createMusic, createSceneMusic, createAmbience, musicTheme, bossTheme, compose, midiOf, SCALES, LAYERS, PLACES, SCENES as MUSIC_SCENES, STAGES as MUSIC_STAGES, SCENE_LAYERS, DEFAULT_VOLUMES, type Mixer, type Music, type SceneMusic, type SceneMusicOptions, type MusicScene, type MusicStage, type SceneLayer, type LayerLevel, type Ambience, type MusicTheme, type Mood, type Layer, type Bus, type Volumes, type SoundHost, type Note as MusicNote } from './sound';
export {
  StoryRunner,
  loadStory,
  storyState,
  dueScene,
  nextChapter,
  storyProgress,
  commitScene,
  validateStory,
  parseLine,
  parseCondition,
  formatStoryPath,
  storyStrings,
  storyText,
  barkText,
  lineKey,
  choiceKey,
  barkKey,
  NARRATOR,
  STORY_LIMITS,
  type StoryI18n,
  type Story,
  type StoryDef,
  type SceneDef,
  type Line,
  type LineDef,
  type ChoiceDef,
  type CastMember,
  type Effects,
  type Moment,
  type Progress,
  type StoryValue,
  type StoryState,
  type StoryLine,
  type StoryChoice,
  type SceneResult,
  type StoryIssue,
  type StoryLimits,
} from './story';
