// A ready dialogue sheet for games with a story (docs/research/story-2026-09.md §3.4), generalized from Brew & Banter's
// dialog (QmaCyber/game5). It shows one line at a time from a simple view model, so it works with StoryRunner or a
// game's own engine: the game calls show(view) and moves its engine on in onNext / onChoose / onSkip.
// What it gets right:
// - a bottom sheet that leaves the game visible: full width on a tall phone, ≤ 45% of a phone on its side;
// - a name plate in the speaker's colour, an optional portrait slot; the narrator (speaker: null) is italic, no plate;
// - a typewriter where the first tap (Enter, Space) shows the whole line and the next one goes on; the line's full
//   text is laid out from the start, so nothing moves under the finger while it types;
// - 1–3 choices as real buttons ≥ minTouchPx, keys 1–3; a Next button when there are no choices;
// - Skip always there (it can't be configured away): the game decides what it skips to;
// - a guard: for 250 ms after a line appears or completes, taps are ignored, so one fast double tap can't both finish
//   the line and go on, or land on a choice that appeared under the finger;
// - prefers-reduced-motion (or typeCps 0) shows lines at once; the full line goes to an aria-live region at once;
// - every rule is scoped under #gp-dialog (a game's `#ui button { … }` can't override it); no ad-like class names;
// - QA hooks: data-gp="dialog" (+ data-gp-speaker, data-gp-line, data-gp-overflow), "dialog-next", "dialog-skip",
//   "dialog-choice" with data-gp-choice="<id>". Esc is left to the game (pause).


import { cardOpened } from './cards.ts';
import { FONT_FALLBACK, type I18n } from './i18n.ts';

export interface DialogueSpeaker {
  id: string;
  name: string;
  /** The name plate's colour (CSS colour; white text on it) */
  color?: string;
}

export interface DialogueChoice {
  id: string;
  text: string;
  /** Shown but can't be picked (say why in the text: "Pay 50 gold (you have 20)") */
  disabled?: boolean;
}

export interface DialogueView {
  /** null: the narrator (italic, no name plate, no portrait) */
  speaker: DialogueSpeaker | null;
  mood?: string;
  text: string;
  /** 1–3 choices; none: the line has a Next button */
  choices?: DialogueChoice[];
  /** The line's id, for QA (data-gp-line) */
  id?: string;
  /** A small badge on the sheet ("Chapter 1 · The Bubbling Kettle") */
  badge?: string;
}

export interface DialogueOptions {
  /** The audience's smallest touch target (host.minTouchPx) */
  minTouchPx: number;
  /** Draw the speaker into the portrait slot (56–64 px square). The slot is kept between lines: reuse what you put
   *  there. Without this option there is no portrait. */
  portrait?(el: HTMLElement, speakerId: string, mood: string | undefined): void;
  /** Typewriter speed in characters per second; default 40; 0 = instant (prefers-reduced-motion is always instant) */
  typeCps?: number;
  /** A talking sound, called every few typed characters (play it through host audio) */
  blip?(speakerId: string | null): void;
  /** The buttons' words; default: the platform's, in the player's language when `i18n` is given (else English) */
  skipLabel?: string;
  nextLabel?: string;
  /** host.i18n: Skip / Next in the player's language, kept in step when the player switches */
  i18n?: I18n;
  /** The line is read and has no choices: show the next one (or hide) */
  onNext(): void;
  onChoose(id: string): void;
  /** The player pressed Skip */
  onSkip(): void;
}

export interface DialogueUi {
  show(view: DialogueView): void;
  hide(): void;
  destroy(): void;
  /** The typewriter is still revealing the line */
  readonly typing: boolean;
  readonly visible: boolean;
}

/** Taps within this time after a line appears or completes are ignored (Brew & Banter used 150 ms after each step) */
const GUARD_MS = 250;

// Every rule starts at #gp-dialog; buttons also carry a class, so `#gp-dialog button.gp-btn` (1,1,1) beats a game's
// `#ui button` (1,0,1) wherever the style tags are.
const CSS = `
#gp-dialog { --gp-dlg-bg: var(--gp-theme-bg, #fff8ec); --gp-dlg-ink: var(--gp-theme-ink, #2b1d10); --gp-dlg-muted: var(--gp-theme-muted, #6b5a48);
  --gp-dlg-edge: var(--gp-theme-edge, #8a5a3a); --gp-dlg-btn: var(--gp-theme-panel, #ffffff); --gp-dlg-accent: var(--gp-theme-accent, #2b1d10);
  --gp-dlg-accent-ink: var(--gp-theme-accent-ink, #fff8ec); --gp-dlg-speaker: var(--gp-theme-edge, #8a5a3a);
  --gp-dlg-radius: var(--gp-theme-radius, 18px); --gp-dlg-font: var(--gp-theme-font, ${FONT_FALLBACK});
  position: fixed; left: 0; right: 0; bottom: max(6px, env(safe-area-inset-bottom)); margin: 0 auto; z-index: 20;
  width: min(720px, calc(100vw - 12px)); box-sizing: border-box; pointer-events: auto; touch-action: manipulation;
  display: flex; flex-direction: column; gap: 8px; padding: 18px 12px 10px; text-align: left; user-select: none;
  -webkit-user-select: none; -webkit-tap-highlight-color: transparent;
  color: var(--gp-dlg-ink); background: var(--gp-dlg-bg); border: 3px solid var(--gp-dlg-edge); border-radius: var(--gp-dlg-radius);
  box-shadow: 0 8px 28px #0008; font: 600 15px var(--gp-dlg-font); }
#gp-dialog[hidden], #gp-dialog [hidden] { display: none !important; }
#gp-dialog .gp-row, #gp-dialog .gp-actions, #gp-dialog .gp-face, #gp-dialog .gp-live { font-size: 15px; }
#gp-dialog .gp-typed, #gp-dialog .gp-rest, #gp-dialog .gp-label { font: inherit; }
#gp-dialog .gp-plate { position: absolute; top: -14px; left: 14px; max-width: calc(100% - 28px); overflow: hidden;
  text-overflow: ellipsis; white-space: nowrap; background: var(--gp-dlg-speaker); color: #fff; font-size: 14px; font-weight: 800;
  line-height: 1.2; padding: 4px 12px; border-radius: 9px; box-shadow: 0 2px 0 #0003; }
#gp-dialog .gp-badge { position: absolute; top: -12px; right: 14px; max-width: 45%; overflow: hidden; text-overflow: ellipsis;
  white-space: nowrap; background: var(--gp-dlg-ink); color: var(--gp-dlg-bg); font-size: 12px; font-weight: 700;
  padding: 3px 9px; border-radius: 8px; }
#gp-dialog.gp-has-plate .gp-badge { max-width: 40%; }
#gp-dialog .gp-row { display: flex; gap: 10px; align-items: flex-start; min-height: 0; }
#gp-dialog .gp-face { font-size: 36px; line-height: 58px; text-align: center; flex: none; width: 64px; height: 64px; border-radius: 50%; overflow: hidden; margin-top: -6px;
  border: 3px solid var(--gp-dlg-speaker); box-sizing: border-box; background: #fff; }
#gp-dialog .gp-face > canvas, #gp-dialog .gp-face > img, #gp-dialog .gp-face > svg { width: 100%; height: 100%; display: block; }
#gp-dialog .gp-text { flex: 1; min-width: 0; font: 500 17px/1.35 var(--gp-dlg-font);
  max-height: calc(1.35em * 5); overflow-y: auto; overflow-wrap: anywhere; }
#gp-dialog.gp-narrator .gp-text { font-style: italic; color: var(--gp-dlg-muted); }
#gp-dialog .gp-rest { visibility: hidden; }
#gp-dialog .gp-live { position: absolute; width: 1px; height: 1px; overflow: hidden; clip-path: inset(50%); white-space: nowrap; }
#gp-dialog .gp-actions { display: flex; flex-wrap: wrap; gap: 6px; align-items: stretch; }
#gp-dialog button.gp-btn { font: 700 15px/1.2 var(--gp-dlg-font); border: 0; border-radius: 14px;
  cursor: pointer; touch-action: manipulation; min-width: 0; width: auto; height: auto; margin: 0; padding: 4px 14px;
  box-shadow: none; text-transform: none; letter-spacing: normal; text-align: center; opacity: 1; filter: none;
  display: flex; align-items: center; justify-content: center; gap: 6px; color: var(--gp-dlg-ink); background: var(--gp-dlg-btn); }
#gp-dialog button.gp-choice { flex: 1 1 100%; justify-content: flex-start; text-align: left; box-shadow: inset 0 0 0 2px var(--gp-dlg-edge); }
#gp-dialog button.gp-choice[aria-disabled=true] { color: var(--gp-dlg-muted); box-shadow: inset 0 0 0 2px #d8cfc2; cursor: default; }
#gp-dialog button.gp-next { order: 2; margin-left: auto; background: var(--gp-dlg-accent); color: var(--gp-dlg-accent-ink); padding: 4px 22px; }
#gp-dialog button.gp-skip { order: 1; background: transparent; color: var(--gp-dlg-muted); font-size: 14px; text-decoration: underline; padding: 4px 10px; }
#gp-dialog .gp-key { display: none; font-size: 12px; font-weight: 800; border-radius: 6px; padding: 2px 6px; background: #0000001a; flex: none; }
#gp-dialog.gp-waiting button.gp-choice { opacity: 0.75; }
@media (hover: hover) and (pointer: fine) { #gp-dialog .gp-key { display: inline-block; } }
/* Wide screens: choices side by side, Skip first in the row */
@media (min-aspect-ratio: 5/4) {
  #gp-dialog button.gp-choice { flex: 1 1 0; }
  #gp-dialog button.gp-skip { order: -1; }
}
/* A phone on its side: a compact sheet, ≤ 45% of the height (three lines of text and one row of buttons) */
@media (min-aspect-ratio: 5/4) and (max-height: 520px) {
  #gp-dialog { bottom: max(4px, env(safe-area-inset-bottom)); padding: 14px 10px 6px; gap: 5px; border-width: 2px; }
  #gp-dialog .gp-text { font-size: 16px; line-height: 1.3; max-height: calc(1.3em * 3); }
  #gp-dialog .gp-face { width: 52px; height: 52px; margin-top: -8px; font-size: 30px; line-height: 46px; }
  #gp-dialog .gp-plate { top: -13px; font-size: 13px; padding: 3px 10px; }
  #gp-dialog button.gp-btn { font-size: 14px; }
}
@media (prefers-reduced-motion: no-preference) {
  #gp-dialog:not([hidden]) { animation: gp-dlg-in 0.18s ease-out; }
}
@keyframes gp-dlg-in { from { transform: translateY(12px); opacity: 0; } }
`;

function el<K extends keyof HTMLElementTagNameMap>(tag: K, cls?: string, text?: string): HTMLElementTagNameMap[K] {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text !== undefined) e.textContent = text;
  return e;
}

/** Mount the dialogue sheet into `root` (hidden until show()). It sits fixed at the bottom of the screen. */
export function mountDialogue(root: HTMLElement, opts: DialogueOptions): DialogueUi {
  if (!document.getElementById('gp-dialog-css')) {
    const style = el('style');
    style.id = 'gp-dialog-css';
    style.textContent = CSS;
    document.head.append(style);
  }
  const min = `${opts.minTouchPx}px`;
  const box = el('section');
  box.id = 'gp-dialog';
  box.dataset.gp = 'dialog';
  const word = (key: string, en: string) => (opts.i18n ? opts.i18n.t(key) : en);
  box.setAttribute('aria-label', word('gp.dialog.label', 'Dialogue'));
  box.hidden = true;
  const plate = el('div', 'gp-plate');
  const badge = el('div', 'gp-badge');
  const row = el('div', 'gp-row');
  const face = el('div', 'gp-face');
  face.setAttribute('aria-hidden', 'true');
  const text = el('div', 'gp-text');
  text.setAttribute('aria-hidden', 'true'); // the typed text changes every frame: screen readers get .gp-live instead
  text.dataset.gpScroll = 'a story line'; // a long line may scroll inside the box (gp qa: only messages may scroll)
  const typed = el('span', 'gp-typed');
  const rest = el('span', 'gp-rest');
  text.append(typed, rest);
  const live = el('div', 'gp-live');
  live.setAttribute('aria-live', 'polite');
  row.append(face, text);
  const actions = el('div', 'gp-actions');
  const skip = el('button', 'gp-btn gp-skip', opts.skipLabel ?? word('gp.dialog.skip', 'Skip'));
  skip.type = 'button';
  skip.dataset.gp = 'dialog-skip';
  const next = el('button', 'gp-btn gp-next', opts.nextLabel ?? word('gp.dialog.next', 'Next'));
  next.type = 'button';
  next.dataset.gp = 'dialog-next';
  for (const b of [skip, next]) b.style.minHeight = min;
  next.style.minWidth = `${opts.minTouchPx * 2}px`;
  skip.style.minWidth = min;
  box.append(plate, badge, row, live, actions);
  root.append(box);

  let view: DialogueView | null = null;
  let chars: string[] = [];
  let shown = 0;
  let cps = 0;
  let raf = 0;
  let last = 0;
  let armedAt = 0;
  let choiceButtons: HTMLButtonElement[] = [];
  const reduced = typeof matchMedia === 'function' ? matchMedia('(prefers-reduced-motion: reduce)') : null;

  const now = () => performance.now();
  const typing = () => view !== null && shown < chars.length;

  function paint(): void {
    const n = Math.floor(shown);
    typed.textContent = chars.slice(0, n).join('');
    rest.textContent = chars.slice(n).join('');
    box.classList.toggle('gp-waiting', typing());
  }

  function complete(): void {
    cancelAnimationFrame(raf);
    raf = 0;
    shown = chars.length;
    armedAt = now() + GUARD_MS;
    paint();
  }

  function frame(t: number): void {
    raf = 0;
    if (!view || box.hidden) return;
    const dt = Math.min(0.1, Math.max(0, (t - last) / 1000)); // a hidden tab doesn't type on in the background
    last = t;
    const before = Math.floor(shown);
    shown = Math.min(chars.length, shown + dt * cps);
    const after = Math.floor(shown);
    if (after !== before) {
      if (opts.blip && Math.floor(after / 3) !== Math.floor(before / 3) && chars[after - 1]?.trim()) opts.blip(view.speaker?.id ?? null);
      if (after >= chars.length) return complete();
      paint();
    }
    raf = requestAnimationFrame(frame);
  }

  /** A tap on the sheet, Next, Enter or Space: finish the line, or go on */
  function advance(): void {
    if (!view) return;
    if (typing()) return complete();
    if (now() < armedAt || view.choices?.length) return;
    armedAt = Infinity; // until the game shows the next line: no second onNext from the same line
    opts.onNext();
  }

  function choose(i: number): void {
    if (!view) return;
    if (typing()) return complete();
    const c = view.choices?.[i];
    if (!c || c.disabled || now() < armedAt) return;
    armedAt = Infinity;
    opts.onChoose(c.id);
  }

  /** On screen as a card (cards.ts): the one-card queue waits until the scene is over */
  let closed: (() => void) | null = null;
  function show(v: DialogueView): void {
    view = v;
    const s = v.speaker;
    box.hidden = false;
    closed ??= cardOpened('story', box);
    box.classList.toggle('gp-narrator', !s);
    box.classList.toggle('gp-has-plate', !!s?.name);
    if (s?.color) box.style.setProperty('--gp-dlg-speaker', s.color);
    else box.style.removeProperty('--gp-dlg-speaker');
    plate.textContent = s?.name ?? '';
    plate.hidden = !s?.name;
    badge.textContent = v.badge ?? '';
    badge.hidden = !v.badge;
    face.hidden = !s || !opts.portrait;
    if (s && opts.portrait) opts.portrait(face, s.id, v.mood);
    if (s) box.dataset.gpSpeaker = s.id;
    else delete box.dataset.gpSpeaker;
    if (v.id) box.dataset.gpLine = v.id;
    else delete box.dataset.gpLine;
    live.textContent = s?.name ? `${s.name}: ${v.text}` : v.text;

    choiceButtons = (v.choices ?? []).slice(0, 3).map((c, i) => {
      const b = el('button', 'gp-btn gp-choice');
      b.type = 'button';
      b.dataset.gp = 'dialog-choice';
      b.dataset.gpChoice = c.id;
      b.dataset.index = String(i);
      b.style.minHeight = min;
      if (c.disabled) b.setAttribute('aria-disabled', 'true');
      const key = el('span', 'gp-key', String(i + 1));
      key.setAttribute('aria-hidden', 'true');
      b.append(key, el('span', 'gp-label', c.text));
      return b;
    });
    next.hidden = choiceButtons.length > 0;
    actions.replaceChildren(...choiceButtons, skip, next);

    chars = Array.from(v.text);
    cps = reduced?.matches ? 0 : (opts.typeCps ?? 40);
    shown = cps > 0 ? 0 : chars.length;
    armedAt = now() + GUARD_MS;
    paint();
    box.dataset.gpOverflow = String(text.scrollHeight > text.clientHeight + 1);
    cancelAnimationFrame(raf);
    raf = 0;
    if (typing()) {
      last = now();
      raf = requestAnimationFrame(frame);
    }
  }

  function hide(): void {
    cancelAnimationFrame(raf);
    raf = 0;
    view = null;
    box.hidden = true;
    closed?.();
    closed = null;
  }

  box.addEventListener('click', (e) => {
    const b = (e.target as HTMLElement).closest('button');
    // A tap or click doesn't leave focus on the button: Space and Enter then go on instead of pressing it again
    if (b && e.detail > 0) b.blur();
    if (b === skip) return opts.onSkip();
    if (b?.dataset.gp === 'dialog-choice') return choose(Number(b.dataset.index));
    advance(); // Next, or anywhere else on the sheet
  });

  const onKey = (e: KeyboardEvent) => {
    if (!view || box.hidden || e.repeat || e.ctrlKey || e.metaKey || e.altKey) return;
    const target = e.target as HTMLElement | null;
    if (target?.closest('input, textarea, select, [contenteditable=true]')) return; // typing into a field is not for us
    const n = Number(e.key);
    if (Number.isInteger(n) && n >= 1 && n <= choiceButtons.length) {
      e.preventDefault();
      choose(n - 1);
    } else if ((e.key === 'Enter' || e.key === ' ') && !target?.closest('button')) {
      // (a button focused with Tab takes Enter and Space itself)
      e.preventDefault();
      advance();
    }
  };
  window.addEventListener('keydown', onKey);
  // The player switched the language (a picker on the pause screen): the buttons follow; the line is the game's to re-show
  const offLang = opts.i18n?.onChange(() => {
    if (!opts.skipLabel) skip.textContent = word('gp.dialog.skip', 'Skip');
    if (!opts.nextLabel) next.textContent = word('gp.dialog.next', 'Next');
    box.setAttribute('aria-label', word('gp.dialog.label', 'Dialogue'));
  });

  return {
    show,
    hide,
    destroy() {
      hide();
      window.removeEventListener('keydown', onKey);
      offLang?.();
      box.remove();
    },
    get typing() {
      return typing();
    },
    get visible() {
      return !box.hidden;
    },
  };
}
