// Documentation must not lie: every full game.yaml example in the docs and every game is valid.

import { existsSync, readdirSync, readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import { validateText } from '../src/index.ts';

const root = new URL('../../../', import.meta.url);
const read = (p: string) => readFileSync(new URL(p, root), 'utf8');

const files = [
  ...readdirSync(new URL('docs/examples/', root)).filter((f) => f.endsWith('.yaml')).map((f) => `docs/examples/${f}`),
  // examples with their own folder: docs/examples/<name>/game.yaml (kids: Balloon Pop; code; art)
  ...readdirSync(new URL('docs/examples/', root), { withFileTypes: true })
    .filter((d) => d.isDirectory() && readdirSync(new URL(`docs/examples/${d.name}/`, root)).includes('game.yaml'))
    .map((d) => `docs/examples/${d.name}/game.yaml`),
  // a `gp new` game inside the platform (games/ is made on demand: the platform ships none of its own)
  ...(existsSync(new URL('games/', root)) ? readdirSync(new URL('games/', root)).map((g) => `games/${g}/game.yaml`) : []),
];

/** ```yaml blocks in markdown that are whole games (start with `spec: 0`) */
const blocks = ['AGENTS.md', 'docs/tutorial.md', 'README.md', 'docs/guides/code-games.md'].flatMap((f) =>
  [...read(f).matchAll(/```yaml\n([\s\S]*?)```/g)].map((m) => m[1]).filter((y) => /^spec: 0/m.test(y)).map((y, i) => [`${f} #${i + 1}`, y] as const),
);

describe('docs examples', () => {
  it.each(files)('%s is valid', (f) => {
    const r = validateText(read(f), { mode: 'dev' });
    expect(r.issues.filter((i) => i.severity === 'error')).toEqual([]);
  });
  it('there are markdown game examples to check', () => expect(blocks.length).toBeGreaterThan(0));
  it.each(blocks)('%s is valid', (_f, y) => {
    const r = validateText(y, { mode: 'dev' });
    expect(r.issues.filter((i) => i.severity === 'error')).toEqual([]);
  });
});
