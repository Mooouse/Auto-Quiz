// Share codes: a small snapshot of a run, a build, a den or a lineup packed into a short code a player copies, sends and
// a friend types back — a visit, a ghost race or a raid on a copy, by real players, without a server (Clash attacks a
// snapshot of a base; docs/research/roblox-2026-10.md P9, §3). Versioned (an old code still reads after an update) and
// checksummed with the game's salt (a typo, or a code of another game, is refused, not misread). Bit-packed by a layout
// the game declares, in the same forgiving alphabet as run seeds (no I, L, O, U; O reads as 0, I and L as 1).
//
//   const DEN = shareCode({
//     salt: 'raccoon-rummage', version: 2,
//     fields: { tree: { type: 'int', min: 0, max: 15 }, shelf: { type: 'list', max: 8, of: { type: 'enum', values: TREASURES } },
//               lock: { type: 'bool' } },
//     older: { 1: { tree: { type: 'int', min: 0, max: 7 }, shelf: { type: 'list', max: 6, of: { type: 'enum', values: TREASURES_V1 } } } },
//     upgrade: (old, v) => ({ lock: false, ...old }),         // a v1 code read by v2
//   });
//   const code = DEN.encode({ tree: 5, shelf: ['bottlecap', 'spoon'], lock: true });   // 'R2K8-M1QA-7C'
//   const r = DEN.decode(input);       // { ok: true, value, version } | { ok: false, reason: 'format' | 'checksum' | 'version' }
//   DEN.url(value, location.href);     // '…#share=R2K8M1QA7C'; DEN.fromUrl(location.href) reads it back
//
// What goes in a code: numbers, choices from the game's own lists, yes/no — never free text (no names, no chat:
// nothing to moderate). Show where a visited snapshot came from ("a friend's den, from a code"), and that the owner
// loses nothing (it is a copy). The checksum is not a secret: a code can be made by hand, so a code never pays out
// more than the game would give for playing (a visit, a race), and a raid on it takes nothing from anyone.

import { normalizeSeedText } from './seed.ts';

/** One field of a layout */
export type ShareShape =
  | { type: 'int'; min: number; max: number }
  | { type: 'enum'; values: readonly (string | number)[] }
  | { type: 'bool' }
  | { type: 'list'; max: number; of: ShareShape }
  | { type: 'object'; fields: Readonly<Record<string, ShareShape>> };

/** A layout: the fields in order (the order of the keys is the layout — add fields only in a new version) */
export type ShareLayout = Readonly<Record<string, ShareShape>>;

export interface ShareCodeOptions<T> {
  /** The game's id: a code of another game fails its checksum */
  salt: string;
  /** This layout's version, 1 … 31 */
  version: number;
  fields: ShareLayout;
  /** Earlier layouts by version: their codes still decode */
  older?: Readonly<Record<number, ShareLayout>>;
  /** An earlier version's value made into today's (default: as it is) */
  upgrade?: (value: Record<string, unknown>, version: number) => T;
}

export type ShareDecode<T> = { ok: true; value: T; version: number } | { ok: false; reason: 'format' | 'checksum' | 'version' };

export interface ShareCodec<T> {
  /** The code of a value (groups of four with dashes); throws when a value is outside the layout */
  encode(value: T): string;
  /** A typed or pasted code back into a value (forgiving: case, spaces, dashes, O/0, I/L/1) */
  decode(text: string): ShareDecode<T>;
  /** The page's address with the code in its hash: `#share=CODE` */
  url(value: T, base: string): string;
  /** The code from an address's hash (`#share=…`), decoded; null when it has none */
  fromUrl(href: string): ShareDecode<T> | null;
  /** The bits a layout takes (the code is ⌈(bits + 15) / 5⌉ characters) */
  readonly bits: number;
}

const ALPHABET = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
const CHECK_BITS = 10;
const VERSION_BITS = 5;

const widthOf = (n: number) => (n <= 1 ? 0 : Math.ceil(Math.log2(n)));

/** The most bits a shape can take (a list at its max length) */
function maxBits(s: ShareShape): number {
  switch (s.type) {
    case 'int':
      return widthOf(s.max - s.min + 1);
    case 'enum':
      return widthOf(s.values.length);
    case 'bool':
      return 1;
    case 'list':
      return widthOf(s.max + 1) + s.max * maxBits(s.of);
    case 'object':
      return Object.values(s.fields).reduce((a, f) => a + maxBits(f), 0);
  }
}

function checkShape(s: ShareShape, path: string): void {
  if (s.type === 'int' && !(Number.isInteger(s.min) && Number.isInteger(s.max) && s.max >= s.min && s.max - s.min < 2 ** 32))
    throw new Error(`shareCode: ${path}: an int needs whole min ≤ max (a range under 2^32)`);
  if (s.type === 'enum' && (!s.values.length || new Set(s.values).size !== s.values.length)) throw new Error(`shareCode: ${path}: an enum needs distinct values`);
  if (s.type === 'list') {
    if (!(Number.isInteger(s.max) && s.max >= 0 && s.max <= 255)) throw new Error(`shareCode: ${path}: a list's max is 0 … 255`);
    checkShape(s.of, `${path}[]`);
  }
  if (s.type === 'object') for (const [k, f] of Object.entries(s.fields)) checkShape(f, `${path}.${k}`);
}

function write(bits: number[], s: ShareShape, v: unknown, path: string): void {
  const put = (n: number, w: number) => {
    for (let i = w - 1; i >= 0; i--) bits.push(Math.floor(n / 2 ** i) % 2);
  };
  switch (s.type) {
    case 'int': {
      if (typeof v !== 'number' || !Number.isInteger(v) || v < s.min || v > s.max) throw new Error(`shareCode: ${path} is ${JSON.stringify(v)}, not a whole number ${s.min} … ${s.max}`);
      put(v - s.min, widthOf(s.max - s.min + 1));
      return;
    }
    case 'enum': {
      const i = s.values.indexOf(v as string | number);
      if (i < 0) throw new Error(`shareCode: ${path} is ${JSON.stringify(v)}, not one of the layout's values`);
      put(i, widthOf(s.values.length));
      return;
    }
    case 'bool':
      if (typeof v !== 'boolean') throw new Error(`shareCode: ${path} is not true or false`);
      bits.push(v ? 1 : 0);
      return;
    case 'list': {
      if (!Array.isArray(v) || v.length > s.max) throw new Error(`shareCode: ${path} is not a list of at most ${s.max}`);
      put(v.length, widthOf(s.max + 1));
      v.forEach((x, i) => write(bits, s.of, x, `${path}[${i}]`));
      return;
    }
    case 'object': {
      const o = (v && typeof v === 'object' ? v : null) as Record<string, unknown> | null;
      if (!o) throw new Error(`shareCode: ${path} is not an object`);
      for (const [k, f] of Object.entries(s.fields)) write(bits, f, o[k], path ? `${path}.${k}` : k);
    }
  }
}

function read(bits: number[], at: { i: number }, s: ShareShape): unknown {
  const get = (w: number) => {
    let n = 0;
    for (let k = 0; k < w; k++) {
      if (at.i >= bits.length) throw new Error('short');
      n = n * 2 + bits[at.i++];
    }
    return n;
  };
  switch (s.type) {
    case 'int': {
      const n = s.min + get(widthOf(s.max - s.min + 1));
      if (n > s.max) throw new Error('range');
      return n;
    }
    case 'enum': {
      const i = get(widthOf(s.values.length));
      if (i >= s.values.length) throw new Error('range');
      return s.values[i];
    }
    case 'bool':
      return get(1) === 1;
    case 'list': {
      const n = get(widthOf(s.max + 1));
      if (n > s.max) throw new Error('range');
      return Array.from({ length: n }, () => read(bits, at, s.of));
    }
    case 'object': {
      const o: Record<string, unknown> = {};
      for (const [k, f] of Object.entries(s.fields)) o[k] = read(bits, at, f);
      return o;
    }
  }
}

/** FNV-1a over the salt, the version and the payload bits: CHECK_BITS of it */
function checksum(salt: string, version: number, bits: number[]): number {
  let h = 0x811c9dc5;
  const feed = (c: number) => {
    h ^= c;
    h = Math.imul(h, 0x01000193) >>> 0;
  };
  for (const ch of `${salt}#${version}#`) feed(ch.charCodeAt(0));
  for (let i = 0; i < bits.length; i += 8) {
    let b = 0;
    for (let k = 0; k < 8; k++) b = b * 2 + (bits[i + k] ?? 0);
    feed(b);
  }
  feed(bits.length & 0xff);
  return (h ^ (h >>> 16)) & ((1 << CHECK_BITS) - 1);
}

const group = (s: string) => s.match(/.{1,4}/g)!.join('-');

/** A codec for one game's snapshots: see the module's comment */
export function shareCode<T extends Record<string, unknown>>(opts: ShareCodeOptions<T>): ShareCodec<T> {
  if (!opts.salt) throw new Error('shareCode: salt (the game id) is required');
  if (!(Number.isInteger(opts.version) && opts.version >= 1 && opts.version <= 31)) throw new Error('shareCode: version is 1 … 31');
  const layouts = new Map<number, ShareShape>([[opts.version, { type: 'object', fields: opts.fields }]]);
  for (const [v, f] of Object.entries(opts.older ?? {})) {
    const n = Number(v);
    if (!(Number.isInteger(n) && n >= 1 && n < opts.version)) throw new Error(`shareCode: an older layout's version ${v} is not below ${opts.version}`);
    layouts.set(n, { type: 'object', fields: f });
  }
  for (const [v, s] of layouts) checkShape(s, `v${v}`);
  const current = layouts.get(opts.version)!;

  const encode = (value: T): string => {
    const payload: number[] = [];
    write(payload, current, value, '');
    const bits: number[] = [];
    for (let i = VERSION_BITS - 1; i >= 0; i--) bits.push((opts.version >> i) & 1);
    bits.push(...payload);
    const c = checksum(opts.salt, opts.version, payload);
    for (let i = CHECK_BITS - 1; i >= 0; i--) bits.push((c >> i) & 1);
    // Zero bits fill the last character (decode accepts only those after the checksum)
    while (bits.length % 5) bits.push(0);
    let s = '';
    for (let i = 0; i < bits.length; i += 5) s += ALPHABET[bits[i] * 16 + bits[i + 1] * 8 + bits[i + 2] * 4 + bits[i + 3] * 2 + bits[i + 4]];
    return group(s);
  };

  const decode = (text: string): ShareDecode<T> => {
    const s = normalizeSeedText(text);
    if (s.length < 3 || [...s].some((c) => !ALPHABET.includes(c))) return { ok: false, reason: 'format' };
    const bits: number[] = [];
    for (const c of s) {
      const n = ALPHABET.indexOf(c);
      for (let i = 4; i >= 0; i--) bits.push((n >> i) & 1);
    }
    let version = 0;
    for (let i = 0; i < VERSION_BITS; i++) version = version * 2 + bits[i];
    const layout = layouts.get(version);
    if (!layout) return { ok: false, reason: version > opts.version ? 'version' : 'format' };
    let value: unknown;
    const at = { i: VERSION_BITS };
    try {
      value = read(bits, at, layout);
    } catch {
      return { ok: false, reason: 'format' };
    }
    const payload = bits.slice(VERSION_BITS, at.i);
    if (at.i + CHECK_BITS > bits.length) return { ok: false, reason: 'format' };
    let c = 0;
    for (let i = 0; i < CHECK_BITS; i++) c = c * 2 + bits[at.i + i];
    // Only zero padding may follow, less than a character of it
    const rest = bits.slice(at.i + CHECK_BITS);
    if (rest.length >= 5 || rest.some((b) => b)) return { ok: false, reason: 'format' };
    if (c !== checksum(opts.salt, version, payload)) return { ok: false, reason: 'checksum' };
    const out = version === opts.version ? (value as T) : opts.upgrade ? opts.upgrade(value as Record<string, unknown>, version) : (value as T);
    return { ok: true, value: out, version };
  };

  return {
    encode,
    decode,
    bits: VERSION_BITS + maxBits(current) + CHECK_BITS,
    url(value, base) {
      const u = new URL(base);
      u.hash = `share=${encode(value).replace(/-/g, '')}`;
      return u.toString();
    },
    fromUrl(href) {
      const m = /[#&]share=([0-9A-Za-z-]+)/.exec(href);
      return m ? decode(m[1]) : null;
    },
  };
}
