// Android: generate the Capacitor project from the resolved game and sync the web build into it.
// Gradle (needs the Android SDK) runs in CI: .github/workflows/android.yml.

import { spawnSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { THEME_METAS } from '@gp/blocks/meta';
import { CHANNELS, type ResolvedGame } from '@gp/spec';
import { checkManifest, generateAndroidProject } from '@gp/android';
import { ROOT, type GameLocation } from './paths.ts';

export function buildAndroid(loc: GameLocation, game: ResolvedGame): string {
  if (game.channel.platform !== 'android') throw new Error(`channel ${game.channel.id} is not an Android channel`);
  const background = THEME_METAS[game.theme as keyof typeof THEME_METAS]?.background ?? '#ffffff';
  const dir = generateAndroidProject({ game, gameDir: loc.dir, background });
  const cap = join(ROOT, 'node_modules/@capacitor/cli/bin/capacitor');
  const r = spawnSync(process.execPath, [cap, 'sync', 'android'], { cwd: loc.dir, stdio: 'inherit' });
  if (r.status !== 0) throw new Error('cap sync android failed');
  return dir;
}

/** Returns a list of problems (empty = fine) */
export function checkAndroidManifest(game: ResolvedGame, manifestPath: string): { report: string; problems: string[] } {
  const ch = CHANNELS[game.channel.id];
  if (!ch.androidPermissions) return { report: `channel ${ch.id} has no Android permission allowlist`, problems: [] };
  const r = checkManifest(readFileSync(manifestPath, 'utf8'), ch.androidPermissions, game.appId, ch.minTargetSdk ?? 0);
  const report = [`Permissions (${r.permissions.length}):`, ...r.permissions.map((p) => `  ${r.forbidden.includes(p) ? '✗' : '✓'} ${p}`), `targetSdkVersion: ${r.targetSdk ?? '(not in the merged manifest)'}`].join('\n');
  return { report, problems: r.problems };
}
