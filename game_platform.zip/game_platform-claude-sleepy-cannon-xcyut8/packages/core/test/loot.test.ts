import { describe, expect, it } from 'vitest';
import { formatOdds, loadLoot, LootTable } from '../src/loot.ts';
import { seededRng } from '../src/rng.ts';

const TIERS = [
  { id: 'common', weight: 60 },
  { id: 'rare', weight: 30 },
  { id: 'epic', weight: 9 },
  { id: 'mythic', weight: 1 },
] as const;
type Tier = (typeof TIERS)[number]['id'];
const ITEMS = [
  { id: 'moss-fox', tier: 'common' as Tier },
  { id: 'reed-cat', tier: 'common' as Tier, weight: 3 },
  { id: 'glow-owl', tier: 'rare' as Tier },
  { id: 'ember-hare', tier: 'epic' as Tier },
  { id: 'star-whale', tier: 'mythic' as Tier },
];

describe('LootTable', () => {
  it('odds are the shares of the weights, and the very numbers roll() uses', () => {
    const t = new LootTable<Tier>({}, 'eggs', { tiers: TIERS, items: ITEMS, rng: seededRng(1) });
    expect(t.odds('meadow').map((o) => [o.tier, o.chance, o.oneIn])).toEqual([
      ['common', 0.6, 2],
      ['rare', 0.3, 3],
      ['epic', 0.09, 11],
      ['mythic', 0.01, 100],
    ]);
    expect(t.oddsText('meadow')).toBe('Common 60% · Rare 30% · Epic 9% · Mythic 1 in 100');
    const n: Record<string, number> = {};
    for (let i = 0; i < 20000; i++) {
      const tier = t.roll('meadow').tier;
      n[tier] = (n[tier] ?? 0) + 1;
    }
    expect(n.common / 20000).toBeGreaterThan(0.56);
    expect(n.common / 20000).toBeLessThan(0.64);
    expect(n.mythic / 20000).toBeGreaterThan(0.004);
  });

  it('seeded: the same rng, the same rolls; items by their weight inside the tier; first only once', () => {
    const roll = () => {
      const t = new LootTable<Tier>({}, 'eggs', { tiers: TIERS, items: ITEMS, rng: seededRng(42) });
      return Array.from({ length: 30 }, () => t.roll('meadow').id);
    };
    expect(roll()).toEqual(roll());
    const t = new LootTable<Tier>({}, 'eggs', { tiers: TIERS, items: ITEMS, rng: seededRng(7) });
    const firsts = new Map<string, number>();
    for (let i = 0; i < 300; i++) {
      const r = t.roll('meadow');
      if (r.first) firsts.set(r.id, (firsts.get(r.id) ?? 0) + 1);
    }
    for (const v of firsts.values()) expect(v).toBe(1);
    const commons = Array.from({ length: 2000 }, () => t.roll('meadow', { floor: 'common' })).filter((r) => r.tier === 'common');
    const cats = commons.filter((r) => r.id === 'reed-cat').length / commons.length;
    expect(cats).toBeGreaterThan(0.68);
    expect(cats).toBeLessThan(0.82);
  });

  it('the pity: the within-th roll without epic or better is one; the odds say so before it', () => {
    // An rng that always gives the commonest outcome: the pity is the only way up
    const save: Record<string, unknown> = {};
    const t = new LootTable<Tier>(save, 'eggs', { tiers: TIERS, rng: () => 0, pity: { tier: 'epic', within: 5 } });
    for (let i = 0; i < 4; i++) {
      const r = t.roll('meadow');
      expect(r.tier).toBe('common');
      expect(r.pityLeft).toBe(4 - i);
    }
    const due = t.odds('meadow');
    expect(due.find((o) => o.tier === 'common')!.chance).toBe(0);
    expect(due.find((o) => o.tier === 'epic')!.chance).toBeCloseTo(0.9);
    const r = t.roll('meadow');
    expect(r).toMatchObject({ tier: 'epic', pity: true, pityLeft: 5 });
    expect(save.eggs).toMatchObject({ dry: { meadow: 0 }, rolls: { meadow: 5 } });
    // Per source
    expect(t.pityLeft('storm')).toBe(5);
  });

  it('a floor (the rewarded lucky roll) and luck only raise the better tiers', () => {
    const t = new LootTable<Tier>({}, 'eggs', { tiers: TIERS, rng: seededRng(3) });
    const floor = t.odds('m', { floor: 'rare' });
    expect(floor[0].chance).toBe(0);
    expect(floor[1].chance).toBeCloseTo(0.75);
    for (let i = 0; i < 200; i++) expect(t.roll('m', { floor: 'rare' }).tier).not.toBe('common');
    const lucky = t.odds('m', { luck: 2 });
    expect(lucky[0].chance).toBeLessThan(0.6);
    expect(lucky[3].chance).toBeGreaterThan(0.01);
    expect(t.odds('m', { luck: 0.5 })[0].chance).toBe(0.6); // bad luck is no luck: never lowers
  });

  it('per-source tables; the expected shares with the pity (a bot reads them)', () => {
    const t = new LootTable<Tier>({}, 'eggs', {
      tiers: TIERS,
      sources: { storm: { weights: { rare: 70, epic: 25, mythic: 5 } } },
      pity: { tier: 'epic', within: 10 },
      rng: seededRng(9),
    });
    expect(t.odds('storm')[0].chance).toBe(0);
    expect(t.odds('storm')[3].chance).toBeCloseTo(0.05);
    const e = t.expected('meadow');
    // Without the pity epic+ is 10 %; with a guarantee every 10th dry roll it is a bit more
    const epicUp = e[2].chance + e[3].chance;
    expect(epicUp).toBeGreaterThan(0.1);
    expect(epicUp).toBeLessThan(0.16);
    expect(e.reduce((a, o) => a + o.chance, 0)).toBeCloseTo(1);
  });

  it('formats odds as people read them; refuses tables that make no sense', () => {
    expect(formatOdds(0.3)).toBe('30%');
    expect(formatOdds(0.025)).toBe('2.5%');
    expect(formatOdds(1 / 250)).toBe('1 in 250');
    expect(formatOdds(1 / 3_200_000)).toBe('1 in 3.2M');
    expect(formatOdds(0)).toBe('0%');
    expect(loadLoot({ dry: { a: 2, b: -1 }, seen: ['x', 'x', 3] })).toEqual({ dry: { a: 2 }, rolls: {}, seen: ['x'] });
    expect(() => new LootTable({}, 'l', { tiers: [], rng: Math.random })).toThrow(/tiers/);
    expect(() => new LootTable({}, 'l', { tiers: TIERS, items: [{ id: 'x', tier: 'gold' as Tier }], rng: Math.random })).toThrow(/unknown tier/);
    expect(() => new LootTable<Tier>({}, 'l', { tiers: TIERS, pity: { tier: 'epic', within: 0 }, rng: Math.random })).toThrow(/within/);
  });
});
