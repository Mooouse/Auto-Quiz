# A dice-board roguelite (from Rogue Legend's mechanics) — 2026-10-15

The owner: «Сможешь повторить игру — Rogue legends?» → «копировать оттуда механики, а нарисовать самим?» → «Давай».
The mechanics are borrowed; the art, names, texts, screens and the twist are our own (AGENTS.md §2 rule 3; CrazyGames
rejected Petri Panic and Kite Royale as "quite close to existing titles").

## What Rogue Legend is (App Store id6754965520, Google Play com.pockethaven.roguelegend, PocketHaven Games)

- **Core loop:** a run from the lobby; roll a die, the hero walks a board; the tile decides — enemy (an automatic fight,
  then pick 1 of 3 upgrades), buff, debuff, a luck minigame, a shop (gold → gear, legendary items); bosses mark progress.
- **Meta:** talents (a talent road, affinity skill trees), pets that fight beside you, a hero collection (level, ascend,
  swap per board), mounts, gear with auto-merge, worlds (Rogue Island, Heliora), events (raid boss, Magma, Chaos Realm),
  guilds; idle growth between runs.
- **Money:** free, 10 IAP packs $0.99–34.99, ad removal, VIP, rewarded ads, loot boxes, energy.
- **Players:** 4.9★ from 6.9K (iOS), #17 in Adventure; "extremely addictive", "unique and engaging"; complaints: pay walls
  in later chapters, energy, wants more tilesets and enemy types. 1.1 GB, 13 languages.
- The same loop on mobile also: Heroll: Dice Roguelike (Percent).

## The portal (search 2026-10-15, crazygames.com closed to this session: web search)

- No roll-to-move board roguelite with auto-battles found on CrazyGames.
- Closest: **TableTop Idle (Remastered)** (a clicker on a Monopoly-like board, a roll moves the pawn, energy per roll),
  **Die in the Dungeon** (dice deck-building, turn-based roguelite, no board), Ludo / Snakes and Ladders (board, no RPG).

## Three twists, forecast (`gp forecast --idea --channel crazygames --session 15 --breaks 4 --rewarded revive,x2`)

| | The twist (what the 3 closest games don't do) | genre | expected, months 1–3 | top lever |
|---|---|---|---|---|
| **A** | **Forge your die:** after every boss you rewrite one face (6 + fire, 2 + heal, back 1 + loot) — you choose where you can land, the board becomes a puzzle you build towards | strategy | €8.7 (€12 with a daily seed) | D1: a daily seed board |
| **B** | **Two dice, one choice:** each turn two dice — one moves, the other powers the fight where you land; a long move or a strong fight, never both | strategy | €8.7 (€12 with a daily seed) | D1: a daily seed board |
| **C** | Rogue Legend's loop + an idle camp that earns while you are away | idle | €9.9 (€14 with a daily seed) | D1: a daily seed board |

The model scores genre and design, not the twist: A, B and C come out close. C is the closest to Rogue Legend and the
weakest at the portal's originality gate. **Recommended: A with C's camp as the meta and a daily seed board**:
the forged die is visible in the first minute (QA's twist check), it is a build the player makes per run (what the owner
liked in Candle Crypt, Swarm Smash, Spin Brawl), the camp and the daily board are the reason to return
(Garage's 1.2.0 answered the same metrics).

Not done yet: the owner's choice; a game chat (`gp init`) — after his go.
