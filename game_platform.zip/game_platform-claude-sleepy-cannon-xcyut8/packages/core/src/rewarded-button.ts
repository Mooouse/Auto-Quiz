// A ready "watch an ad for a reward" button for games with their own screens (kit: code).
// What it gets right (each one broke a real game on CrazyGames; QmaCyber/game2 and game4):
// - it exists only while rewarded ads can be shown (`host.rewardedAvailable`): after one fails — no fill, an ad blocker,
//   Basic Launch, where CrazyGames monetization is off — the next screens offer none;
// - a failed ad says so on the button and leaves the player's other choices as they were: it never ends the run;
// - one tap, one ad: disabled while the ad runs (a double click gets one ad and one reward);
// - no ad-like class names: ad blockers hide `.ad-btn`, `.ads` … (Petri Panic's revive button vanished that way);
// - `data-gp-rewarded` for `gp qa`.

import type { GameHost } from './host.ts';
import type { I18n } from './i18n.ts';
import { icon } from './icons.ts';
import { screenIcon, type ScreenIcon } from './screen-icon.ts';

export interface RewardedButtonOptions {
  /** The host: its i18n says "No ad available right now" in the player's language */
  host: Pick<GameHost, 'rewarded' | 'rewardedAvailable'> & { readonly i18n?: I18n };
  /** Where it is offered ("continue", "double-coins"): for analytics and QA */
  placement: string;
  /**
   * Say what the player gets: "Continue", "×2 coins" — the ad is implied by the icon (a drawn play mark before the
   * words; a leading "▶" in the label becomes that mark) or a line nearby
   */
  label: string;
  /** The mark before the words (default a drawn play triangle: @gp/core/icons): another icon, or false for none */
  icon?: ScreenIcon | false;
  /** The ad was watched to the end: give the reward now */
  onReward(): void;
  /** Shown on the button when no ad could be shown (default: the platform's words, gp.noAd) */
  unavailable?: string;
  /** The game's own classes for the look (never ad-like: `bonus`, `reward`, not `ad-btn`) */
  className?: string;
  /** Optional: no ad could be shown (the button already says so): give the player's other choices back */
  onUnavailable?(): void;
}

/** The button, or null when no rewarded ad can be offered now: then the screen simply goes without it */
export function rewardedButton(opts: RewardedButtonOptions): HTMLButtonElement | null {
  if (!opts.host.rewardedAvailable) return null;
  const b = document.createElement('button');
  b.type = 'button';
  // A "▶" typed into the label is the ad's mark: drawn instead (the same on every system), never twice
  const label = opts.label.replace(/^\s*[▶►▸⯈]\uFE0F?\s*/u, '');
  const mark = opts.icon === false ? null : opts.icon !== undefined ? screenIcon(opts.icon) : icon('play', { style: 'solid', size: '0.95em' });
  if (mark) {
    if (mark instanceof Element) mark.classList.add('gp-rewarded-mark');
    b.append(mark, document.createTextNode(`\u00a0${label}`));
  } else b.textContent = label;
  b.dataset.gpRewarded = opts.placement;
  if (opts.className) b.className = opts.className;
  if (import.meta.env.DEV && /(^|[\s_-])(ads?|advert\w*)([\s_-]|$)/i.test(b.className))
    console.warn(`[ads] rewardedButton class "${b.className}" looks like an ad: ad blockers will hide the button`);
  let busy = false;
  b.addEventListener('click', async () => {
    if (busy || b.disabled) return;
    busy = true;
    b.disabled = true;
    const ok = await opts.host.rewarded(opts.placement);
    if (ok) {
      opts.onReward();
      return;
    }
    b.textContent = opts.unavailable ?? opts.host.i18n?.t('gp.noAd') ?? 'No ad available right now';
    b.setAttribute('aria-disabled', 'true');
    opts.onUnavailable?.();
  });
  return b;
}

export interface RewardedOfferOptions extends RewardedButtonOptions {
  /** The player turned the offer down ("No thanks"): go on without the reward (the results screen) */
  onSkip(): void;
  /** The skip button's words (default: the platform's "No thanks", gp.noThanks, in the player's language) */
  skipLabel?: string;
  /**
   * Optional: the offer still stands — checked again when the ad pays (e.g. `() => state === 'dead'`). A reward that
   * arrives after the run moved on (skipped, the screen closed, a timer ended it) is ignored instead of reviving it
   */
  stillOpen?(): boolean;
  /** 'row' (default): side by side, the same width; 'column': stacked, the full width */
  layout?: 'row' | 'column';
}

/** A rewarded offer and its "No thanks", the same size and look: put `el` on the screen */
export interface RewardedOffer {
  /** Both buttons in a flex box (row or column), `data-gp="offer"` */
  readonly el: HTMLElement;
  readonly offer: HTMLButtonElement;
  /** "No thanks", `data-gp="skip"` */
  readonly skip: HTMLButtonElement;
  /** Decided: rewarded, skipped or closed. A late reward after this is ignored */
  readonly settled: boolean;
  /** The run moved on without either button (a countdown ran out, the player left the screen): ignore a late reward */
  close(): void;
}

/**
 * A rewarded offer ("▶ Continue") with its own "No thanks" — the same class, size and font (CrazyGames: "the same size,
 * font, color"), or null when no rewarded ad can be offered now (then go on as if skipped: call your skip path). What it
 * gets right beyond rewardedButton (Frankengun's code review, bug #1: "No thanks" clicked under a loading revive ad ended
 * the run and the late reward revived it over the results screen — a softlock):
 * - a tap on the offer disables both buttons until the ad is over (and the host makes the UI inert meanwhile);
 * - a failed ad says so on the offer and gives "No thanks" back;
 * - exactly one of onReward / onSkip, once: a reward that arrives after a skip, close(), the offer leaving the page or
 *   `stillOpen()` turning false is ignored.
 */
export function rewardedOffer(opts: RewardedOfferOptions): RewardedOffer | null {
  if (!opts.host.rewardedAvailable) return null;
  let settled = false;
  const el = document.createElement('div');
  const skip = document.createElement('button');
  const offer = rewardedButton({
    ...opts,
    onReward() {
      if (settled || !el.isConnected || (opts.stillOpen && !opts.stillOpen())) {
        if (import.meta.env.DEV) console.warn(`[ads] a late reward for "${opts.placement}" ignored: the offer was already over`);
        return;
      }
      settled = true;
      skip.disabled = true;
      opts.onReward();
    },
    onUnavailable() {
      if (!settled) skip.disabled = false;
      opts.onUnavailable?.();
    },
  })!;
  skip.type = 'button';
  skip.textContent = opts.skipLabel ?? opts.host.i18n?.t('gp.noThanks') ?? 'No thanks';
  skip.dataset.gp = 'skip';
  if (opts.className) skip.className = opts.className;
  el.dataset.gp = 'offer';
  const column = opts.layout === 'column';
  el.style.cssText = `display:flex;flex-direction:${column ? 'column' : 'row'};gap:12px;align-items:stretch;justify-content:center;width:100%`;
  for (const b of [offer, skip]) b.style.cssText += column ? ';width:100%' : ';flex:1 1 0;min-width:0';
  el.append(offer, skip);
  // A tap on the offer: the skip waits too, until the ad is over (given back by onUnavailable when it failed). In the
  // capture phase, so it is disabled before the offer's own handler asks for the ad
  offer.addEventListener(
    'click',
    () => {
      if (!settled) skip.disabled = true;
    },
    { capture: true },
  );
  skip.addEventListener('click', () => {
    if (settled || skip.disabled) return;
    settled = true;
    offer.disabled = true;
    skip.disabled = true;
    opts.onSkip();
  });
  return {
    el,
    offer,
    skip,
    get settled() {
      return settled;
    },
    close() {
      settled = true;
      offer.disabled = true;
      skip.disabled = true;
    },
  };
}
