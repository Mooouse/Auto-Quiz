// How long a new player needs to read a line on screen while playing: what `gp qa` asks of a twist's explanation
// (concept.twist.explained), and what a demo bot waits on a hint that a player dismisses with a tap.
// Pure, no imports: Node reads it too (`@gp/core/reading`).
//
// READING_CPS = 20 characters per second: the ceiling Netflix's Timed Text Style Guide sets for adult subtitles in
// English (17 for children's programmes), and what Brysbaert's meta-analysis of silent reading gives in characters
// (238 words a minute × ≈ 5 characters with the space ≈ 20 a second; Journal of Memory and Language 109, 2019).
// NOTICE_SEC = 2 s on top: a subtitle appears where the viewer already looks; a hint in a game appears while the eyes
// follow the action, and has to be noticed first — the platform's allowance, not a measured figure. Echoflies' playtest
// (an explanation on screen for 30 ms) is far below any of it.
// MAX_SEC = 8 s: a longer text is a wall; the check stops asking for more (Netflix keeps one subtitle ≤ 7 s).

export const READING_CPS = 20;
export const NOTICE_SEC = 2;
export const MAX_READING_SEC = 8;

/** The text as a player reads it: spacing collapsed, trimmed */
export function readableText(text: string): string {
  return text.replace(/\s+/g, ' ').trim();
}

/** Seconds a new player needs to notice and read `text` while playing: 2 s + 50 ms per character, at most 8 s */
export function readingSec(text: string): number {
  const n = [...readableText(text)].length;
  return Math.min(MAX_READING_SEC, NOTICE_SEC + n / READING_CPS);
}
