// Ads. When an ad may be shown is decided by a pure policy function (shouldShowAd) with limits that
// come from the game's channel profile (e.g. android-families: Google Play Families rules).
// Providers: AdMob (Android), a test stub (dev builds), none (web build without ads).
// A web portal SDK is just another AdProvider.

import { Capacitor } from '@capacitor/core';
import { shouldShowAd, type AdMobConfig, type AdPolicy, type AdState } from './ads-policy.ts';

export { shouldShowAd, type AdMobConfig, type AdPolicy, type AdState };

export interface AdProvider {
  readonly name: string;
  /** canLoad() — whether ads may be loaded now (false after "Remove ads" is bought) */
  init(canLoad: () => boolean): Promise<void>;
  /** Load an ad in advance (must not show anything) */
  preload(): void;
  /** Show the loaded ad. Resolves after it is closed; false — it could not be shown */
  show(): Promise<boolean>;
  /**
   * Rewarded ad, if the provider has them. true — watched to the end: give the reward; false — not this time (skipped,
   * no fill); 'off' — no rewarded ad will come this session (CrazyGames' Basic Launch, an ad blocker)
   */
  showRewarded?(placement?: string): Promise<RewardedResult>;
}

export interface AdHooks {
  /** Called before showing — pause the game sound */
  onStart(): void;
  /** Called after the ad is closed; shown — whether it was actually shown */
  onEnd(shown: boolean): void;
  /**
   * Optional: an ad is now on its way (true, from the request — before the provider loads it) or over (false, before
   * onEnd). The code host makes the game's UI inert meanwhile: nothing under a loading ad can be tapped
   */
  onPending?(pending: boolean): void;
}

export type RewardedResult = boolean | 'off';

/** Rewarded offers stop for the session after this many failures in a row (one closed ad must not end them all) */
export const REWARDED_FAILS_TO_STOP = 2;

/** A rewarded ad may only start this soon after the player's own tap or key press, s */
export const REWARDED_INPUT_WINDOW_SEC = 2;

export class AdManager {
  readonly state: AdState;
  private started = false;
  /** An ad is on its way or on screen: a second request (a double click, a button pressed during the ad) is refused */
  private busy = false;
  /** Rewarded ads are on for this game (the channel allows them and the provider has them) */
  readonly rewardedEnabled: boolean;
  /**
   * Rewarded ads won't come this session: the provider said so (CrazyGames' Basic Launch, where monetization is off; an
   * ad blocker), or REWARDED_FAILS_TO_STOP requests in a row failed. No more offers then: a button that does nothing every
   * time is what players and the portal's QA would see. One skipped or unfilled ad alone doesn't stop them (Germ Bait's review).
   */
  private rewardedFailed = false;
  private rewardedFails = 0;

  constructor(
    private readonly provider: AdProvider,
    readonly policy: AdPolicy,
    private readonly isNoAds: () => boolean,
    private readonly hooks: AdHooks,
    private readonly now: () => number = () => performance.now() / 1000,
    rewarded = false,
  ) {
    this.state = { sessionStartSec: now(), roundsThisSession: 0, roundsSinceAd: 0, lastAdSec: null };
    this.rewardedEnabled = rewarded && typeof provider.showRewarded === 'function';
  }

  /** Rewarded ads can be offered now: on for this game, and none has failed this session */
  get rewardedAvailable(): boolean {
    return this.rewardedEnabled && !this.rewardedFailed;
  }

  /** An ad is on its way or on screen */
  get adPending(): boolean {
    return this.busy;
  }

  private setBusy(b: boolean): void {
    if (this.busy === b) return;
    this.busy = b;
    this.hooks.onPending?.(b);
  }

  get providerName(): string {
    return this.provider.name;
  }

  /** Initializes the SDK without showing anything. If ads were removed by purchase, the SDK is never started. */
  async init(): Promise<void> {
    if (this.started || this.isNoAds()) return;
    this.started = true;
    try {
      await this.provider.init(() => !this.isNoAds());
      this.provider.preload();
    } catch (e) {
      console.warn('[ads] init failed', e);
    }
  }

  /**
   * Called exactly once after every finished round, before the result screen.
   * Shows an ad if the limits allow it and waits until it is closed.
   */
  async afterRound(): Promise<void> {
    this.countRound();
    await this.naturalBreak();
  }

  /** A round (run, level) is over: it counts for "first ad after round N" and "every N rounds" */
  countRound(): void {
    this.state.roundsThisSession++;
    this.state.roundsSinceAd++;
  }

  /** A natural break (between rounds): shows a midgame ad if the limits allow it and waits until it is closed */
  async naturalBreak(): Promise<void> {
    const s = this.state;
    if (this.busy || !shouldShowAd(s, this.now(), this.isNoAds(), this.policy)) return;
    this.setBusy(true);
    let shown = false;
    try {
      if (!this.started) await this.init();
      this.hooks.onStart();
    } catch (e) {
      this.setBusy(false);
      throw e;
    }
    try {
      shown = await this.provider.show();
    } catch (e) {
      console.warn('[ads] show failed', e);
    }
    // The ad is over before onEnd: a game resuming in it sees adPending false and the limits already counting this ad
    this.setBusy(false);
    if (shown) {
      s.lastAdSec = this.now();
      s.roundsSinceAd = 0;
    }
    this.hooks.onEnd(shown);
    if (!this.isNoAds()) this.provider.preload();
  }

  /**
   * A rewarded ad the player asked for. true — watched to the end: the game must give the reward.
   * `lastInputSec` is when the player last tapped or pressed a key (same clock as `now`): a rewarded
   * ad that doesn't follow the player's own action is refused, so a game can't show one by itself.
   * "Remove ads" doesn't turn rewarded ads off — the player chooses each one.
   */
  async rewarded(lastInputSec: number | null, placement?: string): Promise<boolean> {
    if (!this.rewardedAvailable || !this.provider.showRewarded || this.busy) return false;
    if (lastInputSec === null || this.now() - lastInputSec > REWARDED_INPUT_WINDOW_SEC) {
      console.error('[ads] a rewarded ad must follow the player\'s tap on its button — refused');
      return false;
    }
    this.setBusy(true);
    let ok = false;
    let off = false;
    try {
      if (!this.started) {
        this.started = true;
        try {
          await this.provider.init(() => !this.isNoAds());
        } catch (e) {
          console.warn('[ads] init failed', e);
        }
      }
      this.hooks.onStart();
    } catch (e) {
      this.setBusy(false);
      throw e;
    }
    try {
      const r = await this.provider.showRewarded(placement);
      ok = r === true;
      off = r === 'off';
    } catch (e) {
      console.warn('[ads] rewarded failed', e);
    }
    // Over before onEnd: a game resuming in it sees adPending false and rewardedAvailable already updated
    this.setBusy(false);
    this.rewardedFails = ok ? 0 : this.rewardedFails + 1;
    if (off || this.rewardedFails >= REWARDED_FAILS_TO_STOP) this.rewardedFailed = true;
    this.hooks.onEnd(ok);
    return ok;
  }
}

// ---------------------------------------------------------------------------------------------
// AdMob (Android)

class AdMobProvider implements AdProvider {
  readonly name = 'admob';
  private mod: typeof import('@capacitor-community/admob') | null = null;
  private loaded = false;
  private loading = false;
  private failures = 0;
  private retryTimer = 0;
  private canLoad: () => boolean = () => true;

  constructor(
    private readonly cfg: AdMobConfig,
    private readonly policy: AdPolicy,
  ) {}

  async init(canLoad: () => boolean): Promise<void> {
    this.canLoad = canLoad;
    this.mod = await import('@capacitor-community/admob');
    const { AdMob, MaxAdContentRating: R, InterstitialAdPluginEvents: E } = this.mod;
    const rating = { G: R.General, PG: R.ParentalGuidance, T: R.Teen, MA: R.MatureAudience }[this.cfg.maxAdContentRating];
    await AdMob.initialize({
      tagForChildDirectedTreatment: this.cfg.childDirected,
      tagForUnderAgeOfConsent: this.cfg.underAgeOfConsent,
      maxAdContentRating: rating,
    });
    await AdMob.addListener(E.Loaded, () => {
      this.loaded = true;
      this.loading = false;
      this.failures = 0;
    });
    await AdMob.addListener(E.FailedToLoad, () => {
      this.loaded = false;
      this.loading = false;
      this.failures++;
      // Retry with a growing pause — don't flood the network with requests
      const delay = Math.min(120, 15 * 2 ** (this.failures - 1));
      clearTimeout(this.retryTimer);
      this.retryTimer = window.setTimeout(() => this.preload(), delay * 1000);
    });
  }

  preload(): void {
    if (!this.mod || this.loaded || this.loading || !this.canLoad()) return;
    this.loading = true;
    this.mod.AdMob.prepareInterstitial({
      adId: this.cfg.interstitialId,
      isTesting: this.cfg.isTesting,
      npa: this.cfg.nonPersonalized,
      immersiveMode: true,
    }).catch(() => {
      this.loading = false;
    });
  }

  async show(): Promise<boolean> {
    if (!this.mod || !this.loaded) return false;
    const { AdMob, InterstitialAdPluginEvents: E } = this.mod;
    this.loaded = false;
    // Once the native show is requested it can't be cancelled. So the game waits right here, in the
    // post-round break, until the ad is closed or has definitely failed — never moving on early and
    // letting a slow device pop the ad up later in the middle of play.
    return new Promise<boolean>((resolve) => {
      const handles: Promise<{ remove: () => Promise<void> }>[] = [];
      let done = false;
      const finish = (ok: boolean) => {
        if (done) return;
        done = true;
        clearTimeout(safetyTimer);
        handles.forEach((h) => void h.then((x) => x.remove()));
        resolve(ok);
      };
      // Last-resort safety net if the SDK loses its events; counts as a shown ad for the limits
      const safetyTimer = window.setTimeout(() => finish(true), this.policy.maxAdWaitSec * 1000);
      handles.push(AdMob.addListener(E.Dismissed, () => finish(true)));
      handles.push(AdMob.addListener(E.FailedToShow, () => finish(false)));
      AdMob.showInterstitial().catch(() => finish(false));
    });
  }
}

// ---------------------------------------------------------------------------------------------
// Test stub for dev builds: a grey screen with a countdown that closes itself.
// `?ads=fail` (or window.__adsFail = true): every ad fails at once, as in CrazyGames' Basic Launch or with an ad blocker
// (rewarded: 'off'); `?ads=unfilled`: every ad fails without saying ads are off (rewarded: false, offers stop after two).

class TestAdProvider implements AdProvider {
  readonly name = 'test';

  constructor(private readonly closeSec: number) {}

  async init(): Promise<void> {}

  preload(): void {}

  private get failing(): 'fail' | 'unfilled' | null {
    const w = window as unknown as { __adsFail?: boolean };
    if (w.__adsFail !== undefined) return w.__adsFail ? 'fail' : null;
    const q = new URLSearchParams(location.search).get('ads');
    return q === 'fail' || q === 'unfilled' ? q : null;
  }

  private fail<T>(result: T): Promise<T> {
    return new Promise((resolve) => setTimeout(() => resolve(result), 100));
  }

  show(): Promise<boolean> {
    return this.failing ? this.fail(false) : this.overlay('TEST AD');
  }

  showRewarded(): Promise<RewardedResult> {
    const f = this.failing;
    return f ? this.fail<RewardedResult>(f === 'fail' ? 'off' : false) : this.overlay('TEST REWARDED AD');
  }

  private overlay(text: string): Promise<boolean> {
    return new Promise((resolve) => {
      const el = document.createElement('div');
      el.style.cssText =
        'position:fixed;inset:0;z-index:10;display:flex;flex-direction:column;align-items:center;' +
        'justify-content:center;gap:16px;background:#555;color:#fff;font:600 22px system-ui,sans-serif;' +
        'touch-action:none;user-select:none';
      el.dataset.testAd = text === 'TEST AD' ? 'midgame' : 'rewarded'; // QA finds it by [data-test-ad]
      const label = document.createElement('div');
      label.textContent = text;
      const counter = document.createElement('div');
      counter.style.fontSize = '56px';
      el.append(label, counter);
      document.body.append(el);
      let left = this.closeSec;
      const tick = () => {
        counter.textContent = String(left);
        if (left <= 0) {
          clearInterval(timer);
          el.remove();
          resolve(true);
        }
        left--;
      };
      const timer = window.setInterval(tick, 1000);
      tick();
    });
  }
}

class NoAdProvider implements AdProvider {
  readonly name = 'none';
  async init(): Promise<void> {}
  preload(): void {}
  async show(): Promise<boolean> {
    return false;
  }
}

export interface AdsOptions {
  policy: AdPolicy;
  /** Rewarded ads allowed on this channel (the player chooses each one) */
  rewarded?: boolean;
  /** null — the game has no AdMob ads (e.g. a web build) */
  admob: AdMobConfig | null;
}

/** portalAds — the portal's ad provider on a web portal (CrazyGames), if the game runs on one */
export function createAdProvider(opts: AdsOptions | null, portalAds: AdProvider | null = null): AdProvider {
  if (!opts) return new NoAdProvider();
  if (Capacitor.isNativePlatform()) return opts.admob ? new AdMobProvider(opts.admob, opts.policy) : new NoAdProvider();
  if (import.meta.env.DEV) return new TestAdProvider(opts.policy.testAdCloseSec);
  return portalAds ?? new NoAdProvider();
}
