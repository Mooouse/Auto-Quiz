// Browser test of the code kit's look measures (qa/suite.ts, @gp/qa/probe): glyphs used as icons in the visible text
// (the game's and the platform's own roots told apart), the HUD's text over text and over touch controls, and the
// probe's records of bitmaps drawn magnified and of the faces canvas text is drawn in. Runs with `npm run test:browser`.

import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { chromium, type Browser, type Page } from 'playwright';
import { installProbe } from '@gp/qa/probe';
import { glyphIcons, playTextFindings } from '../qa/suite.ts';

let browser: Browser;

beforeAll(async () => {
  browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
}, 60000);

afterAll(async () => {
  await browser?.close();
});

async function page(html: string, probe = false): Promise<Page> {
  const ctx = await browser.newContext({ viewport: { width: 360, height: 640 } });
  if (probe) await ctx.addInitScript(installProbe);
  const p = await ctx.newPage();
  await p.setContent(`<style>body{margin:0;font:16px sans-serif}</style>${html}`);
  return p;
}

describe('QA: glyphs as icons on screen', () => {
  it('text nodes and ::before content with symbols are found and named; the platform\'s #gp-* roots are told apart; hidden text and © are not', async () => {
    const p = await page(`
      <style>.done::before { content: "✓ "; }</style>
      <div id="ui"><button>▶ Continue (ad)</button><span class="done">Daily</span><p>© 2026 · ×2 — fine</p><p style="display:none">🔒 hidden</p></div>
      <div id="gp-shop"><span>🔒 Locked</span></div>`);
    const found = await glyphIcons(p);
    expect(found).toEqual(
      expect.arrayContaining([
        { glyphs: ['▶'], text: '▶ Continue (ad)', where: 'button in #ui', platform: false },
        { glyphs: ['✓'], text: '✓', where: 'span.done in #ui::before', platform: false },
        { glyphs: ['🔒'], text: '🔒 Locked', where: 'span in #gp-shop', platform: true },
      ]),
    );
    expect(found).toHaveLength(3);
    await p.context().close();
  });
});

describe('QA: the HUD in play — text over text, text over a touch control', () => {
  const fixed = (x: number, y: number, extra = '') => `position:fixed;left:${x}px;top:${y}px;white-space:nowrap;pointer-events:none;${extra}`;
  it('two HUD labels drawn into each other: over-text; side by side or stacked with a tight line height: nothing', async () => {
    const p = await page(`<div style="${fixed(20, 20)}">Ammo 12</div><div style="${fixed(30, 24)}">Wave 3 incoming</div>`);
    expect(await playTextFindings(p)).toEqual([{ kind: 'over-text', text: 'Wave 3 incoming', where: 'Ammo 12' }]);
    await p.setContent(`<div style="${fixed(20, 20)}">Ammo 12</div><div style="${fixed(160, 20)}">Wave 3</div><div style="position:fixed;left:20px;top:200px;line-height:1"><div>First line</div><div>Second line</div></div>`);
    expect(await playTextFindings(p)).toEqual([]);
    await p.context().close();
  });
  it('a dialog covering the screen hides the HUD under it: nothing; a toast on its own small panel still lands on the score', async () => {
    const p = await page(`<div style="${fixed(20, 20)}">Score 1200</div><div style="position:fixed;inset:0;background:#123;z-index:2"><p style="${fixed(24, 22)}">Paused</p></div>`);
    expect(await playTextFindings(p)).toEqual([]);
    await p.setContent(`<div style="${fixed(20, 20)}">Score 1200</div><div style="${fixed(10, 14, 'background:#123;padding:4px;z-index:2')}">Combo ×3!</div>`);
    expect(await playTextFindings(p)).toEqual([{ kind: 'over-text', text: 'Combo ×3!', where: 'Score 1200' }]);
    await p.context().close();
  });
  it('a hint over an on-screen stick (data-gp-touch): over-touch; the control\'s own label is its own', async () => {
    const p = await page(`<div data-gp-touch="stick" style="position:fixed;left:20px;top:400px;width:120px;height:120px;border-radius:50%;background:#fff3"></div><div style="${fixed(30, 450, 'z-index:2')}">Drag to move</div>`);
    expect(await playTextFindings(p)).toEqual([{ kind: 'over-touch', text: 'Drag to move', where: 'stick' }]);
    await p.setContent(`<div data-gp-touch="jump" style="position:fixed;left:20px;top:400px;width:90px;height:90px">Jump</div>`);
    expect(await playTextFindings(p)).toEqual([]);
    await p.context().close();
  });
});

describe('QA: the probe records bitmaps drawn magnified and the faces of canvas text', () => {
  it('a 32 px sprite drawn at 96 px is 3×; the same crisp (imageSmoothingEnabled false), 1:1 or a 4 px strip is not recorded; fillText fonts are counted', async () => {
    const p = await page('<canvas id="game" width="360" height="640" style="width:360px;height:640px"></canvas>', true);
    const out = await p.evaluate(() => {
      const src = document.createElement('canvas');
      src.width = 32;
      src.height = 32;
      const strip = document.createElement('canvas');
      strip.width = 256;
      strip.height = 4;
      const g = (document.getElementById('game') as HTMLCanvasElement).getContext('2d')!;
      g.drawImage(src, 0, 0, 96, 96);
      g.drawImage(src, 100, 0);
      g.drawImage(strip, 0, 200, 360, 300);
      g.save();
      g.imageSmoothingEnabled = false;
      g.drawImage(src, 0, 300, 128, 128);
      g.restore();
      // A transform scales too: 2× by setTransform, 1.5× by the destination size → 3×
      g.setTransform(2, 0, 0, 2, 0, 0);
      g.drawImage(src, 0, 0, 48, 48);
      g.setTransform(1, 0, 0, 1, 0, 0);
      g.font = '700 20px "Bungee", system-ui';
      g.fillText('Score 120', 10, 30);
      const p = (window as any).__gpProbe;
      return { mags: [...p.mags.values()], fonts: Object.fromEntries(p.canvasFonts) };
    });
    expect(out.mags).toHaveLength(1);
    expect(out.mags[0]).toMatchObject({ image: 'a canvas', w: 32, h: 32, screen: 'first screen', n: 2 });
    expect(out.mags[0].scale).toBeCloseTo(3, 5);
    expect(out.fonts).toEqual({ 'Bungee, system-ui': 8 });
    await p.context().close();
  });
});
