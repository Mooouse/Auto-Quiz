// The look checks of the code kit's QA, judged: pure, so they are unit-tested without a browser. The suite measures in
// the page (suite.ts) and these decide. They turn what portal reviewers and our second agents wrote by hand into
// automatic findings — CrazyGames rejected our games for "the overall quality" while gp qa was green:
//   - the hero is a speck on a desktop screen (host.qa({ hero }));
//   - a three game's camera sees a slit in portrait (the horizontal field of view);
//   - small bitmaps drawn magnified into mush (Garage: «Пиксельное месиво»);
//   - every text in the browser's default face (Velvet: Georgia and system-ui — a web app, not a game);
//   - a title screen with more choices than a new player can take in (Frankengun's 9).

/** A box in CSS px of the viewport */
export interface Box {
  x: number;
  y: number;
  w: number;
  h: number;
}

/** The hero's size, √(w·h), as a share of the screen's short side: under this fails in play on a portal (desktop decides) */
export const HERO_MIN_SHARE = 0.06;

/** host.qa({ hero }) judged at one screen size: its size against the short side, and on screen */
export function heroVerdict(r: Box, view: { width: number; height: number }, min = HERO_MIN_SHARE): { ok: boolean; share: number; text: string } {
  const short = Math.min(view.width, view.height);
  const size = Math.sqrt(Math.max(0, r.w) * Math.max(0, r.h));
  const share = short ? size / short : 0;
  const on = r.x + r.w > 0 && r.y + r.h > 0 && r.x < view.width && r.y < view.height;
  const at = `${Math.round(r.w)}×${Math.round(r.h)} at ${Math.round(r.x)},${Math.round(r.y)}`;
  if (!on) return { ok: false, share, text: `the hero (${at}) is off the ${view.width}×${view.height} screen` };
  const pct = (x: number) => `${(x * 100).toFixed(1)} %`;
  const ok = share >= min;
  return {
    ok,
    share,
    text: `${at}: ${Math.round(size)} px (√(w·h)) is ${pct(share)} of the short side ${short} px${ok ? '' : ` — under ${pct(min)}: on a desktop screen the player's object is a speck in an empty field. Scale the world with the screen (a unit from the short side; the art showcase's camera zoom), or show less of it`}`,
  };
}

/** What QA reads of a camera: three's PerspectiveCamera (fov is vertical, in degrees) or the game's own numbers */
export interface CameraLike {
  isPerspectiveCamera?: boolean;
  isOrthographicCamera?: boolean;
  /** Vertical field of view, degrees (three's PerspectiveCamera.fov) */
  fov?: number;
  aspect?: number;
  zoom?: number;
  /** Or the game says the horizontal field of view itself, degrees */
  hfov?: number;
}

/** The smallest horizontal field of view a first- or third-person view may have in portrait (Frankengun: a slit at 360×800) */
export const PORTRAIT_MIN_HFOV = 60;

/** The horizontal field of view in degrees (null: not a perspective camera, or not enough numbers) */
export function horizontalFovDeg(cam: CameraLike | null | undefined, viewAspect?: number): number | null {
  if (!cam) return null;
  if (typeof cam.hfov === 'number' && Number.isFinite(cam.hfov)) return cam.hfov;
  if (cam.isOrthographicCamera || typeof cam.fov !== 'number' || !Number.isFinite(cam.fov)) return null;
  const aspect = typeof cam.aspect === 'number' && cam.aspect > 0 ? cam.aspect : viewAspect;
  if (!aspect) return null;
  const zoom = typeof cam.zoom === 'number' && cam.zoom > 0 ? cam.zoom : 1;
  const v = (cam.fov * Math.PI) / 180;
  return (2 * Math.atan((Math.tan(v / 2) / zoom) * aspect) * 180) / Math.PI;
}

/** A bitmap drawn magnified (the probe's record: its source size, the screen, the largest scale in device px) */
export interface Magnified {
  image: string;
  w: number;
  h: number;
  screen: string;
  scale: number;
  n: number;
}

/** Over this many source pixels per device pixel a bitmap goes soft (a warning); over MAG_FAIL it is mush (a failure) */
export const MAG_WARN = 1.25;
export const MAG_FAIL = 2;

/** The probe's records judged: the ones over MAG_FAIL fail, between MAG_WARN and MAG_FAIL warn; each named, worst first */
export function judgeMagnified(list: readonly Magnified[]): { fail: string[]; warn: string[] } {
  const line = (m: Magnified) => `${m.image} ${m.w}×${m.h} drawn at ${m.scale.toFixed(2)}× on "${m.screen}"${m.n > 1 ? ` (${m.n} draws)` : ''}`;
  const sorted = [...list].sort((a, b) => b.scale - a.scale);
  return { fail: sorted.filter((m) => m.scale > MAG_FAIL).map(line), warn: sorted.filter((m) => m.scale > MAG_WARN && m.scale <= MAG_FAIL).map(line) };
}

/** A face text renders in, and how many characters of visible text use it */
export interface FaceUse {
  /** The family that renders ("system-ui", "DejaVu Sans", "Bungee") */
  name: string;
  /** A font the game loaded (a FontFace in document.fonts, loaded); false: generic or a system face */
  game: boolean;
  chars: number;
}

/** Families that only carry emoji: never the text's face */
export const EMOJI_FAMILY = /emoji|symbol/i;
/** The generic families: the browser's choice, so a system face */
export const GENERIC_FAMILY = /^(serif|sans-serif|monospace|cursive|fantasy|system-ui|ui-serif|ui-sans-serif|ui-monospace|ui-rounded|math|fangsong|-apple-system|blinkmacsystemfont)$/i;

/**
 * The face a CSS font-family list renders in: the first family that is a loaded font of the game's own, generic, or a
 * system face (a named family that is no FontFace of the page: Arial, Georgia, DejaVu Sans). A FontFace of the page that
 * didn't load (error, never used) falls through to the next. Emoji families are skipped
 */
export function renderingFace(list: string, faces: { loaded: ReadonlySet<string>; declared: ReadonlySet<string> }): { name: string; game: boolean } {
  for (const raw of list.split(',')) {
    const name = raw.trim().replace(/^["']|["']$/g, '');
    if (!name || EMOJI_FAMILY.test(name)) continue;
    const key = name.toLowerCase();
    if (faces.loaded.has(key)) return { name, game: true };
    if (faces.declared.has(key)) continue;
    return { name, game: false };
  }
  return { name: '(the browser default)', game: false };
}

/** Over this share of the visible characters in a system face: W_SYSTEM_FONT */
export const SYSTEM_FONT_SHARE = 0.5;

/** The faces judged: most of the visible text in a system face is a warning (fewer than 20 characters: not judged) */
export function systemFontVerdict(uses: readonly FaceUse[]): { warn: boolean; share: number; text: string } {
  const merged = new Map<string, FaceUse>();
  for (const u of uses) {
    const k = `${u.game}|${u.name}`;
    const e = merged.get(k);
    if (e) e.chars += u.chars;
    else merged.set(k, { ...u });
  }
  const all = [...merged.values()].sort((a, b) => b.chars - a.chars);
  const total = all.reduce((n, u) => n + u.chars, 0);
  const sys = all.filter((u) => !u.game).reduce((n, u) => n + u.chars, 0);
  const share = total ? sys / total : 0;
  const top = all.slice(0, 4).map((u) => `${u.name}${u.game ? ' (loaded by the game)' : ''} ${Math.round((u.chars / Math.max(1, total)) * 100)} %`).join(', ');
  if (total < 20) return { warn: false, share, text: `${total} characters of visible text — not judged` };
  const warn = share > SYSTEM_FONT_SHARE;
  return {
    warn,
    share,
    text: `${Math.round(share * 100)} % of ${total} visible characters in a system face (${top})${warn ? ' — a web page\'s look, not a game\'s (Velvet\'s Georgia and system-ui): load a display face of the game\'s own (a FontFace, @font-face) for titles, buttons and numbers' : ''}`,
  };
}

/** More interactive choices than this on the title after the first run: a warning (W_TITLE_CHOICES) */
export const TITLE_MAX_CHOICES = 6;

// --- From the calibration and the blind scored review (docs/research/qa-calibration-2026-10.md) -----------------------
// What the rejected games shared that no check caught: a title that hides its key art behind a centred modal, small or
// low-contrast play text at 1280×720 (canvas HUD text too), meta screens of "???" silhouettes, an undeclared hero in an
// action game, and 16–20 screens of scope.

/** Over this share of the 1280×720 title under opaque DOM panels (with key art behind): a warning … */
export const TITLE_COVER_WARN = 0.2;
/** … and over this, on crazygames, a failure (E_QA_TITLE_COVERED) */
export const TITLE_COVER_FAIL = 0.45;
/** A DOM layer counts as a panel over the canvas from this effective opacity (its background's alpha × the opacities) */
export const PANEL_MIN_ALPHA = 0.6;

/**
 * The title's key art judged: `covered` the share of the screen under opaque DOM panels over the canvas, `detail` whether
 * the canvas alone (the DOM hidden) has something to show (a flat or empty canvas has no key art to hide: not judged),
 * `dimmed` the share under a translucent layer only (said, not judged). Calibrated on Garage 1.0.0's declared title
 * (approved; the blind reviewer: "a centred dark modal hides the car"): 23 % under its panel, so it warns; a modal over
 * more than 45 % of the art fails on crazygames
 */
export function titleCoverVerdict(o: { covered: number; detail: boolean; dimmed?: number }, portal: boolean): { level: 'ok' | 'warn' | 'fail'; text: string } {
  const pct = (x: number) => `${Math.round(x * 100)} %`;
  const dim = o.dimmed && o.dimmed > 0.05 ? `; a translucent layer dims ${pct(o.dimmed)} more` : '';
  const nums = `${pct(o.covered)} of the screen under opaque DOM panels over the canvas${dim}`;
  if (!o.detail) return { level: 'ok', text: `${nums} — the canvas behind is flat or empty: no key art to hide (not judged)` };
  const fix =
    " — the title is the game's key art: let it fill the screen and put the title and buttons beside it or over its empty part (a column at one side, a bar at the bottom), not a centred modal over it; the blind review marked our titles down for exactly this (E_QA_TITLE_COVERED)";
  if (o.covered > TITLE_COVER_FAIL) return { level: portal ? 'fail' : 'warn', text: `${nums}, over ${pct(TITLE_COVER_FAIL)}${fix}` };
  if (o.covered > TITLE_COVER_WARN) return { level: 'warn', text: `${nums}, over ${pct(TITLE_COVER_WARN)}${fix}` };
  return { level: 'ok', text: nums };
}

/** The later play frame: measured this far into a run (the reviewer's play-2 is 20 s in) */
export const LATER_PLAY_SEC = 15;

/** Play text at 1280×720: under this a warning … */
export const PLAY_TEXT_MIN_PX = 14;
/** … a HUD number under this fails on crazygames (E_QA_PLAY_TEXT) */
export const HUD_NUMBER_MIN_PX = 12;
/** The WCAG ratio for large text and UI parts: under it text is hard to read against what's behind */
export const PLAY_TEXT_MIN_CONTRAST = 3;

export type Rgb = [number, number, number];
export type Rgba = [number, number, number, number];

/** A CSS colour as rgba 0–255 (alpha 0–1): rgb()/rgba() (both syntaxes), #rgb, #rgba, #rrggbb, #rrggbbaa; null otherwise */
export function parseColor(s: string | null | undefined): Rgba | null {
  if (!s) return null;
  const t = s.trim().toLowerCase();
  if (t === 'transparent') return [0, 0, 0, 0];
  const h = t.match(/^#([0-9a-f]{3,8})$/);
  if (h) {
    const x = h[1];
    if (x.length === 3 || x.length === 4) {
      const v = [...x].map((c) => parseInt(c + c, 16));
      return [v[0], v[1], v[2], x.length === 4 ? v[3] / 255 : 1];
    }
    if (x.length === 6 || x.length === 8) {
      const v = [0, 2, 4, 6].map((i) => parseInt(x.slice(i, i + 2), 16));
      return [v[0], v[1], v[2], x.length === 8 ? v[3] / 255 : 1];
    }
    return null;
  }
  const m = t.match(/^rgba?\(([^)]*)\)$/);
  if (!m) return null;
  const parts = m[1].split(/[\s,/]+/).filter(Boolean);
  if (parts.length < 3) return null;
  const ch = (p: string) => (p.endsWith('%') ? (parseFloat(p) / 100) * 255 : parseFloat(p));
  const a = parts[3] === undefined ? 1 : parts[3].endsWith('%') ? parseFloat(parts[3]) / 100 : parseFloat(parts[3]);
  const v: Rgba = [ch(parts[0]), ch(parts[1]), ch(parts[2]), a];
  return v.every((n) => Number.isFinite(n)) ? v : null;
}

/** WCAG relative luminance of an sRGB colour (0–255) */
export function luminance(c: Rgb | Rgba): number {
  const lin = (v: number) => {
    const s = v / 255;
    return s <= 0.04045 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4;
  };
  return 0.2126 * lin(c[0]) + 0.7152 * lin(c[1]) + 0.0722 * lin(c[2]);
}

/** The WCAG contrast ratio (1–21) of a colour (its alpha blended over the background) against the background */
export function contrastRatio(fg: Rgb | Rgba, bg: Rgb): number {
  const a = fg.length === 4 ? Math.max(0, Math.min(1, fg[3])) : 1;
  const mix: Rgb = [fg[0] * a + bg[0] * (1 - a), fg[1] * a + bg[1] * (1 - a), fg[2] * a + bg[2] * (1 - a)];
  const [hi, lo] = [luminance(mix), luminance(bg)].sort((x, y) => y - x);
  return (hi + 0.05) / (lo + 0.05);
}

/**
 * The colour behind a text, from the screenshot's pixels in its box (RGBA): the median (by lightness) of the pixels that
 * are not the text's own colour — the glyphs and their soft edges are a minority of the box. A box that is nearly all the
 * text's colour (text in the colour of its background) gives the median of all its pixels
 */
export function textBackground(rgba: ArrayLike<number>, text: Rgb | Rgba): Rgb | null {
  const n = Math.floor(rgba.length / 4);
  if (!n) return null;
  const all: Rgb[] = [];
  const far: Rgb[] = [];
  for (let i = 0; i < n; i++) {
    const p: Rgb = [rgba[i * 4], rgba[i * 4 + 1], rgba[i * 4 + 2]];
    all.push(p);
    if (Math.abs(p[0] - text[0]) + Math.abs(p[1] - text[1]) + Math.abs(p[2] - text[2]) > 60) far.push(p);
  }
  const pick = far.length >= n * 0.1 ? far : all;
  const y = (p: Rgb) => 0.2126 * p[0] + 0.7152 * p[1] + 0.0722 * p[2];
  pick.sort((a, b) => y(a) - y(b));
  return pick[Math.floor(pick.length / 2)];
}

/** One text a player reads in play: DOM or canvas, its size in CSS px, its colour, an outline or shadow, what is behind */
export interface PlayText {
  text: string;
  px: number;
  source: 'dom' | 'canvas';
  /** Where (the element, or the canvas) */
  where: string;
  color: Rgba | null;
  /** A text stroke or a hard shadow: it separates the glyphs from what's behind */
  outline?: Rgba | null;
  /** The colour behind it, sampled from the screenshot (null: not sampled) */
  bg: Rgb | null;
}

/** A HUD number: mostly digits ("22/58", "1,250", "×3", "0:42") */
export function isHudNumber(text: string): boolean {
  const t = text.replace(/\s+/g, '');
  const digits = (t.match(/\p{N}/gu) ?? []).length;
  return digits > 0 && digits >= t.length * 0.5;
}

/** The contrast a text reads with: against what's behind, or its outline's (whichever is higher); null: unknown colours */
export function textContrast(t: PlayText): number | null {
  if (!t.color || !t.bg) return null;
  const c = contrastRatio(t.color, t.bg);
  if (t.outline && t.outline[3] >= 0.5) return Math.max(c, contrastRatio(t.color, [t.outline[0], t.outline[1], t.outline[2]]));
  return c;
}

/**
 * The play text at 1280×720 judged: a HUD number under 12 px fails (on crazygames; a warning elsewhere), any text under
 * 14 px or under 3:1 against the pixels behind it warns (Velvet's 13 px "Chains 4 · Discards 3", Swarm Smash's objective
 * line under its progress bar, Candle Crypt's pixel HUD). Each text once, the smallest first
 */
export function judgePlayText(texts: readonly PlayText[], portal: boolean): { fail: string[]; warn: string[]; judged: number } {
  const fail: { k: number; s: string }[] = [];
  const warn: { k: number; s: string }[] = [];
  const seen = new Set<string>();
  let judged = 0;
  for (const t of texts) {
    const text = t.text.replace(/\s+/g, ' ').trim();
    if (!/[\p{L}\p{N}]/u.test(text)) continue;
    const key = `${t.source}|${text}|${Math.round(t.px)}`;
    if (seen.has(key)) continue;
    seen.add(key);
    judged++;
    const label = `"${text.length > 30 ? `${text.slice(0, 29)}…` : text}" (${t.where})`;
    if (isHudNumber(text) && t.px < HUD_NUMBER_MIN_PX - 0.01) {
      (portal ? fail : warn).push({ k: t.px, s: `${label}: a HUD number at ${t.px.toFixed(1)} px, under ${HUD_NUMBER_MIN_PX} px` });
      continue;
    }
    const c = textContrast(t);
    const why: string[] = [];
    if (t.px < PLAY_TEXT_MIN_PX - 0.01) why.push(`${t.px.toFixed(1)} px, under ${PLAY_TEXT_MIN_PX} px`);
    if (c !== null && c < PLAY_TEXT_MIN_CONTRAST) why.push(`contrast ${c.toFixed(1)}:1 against what's behind it, under ${PLAY_TEXT_MIN_CONTRAST}:1`);
    if (why.length) warn.push({ k: Math.min(t.px, (c ?? 21) * 4), s: `${label}: ${why.join(', ')}` });
  }
  const order = (l: { k: number; s: string }[]) => l.sort((a, b) => a.k - b.k).map((x) => x.s);
  return { fail: order(fail), warn: order(warn), judged };
}

/** A placeholder's text: "???", "?", "？？？" */
export const PLACEHOLDER_TEXT = /\?{2,}|？{2,}|^\s*[?？]\s*$/;

/**
 * An item's image, judged from its pixels (RGBA): a silhouette or an empty slot — near-zero colour variance (the
 * colourfulness of Hasler and Süsstrunk under 10: a dark shape on a grey card, Garage's album of black cars) or one flat
 * colour (lightness and both colour axes varying under 5 of 255)
 */
export function isPlaceholderImage(rgba: ArrayLike<number>): boolean {
  const n = Math.floor(rgba.length / 4);
  if (!n) return true;
  let srg = 0;
  let syb = 0;
  let sl = 0;
  let qrg = 0;
  let qyb = 0;
  let ql = 0;
  for (let i = 0; i < n; i++) {
    const r = rgba[i * 4];
    const g = rgba[i * 4 + 1];
    const b = rgba[i * 4 + 2];
    const rg = r - g;
    const yb = 0.5 * (r + g) - b;
    const l = 0.2126 * r + 0.7152 * g + 0.0722 * b;
    srg += rg;
    syb += yb;
    sl += l;
    qrg += rg * rg;
    qyb += yb * yb;
    ql += l * l;
  }
  const sd = (s: number, q: number) => Math.sqrt(Math.max(0, q / n - (s / n) ** 2));
  const colourful = Math.hypot(sd(srg, qrg), sd(syb, qyb)) + 0.3 * Math.hypot(srg / n, syb / n);
  if (colourful < 10) return true;
  return sd(sl, ql) < 5 && sd(srg, qrg) < 5 && sd(syb, qyb) < 5;
}

/** A collection item as QA saw it: its text, and whether its images are placeholders */
export interface CollectionItem {
  text: string;
  /** Every image in it a placeholder (true), some art (false), no image (null) */
  placeholderImage: boolean | null;
}

/** At least this many alike items make a collection; over this share of placeholders: W_META_SILHOUETTES */
export const COLLECTION_MIN_ITEMS = 6;
export const COLLECTION_PLACEHOLDER_SHARE = 0.5;

/** An item that shows nothing yet: "???", silhouette images, or an empty slot (no image, no text) */
export function isPlaceholderItem(i: CollectionItem): boolean {
  if (PLACEHOLDER_TEXT.test(i.text)) return true;
  if (i.placeholderImage === true) return true;
  return i.placeholderImage === null && !/[\p{L}\p{N}]/u.test(i.text);
}

/** A declared screen's alike items on a fresh save: mostly placeholders is a warning (the blind review: albums of "???") */
export function silhouettesVerdict(items: readonly CollectionItem[]): { warn: boolean; share: number; text: string } {
  const n = items.length;
  const ph = items.filter(isPlaceholderItem).length;
  const share = n ? ph / n : 0;
  if (n < COLLECTION_MIN_ITEMS) return { warn: false, share, text: `${n} alike items — no collection to judge` };
  const warn = share > COLLECTION_PLACEHOLDER_SHARE;
  return {
    warn,
    share,
    text: `${ph} of ${n} visible items are placeholders ("???", silhouettes, empty slots) on a fresh save${warn ? " — a new player meets a wall of what they don't have: show the first finds earned or nearly earned, the locked ones in colour with how to get them, fewer slots at once, or open the screen after the first finds (W_META_SILHOUETTES)" : ''}`,
  };
}

/** The money genres whose player is a moving object a desktop reviewer must see: host.qa({ hero }) is required on crazygames */
export const HERO_GENRES: readonly string[] = ['action', 'shooting'];

/** host.qa({ hero }) required: an action or shooting game (a sub-genre by its parent: roguelite → action) or one tagged Arcade */
export function heroRequired(genre: string | null | undefined, tags: readonly string[] = []): boolean {
  return (!!genre && HERO_GENRES.includes(genre)) || tags.some((t) => /^arcade$/i.test(t.trim()));
}
