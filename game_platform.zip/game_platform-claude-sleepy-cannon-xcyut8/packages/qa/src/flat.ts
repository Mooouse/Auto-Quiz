// The "flat frame" hint: is a play screenshot a flat, empty-looking picture? Portal reviewers rejected our games for
// "the overall quality", and one wrote it out for Kettlebot: flat panels, big empty spaces, no depth or light. This
// measures what can be measured from pixels — how much of the frame is one colour, how many lightness values it uses,
// how much of it is a featureless area — and gp qa reports it as a hint (never a failing check). The pure part runs on
// any RGBA array (unit tests use synthetic images); framePixels() gets one from a screenshot in the page.

import type { Page } from 'playwright';

export interface FlatFrame {
  /** Share of the frame covered by the single most common colour (4 bits per channel) */
  topShare: number;
  topColor: string;
  /** Lightness levels in use: of 32 equal bins, those holding at least 0.5 % of the pixels */
  levels: number;
  /** Share of 8×8 blocks with no visible variation (luma range ≤ 6 of 255, each channel ≤ 8) */
  uniformShare: number;
  /**
   * The largest rectangle of featureless blocks, as a share of the frame: one big empty area (a phone column in the
   * middle of a desktop screen, half the screen a bare backdrop) even when the frame as a whole has detail
   */
  emptyRect: number;
  /** Any of the three says "flat" */
  flat: boolean;
  /** What to tell the game maker, or null */
  hint: string | null;
}

export const FLAT_LIMITS = { topShare: 0.4, uniformShare: 0.55, levels: 8 };

const hex = (n: number) => n.toString(16).padStart(2, '0');

export function flatFrame(rgba: ArrayLike<number>, w: number, h: number, limits = FLAT_LIMITS): FlatFrame {
  const n = w * h;
  const counts = new Map<number, number>();
  const bins = new Array(32).fill(0);
  for (let i = 0; i < n; i++) {
    const r = rgba[i * 4];
    const g = rgba[i * 4 + 1];
    const b = rgba[i * 4 + 2];
    const k = ((r >> 4) << 8) | ((g >> 4) << 4) | (b >> 4);
    counts.set(k, (counts.get(k) ?? 0) + 1);
    bins[Math.min(31, Math.floor((0.2126 * r + 0.7152 * g + 0.0722 * b) / 8))]++;
  }
  let topK = 0;
  let top = 0;
  for (const [k, c] of counts) if (c > top) [top, topK] = [c, k];
  const topShare = n ? top / n : 0;
  const q = (v: number) => hex(v * 17);
  const topColor = `#${q(topK >> 8)}${q((topK >> 4) & 15)}${q(topK & 15)}`;
  const levels = bins.filter((c) => c >= n * 0.005).length;
  let blocks = 0;
  let uniform = 0;
  const cols = Math.floor(w / 8);
  const rows = Math.floor(h / 8);
  const grid = new Uint8Array(cols * rows);
  for (let by = 0; by + 8 <= h; by += 8)
    for (let bx = 0; bx + 8 <= w; bx += 8) {
      blocks++;
      const lo = [255, 255, 255, 255];
      const hi = [0, 0, 0, 0];
      for (let y = by; y < by + 8; y++)
        for (let x = bx; x < bx + 8; x++) {
          const i = (y * w + x) * 4;
          const v = [rgba[i], rgba[i + 1], rgba[i + 2], 0.2126 * rgba[i] + 0.7152 * rgba[i + 1] + 0.0722 * rgba[i + 2]];
          for (let c = 0; c < 4; c++) {
            if (v[c] < lo[c]) lo[c] = v[c];
            if (v[c] > hi[c]) hi[c] = v[c];
          }
        }
      if (hi[3] - lo[3] <= 6 && hi[0] - lo[0] <= 8 && hi[1] - lo[1] <= 8 && hi[2] - lo[2] <= 8) {
        uniform++;
        grid[(by / 8) * cols + bx / 8] = 1;
      }
    }
  const uniformShare = blocks ? uniform / blocks : 0;
  const emptyRect = blocks ? largestRect(grid, cols, rows) / blocks : 0;
  const why: string[] = [];
  if (topShare >= limits.topShare) why.push(`${Math.round(topShare * 100)}% of the play frame is one flat colour (${topColor})`);
  if (uniformShare >= limits.uniformShare) why.push(`${Math.round(uniformShare * 100)}% of it is featureless area`);
  if (levels < limits.levels) why.push(`only ${levels} lightness levels`);
  const flat = why.length > 0;
  return {
    topShare,
    topColor,
    levels,
    uniformShare,
    emptyRect,
    flat,
    hint: flat ? `${why.join('; ')} — add depth: a lit background with layers (@gp/art scenery), light and shadow (@gp/art light), volume on the main sprites (@gp/art material) — docs/guides/art.md` : null,
  };
}

/** The largest all-ones rectangle in a 0/1 grid, in cells (the histogram method: O(cols × rows)) */
export function largestRect(grid: ArrayLike<number>, cols: number, rows: number): number {
  const heights = new Array(cols).fill(0);
  let best = 0;
  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < cols; x++) heights[x] = grid[y * cols + x] ? heights[x] + 1 : 0;
    const stack: number[] = [];
    for (let x = 0; x <= cols; x++) {
      const hx = x < cols ? heights[x] : 0;
      while (stack.length && heights[stack[stack.length - 1]] >= hx) {
        const top = stack.pop()!;
        const left = stack.length ? stack[stack.length - 1] + 1 : 0;
        best = Math.max(best, heights[top] * (x - left));
      }
      stack.push(x);
    }
  }
  return best;
}

/**
 * Where "flat" stops being a hint and fails, on crazygames at the desktop sizes (1280×720, 821×462): the frame is
 * CLEARLY empty — most of it one colour, or most of it featureless, or one featureless area that is half the screen.
 * Calibrated on our games' QA screenshots (2026-10-19): Garage's (approved) at most 43 % one colour, 68 % featureless,
 * 15 % in one area; Candle Crypt's title (approved: a phone column with dark bars) 60 %, 66 %, 23 %; the art showcase
 * under 12 %, 38 %, 4 %. Germ Dodge's bare dish before it got one: 83–100 % one colour, 89–99 % featureless — fails.
 * A full-screen act card (Candle Crypt's, 81 %) is passing by: the play frame is measured again 2 s later
 */
export const FLAT_FAIL_LIMITS = { topShare: 0.7, uniformShare: 0.8, emptyRect: 0.4 };

/** The desktop verdict: why the frame is clearly empty ([] when it is not) */
export function emptyLayout(f: FlatFrame, limits = FLAT_FAIL_LIMITS): string[] {
  const why: string[] = [];
  if (f.topShare >= limits.topShare) why.push(`${Math.round(f.topShare * 100)}% of the screen is one flat colour (${f.topColor}; over ${Math.round(limits.topShare * 100)}% fails)`);
  if (f.uniformShare >= limits.uniformShare) why.push(`${Math.round(f.uniformShare * 100)}% of it is featureless (over ${Math.round(limits.uniformShare * 100)}% fails)`);
  if (f.emptyRect >= limits.emptyRect) why.push(`one featureless area covers ${Math.round(f.emptyRect * 100)}% of the screen (over ${Math.round(limits.emptyRect * 100)}% fails)`);
  return why;
}

/** One line for the report: the numbers, and the hint when the frame is flat */
export function flatText(f: FlatFrame): string {
  const nums = `top colour ${Math.round(f.topShare * 100)}% (${f.topColor}), ${f.levels}/32 lightness levels, ${Math.round(f.uniformShare * 100)}% featureless, the largest featureless area ${Math.round(f.emptyRect * 100)}%`;
  return f.hint ? `${f.hint} (${nums})` : `looks fine: ${nums}`;
}

/** A screenshot's pixels, scaled down in the page to at most `maxW` px wide (decoded there: no PNG code in Node) */
export async function framePixels(page: Page, png: Buffer, maxW = 320): Promise<{ w: number; h: number; data: number[] }> {
  return page.evaluate(
    async ({ b64, maxW }) => {
      const bin = atob(b64);
      const u8 = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
      const bmp = await createImageBitmap(new Blob([u8], { type: 'image/png' }));
      const k = Math.min(1, maxW / bmp.width);
      const w = Math.max(1, Math.round(bmp.width * k));
      const h = Math.max(1, Math.round(bmp.height * k));
      const c = new OffscreenCanvas(w, h);
      const g = c.getContext('2d', { willReadFrequently: true })!;
      g.imageSmoothingQuality = 'high';
      g.drawImage(bmp, 0, 0, w, h);
      return { w, h, data: Array.from(g.getImageData(0, 0, w, h).data) };
    },
    { b64: png.toString('base64'), maxW },
  );
}

/**
 * A screenshot's pixels under each box (CSS px of the viewport), each scaled down to at most `maxSide` px a side (RGBA,
 * decoded in the page); a box off the screen gives an empty array
 */
export async function boxPixels(page: Page, png: Buffer, boxes: readonly { x: number; y: number; w: number; h: number }[], maxSide = 48): Promise<number[][]> {
  if (!boxes.length) return [];
  return page.evaluate(
    async ({ b64, boxes, maxSide }) => {
      const bin = atob(b64);
      const u8 = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
      const bmp = await createImageBitmap(new Blob([u8], { type: 'image/png' }));
      const k = bmp.width / innerWidth;
      const c = new OffscreenCanvas(maxSide, maxSide);
      const g = c.getContext('2d', { willReadFrequently: true })!;
      // Nearest pixels, not blends: a glyph's colour and the background's stay apart
      g.imageSmoothingEnabled = false;
      return boxes.map((b) => {
        const x0 = Math.max(0, Math.floor(b.x * k));
        const y0 = Math.max(0, Math.floor(b.y * k));
        const x1 = Math.min(bmp.width, Math.ceil((b.x + b.w) * k));
        const y1 = Math.min(bmp.height, Math.ceil((b.y + b.h) * k));
        if (x1 - x0 < 1 || y1 - y0 < 1) return [];
        const s = Math.min(1, maxSide / Math.max(x1 - x0, y1 - y0));
        const w = Math.max(1, Math.round((x1 - x0) * s));
        const h = Math.max(1, Math.round((y1 - y0) * s));
        g.clearRect(0, 0, maxSide, maxSide);
        g.drawImage(bmp, x0, y0, x1 - x0, y1 - y0, 0, 0, w, h);
        return Array.from(g.getImageData(0, 0, w, h).data);
      });
    },
    { b64: png.toString('base64'), boxes: boxes.map((b) => ({ x: b.x, y: b.y, w: b.w, h: b.h })), maxSide },
  );
}

export async function flatFrameOf(page: Page, png: Buffer): Promise<FlatFrame> {
  const { w, h, data } = await framePixels(page, png);
  return flatFrame(data, w, h);
}
