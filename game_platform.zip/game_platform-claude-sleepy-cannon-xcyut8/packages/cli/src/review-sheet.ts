// The calibrated look of `gp review`: qa/review-sheet.png, the game's own desktop frames beside what CrazyGames approved
// and rejected.
//
// Our second-agent reviews passed games the portal then rejected for "the overall quality" (Swarm Smash 0 blocking /
// 0 nice, Velvet Domino Rogue 0 / 14, Candle Crypt 1.7.2 0 blocking — publisher/results.yaml): the brief measured
// compliance with a checklist, not how the game looks next to the games the portal takes. So the review starts from a
// picture: the game's first screen, two moments of play and a meta screen at 1280×720 (DPR 1, as the portal's QA sees
// it on a desktop), its cover, and under them 3 approved and 2 rejected shots of our own games
// (publisher/reference/index.yaml). The reviewer scores each of the game's screens 1–5 for "would sit on CrazyGames'
// front page next to these" in quality.md's `## Scores`; a score below PASS_SCORE (review.ts) is a [blocking] finding.
//
//   games/<id>/qa/review-title.png, review-play-1.png, review-play-2.png   captured here (the dev build, a virtual clock,
//                                                                          ?seed=1, the game's demo bot), 1280×720
//   games/<id>/qa/review-sheet.png                                          the sheet

import { existsSync, mkdirSync, readFileSync, readdirSync, statSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import type { Browser, Page } from 'playwright';
import { loadYaml, type ResolvedGame } from '@gp/spec';
import { ROOT, type GameLocation } from './paths.ts';
import { sameness, type Sameness } from './sameness.ts';

export const REFERENCE_DIR = join(ROOT, 'publisher/reference');
export const REFERENCE_INDEX = join(REFERENCE_DIR, 'index.yaml');
export const SHEET_FILE = 'review-sheet.png';
/** The size the portal's QA first sees a game at, and every frame of the sheet */
export const SHEET_W = 1280;
export const SHEET_H = 720;
/** At most this many approved shots in the platform (they are committed: small, few, the best of what we have) */
export const MAX_APPROVED = 12;
export const MAX_REFERENCE_BYTES = 100_000;

export type ScreenKind = 'title' | 'play' | 'meta';

export interface ReferenceShot {
  /** Under publisher/reference/ */
  file: string;
  /** The game's id in publisher/results.yaml */
  game: string;
  title: string;
  version: string;
  /** The commit of the previews repository the build came from */
  preview: string;
  outcome: 'approved' | 'rejected';
  /** The portal's answer */
  date: string;
  genre: string;
  screen: ScreenKind;
  shows: string;
  /** Absolute path */
  path: string;
}

const KINDS: ScreenKind[] = ['title', 'play', 'meta'];

/** publisher/reference/index.yaml, checked: what is wrong is said, not thrown */
export function loadReferences(file = REFERENCE_INDEX): { refs: ReferenceShot[]; problems: string[] } {
  if (!existsSync(file)) return { refs: [], problems: [`${file} is missing`] };
  const loaded = loadYaml(readFileSync(file, 'utf8'));
  const problems: string[] = loaded.issues.map((i) => i.message);
  const list = (loaded.data as { references?: unknown })?.references;
  if (!Array.isArray(list)) return { refs: [], problems: [...problems, 'no `references:` list'] };
  const refs: ReferenceShot[] = [];
  list.forEach((raw, i) => {
    const r = raw as Partial<ReferenceShot>;
    const at = `references[${i}]`;
    for (const k of ['file', 'game', 'title', 'version', 'preview', 'date', 'genre', 'shows'] as const)
      if (typeof r[k] !== 'string' || !r[k]) problems.push(`${at}: \`${k}\` is missing`);
    if (r.outcome !== 'approved' && r.outcome !== 'rejected') problems.push(`${at}: outcome "${String(r.outcome)}" is not approved or rejected`);
    if (!KINDS.includes(r.screen as ScreenKind)) problems.push(`${at}: screen "${String(r.screen)}" is not ${KINDS.join(', ')}`);
    if (typeof r.file === 'string') refs.push({ ...(r as ReferenceShot), path: join(REFERENCE_DIR, r.file) });
  });
  return { refs, problems };
}

/**
 * The references the sheet shows: 3 approved (a title, a play, a meta shot) and 2 rejected (a title, a play), each of a
 * different game, the game's own genre first. Deterministic: the index's order breaks ties. A game of the index is not
 * left out: a resubmission is shown its own approved and rejected looks, the comparison that matters most then.
 */
export function pickReferences(refs: readonly ReferenceShot[], genre: string | null): { approved: ReferenceShot[]; rejected: ReferenceShot[] } {
  const pick = (outcome: ReferenceShot['outcome'], kinds: ScreenKind[]) => {
    const pool = refs
      .map((r, i) => ({ r, i }))
      .filter(({ r }) => r.outcome === outcome && existsSync(r.path))
      .sort((a, b) => Number(b.r.genre === genre) - Number(a.r.genre === genre) || a.i - b.i)
      .map(({ r }) => r);
    // The rarest kind is placed first (one meta shot must not lose its game to a title), then shown in the asked order
    const order = kinds.map((k, i) => ({ k, i })).sort((a, b) => pool.filter((x) => x.screen === a.k).length - pool.filter((x) => x.screen === b.k).length || a.i - b.i);
    const out: { r: ReferenceShot; i: number }[] = [];
    const used = new Set<string>();
    for (const { k, i } of order) {
      const r = pool.find((x) => x.screen === k && !used.has(x.game)) ?? pool.find((x) => !used.has(x.game));
      if (!r) break;
      out.push({ r, i });
      used.add(r.game);
    }
    return out.sort((a, b) => a.i - b.i).map((x) => x.r);
  };
  return { approved: pick('approved', ['title', 'play', 'meta']), rejected: pick('rejected', ['title', 'play']) };
}

// --- The game's own frames ------------------------------------------------------------------------------------------

/** The game's screens the reviewer scores, in quality.md's `## Scores` (review.ts) */
export const SCORED_SCREENS = ['title', 'play-1', 'play-2', 'meta'] as const;
export type ScoredScreen = (typeof SCORED_SCREENS)[number];

export interface SheetCell {
  /** title, play-1, play-2, meta, cover */
  id: ScoredScreen | 'cover';
  /** What the frame is, for the caption */
  label: string;
  file: string | null;
  /** Why it is missing, or where it came from */
  note: string;
}

const list = (dir: string) => (existsSync(dir) ? readdirSync(dir).filter((f) => statSync(join(dir, f)).isFile()) : []);

/** A meta screen: the progression the game declares to QA (shop, upgrades, map…), else the results */
const META_NAME = /shop|upgrade|meta|map|unlock|roster|loom|tree|pact|collection|album|armory|armoury|hangar|salon|workshop|bureau|garage|level|night|depth|stage|site|codex|journal|chassis|season|skill|perk|deck|relic|inventory|observatory|cards?$/i;
const NOT_META = /^(title|paused?|settings|lang.*|ouch|welcome.*|tutorial|how.*|credits|loading)$/i;

/**
 * The game's frames for the sheet: the captured ones first, then what the last `gp qa` left at 1280×720 — the declared
 * title screen, the desktop play frame, a meta screen (a declared shop/upgrade/map screen, else the results) — and the
 * landscape cover.
 */
export function gameCells(loc: GameLocation, captured: Partial<Record<'first' | 'play-1' | 'play-2', string>> = {}): SheetCell[] {
  const qa = join(loc.dir, 'qa');
  const files = list(qa);
  const at = (f: string | undefined) => (f && files.includes(f) ? join(qa, f) : null);
  const screens = files.map((f) => f.match(/^screen-(.+)-desktop-1280x720\.png$/)?.[1]).filter((x): x is string => !!x);
  const title = at('screen-title-desktop-1280x720.png');
  const first = captured.first ?? at('desktop-1280x720-1-first-screen.png');
  const metaName = screens.find((s) => META_NAME.test(s) && !NOT_META.test(s)) ?? null;
  const results = at('screen-results-desktop-1280x720.png') ?? at('desktop-1280x720-3-results.png');
  const otherName = screens.find((s) => !NOT_META.test(s)) ?? null;
  const meta = metaName ? at(`screen-${metaName}-desktop-1280x720.png`) : results ?? (otherName ? at(`screen-${otherName}-desktop-1280x720.png`) : null);
  const cover = ['cover-landscape-1920x1080.png'].map((f) => join(loc.dir, 'store', f)).find((f) => existsSync(f)) ?? null;
  const qaPlay = at('desktop-1280x720-2-play.png');
  return [
    title
      ? { id: 'title', label: 'title', file: title, note: 'the declared title screen (gp qa: screen-title-desktop-1280x720.png)' }
      : { id: 'title', label: 'first screen', file: first, note: first ? (captured.first ? 'a fresh save, as the portal opens it (gp review)' : 'gp qa: desktop-1280x720-1-first-screen.png') : 'not captured: no title screen at 1280×720 — run gp qa, or gp review without --no-capture' },
    { id: 'play-1', label: 'play, early', file: captured['play-1'] ?? qaPlay, note: captured['play-1'] ? '5 s into the demo run (gp review)' : qaPlay ? 'gp qa: desktop-1280x720-2-play.png' : 'not captured' },
    { id: 'play-2', label: 'play, later', file: captured['play-2'] ?? null, note: captured['play-2'] ? '20 s into the demo run (gp review)' : 'not captured: gp review captures it (the dev build and the demo bot) — run it without --no-capture' },
    {
      id: 'meta',
      label: metaName ? `meta: ${metaName}` : meta === results && results ? 'meta: results' : otherName ? `meta: ${otherName}` : 'meta',
      file: meta,
      note: meta ? 'gp qa (a declared screen at 1280×720)' : 'not captured: no shop, upgrade, map or results screen at 1280×720 — declare it in host.qa({ screens }) and run gp qa',
    },
    { id: 'cover', label: 'cover', file: cover, note: cover ? 'store/cover-landscape-1920x1080.png' : 'no cover yet: gp covers' },
  ];
}

/** A fresh player's run on the dev build, driven on the virtual clock (gp review's frames and its first look) */
export interface FreshRun {
  page: Page;
  /** Advance the virtual clock by `sec` seconds, in 30 fps frames */
  step(sec: number): Promise<void>;
  /** Seconds of virtual time since the page loaded */
  now(): number;
  /** Whether the host says the run is in play (true when the game doesn't say) */
  playing(): Promise<boolean>;
}

/**
 * Open the game at 1280×720 from a fresh save — the dev build on a virtual clock with ?seed=1, as `gp video` films, so two
 * runs give the same frames — and wait for its first screen (Play visible, at most 8 s). `first` is called on it; then
 * Play is tapped and the game's demo bot (host.qa({ demo })) switched on, and `play` is called. Without a demo bot the run
 * plays itself untouched (a problem says so: the frames may show an idle start).
 */
export async function freshRun(loc: GameLocation, first: (r: FreshRun) => Promise<void>, play: (r: FreshRun) => Promise<void>): Promise<{ problems: string[] }> {
  const { chromium } = await import('playwright');
  const { startDev } = await import('./vite.ts');
  const { advanceClock, virtualClock } = await import('./clock.ts');
  const { PLAY_SELECTOR } = await import('./video.ts');
  const problems: string[] = [];
  const server = await startDev(loc, undefined, { frozen: true });
  const url = server.resolvedUrls?.local[0] ?? 'http://localhost:5173/';
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  try {
    const page = await browser.newPage({ viewport: { width: SHEET_W, height: SHEET_H }, deviceScaleFactor: 1 });
    await page.addInitScript(virtualClock);
    await page.goto(`${url}?seed=1`);
    let frames = 0;
    const tick = async () => {
      await advanceClock(page, 1000 / 30);
      frames++;
    };
    const run: FreshRun = {
      page,
      step: async (sec) => {
        for (let i = 0; i < Math.round(sec * 30); i++) await tick();
      },
      now: () => frames / 30,
      playing: () => page.evaluate(() => (window as unknown as { __gp?: { host?: { isPlaying?: boolean } } }).__gp?.host?.isPlaying !== false),
    };
    const visible = () =>
      page.evaluate((q) => {
        const e = document.querySelector<HTMLElement>(q);
        if (!e) return false;
        const r = e.getBoundingClientRect();
        return r.width > 0 && r.height > 0 && getComputedStyle(e).visibility !== 'hidden' && getComputedStyle(e).display !== 'none';
      }, PLAY_SELECTOR);
    let canPlay = false;
    for (let i = 0; i < 30 * 8 && !(canPlay = await visible()); i++) await tick();
    await run.step(0.5);
    await first(run);
    if (canPlay) {
      const box = await page.locator(PLAY_SELECTOR).first().boundingBox().catch(() => null);
      if (box) await page.mouse.click(box.x + box.width / 2, box.y + box.height / 2);
    }
    const demo = await page.evaluate(() => {
      const d = (window as unknown as { __gp?: { host?: { qaDriver?: { demo?: () => void } } } }).__gp?.host?.qaDriver;
      if (typeof d?.demo !== 'function') return false;
      d.demo();
      return true;
    });
    if (!demo) problems.push('no demo bot (host.qa({ demo })): the play frames show the run untouched');
    await play(run);
    await page.close();
  } finally {
    await browser.close();
    await server.close();
  }
  return { problems };
}

/**
 * Capture the game at 1280×720 from a fresh save (freshRun): the first screen (before Play), then — Play tapped, the
 * demo bot on — 5 s and 20 s into the run.
 */
export async function captureFrames(loc: GameLocation, outDir: string): Promise<{ files: Partial<Record<'first' | 'play-1' | 'play-2', string>>; problems: string[] }> {
  mkdirSync(outDir, { recursive: true });
  const files: Partial<Record<'first' | 'play-1' | 'play-2', string>> = {};
  const extra: string[] = [];
  const { problems } = await freshRun(
    loc,
    async ({ page }) => {
      files.first = join(outDir, 'review-title.png');
      await page.screenshot({ path: files.first });
    },
    async ({ page, step, playing }) => {
      await step(5);
      files['play-1'] = join(outDir, 'review-play-1.png');
      await page.screenshot({ path: files['play-1'] });
      // The later frame is the last one still in play (a results card or a lost run is not a play frame: Hang the Moon's
      // "Night 1" card was scored as play-2 in the blind calibration of 2026-10-19)
      files['play-2'] = join(outDir, 'review-play-2.png');
      let shot: Buffer | null = null;
      let at = 5;
      for (let s = 0; s < 15; s++) {
        await step(1);
        if (!(await playing())) break;
        shot = await page.screenshot();
        at = 6 + s;
      }
      if (shot) writeFileSync(files['play-2'], shot);
      else await page.screenshot({ path: files['play-2'] });
      if (at < 20) extra.push(`play ended ${at} s into the demo run: play-2 is the last frame still in play (${at} s), not 20 s`);
    },
  );
  return { files, problems: [...problems, ...extra] };
}

/** The sheet as an HTML page: the game's row, then the references' row, every picture captioned */
export function sheetHtml(title: string, cells: readonly SheetCell[], refs: { approved: readonly ReferenceShot[]; rejected: readonly ReferenceShot[] }, img: (file: string) => string, others: Sameness['row'] = []): string {
  const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;');
  const short = (v: string) => v.replace(/\s*\(.*$/, '');
  const cell = (src: string | null, head: string, sub: string, cls: string) =>
    `<figure class="${cls}">${src ? `<img src="${img(src)}">` : `<div class="none">${esc(sub)}</div>`}<figcaption><b>${esc(head)}</b>${src ? `<span>${esc(sub)}</span>` : ''}</figcaption></figure>`;
  const game = cells.map((c) => cell(c.file, c.id === 'cover' ? 'cover (not scored here: gp covers)' : `${c.id} · ${c.label}`, c.file ? c.note : c.note, 'game')).join('');
  const ref = [
    ...refs.approved.map((r) => cell(r.path, `APPROVED · ${r.title} ${short(r.version)}`, `${r.date} · ${r.screen} · ${r.genre}`, 'ok')),
    ...refs.rejected.map((r) => cell(r.path, `REJECTED (overall quality) · ${r.title} ${short(r.version)}`, `${r.date} · ${r.screen} · ${r.genre}`, 'no')),
  ].join('');
  const near = (m: Sameness['row'][number]['best']) => (m ? `closest to this game's ${m.screen}: colour ${m.sim.colour} · layout ${m.sim.layout}${m.closeness ? ` — ${m.closeness.toUpperCase()}` : ''}` : '');
  const own = others.slice(0, OTHERS_SHOWN).map((o) => cell(o.other.file, `${o.other.title} · ${o.other.screen}`, near(o.best), o.best?.closeness === 'very close' ? 'same' : 'other')).join('');
  return `<!doctype html><meta charset="utf-8"><style>
    body { margin: 0; padding: 16px; background: #15171c; color: #e8e8ea; font: 15px/1.35 system-ui, sans-serif; width: max-content; }
    h1 { font-size: 20px; margin: 0 0 4px; } p { margin: 0 0 14px; color: #b8bcc6; max-width: 2400px; }
    h2 { font-size: 15px; margin: 14px 0 6px; color: #9aa0aa; text-transform: uppercase; letter-spacing: .06em; }
    .row { display: grid; grid-template-columns: repeat(5, 480px); gap: 12px; }
    figure { margin: 0; } img, .none { display: block; width: 480px; height: 270px; object-fit: contain; background: #000; outline: 2px solid #333; }
    .none { display: flex; align-items: center; justify-content: center; text-align: center; padding: 0 24px; box-sizing: border-box; color: #8a8f99; background: #23262d; }
    figcaption { padding: 5px 2px 0; } figcaption b { display: block; font-size: 14px; } figcaption span { color: #9aa0aa; font-size: 13px; }
    .game img { outline-color: #4a6fa5; } .ok img { outline: 3px solid #2e8b57; } .ok b { color: #6fd39b; } .no img { outline: 3px solid #b3261e; } .no b { color: #ff8a80; }
    .other img { outline-color: #6b6f78; } .same img { outline: 3px solid #e0a020; } .same span { color: #ffc861; }
  </style><h1>${esc(title)} — review sheet</h1>
  <p>Would each of this game's screens sit on CrazyGames' front page next to the approved ones? Score title, play-1, play-2 and meta 1–5 in quality.md (## Scores) with a reason; below 3 is a [blocking] finding. Every frame 1280×720 at DPR 1, the desktop the portal's QA plays first. The references are our own games: the portal approved the green ones, rejected the red ones for "the overall quality" (publisher/reference/index.yaml).</p>
  <h2>This game</h2><div class="row">${game}</div>
  <h2>CrazyGames' answers on our games</h2><div class="row">${ref}</div>${own ? `
  <h2>Our other games — closest first (sameness: a screen very close to another game's is outlined amber)</h2><div class="row">${own}</div>` : ''}`;
}

export interface ReviewSheet {
  /** qa/review-sheet.png, or null when it could not be composed */
  file: string | null;
  cells: SheetCell[];
  approved: ReferenceShot[];
  rejected: ReferenceShot[];
  /** This game's title, results and language screens against our other games' (sameness.ts) */
  sameness?: Sameness | null;
  /** What went wrong or is missing (the sheet is still made when it can be) */
  problems: string[];
}

/** How many of our other games' titles the sheet's last row shows */
export const OTHERS_SHOWN = 5;

/** Capture the game's frames (unless `capture: false`), pick the references and compose qa/review-sheet.png */
export async function buildReviewSheet(loc: GameLocation, game: Pick<ResolvedGame, 'title' | 'money'> & Partial<Pick<ResolvedGame, 'id'>>, opts: { capture?: boolean } = {}): Promise<ReviewSheet> {
  const qa = join(loc.dir, 'qa');
  mkdirSync(qa, { recursive: true });
  const problems: string[] = [];
  let captured: Partial<Record<'first' | 'play-1' | 'play-2', string>> = {};
  if (opts.capture !== false) {
    try {
      const c = await captureFrames(loc, qa);
      captured = c.files;
      problems.push(...c.problems);
    } catch (e) {
      problems.push(`capture failed: ${String((e as Error).message).split('\n')[0]} — the sheet uses the last gp qa's screenshots`);
    }
  }
  const cells = gameCells(loc, captured);
  const { refs, problems: refProblems } = loadReferences();
  problems.push(...refProblems.map((p) => `publisher/reference/index.yaml: ${p}`));
  const picked = pickReferences(refs, game.money?.genre ?? null);
  const file = join(qa, SHEET_FILE);
  let same: Sameness | null = null;
  try {
    const { chromium } = await import('playwright');
    const browser: Browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
    try {
      // The previews are captured with the frames (a run without --no-capture); otherwise only what the cache has
      try {
        same = await sameness(browser, loc, { id: game.id ?? loc.id, title: game.title }, refs, { capturedTitle: captured.first ?? null, capturePreviews: opts.capture !== false });
      } catch (e) {
        problems.push(`sameness not compared: ${String((e as Error).message).split('\n')[0]}`);
      }
      const page = await browser.newPage({ viewport: { width: 2500, height: 800 }, deviceScaleFactor: 1 });
      const mime = (f: string) => (f.endsWith('.png') ? 'image/png' : 'image/jpeg');
      await page.setContent(sheetHtml(game.title, cells, picked, (f) => `data:${mime(f)};base64,${readFileSync(f).toString('base64')}`, same?.row ?? []));
      await page.waitForFunction(() => [...document.images].every((i) => i.complete), null, { timeout: 30000 });
      await page.screenshot({ path: file, fullPage: true });
      await page.close();
    } finally {
      await browser.close();
    }
    return { file, cells, ...picked, sameness: same, problems };
  } catch (e) {
    problems.push(`the sheet was not composed: ${String((e as Error).message).split('\n')[0]}`);
    return { file: null, cells, ...picked, sameness: same, problems };
  }
}
