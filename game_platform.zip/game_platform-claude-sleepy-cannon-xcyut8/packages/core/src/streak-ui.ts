// The daily reward card: the week's dots, today's reward to claim, tomorrow's reward (the reason to come back). A
// modal over whatever is on screen, one screen at every size (seven dots in a row on a 360 px phone, no scrolling), a
// close button, the platform's words in the player's language (gp.streak.*). It opens only when the streak says so —
// never before the player's first play, never twice a day — and never says what was missed (D56).
//
//   const streak = dailyStreak(save, { reward: (d) => 50 * d, persist: () => host.save(save) });
//   mountStreakCard(ui, streak, { host, icon: icon('gem', { style: 'solid', color: '#7fe0ff' }), onClaim: (n) => { save.coins += n; host.save(save); } });
//
// The marks are drawn (@gp/core/icons): the currency (default a gold coin), the check of a claimed day, the close ×.
// Themeable: screenTheme() for every platform screen at once, or --gp-streak-bg, -ink, -muted, -accent, -accent-ink,
// -dot, -radius, -font on #gp-streak.

import { cardOpened } from './cards.ts';
import type { GameHost } from './host.ts';
import { FONT_FALLBACK } from './i18n.ts';
import { icon as drawn } from './icons.ts';
import { DEFAULT_CURRENCY, ICON_AT, screenIcon, setIconText, type ScreenIcon } from './screen-icon.ts';
import type { DailyStreak, StreakState } from './streak.ts';
import { formatAmount } from './upgrades.ts';

/** The card's words (default: the platform's gp.streak.* in the player's language) */
export interface StreakTexts {
  title: string;
  /** "Day 3" */
  day: (n: number) => string;
  /** The claim button: "Claim 🪙 150" */
  claim: (reward: string) => string;
  /** The button after the claim */
  claimed: string;
  /** "Tomorrow: 🪙 200" */
  tomorrow: (reward: string) => string;
}

export interface StreakCardOptions {
  host: Pick<GameHost, 'minTouchPx' | 'screen' | 't'>;
  /** Today's reward was claimed: pay it (and save) */
  onClaim(amount: number): void;
  /** The card was closed (× or a tap outside) */
  onClose?(): void;
  /**
   * The currency before every amount (default the platform's drawn coin): a drawn icon (icon('gem') from
   * @gp/core/icons, iconImg() from @gp/art/dom), a function that makes one, an image URL, text, or '' for none
   */
  icon?: ScreenIcon;
  /** How an amount reads (default formatAmount: 1.23K) */
  format?: (n: number) => string;
  texts?: Partial<StreakTexts>;
  /** Open even when there is nothing to claim (a look at the week from a menu); never before the first play */
  force?: boolean;
}

const CSS = `
:where(#gp-streak) { --gp-streak-bg: var(--gp-theme-bg, #18263a); --gp-streak-ink: var(--gp-theme-ink, #f2f7ff);
  --gp-streak-muted: var(--gp-theme-muted, #a9b9cc); --gp-streak-accent: var(--gp-theme-accent, #ffd166);
  --gp-streak-accent-ink: var(--gp-theme-accent-ink, #18222e); --gp-streak-dot: var(--gp-theme-panel, rgba(255, 255, 255, 0.08));
  --gp-streak-radius: var(--gp-theme-radius, 20px); --gp-streak-font: var(--gp-theme-font, ${FONT_FALLBACK}); }
#gp-streak-veil { position: fixed; inset: 0; z-index: 40; display: flex; align-items: center; justify-content: center; background: var(--gp-theme-backdrop, rgba(0, 0, 0, 0.45)); }
#gp-streak { position: relative; box-sizing: border-box; width: min(92vw, 440px); max-height: 92vh; display: flex; flex-direction: column;
  gap: 12px; padding: 20px 8px 16px; border-radius: var(--gp-streak-radius); background: var(--gp-streak-bg); color: var(--gp-streak-ink);
  font: 600 16px var(--gp-streak-font); text-align: center; }
#gp-streak h2 { margin: 0 36px; font-size: 26px; line-height: 1.15; font-family: var(--gp-theme-display, inherit); }
#gp-streak .gp-s-dots { display: flex; flex-wrap: wrap; justify-content: center; gap: 2px; }
#gp-streak .gp-s-dot { box-sizing: border-box; flex: 1 1 0; min-width: 34px; max-width: 58px; padding: 5px 0; border-radius: 12px;
  background: var(--gp-streak-dot); display: flex; flex-direction: column; align-items: center; gap: 2px; border: 2px solid transparent; }
#gp-streak .gp-s-dot small { font-size: 12px; line-height: 1.1; letter-spacing: -0.02em; color: var(--gp-streak-muted); overflow-wrap: anywhere; }
#gp-streak .gp-s-dot b { font-size: 12px; letter-spacing: -0.02em; font-variant-numeric: tabular-nums; white-space: nowrap; }
#gp-streak .gp-s-dot i { font-style: normal; font-size: 14px; line-height: 1; height: 18px; display: flex; align-items: center; justify-content: center; }
#gp-streak .gp-s-dot i svg, #gp-streak .gp-s-dot i img { width: 18px; height: 18px; vertical-align: 0; }
#gp-streak .gp-s-dot i .gp-s-pip { width: 6px; height: 6px; border-radius: 50%; background: currentColor; }#gp-streak .gp-s-dot[data-state=claimed] { opacity: 0.75; }
#gp-streak .gp-s-dot[data-state=claimed] i { color: var(--gp-streak-accent); }
#gp-streak .gp-s-dot[data-current] { border-color: var(--gp-streak-accent); }
#gp-streak .gp-s-line { color: var(--gp-streak-muted); }
#gp-streak button.gp-s-claim { min-width: 0; margin: 0; text-transform: none; border: 0; border-radius: 999px; cursor: pointer;
  background: var(--gp-streak-accent); color: var(--gp-streak-accent-ink); font: 800 21px var(--gp-theme-display, var(--gp-streak-font)); padding: 0 20px; }
#gp-streak button.gp-s-claim svg { margin-left: 0.25em; }
#gp-streak button.gp-s-claim[aria-disabled=true] { cursor: default; opacity: 0.6; }
#gp-streak button.gp-s-x { position: absolute; min-width: 0; padding: 0; margin: 0; top: 6px; right: 6px; border: 0; background: transparent;
  color: var(--gp-streak-muted); font: 700 24px var(--gp-streak-font); cursor: pointer; display: flex; align-items: center; justify-content: center; }
@media (max-height: 520px) { #gp-streak { gap: 6px; padding: 12px 14px 10px; } #gp-streak h2 { font-size: 21px; } }
`;

/** The platform's words for the card in the player's language */
export function streakTexts(t: (key: string, params?: Record<string, string | number>) => string): StreakTexts {
  return {
    title: t('gp.streak.title'),
    day: (n) => t('gp.streak.day', { n }),
    claim: (reward) => t('gp.streak.claim', { reward }),
    claimed: t('gp.streak.claimed'),
    tomorrow: (reward) => t('gp.streak.tomorrow', { reward }),
  };
}

/**
 * The claim card, open now in `root` (a modal veil; null: document.body) — or null when the streak has nothing to show
 * (before the first play, or claimed today without `force`). host.screen('streak'). Returns close() for the game; it
 * closes itself on × and a tap outside
 */
export function mountStreakCard(root: HTMLElement | null, streak: DailyStreak, opts: StreakCardOptions): { el: HTMLElement; close(): void } | null {
  const first = streak.state();
  if (!streak.log.played || (!first.show && !opts.force)) return null;
  const { host } = opts;
  if (!document.getElementById('gp-streak-css')) {
    const style = document.createElement('style');
    style.id = 'gp-streak-css';
    style.textContent = CSS;
    document.head.append(style);
  }
  const words: StreakTexts = { ...streakTexts((k, p) => host.t(k, p)), ...opts.texts };
  const cur: ScreenIcon | null = opts.icon === '' ? null : (opts.icon ?? DEFAULT_CURRENCY);
  const fmt = opts.format ?? ((n: number) => formatAmount(n));
  // The icon's place in the translated words ("Claim {reward}"), filled with the drawn icon by setIconText
  const amount = (n: number) => (cur ? `${ICON_AT}\u00a0${fmt(n)}` : fmt(n));

  document.getElementById('gp-streak-veil')?.remove();
  const veil = document.createElement('div');
  veil.id = 'gp-streak-veil';
  const card = document.createElement('section');
  card.id = 'gp-streak';
  card.dataset.gp = 'streak';
  card.setAttribute('role', 'dialog');
  card.setAttribute('aria-modal', 'true');
  card.setAttribute('aria-label', words.title);
  const h = document.createElement('h2');
  h.textContent = words.title;
  const dots = document.createElement('div');
  dots.className = 'gp-s-dots';
  dots.dataset.gp = 'streak-dots';
  const line = document.createElement('div');
  line.className = 'gp-s-line';
  line.dataset.gp = 'streak-tomorrow';
  const claim = document.createElement('button');
  claim.type = 'button';
  claim.className = 'gp-s-claim';
  claim.dataset.gp = 'streak-claim';
  claim.style.minHeight = `${Math.max(56, host.minTouchPx * 1.2)}px`;
  const x = document.createElement('button');
  x.type = 'button';
  x.className = 'gp-s-x';
  x.dataset.gp = 'streak-close';
  x.append(drawn('close', { size: 22, stroke: 2.4 }));
  x.setAttribute('aria-label', host.t('gp.back'));
  x.style.minWidth = x.style.minHeight = `${host.minTouchPx}px`;

  const draw = (s: StreakState) => {
    dots.replaceChildren(
      ...s.dots.map((d) => {
        const e = document.createElement('div');
        e.className = 'gp-s-dot';
        e.dataset.state = d.state;
        if (d.current) e.dataset.current = '';
        const label = document.createElement('small');
        label.textContent = words.day(d.day);
        const mark = document.createElement('i');
        if (d.state === 'claimed') mark.append(drawn('check', { stroke: 3 }));
        else if (cur) mark.append(screenIcon(cur));
        else mark.append(Object.assign(document.createElement('span'), { className: 'gp-s-pip' }));
        mark.setAttribute('aria-hidden', 'true');
        const r = document.createElement('b');
        r.textContent = fmt(d.reward);
        e.append(label, mark, r);
        return e;
      }),
    );
    if (s.canClaim) {
      setIconText(claim, words.claim(amount(s.reward)), cur);
      claim.removeAttribute('aria-disabled');
    } else {
      claim.textContent = words.claimed;
      claim.append(drawn('check', { stroke: 2.8 }));
      claim.setAttribute('aria-disabled', 'true');
    }
    setIconText(line, words.tomorrow(amount(s.tomorrow.reward)), cur);
  };
  draw(first);
  card.append(h, dots, claim, line, x);
  veil.append(card);

  let open = true;
  let closed = () => {};
  const close = () => {
    if (!open) return;
    open = false;
    veil.remove();
    closed();
  };
  claim.addEventListener('click', () => {
    const paid = streak.claim();
    if (paid === null) return;
    opts.onClaim(paid);
    draw(streak.state());
  });
  const dismiss = () => {
    close();
    opts.onClose?.();
  };
  x.addEventListener('click', dismiss);
  veil.addEventListener('click', (e) => {
    if (e.target === veil) dismiss();
  });
  (root ?? document.body).append(veil);
  closed = cardOpened('streak', veil); // one card at a time (cards.ts)
  host.screen('streak');
  return { el: card, close };
}
