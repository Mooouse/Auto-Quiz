// The balance model: the designer's spreadsheet, in code. A game describes its economy as tables (the stages with their
// difficulty, reward and length; the purchases with their price and what they add) and the platform walks a player
// through them in expected values: no randomness, no game code, milliseconds. Out come the tables a designer reads
// (power against difficulty on arrival at every stage, the attempts and the farming it takes, when each purchase is
// affordable), the checks (walls, grind, stretches that play themselves, dominant or dead purchases, curves that fall;
// the first session's pacing, the shape of the difficulty, what the player has at the session's end) and a
// BalanceReport, so `gp balance` and `gp qa` read the model like a bot's campaign. The bot then confirms the
// model on the real game; the model is how you get the numbers right before that (docs/guides/upgrades.md → the model).
//
// Pure, no imports but the balance contract: Node runs it as is.

import type { BalanceReport, BalanceRow, BalanceStatus, BuyerCurve, DifficultyTarget } from './balance.ts';

/**
 * What a clear or a purchase brings the player, for the reward timeline and the "big rewards" check. The weight says how
 * big it feels: by default 1 for a stage and an item, 2 for an unlock and a story beat, 3 for a boss; from
 * MODEL_TARGETS.bigNews up it is a big reward
 */
export interface ModelNews {
  kind: 'unlock' | 'stage' | 'boss' | 'story' | 'item';
  weight?: number;
}

/** One step of the progression: a stage, a wave set, a floor, a depth band, a level */
export interface ModelStage {
  id: string;
  /** How hard it is, in the same unit as the player's power (enemy HP × DPS, the depth's score to beat …) */
  difficulty: number;
  /** Coins for a win (a clear) */
  reward: number;
  /** Minutes of play of one attempt */
  minutes: number;
  /** The share of `reward` a lost attempt still pays (default the model's `lossReward`, 0.3) */
  lossReward?: number;
  /**
   * Coins paid once to start it (buying the house to flip, an entry ticket): the player farms the last cleared stage
   * until they can pay it (Secret House Tycoon)
   */
  entry?: number;
  /** Clearing it is a new thing for the player (default true): it counts in the goals curve */
  goal?: boolean;
  /**
   * A deliberate peak (a boss) or dip (a breather): the "difficulty rises" check takes the fall after a boss and at a
   * breather as designed, and the stage-time and hard-streak checks leave bosses out
   */
  kind?: 'boss' | 'breather';
  /** What clearing it brings (default { kind: 'stage' }, a boss { kind: 'boss' }; none when `goal: false`) */
  news?: ModelNews;
}

/** One purchase: an upgrade level, a hero, a weapon, a tier */
export interface ModelItem {
  id: string;
  cost: number;
  /** Power it adds … */
  power?: number;
  /** … or the factor it multiplies the power by (1.2 = +20 %) */
  mult?: number;
  /** For sale only after this stage is cleared (default: from the start) */
  after?: string;
  /** For sale only after this item is bought (the next level of the same upgrade) */
  requires?: string;
  /** Buying it is a new thing for the player (a hero, a weapon — default false: a stat level is not; true with `news`) */
  goal?: boolean;
  /** What buying it brings, when it is news (a goal item without it: { kind: 'unlock' }) */
  news?: ModelNews;
}

export interface BalanceModel {
  /** The player's power and coins on a fresh save */
  start: { power: number; coins?: number };
  stages: readonly ModelStage[];
  items: readonly ModelItem[];
  /**
   * The chance to clear a stage from power / difficulty. Default: a logistic in the log of the ratio,
   * p = r^k / (1 + r^k) — even power wins half the time; `steepness` k (default 4: 1.5× the power wins 84 %, 0.7× 19 %).
   * Fit k to the game's bot with fitWinCurve(), or give the game's own function
   */
  win?: { steepness?: number } | ((ratio: number) => number);
  /** Minutes of menus around each attempt (default 0.25) */
  overheadMin?: number;
  /** The share of the reward a loss pays, for stages that don't say (default 0.3) */
  lossReward?: number;
  /** Below this chance to win the next stage, the player replays the last cleared one for coins (default 0.25) */
  farmBelow?: number;
  /**
   * When the campaign is over: the last stage cleared (default), or that and every item bought. A run-shaped model's
   * meta is its purchases: by default it is over when every item is bought; 'stages' waits for a first win instead
   * (the last stage cleared), 'all' for both
   */
  finish?: 'stages' | 'all';
  /** Give up after this many minutes of play (default 600): the rest is out of reach */
  maxMinutes?: number;
  /** What the power is, in words, for the report ("DPS × HP", "metres a run"): the anchor's name or unit (game.yaml balance.anchor) */
  measure?: string;
  /** Minutes of one session as designed, for the session-end hook (game.yaml money.session.minutes wins) */
  sessionMin?: number;
  /**
   * How the stages are played (game.yaml balance.anchor.shape wins): 'campaign' (default) — a stage at a time, retried
   * until cleared, the last one replayed for coins; 'run' — a roguelite's run: every attempt starts at the first stage
   * and goes on until a loss, the purchases come between runs (the stages are a run's waves, floors or rooms)
   */
  shape?: ModelShape;
  /** shape 'run': the share of a stage's minutes played on the one a run is lost on (default 0.5) */
  deathShare?: number;
}

/** How the stages are played: one at a time until cleared (a campaign), or from the first in every run (a run) */
export type ModelShape = 'campaign' | 'run';

export type ModelBuyer = 'cheapest' | 'best-value';

export interface ModelStageRow {
  id: string;
  difficulty: number;
  reward: number;
  /** Minute of play the player first reached it; null: never */
  arriveMin: number | null;
  arrivePower: number | null;
  /** power / difficulty on arrival */
  ratio: number | null;
  /** The chance to clear it on arrival */
  winOnArrival: number | null;
  /** Expected attempts it took (purchases between attempts included) */
  attempts: number | null;
  /** Minutes spent replaying the previous stage for coins before clearing this one */
  farmMin: number;
  clearedMin: number | null;
  /** Coins earned so far when it was cleared */
  coinsEarned: number | null;
}

export interface ModelItemRow {
  id: string;
  cost: number;
  after?: string;
  /** Minute of play it was bought; null: never within the campaign */
  boughtMin: number | null;
  /** The stage the player was on */
  atStage: string | null;
  powerBefore: number | null;
  powerAfter: number | null;
  /** The power it adds per 1 000 coins (value for money: what the best-value buyer maximises) */
  valuePer1k: number | null;
  /** Minutes of the player's income it cost when bought (time to afford from zero) */
  incomeMin: number | null;
}

export interface ModelRun {
  buyer: ModelBuyer;
  stages: ModelStageRow[];
  items: ModelItemRow[];
  firstPurchaseMin: number | null;
  firstPurchaseRun: number | null;
  /** Minutes of each new thing, in order */
  goalsMin: number[];
  /** The first clear or purchase, in minutes of play: the first reward */
  firstRewardMin: number | null;
  /** Every clear and purchase in order: the reward timeline */
  timeline: ModelEvent[];
  finishMin: number | null;
  finishRun: number | null;
  attempts: number;
  farmMin: number;
  /** The power at the end */
  power: number;
  /** Where it got stuck, when it did */
  stuck: string | null;
  /** shape 'run': each run of the walk, in expected values */
  runs?: ModelRunRow[];
}

/** One run of a run-shaped walk (expected values): how far it gets, how long it lasts, what it pays */
export interface ModelRunRow {
  run: number;
  /** Minute of play it starts */
  startMin: number;
  power: number;
  /** Expected stages cleared */
  depth: number;
  /** The chance it clears every stage (a win) */
  win: number;
  minutes: number;
  coins: number;
}

/** A run with a given power, in expected values: depth, the chance to win, minutes, coins */
export interface ModelRunShape {
  power: number;
  depth: number;
  win: number;
  minutes: number;
  coins: number;
}

/** A clear or a purchase on the reward timeline */
export interface ModelEvent {
  min: number;
  id: string;
  what: 'stage' | 'item';
  /** Set when it is news to the player (a stage clear, a goal item), with its weight filled in */
  news?: Required<ModelNews>;
}

/** The walk at one minute of play (atMinute): what the player has, and how far the next goal is */
export interface ModelSnapshot {
  /** The minute asked; the walk's last moment at or before it */
  minute: number;
  walkMin: number;
  /** Stages cleared, of all; the stage the player is on (null: all cleared) and its expected clear progress (0–1) */
  cleared: number;
  stages: number;
  stage: string | null;
  stageShare: number;
  power: number;
  coins: number;
  bought: number;
  items: number;
  /** The next purchase: the cheapest for sale, and the share of its price the player has */
  purchase: { id: string; share: number } | null;
  /** The next goal: of what the player works toward (the stage they are on, the items for sale) the nearest to done */
  goal: { id: string; kind: 'stage' | 'item'; share: number } | null;
  /** The campaign was over before that minute (everything done, or stuck) */
  over: boolean;
}

/**
 * The goal over a window of minutes around the session's end (atMinuteWindow). The walk is read at fixed steps through
 * [minute − window, minute + window], with the stage's progress and the coins growing through each attempt as they do
 * in play, so a small change of an attempt's length moves the numbers a little — not, as one instant did, from just
 * before a clear to just after it (0.8 → 0.85 min an attempt flipped a goal from 6 % to 64 %). The session-end check
 * reads `mean`, the nearest goal's share averaged over the window: the best moment is ≈ 100 % whenever anything is
 * bought or cleared in it, and the median jumps where the shares have a gap (a clear: from 40 % to 95 %)
 */
export interface ModelWindow {
  /** The window, in minutes of play (from clamped at 0) */
  from: number;
  to: number;
  /** The nearest goal's share averaged over the window (0 at a moment with nothing left to reach) */
  mean: number;
  /** The moments the nearest goal was least and furthest reached (walkMin: the minute) */
  worst: ModelSnapshot;
  best: ModelSnapshot;
  /** A moment of the window with nothing left to reach (everything done, or the campaign over) */
  empty: boolean;
}

/** What game.yaml says about the balance (the CLI passes it): the anchor and the design's session and meta */
export interface ModelDesign {
  /** game.yaml balance.anchor: declared, the model's new checks fail like the others; else they only warn. Its shape wins over the model's */
  anchor?: { name: string; unit: string; says?: string; shape?: ModelShape } | null;
  /** game.yaml money.session.minutes (else the model's sessionMin) */
  sessionMin?: number | null;
  /** game.yaml money.meta.minutes */
  metaMin?: number | null;
  /** game.yaml balance.difficulty: the skill ladder's targets (the bot's report is held to them; the model ignores them) */
  difficulty?: DifficultyTarget | null;
}

export interface ModelResult {
  measure: string;
  cheap: ModelRun;
  careful: ModelRun;
  /** Growth of each column from one stage to the next (geometric mean) */
  growth: { difficulty: number | null; reward: number | null; price: number | null };
  checks: BalanceRow[];
  failed: number;
  warned: number;
  /** The anchor is declared: the first-session and difficulty-shape checks fail; without it they warn */
  strict: boolean;
  /** How the stages are played: the campaign's checks, or a run's */
  shape: ModelShape;
  /**
   * shape 'run': a fresh player's first run, a fully progressed one (the power at the meta's end), a run that clears
   * every stage (its minutes), and the run in progress at the session's end
   */
  run: { fresh: ModelRunShape; full: ModelRunShape; winMinutes: number; atSession: ModelRunRow | null } | null;
  /** The first reward, in seconds of play (the cheapest-first player) */
  firstRewardSec: number | null;
  /**
   * The session-end hook: the walk at the session's last minute, and the goal over the session ± sessionWindowMin
   * (what the check reads: the nearest goal's share averaged over that window) — null: no session length known
   */
  session: (ModelSnapshot & { from: string; window: ModelWindow }) | null;
  /** For gp balance / gp qa: the model read like a bot's campaign */
  report: BalanceReport;
  markdown: string;
}

/** The model's own thresholds (the curve targets come from the channel: BalanceTargets) */
export interface ModelTargets {
  /** More expected attempts than this at one stage is a wall (warn) … */
  wallAttempts: number;
  /** … and more than this, a failure */
  failWallAttempts: number;
  /** Farming more than this share of the play time is a grind (warn) */
  grindShare: number;
  /** Winning on arrival at least this often, … */
  easyWin: number;
  /** … this many stages in a row, plays itself (warn) */
  easyRun: number;
  /** An item worth more than this many times the median value for money dominates (warn) */
  dominant: number;
  /** The first reward (a clear, a purchase, a goal) within this many seconds of play */
  firstRewardSec: number;
  /** Inside the first `earlyMin` minutes, no stretch longer than this without a new thing (later: BalanceTargets.goalGapMin) */
  earlyGapMin: number;
  earlyMin: number;
  /** News of this weight or more is a big reward … */
  bigNews: number;
  /** … and two big rewards come at least this many minutes apart */
  bigApartMin: number;
  /** More attempts than this at a stage is hard … */
  hardAttempts: number;
  /** … and this many hard stages in a row is a hard streak (bosses aside) */
  hardRun: number;
  /** The time a stage takes (arrival to clear) grows at most this much from one stage to the next (bosses aside) */
  stageTimeGrowth: number;
  /** At the session's end, the next goal is at least this far reached ("a goal left at 80 %") … */
  sessionGoalShare: number;
  /** … on average over this many minutes either side of the session's end (a player stops around it, not on one instant) */
  sessionWindowMin: number;
  /** The meta lasts at least this many sessions */
  metaOverSession: number;
  /** The model's meta and game.yaml money.meta.minutes within this share of each other (warn) */
  metaTolerance: number;
  /** shape 'run': a fresh player's first run lasts at least this many minutes … */
  runFreshMin: number;
  /** … the fully progressed one gets at least this many times as far (or nearly to the end: runFullShare of the stages) … */
  runFullOverFresh: number;
  runFullShare: number;
  /** … a run that clears every stage fits this many sessions … */
  runWinSessions: number;
  /** … and the run in progress at the session's end gets at least this many stages further than the first one */
  runSessionGain: number;
}

/**
 * The first-session targets (from firstRewardSec on) are the owner's game-balance method (2026-10: time is the first
 * resource; many small rewards spread over the first session, the first within a minute, a new thing every 1–3 min of
 * the first 10; never two big rewards at once; a goal left in reach at the session's end) and Schreiber, "Game Balance
 * Concepts", level 7: advancement, progression and pacing (CC BY 3.0, https://gamebalanceconcepts.wordpress.com/) — a
 * difficulty that rises in a sawtooth with deliberate peaks and dips, not a streak of walls or a jump in a stage's length.
 * Without game.yaml balance.anchor they only warn (games made before them keep passing); with it they fail.
 */
export const MODEL_TARGETS: ModelTargets = {
  wallAttempts: 4,
  failWallAttempts: 10,
  grindShare: 0.25,
  easyWin: 0.95,
  easyRun: 3,
  dominant: 3,
  firstRewardSec: 60,
  earlyGapMin: 3,
  earlyMin: 10,
  bigNews: 2,
  bigApartMin: 1,
  hardAttempts: 2.5,
  hardRun: 3,
  stageTimeGrowth: 1.5,
  sessionGoalShare: 0.6,
  sessionWindowMin: 1,
  metaOverSession: 2,
  metaTolerance: 0.25,
  runFreshMin: 2,
  runFullOverFresh: 1.5,
  runFullShare: 0.9,
  runWinSessions: 1.25,
  runSessionGain: 1,
};

const NEWS_WEIGHT: Record<ModelNews['kind'], number> = { stage: 1, item: 1, unlock: 2, story: 2, boss: 3 };
const newsOf = (n: ModelNews): Required<ModelNews> => ({ kind: n.kind, weight: n.weight ?? NEWS_WEIGHT[n.kind] });
/** A stage clear's news (none when it is not a goal) */
const stageNews = (s: ModelStage): Required<ModelNews> | undefined => (s.goal === false ? undefined : newsOf(s.news ?? { kind: s.kind === 'boss' ? 'boss' : 'stage' }));
/** An item's news: with `news`, or a goal item (an unlock); a stat level has none */
const itemNews = (i: ModelItem): Required<ModelNews> | undefined => ((i.goal ?? !!i.news) ? newsOf(i.news ?? { kind: 'unlock' }) : undefined);

const num = (v: unknown): v is number => typeof v === 'number' && Number.isFinite(v);
const f1 = (n: number) => (Math.abs(n) >= 100 ? String(Math.round(n)) : String(Math.round(n * 10) / 10));
const f2 = (n: number) => (Math.abs(n) >= 100 ? String(Math.round(n)) : String(Math.round(n * 100) / 100));
const pct = (p: number) => `${Math.round(p * 100)} %`;

/** The default chance to win: p = r^k / (1 + r^k) */
export function winChance(ratio: number, steepness = 4): number {
  if (!(ratio > 0)) return 0;
  const x = Math.pow(ratio, steepness);
  return Number.isFinite(x) ? x / (1 + x) : 1;
}

/**
 * The steepness k of winChance that best fits the game's bot (least squares on logit p = k · ln r), from a few points
 * the bot measured: { ratio: power / difficulty, win: the share of its runs won }. Rates are clamped to 2–98 %
 */
export function fitWinCurve(points: readonly { ratio: number; win: number }[]): number {
  let sxy = 0;
  let sxx = 0;
  for (const { ratio, win } of points) {
    if (!(ratio > 0) || ratio === 1) continue;
    const p = Math.min(0.98, Math.max(0.02, win));
    const x = Math.log(ratio);
    sxy += x * Math.log(p / (1 - p));
    sxx += x * x;
  }
  return sxx > 0 ? Math.max(0.5, sxy / sxx) : 4;
}

/** Tables of numbers for a model: n values of a curve, rounded to whole numbers unless `exact` */
export const curve = {
  /** a, a + step, a + 2·step … */
  linear: (n: number, a: number, step: number, exact = false) => Array.from({ length: n }, (_, i) => round(a + step * i, exact)),
  /** a, a·rate, a·rate² … (built by repeated multiplication, as UpgradeShop prices are) */
  geometric: (n: number, a: number, rate: number, exact = false) => {
    const out: number[] = [];
    let v = a;
    for (let i = 0; i < n; i++, v *= rate) out.push(round(v, exact));
    return out;
  },
  /** a · (i + 1)^exp: polynomial growth, slower than geometric over a long campaign */
  power: (n: number, a: number, exp: number, exact = false) => Array.from({ length: n }, (_, i) => round(a * Math.pow(i + 1, exp), exact)),
  /** The geometric-mean growth from one value to the next (null under two positive values) */
  rate: (values: readonly number[]): number | null => {
    const v = values.filter((x) => x > 0);
    return v.length >= 2 ? Math.pow(v[v.length - 1] / v[0], 1 / (v.length - 1)) : null;
  },
};

function round(v: number, exact: boolean): number {
  return exact ? v : Math.round(v);
}

/**
 * Walk one buyer through the model, in expected values; `at`: also snapshot the walk at that minute (atMinute), and with
 * `window` read the goal over [at − window, at + window] (atMinuteWindow)
 */
export function walkModel(model: BalanceModel, buyer: ModelBuyer, opts: { at?: number; window?: number; shape?: ModelShape } = {}): ModelRun & { snapshot?: ModelSnapshot; window?: ModelWindow } {
  if ((opts.shape ?? model.shape ?? 'campaign') === 'run') return walkRuns(model, buyer, opts);
  const win = typeof model.win === 'function' ? model.win : (r: number) => winChance(r, (model.win as { steepness?: number } | undefined)?.steepness ?? 4);
  const overhead = model.overheadMin ?? 0.25;
  const lossDefault = model.lossReward ?? 0.3;
  const farmBelow = model.farmBelow ?? 0.25;
  const maxMin = model.maxMinutes ?? 600;
  const stages = model.stages;
  let power = model.start.power;
  let coins = model.start.coins ?? 0;
  let earned = 0;
  let t = 0;
  let attemptsTotal = 0;
  let farmTotal = 0;
  const cleared = new Set<string>();
  const bought = new Set<string>();
  const stageRows: ModelStageRow[] = stages.map((s) => ({ id: s.id, difficulty: s.difficulty, reward: s.reward, arriveMin: null, arrivePower: null, ratio: null, winOnArrival: null, attempts: null, farmMin: 0, clearedMin: null, coinsEarned: null }));
  const itemRows = new Map<string, ModelItemRow>(model.items.map((i) => [i.id, { id: i.id, cost: i.cost, ...(i.after ? { after: i.after } : {}), boughtMin: null, atStage: null, powerBefore: null, powerAfter: null, valuePer1k: null, incomeMin: null }]));
  const goals: number[] = [];
  const timeline: ModelEvent[] = [];
  let firstPurchaseMin: number | null = null;
  let firstPurchaseRun: number | null = null;
  let stuck: string | null = null;

  const forSale = () => model.items.filter((i) => !bought.has(i.id) && (!i.after || cleared.has(i.after)) && (!i.requires || bought.has(i.requires)));
  const gain = (i: ModelItem) => (i.mult ? power * (i.mult - 1) : 0) + (i.power ?? 0);
  const shop = (stageId: string) => {
    for (;;) {
      const open = forSale().filter((i) => i.cost <= coins);
      if (!open.length) return;
      const pick =
        buyer === 'cheapest'
          ? open.reduce((a, b) => (b.cost < a.cost ? b : a))
          : open.reduce((a, b) => (gain(b) / Math.max(1, b.cost) > gain(a) / Math.max(1, a.cost) ? b : a));
      const before = power;
      coins -= pick.cost;
      power = (power + (pick.power ?? 0)) * (pick.mult ?? 1);
      bought.add(pick.id);
      const rate = t > 0 ? earned / t : 0;
      Object.assign(itemRows.get(pick.id)!, {
        boughtMin: t,
        atStage: stageId,
        powerBefore: before,
        powerAfter: power,
        valuePer1k: ((power - before) * 1000) / Math.max(1, pick.cost),
        incomeMin: rate > 0 ? pick.cost / rate : null,
      });
      if (firstPurchaseMin === null) [firstPurchaseMin, firstPurchaseRun] = [t, attemptsTotal];
      const news = itemNews(pick);
      if (news) goals.push(t);
      timeline.push({ min: t, id: pick.id, what: 'item', ...(news ? { news } : {}) });
    }
  };
  // The last state at or before minute `at`, kept as the walk goes (atMinute reads it). With a window, every attempt
  // that overlaps it, as a segment: the stage's progress and the coins grow through an attempt, as they do in play, so
  // the window reads a continuous curve (atMinuteWindow) — not one state an attempt, which a small change of an
  // attempt's length moves in or out of the window
  const at = opts.at;
  const w = at !== undefined && num(opts.window) && opts.window > 0 ? opts.window : 0;
  let seen: WalkState | null = null;
  let cur = { si: 0, progress: 0 };
  const segs: { from: WalkState; t1: number; coins1: number; progress1: number }[] = [];
  const look = (si: number, progress: number) => {
    cur = { si, progress };
    if (at !== undefined && t <= at) seen = { t, si, progress, coins, power, bought: new Set(bought) };
  };
  // One attempt at stage s (or the share of one that is still needed): its expected coins and clear progress, then the shop
  const attempt = (s: ModelStage, stageId: string, share = 1): number => {
    const p = win(power / s.difficulty);
    const loss = s.lossReward ?? lossDefault;
    const got = s.reward * (p + (1 - p) * loss) * share;
    const before: WalkState | null = w && t <= at! + w ? { t, si: cur.si, progress: cur.progress, coins, power, bought: new Set(bought) } : null;
    coins += got;
    earned += got;
    t += (s.minutes + overhead) * share;
    attemptsTotal += share;
    // Farming the stage before moves no progress on the one ahead
    if (before && t > at! - w) segs.push({ from: before, t1: t, coins1: coins, progress1: Math.min(1, cur.progress + (s.id === stageId ? p * share : 0)) });
    shop(stageId);
    return p * share;
  };

  shop(stages[0]?.id ?? '');
  look(0, 0);
  for (let si = 0; si < stages.length && !stuck; si++) {
    const s = stages[si];
    const row = stageRows[si];
    row.arriveMin = t;
    row.arrivePower = power;
    row.ratio = power / s.difficulty;
    row.winOnArrival = win(row.ratio);
    let progress = 0;
    let tries = 0;
    // The entry: farm the last cleared stage until it is paid
    const entry = s.entry ?? 0;
    while (entry > coins && !stuck) {
      look(si, 0);
      if (si === 0 || t > maxMin) {
        stuck = `stage ${s.id}: its entry of ${f1(entry)} coins is out of reach${si === 0 ? ' from the start' : ` after ${f1(t)} min`}`;
        break;
      }
      const t0 = t;
      attempt(stages[si - 1], s.id);
      row.farmMin += t - t0;
      farmTotal += t - t0;
    }
    if (stuck) break;
    coins -= entry;
    while (progress < 1) {
      look(si, progress);
      if (t > maxMin) {
        stuck = `stage ${s.id}: still not cleared after ${f1(t)} min (${pct(win(power / s.difficulty))} to win)`;
        break;
      }
      // Too hard for now: farm the last cleared stage, as players do, until a purchase makes it winnable
      if (si > 0 && win(power / s.difficulty) < farmBelow && forSale().some((i) => i.cost > coins)) {
        const prev = stages[si - 1];
        const t0 = t;
        attempt(prev, s.id);
        row.farmMin += t - t0;
        farmTotal += t - t0;
        continue;
      }
      // The last attempt counts only the share still needed: a 60 % chance clears in 1/0.6 ≈ 1.7 attempts on average,
      // as a bot's runs do — not 2 (a whole attempt would put every clear late)
      const p = win(power / s.difficulty);
      const share = p > 0 && progress + p > 1 ? (1 - progress) / p : 1;
      progress += attempt(s, s.id, share);
      tries += share;
      if (share < 1) progress = 1;
    }
    if (stuck) break;
    row.attempts = tries;
    row.clearedMin = t;
    row.coinsEarned = earned;
    cleared.add(s.id);
    const news = stageNews(s);
    if (news) goals.push(t);
    timeline.push({ min: t, id: s.id, what: 'stage', ...(news ? { news } : {}) });
    shop(s.id);
    look(si + 1, 0);
  }
  const lastStage = stageRows.at(-1)?.clearedMin ?? null;
  // finish 'all': keep farming the last stage until everything is bought
  let finishMin = lastStage;
  if (lastStage !== null && model.finish === 'all') {
    const last = stages[stages.length - 1];
    while (forSale().length && t <= maxMin) {
      attempt(last, last.id);
      look(stages.length, 0);
    }
    finishMin = forSale().length || model.items.some((i) => !bought.has(i.id)) ? null : t;
    if (finishMin === null && !stuck) stuck = `not every item bought after ${f1(t)} min`;
  }
  const firstClear = stageRows[0]?.clearedMin ?? null;
  const rewards = [firstClear, firstPurchaseMin].filter(num);
  // The snapshot: the stage the player was on and how far, the next purchase and the nearest goal
  const snapshot = at !== undefined && seen ? snapshotOf(model, seen, at, t < at) : undefined;
  // The window: read at fixed steps from its start to its end; inside an attempt, the progress and coins so far
  const window = at !== undefined && w ? windowOf(model, at, w, segs, { t, si: cur.si, progress: cur.progress, coins, power, bought: new Set(bought) }) : undefined;
  return {
    buyer,
    stages: stageRows,
    items: [...itemRows.values()],
    firstPurchaseMin,
    firstPurchaseRun: firstPurchaseRun === null ? null : Math.max(1, Math.ceil(firstPurchaseRun - 1e-9)),
    goalsMin: goals.sort((a, b) => a - b),
    firstRewardMin: rewards.length ? Math.min(...rewards) : null,
    timeline,
    finishMin,
    finishRun: finishMin === null ? null : Math.ceil(attemptsTotal - 1e-9),
    attempts: attemptsTotal,
    farmMin: farmTotal,
    power,
    stuck,
    ...(snapshot ? { snapshot } : {}),
    ...(window ? { window } : {}),
  };
}

/** The win curve of a model */
const winOf = (model: BalanceModel) => (typeof model.win === 'function' ? model.win : (r: number) => winChance(r, (model.win as { steepness?: number } | undefined)?.steepness ?? 4));

/**
 * One run at a power, in expected values: it starts at the first stage and goes on until a loss. Each stage is reached
 * with the chance of clearing every one before it; the stage a run is lost on is played for `deathShare` of its minutes
 * and pays its loss reward. Returns the expected stages cleared (depth), the chance to clear them all, minutes and
 * coins, and per stage the chance to reach and to clear it
 */
export function runAt(model: BalanceModel, power: number): ModelRunShape & { reach: number[]; clear: number[] } {
  const win = winOf(model);
  const death = model.deathShare ?? 0.5;
  const lossDefault = model.lossReward ?? 0.3;
  let reach = 1;
  let depth = 0;
  let minutes = model.overheadMin ?? 0.25;
  let coins = 0;
  const reachs: number[] = [];
  const clears: number[] = [];
  for (const s of model.stages) {
    const p = win(power / s.difficulty);
    reachs.push(reach);
    const clear = reach * p;
    clears.push(clear);
    depth += clear;
    minutes += reach * s.minutes * (p + (1 - p) * death);
    coins += reach * s.reward * (p + (1 - p) * (s.lossReward ?? lossDefault));
    reach = clear;
  }
  return { power, depth, win: reach, minutes, coins, reach: reachs, clear: clears };
}

/**
 * The walk of a run-shaped model (`shape: 'run'`): runs from the first stage, in expected values, the purchases
 * between runs. A stage is first reached, and first cleared, in the run by which half the players have done it
 * (the chance of never having done it falls to 50 %: a stage cleared 99.9 % of the time is cleared in run 1); its
 * "attempts" are the runs expected to reach it until then. The snapshots read the stage the player works toward (the
 * first not yet cleared by half the players) and how close it is: the chance of having cleared it, over that half
 */
function walkRuns(model: BalanceModel, buyer: ModelBuyer, opts: { at?: number; window?: number }): ModelRun & { snapshot?: ModelSnapshot; window?: ModelWindow } {
  const win = winOf(model);
  const overhead = model.overheadMin ?? 0.25;
  const maxMin = model.maxMinutes ?? 600;
  const stages = model.stages;
  let power = model.start.power;
  let coins = model.start.coins ?? 0;
  let earned = 0;
  let t = 0;
  let runs = 0;
  const bought = new Set<string>();
  const cleared = new Set<string>();
  const stageRows: ModelStageRow[] = stages.map((s) => ({ id: s.id, difficulty: s.difficulty, reward: s.reward, arriveMin: null, arrivePower: null, ratio: null, winOnArrival: null, attempts: null, farmMin: 0, clearedMin: null, coinsEarned: null }));
  const itemRows = new Map<string, ModelItemRow>(model.items.map((i) => [i.id, { id: i.id, cost: i.cost, ...(i.after ? { after: i.after } : {}), boughtMin: null, atStage: null, powerBefore: null, powerAfter: null, valuePer1k: null, incomeMin: null }]));
  const goals: number[] = [];
  const timeline: ModelEvent[] = [];
  const runRows: ModelRunRow[] = [];
  // Runs expected to reach each stage; the chance never to have reached it, never to have cleared it
  const cumReach = stages.map(() => 0);
  const missReach = stages.map(() => 1);
  const missClear = stages.map(() => 1);
  let firstPurchaseMin: number | null = null;
  let firstPurchaseRun: number | null = null;
  let stuck: string | null = null;

  const forSale = () => model.items.filter((i) => !bought.has(i.id) && (!i.after || cleared.has(i.after)) && (!i.requires || bought.has(i.requires)));
  const gain = (i: ModelItem) => (i.mult ? power * (i.mult - 1) : 0) + (i.power ?? 0);
  /** The stage the player works toward: the first that half the players haven't cleared yet */
  const front = () => {
    const i = missClear.findIndex((m) => m > 0.5);
    return i < 0 ? stages.length : i;
  };
  const progressOf = (i: number) => (i < stages.length ? Math.min(1, (1 - missClear[i]) / 0.5) : 0);
  const shop = () => {
    for (;;) {
      const open = forSale().filter((i) => i.cost <= coins);
      if (!open.length) return;
      const pick = buyer === 'cheapest' ? open.reduce((a, b) => (b.cost < a.cost ? b : a)) : open.reduce((a, b) => (gain(b) / Math.max(1, b.cost) > gain(a) / Math.max(1, a.cost) ? b : a));
      const before = power;
      coins -= pick.cost;
      power = (power + (pick.power ?? 0)) * (pick.mult ?? 1);
      bought.add(pick.id);
      const rate = t > 0 ? earned / t : 0;
      Object.assign(itemRows.get(pick.id)!, { boughtMin: t, atStage: stages[Math.min(front(), stages.length - 1)]?.id ?? null, powerBefore: before, powerAfter: power, valuePer1k: ((power - before) * 1000) / Math.max(1, pick.cost), incomeMin: rate > 0 ? pick.cost / rate : null });
      if (firstPurchaseMin === null) [firstPurchaseMin, firstPurchaseRun] = [t, runs];
      const news = itemNews(pick);
      if (news) goals.push(t);
      timeline.push({ min: t, id: pick.id, what: 'item', ...(news ? { news } : {}) });
    }
  };
  // The snapshots: the state at the start of each run (and after its shop), and each run as a segment for the window
  const at = opts.at;
  const w = at !== undefined && num(opts.window) && opts.window > 0 ? opts.window : 0;
  const stateNow = (): WalkState => {
    const si = front();
    return { t, si, progress: progressOf(si), coins, power, bought: new Set(bought) };
  };
  let seen: WalkState | null = null;
  const look = () => {
    if (at !== undefined && t <= at) seen = stateNow();
  };
  const segs: { from: WalkState; t1: number; coins1: number; progress1: number }[] = [];
  // The meta is over: every item bought (the default), a first win ('stages'), or both ('all'); no items: a first win
  const needWin = model.finish === 'stages' || model.finish === 'all' || !model.items.length;
  const needItems = model.finish !== 'stages' && model.items.length > 0;
  const done = () => (!needWin || front() >= stages.length) && (!needItems || model.items.every((i) => bought.has(i.id)));

  shop();
  look();
  while (stages.length && !done()) {
    if (t > maxMin) {
      const si = front();
      stuck =
        needWin && si < stages.length
          ? `stage ${stages[si].id}: not yet cleared by half the players after ${f1(t)} min of runs (a run reaches it ${pct(runAt(model, power).reach[si])} of the time and wins it ${pct(win(power / stages[si].difficulty))})`
          : `not every item bought after ${f1(t)} min`;
      break;
    }
    const r = runAt(model, power);
    const from = stateNow();
    runs++;
    // The stages reached and cleared for the first time in this run, at the minute of the run they come
    let into = t + overhead;
    stages.forEach((s, i) => {
      const row = stageRows[i];
      cumReach[i] += r.reach[i];
      missReach[i] *= 1 - r.reach[i];
      missClear[i] *= 1 - r.clear[i];
      if (row.arriveMin === null && missReach[i] <= 0.5) Object.assign(row, { arriveMin: into, arrivePower: power, ratio: power / s.difficulty, winOnArrival: win(power / s.difficulty) });
      if (row.clearedMin === null && missClear[i] <= 0.5) {
        Object.assign(row, { clearedMin: into + s.minutes, attempts: cumReach[i], coinsEarned: earned + r.coins });
        cleared.add(s.id);
        const news = stageNews(s);
        if (news) goals.push(into + s.minutes);
        timeline.push({ min: into + s.minutes, id: s.id, what: 'stage', ...(news ? { news } : {}) });
      }
      into += s.minutes;
    });
    runRows.push({ run: runs, startMin: t, power, depth: r.depth, win: r.win, minutes: r.minutes, coins: r.coins });
    t += r.minutes;
    coins += r.coins;
    earned += r.coins;
    if (w && from.t <= at! + w && t > at! - w) segs.push({ from, t1: t, coins1: coins, progress1: progressOf(from.si) });
    look();
    shop();
    look();
  }
  const finishMin = stuck || !stages.length ? null : t;
  const firstClear = stageRows[0]?.clearedMin ?? null;
  const rewards = [firstClear, firstPurchaseMin].filter(num);
  const snapshot = at !== undefined && seen ? snapshotOf(model, seen, at, t < at) : undefined;
  const window = at !== undefined && w ? windowOf(model, at, w, segs, stateNow()) : undefined;
  timeline.sort((a, b) => a.min - b.min);
  return {
    buyer,
    stages: stageRows,
    items: [...itemRows.values()],
    firstPurchaseMin,
    firstPurchaseRun: firstPurchaseRun === null ? null : Math.max(1, firstPurchaseRun),
    goalsMin: goals.sort((a, b) => a - b),
    firstRewardMin: rewards.length ? Math.min(...rewards) : null,
    timeline,
    finishMin,
    finishRun: finishMin === null ? null : runs,
    attempts: runs,
    farmMin: 0,
    power,
    stuck,
    runs: runRows,
    ...(snapshot ? { snapshot } : {}),
    ...(window ? { window } : {}),
  };
}

/** The goal over [at − w, at + w], read at fixed steps through the walk's segments (an attempt, or a run) */
function windowOf(model: BalanceModel, at: number, w: number, segs: readonly { from: WalkState; t1: number; coins1: number; progress1: number }[], end: WalkState): ModelWindow {
  const from = Math.max(0, at - w);
  const to = at + w;
  const share = (x: ModelSnapshot) => x.goal?.share ?? 0;
  const steps = 120;
  const shots: ModelSnapshot[] = [];
  for (let k = 0; k <= steps; k++) {
    const tau = from + ((to - from) * k) / steps;
    const g = segs.find((x) => x.from.t <= tau && tau < x.t1);
    const f = g ? (tau - g.from.t) / (g.t1 - g.from.t) : 0;
    const v: WalkState = g
      ? { ...g.from, t: tau, progress: g.from.progress + (g.progress1 - g.from.progress) * f, coins: g.from.coins + (g.coins1 - g.from.coins) * f }
      : { ...(tau < end.t ? (segs.find((x) => x.from.t >= tau)?.from ?? end) : end), t: tau };
    shots.push(snapshotOf(model, v, at, end.t < tau));
  }
  // The extremes: on a tie, the moment nearest the session's end
  const pick = (sign: 1 | -1) =>
    shots.reduce((a, b) => {
      const d = sign * (share(b) - share(a));
      return d > 1e-9 || (Math.abs(d) <= 1e-9 && Math.abs(b.walkMin - at) < Math.abs(a.walkMin - at)) ? b : a;
    });
  // The mean by the trapezoid rule over the equal steps
  const mean = shots.reduce((n, x, k) => n + share(x) * (k === 0 || k === steps ? 0.5 : 1), 0) / steps;
  return { from, to, mean, worst: pick(-1), best: pick(1), empty: shots.some((x) => !x.goal || x.over) };
}

/** A moment of the walk, as walkModel keeps it for the snapshots */
interface WalkState {
  t: number;
  si: number;
  progress: number;
  coins: number;
  power: number;
  bought: Set<string>;
}

/** A moment of the walk read: the stage the player is on and how far, the next purchase, the nearest goal */
function snapshotOf(model: BalanceModel, v: WalkState, minute: number, over: boolean): ModelSnapshot {
  const stages = model.stages;
  const done = new Set(stages.slice(0, v.si).map((s) => s.id));
  const open = model.items.filter((i) => !v.bought.has(i.id) && (!i.after || done.has(i.after)) && (!i.requires || v.bought.has(i.requires)));
  const share = (i: ModelItem) => Math.min(1, v.coins / Math.max(1, i.cost));
  const cheapest = open.reduce<ModelItem | null>((a, b) => (!a || b.cost < a.cost ? b : a), null);
  const stage = stages[v.si];
  const goalsOpen: { id: string; kind: 'stage' | 'item'; share: number }[] = [
    ...(stage && stage.goal !== false ? [{ id: stage.id, kind: 'stage' as const, share: Math.min(1, v.progress) }] : []),
    ...open.map((i) => ({ id: i.id, kind: 'item' as const, share: share(i) })),
  ];
  return {
    minute,
    walkMin: v.t,
    cleared: v.si,
    stages: stages.length,
    stage: stage?.id ?? null,
    stageShare: stage ? Math.min(1, v.progress) : 1,
    power: v.power,
    coins: v.coins,
    bought: v.bought.size,
    items: model.items.length,
    purchase: cheapest ? { id: cheapest.id, share: share(cheapest) } : null,
    goal: goalsOpen.reduce<(typeof goalsOpen)[number] | null>((a, b) => (!a || b.share > a.share ? b : a), null),
    over,
  };
}

/** The walk at minute t of play (the cheapest-first player by default): what the player has, how far the next goal is */
export function atMinute(model: BalanceModel, t: number, buyer: ModelBuyer = 'cheapest'): ModelSnapshot {
  return walkModel(model, buyer, { at: t }).snapshot!;
}

/**
 * The goal over minutes t ± window of play (the cheapest-first player by default): its share on average, at worst and
 * at best. The session-end check reads the average, so a small change of an attempt's length can't flip it
 */
export function atMinuteWindow(model: BalanceModel, t: number, window: number = MODEL_TARGETS.sessionWindowMin, buyer: ModelBuyer = 'cheapest'): ModelWindow {
  return walkModel(model, buyer, { at: t, window: Math.max(1e-3, window) }).window!;
}

/** A window in words: "over minutes 14–16 the nearest goal is 64 % reached on average (31 % at minute 14.2: s4 of the way; 100 % at minute 15.6: Lithium Candle paid)" */
export function windowText(w: ModelWindow): string {
  const at = (x: ModelSnapshot) => `${pct(x.goal?.share ?? 0)} at minute ${f1(x.walkMin)}${x.goal ? `: ${x.goal.id} ${x.goal.kind === 'item' ? 'paid' : 'of the way'}` : ': nothing left to reach'}`;
  return `over minutes ${f1(w.from)}–${f1(w.to)} the nearest goal is ${pct(w.mean)} reached on average (${at(w.worst)}; ${at(w.best)})`;
}

/** A snapshot in words: "at minute 15: Lithium Candle 82 % paid, 4 of 9 stages, 6 of 20 purchases" */
export function snapshotText(s: ModelSnapshot): string {
  const goal = s.goal ? `${s.goal.id} ${pct(s.goal.share)} ${s.goal.kind === 'item' ? 'paid' : 'of the way'}, ` : 'nothing left to reach, ';
  return `at minute ${f1(s.minute)}: ${goal}${s.cleared} of ${s.stages} stages, ${s.bought} of ${s.items} purchases${s.over ? ` — the campaign was over at minute ${f1(s.walkMin)}` : ''}`;
}

/** Solve the model: both buyers, the tables, the model's checks and the BalanceReport (evaluateBalance reads its curve against the channel) */
export function solveModel(input: BalanceModel, opts: { targets?: Partial<ModelTargets> } & ModelDesign = {}): ModelResult {
  const mt = { ...MODEL_TARGETS, ...opts.targets };
  const anchor = opts.anchor ?? null;
  const strict = !!anchor;
  // The shape: game.yaml balance.anchor.shape, else the model's own; every walk below (the snapshots too) plays it
  const shape: ModelShape = anchor?.shape ?? input.shape ?? 'campaign';
  const isRun = shape === 'run';
  const model: BalanceModel = (input.shape ?? 'campaign') === shape ? input : { ...input, shape };
  const cheap = walkModel(model, 'cheapest');
  const careful = walkModel(model, 'best-value');
  const win = winOf(model);
  const growth = {
    difficulty: curve.rate(model.stages.map((s) => s.difficulty)),
    reward: curve.rate(model.stages.map((s) => s.reward)),
    price: curve.rate([...model.items].map((i) => i.cost).sort((a, b) => a - b)),
  };

  const checks: BalanceRow[] = [];
  const row = (name: string, status: BalanceStatus, detail: string, target: string) => checks.push({ name: `model: ${name}`, status, detail, target });
  // The checks added with the anchor (the first session, the difficulty's shape, the session's end) fail only when
  // game.yaml declares balance.anchor: games made before them keep passing, and see them as warnings
  const sev = (bad: boolean): BalanceStatus => (bad ? (strict ? 'fail' : 'warn') : 'ok');
  const soft = strict ? '' : ' — a warning until game.yaml declares balance.anchor';
  // A run-shaped model leaves out the checks that assume a campaign: a run's stages are reached, not retried one by one
  const notInRun = (name: string, why: string) => row(name, 'skip', `not for a run (balance.anchor.shape: run): ${why}`, 'the run checks below');
  // 1. The curves rise: a fall at a breather, or after a boss, is the design (kind: 'breather' | 'boss')
  {
    const planned = (i: number) => model.stages[i].kind === 'breather' || model.stages[i - 1].kind === 'boss';
    const fall = model.stages.findIndex((s, i) => i > 0 && s.difficulty < model.stages[i - 1].difficulty && !planned(i));
    const rfall = model.stages.findIndex((s, i) => i > 0 && s.reward < model.stages[i - 1].reward && !planned(i));
    const parts = [fall > 0 ? `difficulty falls at ${model.stages[fall].id}` : '', rfall > 0 ? `reward falls at ${model.stages[rfall].id}` : ''].filter(Boolean);
    row('Difficulty and reward rise stage by stage', parts.length ? 'warn' : 'ok', parts.join('; ') || `difficulty ×${growth.difficulty ? f2(growth.difficulty) : '–'} a stage, reward ×${growth.reward ? f2(growth.reward) : '–'}`, 'never lower than the stage before (a breather or the stage after a boss: say so with its kind)');
  }
  // 2. Walls (a run: the runs that reach a stage before it is first cleared; only being stuck fails)
  {
    const worst = cheap.stages.filter((r) => num(r.attempts)).reduce<ModelStageRow | null>((a, b) => (!a || (b.attempts ?? 0) > (a.attempts ?? 0) ? b : a), null);
    const target = isRun
      ? `the meta finishes (stuck fails); ≤ ${2 * mt.failWallAttempts} runs reach a stage before it is first cleared`
      : `≤ ${mt.wallAttempts} attempts a stage (fails over ${mt.failWallAttempts}, or never cleared)`;
    if (cheap.stuck) row('No wall', 'fail', `stuck — ${cheap.stuck}`, target);
    else if (!worst) row('No wall', 'skip', 'no stages', target);
    else if (isRun) {
      const a = worst.attempts!;
      row('No wall', a > 2 * mt.failWallAttempts ? 'warn' : 'ok', `the hardest: ${worst.id}, first cleared after ${f1(a)} runs reached it (power ${f1(worst.ratio ?? 0)}× its difficulty when first reached)`, target);
    } else {
      const a = worst.attempts!;
      row('No wall', a > mt.failWallAttempts ? 'fail' : a > mt.wallAttempts ? 'warn' : 'ok', `the hardest: ${worst.id}, ${f1(a)} attempts (power ${f1(worst.ratio ?? 0)}× its difficulty on arrival, ${pct(worst.winOnArrival ?? 0)} to win)`, target);
    }
  }
  // 3. Grind
  if (isRun) notInRun('No grind', 'a run never replays a cleared stage for coins: every run starts at the first');
  else {
    const total = cheap.finishMin ?? cheap.stages.reduce((m, r) => Math.max(m, r.clearedMin ?? 0), 0);
    const share = total > 0 ? cheap.farmMin / total : 0;
    const worst = cheap.stages.reduce((a, b) => (b.farmMin > a.farmMin ? b : a), cheap.stages[0]);
    row('No grind', share > mt.grindShare ? 'warn' : 'ok', cheap.farmMin > 0 ? `${pct(share)} of the play is replaying for coins (most before ${worst.id}: ${f1(worst.farmMin)} min)` : 'no replaying for coins', `≤ ${pct(mt.grindShare)} of the play replaying a cleared stage`);
  }
  // 4. Stretches that play themselves
  if (isRun) notInRun('No stretch that plays itself', "a run's first stages are won on arrival by design: the run builds up to its peaks");
  else {
    let run = 0;
    let best = 0;
    let at = '';
    for (const r of cheap.stages) {
      run = (r.winOnArrival ?? 0) >= mt.easyWin ? run + 1 : 0;
      if (run > best) [best, at] = [run, r.id];
    }
    row('No stretch that plays itself', best >= mt.easyRun ? 'warn' : 'ok', best >= mt.easyRun ? `${best} stages in a row won on arrival ≥ ${pct(mt.easyWin)} of the time (to ${at}): purchases outpace the difficulty` : `at most ${best} in a row won ≥ ${pct(mt.easyWin)} on arrival`, `fewer than ${mt.easyRun} stages in a row that are won on arrival ≥ ${pct(mt.easyWin)}`);
  }
  // 5. Every item gets bought, none dominates, none is dead
  {
    const never = cheap.items.filter((i) => i.boughtMin === null).map((i) => i.id);
    row('Every purchase is reached', never.length ? 'warn' : 'ok', never.length ? `never bought within the campaign: ${never.slice(0, 6).join(', ')}${never.length > 6 ? ` +${never.length - 6}` : ''}` : `all ${cheap.items.length} bought`, 'the cheapest-first player buys everything by the end (or the item is a goal past the campaign: say so)');
    const dead = model.items.filter((i) => !(i.power ?? 0) && (i.mult ?? 1) === 1).map((i) => i.id);
    row('Every purchase adds power', dead.length ? 'fail' : 'ok', dead.length ? `adds nothing: ${dead.join(', ')}` : 'all add power or a factor', 'power > 0 or mult ≠ 1 (a cosmetic is not a model item)');
    const values = careful.items.map((i) => i.valuePer1k).filter(num).sort((a, b) => a - b);
    const median = values.length ? values[Math.floor(values.length / 2)] : 0;
    const top = careful.items.filter((i) => num(i.valuePer1k)).reduce<ModelItemRow | null>((a, b) => (!a || b.valuePer1k! > a.valuePer1k! ? b : a), null);
    if (!top || median <= 0) row('No purchase dominates', 'skip', 'too few items bought to compare', `≤ ${mt.dominant}× the median value for money`);
    else {
      const x = top.valuePer1k! / median;
      row('No purchase dominates', x > mt.dominant ? 'warn' : 'ok', `the best value: ${top.id}, ${f1(x)}× the median (+${f2(top.valuePer1k!)} power per 1 000 coins)`, `≤ ${mt.dominant}× the median value for money`);
    }
  }

  // 6. The first reward: within a minute of play
  const firstRewardSec = num(cheap.firstRewardMin) ? cheap.firstRewardMin * 60 : null;
  {
    const target = `a clear or a purchase within ${mt.firstRewardSec} s of play${soft}`;
    row('The first reward within a minute', sev(firstRewardSec === null || firstRewardSec > mt.firstRewardSec), firstRewardSec === null ? 'no stage cleared and nothing bought, ever' : `at ${Math.round(firstRewardSec)} s (${cheap.timeline[0]?.id ?? '—'})`, target);
  }
  // 7. Early gaps: a new thing every few minutes of the first ten (later, the curve's goalGapMin)
  {
    let gap = 0;
    let from = 0;
    let prev = 0;
    for (const g of cheap.goalsMin) {
      if (prev < mt.earlyMin && g - prev > gap) [gap, from] = [g - prev, prev];
      prev = g;
    }
    // A run replays the stages it has cleared before new ground: its news in between are the run's own (level-ups,
    // drops, run choices), which the tables don't hold — a warning there, for the bot and a playtest to judge
    const target = `≤ ${mt.earlyGapMin} min between new things in a stretch that starts in the first ${mt.earlyMin} min${isRun ? " — a warning in a run: the run's own rewards (level-ups, drops, run choices) are not in the model" : soft}`;
    const early = (bad: boolean): BalanceStatus => (isRun ? (bad ? 'warn' : 'ok') : sev(bad));
    if (!cheap.goalsMin.length) row('A new thing every few minutes at first', sev(true), 'no new thing at all (no stage clear, no goal item)', target);
    else row('A new thing every few minutes at first', early(gap > mt.earlyGapMin), `the longest early stretch: ${f1(gap)} min from minute ${f1(from)}`, target);
  }
  // 8. Big rewards apart: two in the same minute waste one
  {
    const big = cheap.timeline.filter((e) => e.news && e.news.weight >= mt.bigNews);
    const pair = big.findIndex((e, i) => i > 0 && e.min - big[i - 1].min < mt.bigApartMin);
    const target = `big rewards (news of weight ≥ ${mt.bigNews}: an unlock, a boss, a story beat) ≥ ${mt.bigApartMin} min apart${isRun ? " — a warning in a run: its results pay the unlocks right after the run's last clear" : soft}`;
    row('No two big rewards in the same minute', isRun ? (pair > 0 ? 'warn' : 'ok') : sev(pair > 0), pair > 0 ? `${big[pair - 1].id} (${big[pair - 1].news!.kind}) at ${f1(big[pair - 1].min)} min and ${big[pair].id} (${big[pair].news!.kind}) at ${f1(big[pair].min)} min` : `${big.length} big reward(s), none within ${mt.bigApartMin} min of another`, target);
  }
  // 9. The difficulty's shape: a hard streak, a jump in the time a stage takes (bosses aside)
  if (isRun) {
    notInRun('No hard streak', "a run's stages are reached, not retried: the run checks read how far runs get");
    notInRun('Stage time grows steadily', 'a stage of a run is played once a run: its "time to clear" counts whole runs, which grow with the depth by design');
  } else {
    let run = 0;
    let best = 0;
    let at = '';
    model.stages.forEach((s, i) => {
      if (s.kind === 'boss') return;
      const a = cheap.stages[i].attempts;
      run = num(a) && a > mt.hardAttempts ? run + 1 : 0;
      if (run > best) [best, at] = [run, s.id];
    });
    row('No hard streak', sev(best >= mt.hardRun), best >= mt.hardRun ? `${best} stages in a row need more than ${mt.hardAttempts} attempts (to ${at})` : `at most ${best} in a row need more than ${mt.hardAttempts} attempts`, `fewer than ${mt.hardRun} stages in a row over ${mt.hardAttempts} attempts each (bosses aside)${soft}`);
    // Across a boss or a breather left out, the growth is per step (two steps: its square root)
    let jump = 0;
    let where = '';
    let prev: { time: number; i: number } | null = null;
    model.stages.forEach((s, i) => {
      const r = cheap.stages[i];
      if (s.kind || !num(r.clearedMin) || !num(r.arriveMin)) return;
      const time = r.clearedMin - r.arriveMin;
      const step = prev && prev.time > 0 ? Math.pow(time / prev.time, 1 / (i - prev.i)) : 0;
      if (step > jump) [jump, where] = [step, `${s.id}: ${f1(prev!.time)} → ${f1(time)} min${i - prev!.i > 1 ? ` over ${i - prev!.i} stages` : ''}`];
      prev = { time, i };
    });
    row('Stage time grows steadily', sev(jump > mt.stageTimeGrowth), jump ? `the biggest step: ×${f2(jump)} a stage (${where})` : 'fewer than two stages to compare', `the time a stage takes (arrival to clear, farming included) ≤ ×${mt.stageTimeGrowth} the stage before (bosses and breathers aside: per stage across them)${soft}`);
  }
  // 10. The session's end (D1): a goal in reach, and a meta that outlasts it
  const sessionMin = opts.sessionMin ?? model.sessionMin ?? null;
  const session =
    num(sessionMin) && sessionMin > 0
      ? { ...atMinute(model, sessionMin), from: num(opts.sessionMin) ? 'money.session.minutes' : "the model's sessionMin", window: atMinuteWindow(model, sessionMin, mt.sessionWindowMin) }
      : null;
  {
    const target = `the next goal ≥ ${pct(mt.sessionGoalShare)} reached around the session's end — on average over its ±${f1(mt.sessionWindowMin)} min ("a goal left at 80 %")${soft}`;
    if (!session) row('The session ends with a goal in reach', 'skip', "no session length: game.yaml money.session.minutes or the model's sessionMin", target);
    else {
      const wn = session.window;
      row('The session ends with a goal in reach', sev(session.over || wn.mean < mt.sessionGoalShare), `${snapshotText(session)}; ${windowText(wn)}`, target);
    }
    const fin = cheap.finishMin;
    const mtarget = `the meta lasts ≥ ${mt.metaOverSession}× the session${soft}`;
    if (!session) row('The meta outlasts the session', 'skip', 'no session length', mtarget);
    else if (!num(fin)) row('The meta outlasts the session', 'skip', 'the campaign does not finish (the wall check says why)', mtarget);
    else row('The meta outlasts the session', sev(fin < mt.metaOverSession * sessionMin!), `the meta ${f1(fin)} min, the session ${f1(sessionMin!)} min (${f1(fin / sessionMin!)}×)`, mtarget);
    const meta = opts.metaMin;
    if (num(meta) && meta > 0 && num(fin)) {
      const off = Math.abs(fin - meta) / meta;
      row("The meta's length agrees with money.meta", off > mt.metaTolerance ? 'warn' : 'ok', `the model ${f1(fin)} min, game.yaml money.meta.minutes ${f1(meta)} (${Math.round(off * 100)} % apart)`, `within ${pct(mt.metaTolerance)} (a warning: correct the one that is wrong)`);
    }
  }
  // 12. A run's checks (shape: run): the first run's length, how far the progressed player gets, a winning run's length
  // against the session, the runs getting further within the first session
  let run: ModelResult['run'] = null;
  if (isRun && model.stages.length) {
    const runs = cheap.runs ?? [];
    const first = runs[0];
    const fresh = first ? { power: first.power, depth: first.depth, win: first.win, minutes: first.minutes, coins: first.coins } : runShape(model, model.start.power);
    const full = runShape(model, cheap.power);
    const winMinutes = (model.overheadMin ?? 0.25) + model.stages.reduce((m, s) => m + s.minutes, 0);
    const atSession = num(sessionMin) && sessionMin > 0 ? (runs.filter((r) => r.startMin <= sessionMin).at(-1) ?? null) : null;
    run = { fresh, full, winMinutes, atSession };
    const n = model.stages.length;
    const stagesText = (r: ModelRunShape) => `${f1(r.depth)} of ${n} stages, ${f1(r.minutes)} min (wins ${pct(r.win)})`;
    row('A first run shows the game', sev(fresh.minutes < mt.runFreshMin || fresh.depth < 1), `the first run: ${stagesText(fresh)}`, `a fresh player's first run lasts ≥ ${mt.runFreshMin} min and clears ≥ 1 stage${soft}`);
    const grows = full.depth >= mt.runFullOverFresh * fresh.depth || full.depth >= mt.runFullShare * n;
    row('Progress carries into the run', sev(!grows), `fresh ${f1(fresh.depth)} → fully progressed ${f1(full.depth)} stages a run (×${f2(full.depth / Math.max(1e-9, fresh.depth))}); a full run wins ${pct(full.win)}`, `the fully progressed player gets ≥ ${mt.runFullOverFresh}× as far as a fresh one, or to ${pct(mt.runFullShare)} of the stages${soft}`);
    const wtarget = `a run that clears every stage fits ${mt.runWinSessions === 1 ? 'the session' : `${f2(mt.runWinSessions)} sessions`}${soft}`;
    if (!num(sessionMin) || !(sessionMin > 0)) row('A winning run fits the session', 'skip', "no session length: game.yaml money.session.minutes or the model's sessionMin", wtarget);
    else row('A winning run fits the session', sev(winMinutes > mt.runWinSessions * sessionMin), `a run of all ${n} stages: ${f1(winMinutes)} min, the session ${f1(sessionMin)} min`, wtarget);
    const gtarget = `the run in progress at the session's end gets ≥ ${f1(mt.runSessionGain)} stage${mt.runSessionGain === 1 ? '' : 's'} further than the first run${soft}`;
    if (!atSession || !first) row('The runs get further in the first session', 'skip', atSession ? 'no run' : 'no session length', gtarget);
    else if (atSession.run === 1) row('The runs get further in the first session', 'skip', `the first run lasts the whole session (${f1(first.minutes)} min)`, gtarget);
    else row('The runs get further in the first session', sev(atSession.depth - first.depth < mt.runSessionGain), `run ${atSession.run} (at minute ${f1(atSession.startMin)}): ${f1(atSession.depth)} stages, the first ${f1(first.depth)} (+${f1(atSession.depth - first.depth)})`, gtarget);
  }
  // 11. The power is the anchor: the model's measure names it
  if (anchor && model.measure) {
    const word = (w: string) => new RegExp(`(^|[^\\p{L}\\p{N}])${w.trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}($|[^\\p{L}\\p{N}])`, 'iu').test(model.measure!);
    const ok = word(anchor.unit) || word(anchor.name);
    row('The power is measured in the anchor', ok ? 'ok' : 'warn', ok ? `"${model.measure}" names the anchor (${anchor.name}, ${anchor.unit})` : `"${model.measure}" names neither "${anchor.name}" nor its unit "${anchor.unit}": the tables may balance another number than the game`, 'the model\'s `measure` names game.yaml balance.anchor (its name or unit)');
  }

  // The report: the model's campaign, as a bot would give it
  const curveOf = (r: ModelRun): BuyerCurve => ({ firstPurchaseRun: r.firstPurchaseRun, firstPurchaseMin: r.firstPurchaseMin, finishMin: r.finishMin, finishRun: r.finishRun, goalsMin: r.goalsMin });
  const last = model.stages[model.stages.length - 1];
  const report: BalanceReport = {
    measure: isRun
      ? `stages cleared a run in the model${model.measure ? ` (power: ${model.measure})` : ''}`
      : `the chance to clear ${last?.id ?? 'the last stage'} in the model${model.measure ? ` (power: ${model.measure})` : ''}`,
    ...(run ? { fresh: round2(run.fresh.depth), full: round2(run.full.depth) } : last ? { fresh: round2(win(model.start.power / last.difficulty)), full: round2(win(cheap.power / last.difficulty)) } : {}),
    cheap: curveOf(cheap),
    careful: curveOf(careful),
    dead: model.items.filter((i) => !(i.power ?? 0) && (i.mult ?? 1) === 1).map((i) => i.id),
    note: `the balance model: ${model.stages.length} stages${isRun ? ' a run' : ''}, ${model.items.length} items, expected values`,
  };

  const failed = checks.filter((c) => c.status === 'fail').length;
  const warned = checks.filter((c) => c.status === 'warn').length;
  const result: ModelResult = { measure: model.measure ?? 'power', cheap, careful, growth, checks, failed, warned, strict, shape, run, firstRewardSec, session, report, markdown: '' };
  result.markdown = modelMarkdown(result);
  return result;
}

const round2 = (n: number) => Math.round(n * 1000) / 1000;

/** A run at a power, without the per-stage chances */
function runShape(model: BalanceModel, power: number): ModelRunShape {
  const { depth, win, minutes, coins } = runAt(model, power);
  return { power, depth, win, minutes, coins };
}

const icon: Record<BalanceStatus, string> = { ok: '✅', warn: '⚠️', fail: '❌', skip: '–' };
const cell = (v: number | null | undefined, f = f1) => (num(v) ? f(v) : '—');

/** The model's tables and checks, for qa/balance.md */
export function modelMarkdown(r: ModelResult): string {
  const c = r.cheap;
  return [
    `## The balance model (power: ${r.measure})`,
    '',
    r.shape === 'run'
      ? `Runs (balance.anchor.shape: run — every run starts at the first stage and goes on until a loss; purchases between runs). Cheapest-first: the meta ends at ${cell(c.finishMin)} min after ${c.attempts} runs${c.stuck ? ` — **stuck: ${c.stuck}**` : ''}. Best-value: ${cell(r.careful.finishMin)} min. Growth a stage: difficulty ×${cell(r.growth.difficulty, f2)}, reward ×${cell(r.growth.reward, f2)}; prices ×${cell(r.growth.price, f2)} from one item to the next dearer one.${r.run ? ` A fresh run: ${f1(r.run.fresh.depth)} stages in ${f1(r.run.fresh.minutes)} min; fully progressed: ${f1(r.run.full.depth)} stages, wins ${pct(r.run.full.win)}; a run of every stage takes ${f1(r.run.winMinutes)} min.` : ''}`
      : `Cheapest-first: the campaign ends at ${cell(c.finishMin)} min, ${Math.round(c.attempts * 10) / 10} attempts, ${f1(c.farmMin)} min replaying for coins${c.stuck ? ` — **stuck: ${c.stuck}**` : ''}. Best-value: ${cell(r.careful.finishMin)} min. Growth a stage: difficulty ×${cell(r.growth.difficulty, f2)}, reward ×${cell(r.growth.reward, f2)}; prices ×${cell(r.growth.price, f2)} from one item to the next dearer one.`,
    '',
    '| | Check | Model | Target |',
    '|---|---|---|---|',
    ...r.checks.map((k) => `| ${icon[k.status]} | ${k.name.replace(/^model: /, '')} | ${k.detail.replace(/\|/g, '\\|')} | ${k.target} |`),
    '',
    r.strict
      ? `game.yaml declares \`balance.anchor\`: the first-session, ${r.shape === 'run' ? 'run' : 'difficulty-shape'} and session-end checks fail like the others.`
      : `game.yaml declares no \`balance.anchor\`: the first-session, ${r.shape === 'run' ? 'run' : 'difficulty-shape'} and session-end checks only warn (docs/guides/upgrades.md → Start from time, then the anchor).`,
    '',
    ...timelineMarkdown(r),
    ...(r.shape === 'run' ? runsMarkdown(c.runs ?? []) : []),
    '### Stages (cheapest-first player)',
    '',
    r.shape === 'run'
      ? '| Stage | Difficulty | Reward | First reached (min) | Power then | Power ÷ difficulty | Win when reached | Runs reaching it | Farming (min) | First cleared (min) |'
      : '| Stage | Difficulty | Reward | Arrives (min) | Power on arrival | Power ÷ difficulty | Win on arrival | Attempts | Farming (min) | Cleared (min) |',
    '|---|---|---|---|---|---|---|---|---|---|',
    ...c.stages.map((s) => `| ${s.id} | ${f1(s.difficulty)} | ${f1(s.reward)} | ${cell(s.arriveMin)} | ${cell(s.arrivePower)} | ${cell(s.ratio, f2)} | ${num(s.winOnArrival) ? pct(s.winOnArrival) : '—'} | ${cell(s.attempts)} | ${f1(s.farmMin)} | ${cell(s.clearedMin)} |`),
    '',
    '### Purchases (cheapest-first player)',
    '',
    '| Item | Cost | For sale after | Bought (min) | On stage | Power before → after | Power per 1 000 coins | Minutes of income |',
    '|---|---|---|---|---|---|---|---|',
    ...c.items.map((i) => `| ${i.id} | ${f1(i.cost)} | ${i.after ?? 'start'} | ${cell(i.boughtMin)} | ${i.atStage ?? '—'} | ${num(i.powerBefore) ? `${f1(i.powerBefore)} → ${f1(i.powerAfter!)}` : '—'} | ${cell(i.valuePer1k, f2)} | ${cell(i.incomeMin)} |`),
    '',
  ].join('\n');
}

/** A run-shaped walk's runs: the first ten, then every tenth, and the last */
function runsMarkdown(runs: readonly ModelRunRow[]): string[] {
  const shown = runs.filter((r, i) => i < 10 || r.run % 10 === 0 || i === runs.length - 1);
  return [
    '### Runs (cheapest-first player, expected values)',
    '',
    '| Run | Starts (min) | Power | Stages cleared | Wins | Minutes | Coins |',
    '|---|---|---|---|---|---|---|',
    ...shown.map((r) => `| ${r.run} | ${f1(r.startMin)} | ${f1(r.power)} | ${f1(r.depth)} | ${pct(r.win)} | ${f1(r.minutes)} | ${f1(r.coins)} |`),
    '',
  ];
}

/** The first session: the session-end hook and the reward timeline (minute → what arrives), up to the session's end */
function timelineMarkdown(r: ModelResult): string[] {
  const c = r.cheap;
  const until = r.session?.minute ?? 15;
  const rows = new Map<number, string[]>();
  for (const e of c.timeline) {
    if (e.min > until) break;
    const m = Math.floor(e.min);
    const what = e.what === 'stage' ? `${e.id} cleared${e.news && e.news.kind !== 'stage' ? ` (${e.news.kind})` : ''}` : `${e.id}${e.news ? ` (${e.news.kind})` : ''}`;
    rows.set(m, [...(rows.get(m) ?? []), `${e.news ? (e.news.weight >= MODEL_TARGETS.bigNews ? '★ ' : '') : ''}${what}`]);
  }
  const later = c.timeline.filter((e) => e.min > until).length;
  return [
    `### The first session (cheapest-first player)`,
    '',
    `The first reward at ${num(r.firstRewardSec) ? `${Math.round(r.firstRewardSec)} s` : '—'}. ${r.session ? `The session's end (${f1(r.session.minute)} min, ${r.session.from}): ${snapshotText(r.session)}; ${windowText(r.session.window)}.` : "No session length (game.yaml money.session.minutes, or the model's sessionMin): the session-end hook is not read."}`,
    '',
    '| Minute | What arrives (★ a big reward; a name alone: a purchase that is not news) |',
    '|---|---|',
    ...[...rows].map(([m, xs]) => `| ${m} | ${xs.length > 8 ? `${xs.slice(0, 8).join(', ')} +${xs.length - 8}` : xs.join(', ')} |`),
    ...(later ? [`| later | ${later} more clear(s) and purchase(s) until the campaign ends |`] : []),
    '',
  ];
}

/** The two tables as CSV (qa/balance-stages.csv, balance-items.csv), to open in Google Sheets or Excel and play with */
export function modelCsv(r: ModelResult): { stages: string; items: string } {
  const esc = (v: unknown) => {
    const s = v === null || v === undefined ? '' : String(typeof v === 'number' ? Math.round(v * 1000) / 1000 : v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const csv = (head: string[], rows: unknown[][]) => [head, ...rows].map((row) => row.map(esc).join(',')).join('\n') + '\n';
  return {
    stages: csv(
      ['stage', 'difficulty', 'reward', 'arrive_min', 'arrive_power', 'ratio', 'win_on_arrival', 'attempts', 'farm_min', 'cleared_min', 'coins_earned'],
      r.cheap.stages.map((s) => [s.id, s.difficulty, s.reward, s.arriveMin, s.arrivePower, s.ratio, s.winOnArrival, s.attempts, s.farmMin, s.clearedMin, s.coinsEarned]),
    ),
    items: csv(
      ['item', 'cost', 'after', 'bought_min', 'at_stage', 'power_before', 'power_after', 'power_per_1000', 'income_min', 'careful_bought_min'],
      r.cheap.items.map((i) => [i.id, i.cost, i.after ?? '', i.boughtMin, i.atStage, i.powerBefore, i.powerAfter, i.valuePer1k, i.incomeMin, r.careful.items.find((x) => x.id === i.id)?.boughtMin ?? null]),
    ),
  };
}

/**
 * The model against the bot, at a game's launch: the meta's length and the first purchase within `tolerance` (default
 * 25 %). A patch then trusts the model alone (gp qa skips the bot in an update), so a disagreement here is a warning
 * to calibrate it: fitWinCurve() from the bot's wins, the stages' minutes, the power each purchase adds
 */
export function compareToBot(model: BalanceReport, bot: BalanceReport, tolerance = 0.25): BalanceRow[] {
  const rows: BalanceRow[] = [];
  const target = `the model within ${Math.round(tolerance * 100)} % of the bot (patches run the model alone)`;
  const pair = (name: string, m: number | null | undefined, b: number | null | undefined, unit: string) => {
    if (!num(b) || !num(m)) {
      rows.push({ name: `model vs bot: ${name}`, status: num(b) !== num(m) ? 'warn' : 'skip', detail: `model ${num(m) ? `${f1(m)} ${unit}` : 'never'}, bot ${num(b) ? `${f1(b)} ${unit}` : 'never'}`, target });
      return;
    }
    const err = b > 0 ? Math.abs(m - b) / b : m === b ? 0 : 1;
    rows.push({ name: `model vs bot: ${name}`, status: err <= tolerance ? 'ok' : 'warn', detail: `model ${f1(m)} ${unit}, bot ${f1(b)} ${unit} (${err <= tolerance ? '' : 'off by '}${Math.round(err * 100)} %)`, target });
  };
  pair("the meta's length", model.cheap?.finishMin, bot.cheap?.finishMin, 'min');
  // The first purchase is a minute or two: a whole minute apart is the honest tolerance there
  const fm = model.cheap?.firstPurchaseMin;
  const fb = bot.cheap?.firstPurchaseMin;
  if (num(fm) && num(fb)) {
    const ok = Math.abs(fm - fb) <= Math.max(1, tolerance * fb);
    rows.push({ name: 'model vs bot: the first purchase', status: ok ? 'ok' : 'warn', detail: `model at ${f1(fm)} min, bot at ${f1(fb)} min`, target: `within ${Math.round(tolerance * 100)} % or a minute` });
  }
  return rows;
}

// --- A model from the bot's campaign ------------------------------------------------------------------------------------

/** One stage of a bot's campaign as it played it: the minutes it took, the coins it earned there, its power on arrival */
export interface CampaignStage {
  /** The stage's id (default `stage-<n>`) */
  id?: string;
  /** Minutes the bot spent on it, from arrival to the clear (noisy: a lucky drop, a rare chest — smoothed below) */
  minutes: number;
  /** Coins it earned there */
  reward: number;
  /** The bot's power on arrival, in the model's unit (damage a second, income a minute) */
  power: number;
  kind?: 'boss' | 'breather';
  news?: ModelNews;
  goal?: boolean;
  lossReward?: number;
}

/** One purchase in a bot's campaign */
export interface CampaignBuy {
  /** Minute of play it was bought */
  min: number;
  cost: number;
  /** The power it added (the bot measured before → after) … */
  gain?: number;
  /** … or the power right after it (a dip — a new place's fresh tools — is held at the best so far: the model's power never falls) */
  powerAfter?: number;
  id?: string;
  news?: ModelNews;
}

/** A bot's campaign: where it started, the stages it cleared in order, what it bought and when */
export interface CampaignLog {
  start: { power: number; coins?: number };
  stages: readonly CampaignStage[];
  buys?: readonly CampaignBuy[];
}

/** How modelFromCampaign() turns the campaign into tables; the rest are the model's own fields (win, finish, sessionMin …) */
export interface FromCampaignOptions extends Omit<Partial<BalanceModel>, 'stages' | 'items' | 'start'> {
  /** A stage's minutes are the running mean of this many stages around it (default 5; bosses keep their own) */
  smooth?: number;
  /** … rising at most this much from the stage before (default 1.3) */
  growthCap?: number;
  /** … and never under this (default 0.2 min) */
  minMinutes?: number;
  /** A stage's difficulty: the bot's power on arrival × this (default 0.7 — the bot arrived able to clear it) */
  difficultyShare?: number;
  /** Purchases within this many minutes of the first of them are one item (default 0.25: a quarter-minute's shopping) */
  batchMin?: number;
}

const heavier = (a: ModelNews | undefined, b: ModelNews | undefined): ModelNews | undefined => {
  if (!a || !b) return a ?? b;
  return (b.weight ?? NEWS_WEIGHT[b.kind]) > (a.weight ?? NEWS_WEIGHT[a.kind]) ? b : a;
};

/**
 * A balance model built from the bot's own campaign — the recipe both idle games wrote by hand (Craft Pickaxe's and
 * Garage Evolution's bot.ts): a stage per stage the bot cleared, its minutes the running mean of `smooth` stages around
 * it (the bot's times are noisy) rising at most ×`growthCap` a stage, its difficulty the bot's power on arrival ×
 * `difficultyShare`, its reward what the bot earned there; the purchases what the bot bought, a quarter-minute's
 * shopping one item, each after the one before (the bot's order), with the power it measured. Several campaigns
 * (seeds): the stages averaged one by one over the stages every campaign reached, the purchases from the first. The
 * model stays true to the real rules after every price change, and a patch can run it alone (docs/guides/upgrades.md §7)
 */
export function modelFromCampaign(campaigns: CampaignLog | readonly CampaignLog[], opts: FromCampaignOptions = {}): BalanceModel {
  const list: readonly CampaignLog[] = Array.isArray(campaigns) ? campaigns : [campaigns as CampaignLog];
  if (!list.length) throw new Error('modelFromCampaign: no campaign');
  const { smooth = 5, growthCap = 1.3, minMinutes = 0.2, difficultyShare = 0.7, batchMin = 0.25, ...model } = opts;
  const n = Math.min(...list.map((c) => c.stages.length));
  const mean = (pick: (s: CampaignStage) => number, i: number) => list.reduce((a, c) => a + pick(c.stages[i]), 0) / list.length;
  const first = list[0];
  const raw = Array.from({ length: n }, (_, i) => ({ ...first.stages[i], minutes: mean((s) => s.minutes, i), reward: mean((s) => s.reward, i), power: mean((s) => s.power, i) }));
  // The running mean over the stages around it (bosses aside: a deliberate peak keeps its own length), capped in growth
  const half = Math.max(0, Math.floor(smooth / 2));
  const plain = raw.map((s, i) => ({ s, i })).filter((x) => x.s.kind !== 'boss');
  const smoothed = new Map<number, number>();
  let prev = 0;
  plain.forEach((x, k) => {
    const near = plain.slice(Math.max(0, k - half), k + half + 1);
    let m = near.reduce((a, y) => a + y.s.minutes, 0) / near.length;
    if (prev > 0) m = Math.min(m, prev * growthCap);
    prev = m = Math.max(minMinutes, m);
    smoothed.set(x.i, m);
  });
  const stages: ModelStage[] = raw.map((s, i) => ({
    id: s.id ?? `stage-${i + 1}`,
    difficulty: Math.max(1e-9, s.power * difficultyShare),
    reward: Math.max(0, s.reward),
    minutes: smoothed.get(i) ?? Math.max(minMinutes, s.minutes),
    ...(s.kind ? { kind: s.kind } : {}),
    ...(s.news ? { news: s.news } : {}),
    ...(s.goal !== undefined ? { goal: s.goal } : {}),
    ...(s.lossReward !== undefined ? { lossReward: s.lossReward } : {}),
  }));
  // The purchases, batched by time, in the bot's order: the power they add, or the power path held so it never falls
  const items: ModelItem[] = [];
  const startPower = list.reduce((a, c) => a + c.start.power, 0) / list.length;
  let held = startPower;
  type Batch = { at: number; cost: number; gain: number; gains: boolean; after: number | null; ids: string[]; news?: ModelNews };
  let batch: Batch | null = null;
  const flush = (b: Batch | null) => {
    if (!b || b.cost <= 0) return;
    const id = b.ids.length === 1 && b.ids[0] ? `${b.ids[0]}#${items.length + 1}` : `buy-${items.length + 1}`;
    const before = held;
    let add: { power: number } | { mult: number };
    if (!b.gains && b.after !== null) {
      held = Math.max(held * 1.0005, b.after);
      add = { mult: Math.round((held / before) * 1e5) / 1e5 };
    } else {
      held += b.gain;
      add = { power: Math.max(1e-9, b.gain) };
    }
    items.push({ id, cost: Math.round(b.cost), ...add, ...(items.length ? { requires: items[items.length - 1].id } : {}), ...(b.news ? { news: b.news } : {}) });
  };
  for (const b of [...(first.buys ?? [])].sort((x, y) => x.min - y.min)) {
    if (!batch || b.min - batch.at > batchMin) {
      flush(batch);
      batch = { at: b.min, cost: 0, gain: 0, gains: false, after: null, ids: [] };
    }
    batch.cost += b.cost;
    if (num(b.gain)) (batch.gain += b.gain), (batch.gains = true);
    if (num(b.powerAfter)) batch.after = b.powerAfter;
    batch.ids.push(b.id ?? '');
    batch.news = heavier(batch.news, b.news);
  }
  flush(batch);
  return { ...model, start: { power: startPower, ...(num(first.start.coins) ? { coins: first.start.coins } : {}) }, stages, items };
}
