// gp forecast: idea mode (step 1, before any code), game mode (the money section, the code, the report file),
// the recorded results; and what it reads from a game's code.

import { execFileSync } from 'node:child_process';
import { cpSync, existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterAll, describe, expect, it } from 'vitest';
import { runBalance } from '../src/balance.ts';
import { codeFacts, forecastLine, gameForecast, loadResults } from '../src/forecast.ts';
import { checkGame } from '../src/game.ts';
import { locateGame, ROOT } from '../src/paths.ts';

const tmp = mkdtempSync(join(tmpdir(), 'gp-forecast-'));
afterAll(() => rmSync(tmp, { recursive: true, force: true }));

function gp(args: string[]): { code: number; out: string } {
  try {
    return { code: 0, out: execFileSync(process.execPath, [join(ROOT, 'packages/cli/src/gp.ts'), ...args], { cwd: ROOT, encoding: 'utf8', env: { ...process.env, GP_NO_LOG: '1', NO_COLOR: '1' } }) };
  } catch (e) {
    const x = e as { status: number; stdout: string };
    return { code: x.status, out: x.stdout };
  }
}

/** A game from the template with its concept and money written */
function fromTemplate(name: string, money?: string): string {
  const dir = join(tmp, name, 'games', name);
  cpSync(join(ROOT, 'templates/game-repo'), join(tmp, name), { recursive: true });
  cpSync(join(tmp, name, 'games/__ID__'), dir, { recursive: true });
  rmSync(join(tmp, name, 'games/__ID__'), { recursive: true });
  let yaml = readFileSync(join(dir, 'game.yaml'), 'utf8').replace(/__ID__/g, name).replace(/__TITLE__/g, 'Lantern Walk');
  yaml = yaml
    .replace(/  pitch: .*\n/, '  pitch: "Swing a lantern on a rope to light the path for a sleepwalker."\n')
    .replace(/  closest: .*\n/, '  closest: ["Rope Hero", "Night Walk", "Light Path"]\n')
    .replace(/  different: .*\n/, '  different: "You never control the walker: you only move the light, and the walker steps only where it falls."\n')
    .replace(/  progression: .*\n/, '  progression: "Lanterns: fireflies buy new lanterns, each lighting the path its own way"\n');
  if (money !== undefined) yaml = yaml.replace(/money:\n(  .*\n|  #.*\n)+/, money);
  else
    yaml = yaml
      .replace(/  genre: TODO.*\n/, '  genre: puzzle\n')
      .replace(/TODO: where the breaks are[^"]*/, 'a walk ends → Next night')
      .replace(/TODO: what the player gets[^"]*/, 'the lantern relit once')
      .replace(/TODO: why a player comes back tomorrow[^"]*/, 'a new night every day');
  writeFileSync(join(dir, 'game.yaml'), yaml);
  return dir;
}

describe('gp forecast --idea', () => {
  it('prints the path, a revenue table with three columns, the expected value, levers and the assumptions with their confidence', () => {
    const r = gp(['forecast', '--idea', '--channel', 'crazygames', '--genre', 'idle', '--session', '15', '--breaks', '4', '--rewarded', 'revive,x2']);
    expect(r.code).toBe(0);
    expect(r.out).toContain('Estimates, not promises');
    expect(r.out).toMatch(/\| Month 1 after submission \| €[\d.,]+ \| €[\d.,]+ \| €[\d.,]+ \|/);
    expect(r.out).toContain('**Expected value**');
    expect(r.out).toContain('QA review');
    expect(r.out).toContain('Basic Launch');
    expect(r.out).toMatch(/## Levers[\s\S]*1\. \*\*/);
    expect(r.out).toMatch(/\d+ inputs: .*low/);
    expect(r.out).toMatch(/^money \(estimates\): P\(approval\)/m);
  });
  it('--json gives the numbers; a genre it doesn\'t know is refused', () => {
    const j = JSON.parse(gp(['forecast', '--idea', '--channel', 'crazygames', '--genre', 'puzzle', '--json']).out);
    expect(j.forecast.pApproval.low).toBeLessThanOrEqual(j.forecast.pApproval.high);
    expect(j.design.genre).toBe('puzzle');
    const bad = gp(['forecast', '--idea', '--channel', 'crazygames', '--genre', 'rhythm']);
    expect(bad.code).toBe(1);
    expect(bad.out).toContain('unknown genre');
    // A sub-genre is benchmarked as its genre (genres.ts), and the idea forecast names its must-haves
    const rogue = gp(['forecast', '--idea', '--channel', 'crazygames', '--genre', 'roguelite']);
    expect(rogue.code).toBe(0);
    expect(rogue.out).toContain('Roguelite players expect');
  });
  it('--pitch is read against the taken concepts; kids get no rewarded ads; --out writes the full report', () => {
    const pp = JSON.parse(gp(['forecast', '--idea', '--channel', 'crazygames', '--genre', 'action', '--pitch', 'A cell fights germs in a survivors-like with auto-attack', '--json']).out);
    // Taken concepts take at most 25 points, as in gp uniqueness
    expect(pp.design.uniqueness.score).toBe(55);
    const kids = JSON.parse(gp(['forecast', '--idea', '--channel', 'android-families', '--rewarded', 'revive', '--json']).out);
    expect(kids.forecast.unit.rewarded.high).toBe(0);
    const file = join(tmp, 'idea.md');
    expect(gp(['forecast', '--idea', '--channel', 'crazygames', '--genre', 'puzzle', '--out', file]).code).toBe(0);
    expect(readFileSync(file, 'utf8')).toContain('| Input | Low | Mid | High | Unit | Confidence | Source |');
  });
});

describe('gp forecast --idea refuses what the validator would', () => {
  it('a 0-min session or a fractional break count: a clear error, at once (it used to hang)', () => {
    const t = Date.now();
    const r = gp(['forecast', '--idea', '--genre', 'puzzle', '--session', '0', '--breaks', '3']);
    expect(r.code).toBe(1);
    expect(r.out).toMatch(/--session 0: minutes per session, more than 0/);
    expect(Date.now() - t).toBeLessThan(20_000);
    const b = gp(['forecast', '--idea', '--genre', 'puzzle', '--breaks', '2.5']);
    expect(b.code).toBe(1);
    expect(b.out).toMatch(/--breaks 2.5: natural breaks per session, a whole number/);
  });
  it('an audience the channel doesn\'t accept, or an unknown one', () => {
    const kids = gp(['forecast', '--idea', '--channel', 'crazygames', '--audience', 'ages-2-5', '--genre', 'puzzle']);
    expect(kids.code).toBe(1);
    expect(kids.out).toContain('ages-2-5');
    const unknown = gp(['forecast', '--idea', '--channel', 'crazygames', '--audience', 'grown-ups', '--genre', 'puzzle']);
    expect(unknown.code).toBe(1);
    expect(unknown.out).toContain('unknown audience "grown-ups"');
  });
});

describe('gp forecast <game>', () => {
  it('"Record the outcome": revenue per day is month 2 ÷ 30 of each scenario, on Google Play too', () => {
    const file = join(tmp, 'balloon-forecast.md');
    expect(gp(['forecast', 'balloon-pop', '--out', file]).code).toBe(0);
    const j = JSON.parse(gp(['forecast', 'balloon-pop', '--json']).out);
    const m = readFileSync(file, 'utf8').match(/revenuePerDay: \[([^\]]+)\]/);
    expect(m).not.toBeNull();
    const printed = m![1].split(',').map(Number);
    const want = [j.forecast.months.pessimistic[1], j.forecast.months.median[1], j.forecast.months.optimistic[1]].map((x: number) => Math.round((x / 30) * 100) / 100);
    expect(printed).toEqual(want);
  });
  it('the forecast takes the balance run it is given (gp qa\'s), so the qa line and forecast.md agree', async () => {
    const dir = fromTemplate('balrun');
    const loc = locateGame(dir);
    const r = checkGame(loc, 'dev');
    expect(r.game).toBeTruthy();
    const game = r.game!;
    const own = await gameForecast(loc, game, r.issues);
    const run = await runBalance(loc, game.channel.id);
    expect(run).not.toBeNull();
    const given = await gameForecast(loc, game, r.issues, { balanceRun: run });
    expect(given.forecast).toEqual(own.forecast);
    expect(given.balance).toBe(own.balance);
    // What the qa run found is what the forecast reads: a meta of 999 min, a failed run, no export
    const long = await gameForecast(loc, game, r.issues, { balanceRun: { ...run!, report: { ...run!.report, cheap: { ...run!.report.cheap!, finishMin: 999 } } } });
    expect(long.design.metaMin).toBe(999);
    expect((await gameForecast(loc, game, r.issues, { balanceRun: new Error('boom') })).balance).toMatch(/balance\(\) failed: boom/);
    expect((await gameForecast(loc, game, r.issues, { balanceRun: null })).balance).toBeNull();
    // balance.difficulty.winningRunMin declared: the session is the bot's winning run, else the range's middle
    const roguelite = { ...game, kit: { ...(game.kit as object), difficulty: { winningRunMin: [30, 40] as const } } } as typeof game;
    const won = await gameForecast(loc, roguelite, r.issues, { balanceRun: { ...run!, report: { ...run!.report, skills: { skilled: { runs: 120, wins: 24, winMin: 33 } } } } });
    expect(won.design.sessionMin).toBe(33);
    expect(won.design.from.session).toMatch(/^balance\(\): the skilled bot's winning run, 33\.0 min \(median; declared 30–40\) — balance\.difficulty\.winningRunMin is declared/);
    const declared = await gameForecast(loc, roguelite, r.issues, { balanceRun: null });
    expect(declared.design.sessionMin).toBe(35);
    expect(declared.design.from.session).toMatch(/its middle \(no winning run measured/);
  }, 60_000);
  it('reads the money section, writes qa/forecast.md with every assumption and the lines to record the outcome', () => {
    const dir = fromTemplate('lantern');
    const r = gp(['forecast', dir]);
    expect(r.code).toBe(0);
    expect(r.out).toContain('Lantern Walk — money forecast (crazygames)');
    expect(r.out).toMatch(/\| Natural breaks \| 5 per session .*\| money\.session\.breaks \|/);
    expect(r.out).toMatch(/\| Uniqueness \| \d+\/100/);
    const md = readFileSync(join(dir, 'qa', 'forecast.md'), 'utf8');
    expect(md).toContain('| Input | Low | Mid | High | Unit | Confidence | Source |');
    expect(md).toContain('## Record the outcome');
    expect(md).toContain('  - game: lantern');
    expect(md).toContain('petri-panic');
  });
  it('the template\'s TODO money design is refused, like its concept', () => {
    const dir = join(tmp, 'todo', 'games', 'todo');
    cpSync(join(ROOT, 'templates/game-repo/games/__ID__'), dir, { recursive: true });
    writeFileSync(join(dir, 'game.yaml'), readFileSync(join(dir, 'game.yaml'), 'utf8').replace(/__ID__/g, 'todo').replace(/__TITLE__/g, 'Todo Game'));
    const r = gp(['forecast', dir]);
    expect(r.code).toBe(1);
    expect(r.out).toContain('E_MONEY');
    expect(r.out).toContain('gp forecast --idea');
  });
  it('without a money section it derives the design from the code and says so; --out keeps the game folder clean', () => {
    const dir = fromTemplate('nomoney', '');
    const out = join(tmp, 'elsewhere', 'forecast.md');
    const r = gp(['forecast', dir, '--out', out]);
    expect(r.code).toBe(0);
    expect(r.out).toContain('W_MONEY_MISSING');
    expect(r.out).toMatch(/\| Rewarded offers \| continue \(continue, per session\) \| the code/);
    expect(existsSync(out)).toBe(true);
    expect(existsSync(join(dir, 'qa', 'forecast.md'))).toBe(false);
  });
});

describe('what the code says, and the recorded results', () => {
  it('codeFacts: host.rewarded, rewardedButton placements, the game\'s own wrapper, host.adBreak', () => {
    const dir = join(tmp, 'facts', 'games', 'facts');
    mkdirSync(join(dir, 'src'), { recursive: true });
    writeFileSync(join(dir, 'game.yaml'), 'spec: 0\n');
    writeFileSync(join(dir, 'main.ts'), "const offer = (placement: string, label: string) => rewardedButton({ host, placement, label });\noffer('hint', 'Show a hook');\nawait host.rewarded('double');\n");
    writeFileSync(join(dir, 'src', 'ui.ts'), "rewardedButton({ host, placement: 'rise-again', label: 'Rise' });\nawait host.adBreak();\n");
    writeFileSync(join(dir, 'main.test.ts'), "host.rewarded('from-a-test');\n");
    const f = codeFacts(locateGame(dir));
    expect(f.rewarded.sort()).toEqual(['double', 'hint', 'rise-again']);
    expect(f.adBreak).toBe(true);
  });
  it('gp forecast --results checks publisher/results.yaml and compares the model with it', () => {
    const r = gp(['forecast', '--results']);
    expect(r.code).toBe(0);
    expect(r.out).toContain('petri-panic');
    expect(r.out).toContain('rejected');
    expect(r.out).toMatch(/✓ publisher\/results\.yaml: \d+ result/);
    expect(loadResults().issues).toEqual([]);
    const bad = join(tmp, 'results.yaml');
    writeFileSync(bad, 'results:\n  - { game: x-game, channel: crazygames, review: { verdict: maybe } }\n');
    expect(loadResults(bad).issues.map((i) => i.code)).toContain('E_ENUM');
  });
  it('the qa line never claims one number', () => {
    const j = JSON.parse(gp(['forecast', '--idea', '--channel', 'crazygames', '--genre', 'action', '--json']).out);
    expect(forecastLine(j.forecast)).toMatch(/estimates.*–.*\/.*\/.*range/);
  });
});
