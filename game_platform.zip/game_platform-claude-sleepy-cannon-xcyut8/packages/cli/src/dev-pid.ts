// Which `gp dev` serves a game, so `gp dev --stop` can stop exactly that one. Agents used `pkill -f vite` and killed
// their own shell, whose command line contains the pattern (Craft Pickaxe Idle's report). One small JSON per game folder
// in the OS temp dir (never in the repository): { pid, url, dir, started }.

import { createHash } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';

export interface DevRecord {
  pid: number;
  url: string;
  dir: string;
  started: string;
}

/** Where the record of the game in `dir` lives (GP_DEV_DIR overrides the folder: tests) */
export function devRecordFile(dir: string): string {
  const base = process.env.GP_DEV_DIR || join(tmpdir(), 'gp-dev');
  return join(base, `${createHash('sha1').update(resolve(dir)).digest('hex').slice(0, 16)}.json`);
}

export function writeDevRecord(dir: string, rec: Omit<DevRecord, 'dir' | 'started'>): string {
  const file = devRecordFile(dir);
  mkdirSync(join(file, '..'), { recursive: true });
  writeFileSync(file, JSON.stringify({ ...rec, dir: resolve(dir), started: new Date().toISOString() }));
  return file;
}

/** The record, or null when there is none or its process is gone (a stale record is removed) */
export function readDevRecord(dir: string): DevRecord | null {
  const file = devRecordFile(dir);
  if (!existsSync(file)) return null;
  try {
    const rec = JSON.parse(readFileSync(file, 'utf8')) as DevRecord;
    if (Number.isInteger(rec.pid) && rec.pid > 0 && alive(rec.pid) && isGp(rec.pid)) return rec;
  } catch {
    // a broken record: as if none
  }
  rmSync(file, { force: true });
  return null;
}

/** Remove the record if it is this process's (on exit) */
export function clearDevRecord(dir: string, pid = process.pid): void {
  const file = devRecordFile(dir);
  try {
    if ((JSON.parse(readFileSync(file, 'utf8')) as DevRecord).pid === pid) rmSync(file, { force: true });
  } catch {
    // nothing to clear
  }
}

/** On Linux the process must still be a gp one (a reused pid after a reboot is someone else's); elsewhere trusted */
function isGp(pid: number): boolean {
  const f = `/proc/${pid}/cmdline`;
  if (!existsSync(f)) return true;
  try {
    return /gp|vite|node/.test(readFileSync(f, 'utf8'));
  } catch {
    return true;
  }
}

function alive(pid: number): boolean {
  try {
    process.kill(pid, 0);
    return true;
  } catch (e) {
    return (e as NodeJS.ErrnoException).code === 'EPERM';
  }
}

/** Stop the game's `gp dev` (SIGTERM, then SIGKILL after `graceMs`): what was stopped, or null when none runs */
export async function stopDev(dir: string, graceMs = 3000): Promise<DevRecord | null> {
  const rec = readDevRecord(dir);
  if (!rec) return null;
  try {
    process.kill(rec.pid, 'SIGTERM');
  } catch {
    // gone meanwhile
  }
  const until = Date.now() + graceMs;
  while (alive(rec.pid) && Date.now() < until) await new Promise((r) => setTimeout(r, 100));
  if (alive(rec.pid)) {
    try {
      process.kill(rec.pid, 'SIGKILL');
    } catch {
      // gone
    }
  }
  rmSync(devRecordFile(dir), { force: true });
  return rec;
}
