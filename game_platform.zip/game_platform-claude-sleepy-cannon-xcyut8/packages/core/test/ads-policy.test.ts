// Ad display rules — ported from "Pop the balloon!" tests/ads.test.ts, now with the policy as a parameter.

import { describe, expect, it } from 'vitest';
import { shouldShowAd, type AdPolicy, type AdState } from '../src/ads-policy.ts';

const FAMILIES: AdPolicy = { noAdsAfterLaunchSec: 60, firstAdAfterRound: 2, everyRounds: 2, minIntervalSec: 90, maxAdWaitSec: 120, testAdCloseSec: 5 };

const state = (over: Partial<AdState> = {}): AdState => ({ sessionStartSec: 0, roundsThisSession: 2, roundsSinceAd: 2, lastAdSec: null, ...over });

describe('shouldShowAd with the Families policy', () => {
  it('no ads in the first minute after launch', () => {
    expect(shouldShowAd(state(), 59, false, FAMILIES)).toBe(false);
    expect(shouldShowAd(state(), 60, false, FAMILIES)).toBe(true);
  });
  it('first ad not before round 2', () => {
    expect(shouldShowAd(state({ roundsThisSession: 1, roundsSinceAd: 1 }), 500, false, FAMILIES)).toBe(false);
    expect(shouldShowAd(state({ roundsThisSession: 2, roundsSinceAd: 2 }), 500, false, FAMILIES)).toBe(true);
  });
  it('then at most once per 2 rounds', () => {
    expect(shouldShowAd(state({ roundsThisSession: 3, roundsSinceAd: 1, lastAdSec: 100 }), 500, false, FAMILIES)).toBe(false);
    expect(shouldShowAd(state({ roundsThisSession: 4, roundsSinceAd: 2, lastAdSec: 100 }), 500, false, FAMILIES)).toBe(true);
  });
  it('and at most once per 90 seconds', () => {
    expect(shouldShowAd(state({ roundsSinceAd: 5, lastAdSec: 450 }), 539, false, FAMILIES)).toBe(false);
    expect(shouldShowAd(state({ roundsSinceAd: 5, lastAdSec: 450 }), 540, false, FAMILIES)).toBe(true);
  });
  it('never after "Remove ads"', () => {
    expect(shouldShowAd(state({ roundsSinceAd: 50 }), 10_000, true, FAMILIES)).toBe(false);
  });
});

// CrazyGames (profiles.ts): no ads in the first 3 min; the first at the end of round 3 OR after 5 min of the session,
// whichever comes first; then at most one per round and per 3 min
const CRAZYGAMES: AdPolicy = { noAdsAfterLaunchSec: 180, firstAdAfterRound: 3, firstAdAfterSec: 300, everyRounds: 1, minIntervalSec: 180, maxAdWaitSec: 60, testAdCloseSec: 3 };

describe('shouldShowAd with a time path (firstAdAfterSec)', () => {
  it('a game of long runs gets its first ad at 5 min, after round 1 — not at round 3 (12–15 min in)', () => {
    const run1 = state({ roundsThisSession: 1, roundsSinceAd: 1 });
    expect(shouldShowAd(run1, 299, false, CRAZYGAMES)).toBe(false);
    expect(shouldShowAd(run1, 300, false, CRAZYGAMES)).toBe(true);
  });
  it('a game of short levels still gets it at the end of round 3, once the first 3 min are over', () => {
    expect(shouldShowAd(state({ roundsThisSession: 2, roundsSinceAd: 2 }), 200, false, CRAZYGAMES)).toBe(false);
    expect(shouldShowAd(state({ roundsThisSession: 3, roundsSinceAd: 3 }), 200, false, CRAZYGAMES)).toBe(true);
  });
  it('never in the first 180 s, however many rounds', () => {
    expect(shouldShowAd(state({ roundsThisSession: 20, roundsSinceAd: 20 }), 179, false, CRAZYGAMES)).toBe(false);
    // A time path shorter than the no-ads time doesn't open it earlier
    expect(shouldShowAd(state({ roundsThisSession: 1, roundsSinceAd: 1 }), 179, false, { ...CRAZYGAMES, firstAdAfterSec: 60 })).toBe(false);
  });
  it('measured from the session start; after the first ad the interval and the rounds hold as before', () => {
    expect(shouldShowAd(state({ sessionStartSec: 1000, roundsThisSession: 1, roundsSinceAd: 1 }), 1299, false, CRAZYGAMES)).toBe(false);
    expect(shouldShowAd(state({ sessionStartSec: 1000, roundsThisSession: 1, roundsSinceAd: 1 }), 1300, false, CRAZYGAMES)).toBe(true);
    expect(shouldShowAd(state({ roundsThisSession: 2, roundsSinceAd: 1, lastAdSec: 300 }), 479, false, CRAZYGAMES)).toBe(false);
    expect(shouldShowAd(state({ roundsThisSession: 2, roundsSinceAd: 1, lastAdSec: 300 }), 480, false, CRAZYGAMES)).toBe(true);
    expect(shouldShowAd(state({ roundsThisSession: 2, roundsSinceAd: 1 }), 10_000, true, CRAZYGAMES)).toBe(false);
  });
  it('without it (Families, kids) nothing changes: an hour into the session, round 1 still shows no ad', () => {
    expect(FAMILIES.firstAdAfterSec).toBeUndefined();
    expect(shouldShowAd(state({ roundsThisSession: 1, roundsSinceAd: 1 }), 3600, false, FAMILIES)).toBe(false);
  });
});
