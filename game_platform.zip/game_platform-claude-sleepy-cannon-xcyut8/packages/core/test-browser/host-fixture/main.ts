// Test page for GameHost (packages/core/test-browser/host.test.ts): not a game, a host on a WebGL canvas with a log of
// what a game would see. ?engine=rebuilds: an "engine" listener, added after the host's (an engine made at Play), calls
// preventDefault() on the context loss so the context can come back, and re-creates its state on the restore.
// ?legacy=1: a game written before the reasons set (one-argument onPause).
// The UI layer (#ui) is inert while an ad is pending; mountOffer() puts a rewardedOffer on it (a revive screen).
import { GameHost, rewardedOffer, type RewardedOffer } from '../../src/index';

const q = new URLSearchParams(location.search);
const canvas = document.getElementById('game') as HTMLCanvasElement;
const host = new GameHost({
  saveKey: 'host-fixture',
  minTouchPx: 48,
  locale: 'en-US',
  // Every break may show the dev test ad (1 s; ?ads=fail fails it after 0.1 s)
  ads: { policy: { noAdsAfterLaunchSec: 0, firstAdAfterRound: 0, everyRounds: 1, minIntervalSec: 0, maxAdWaitSec: 10, testAdCloseSec: 1 }, rewarded: true, admob: null },
  portal: null,
  keepEventLog: true,
  canvas,
  title: 'Host Fixture',
});
const gl = canvas.getContext('webgl');
const log: string[] = [];
const sorted = (s: ReadonlySet<string>) => [...s].sort().join(',');
if (q.get('legacy') === '1') host.onPause((reason) => log.push(`pause:${reason}`));
else host.onPause((reason, reasons) => log.push(`pause:${reason}:[${sorted(reasons)}]:pending=${host.adPending}`));
host.onResume(() => log.push(`resume:pending=${host.adPending}:paused=${host.paused}:lost=${gl?.isContextLost()}`));
if (q.get('engine') === 'rebuilds') {
  canvas.addEventListener('webglcontextlost', (e) => {
    e.preventDefault();
    log.push('engine:lost');
  });
  canvas.addEventListener('webglcontextrestored', () => log.push('engine:restored'));
}

/** Play a hidden tab: headless Chromium is never hidden by itself */
function setHidden(hidden: boolean): void {
  Object.defineProperty(document, 'hidden', { configurable: true, get: () => hidden });
  Object.defineProperty(document, 'visibilityState', { configurable: true, get: () => (hidden ? 'hidden' : 'visible') });
  document.dispatchEvent(new Event('visibilitychange'));
}

const ui = document.createElement('div');
ui.id = 'ui';
ui.style.cssText = 'position:fixed;inset:0;display:flex;align-items:center;justify-content:center;padding:16px';
document.body.append(ui);
host.inertDuringAds(ui, canvas);
/** What the "game" did: 'revived' / 'skipped' */
const outcome: string[] = [];
let offer: RewardedOffer | null = null;
function mountOffer(): boolean {
  offer = rewardedOffer({ host, placement: 'continue', label: 'Continue', className: 'btn', onReward: () => outcome.push('revived'), onSkip: () => outcome.push('skipped') });
  if (offer) ui.replaceChildren(offer.el);
  return !!offer;
}

const lose = gl?.getExtension('WEBGL_lose_context') ?? null;
(window as unknown as Record<string, unknown>).__t = {
  host,
  log,
  webgl: !!gl,
  setHidden,
  reasons: () => sorted(host.pauseReasons),
  events: () => host.events.log.map((e) => e.type),
  loseContext: () => lose!.loseContext(),
  restoreContext: () => lose!.restoreContext(),
  ui,
  outcome,
  mountOffer,
  offer: () => offer,
};
