// @gp/core/aim — aim assist, pure: the target nearest the crosshair inside a cone and a range (with a line of sight, if
// the game says how to check one), and the aim turned a little toward it — a soft pull, never a snap. For a touch
// player in a shooter (Frankengun: 0.16 rad cone, at most 0.02 rad a step × 0.6; Candle Crypt's auto-aim on touch), and
// `onTarget` for auto-fire. Works in 3D (x, y, z) and top-down 2D (x, y; z left out).
//
//   const a = aimAssist(eye, forward(yaw, pitch), live, { cone: 0.16, range: 30, strength: 0.6, maxTurn: 0.012, visible: (t) => lineFree(eye, t) });
//   if (touch && a) { ({ yaw, pitch } = yawPitch(a.dir)); if (autoFire && a.onTarget) fire = true; }
//
// Deterministic (no randomness); `visible` is asked only for the candidates, nearest the crosshair first.

export interface V3 {
  x: number;
  y: number;
  z?: number;
}

export interface AimCandidate extends V3 {
  /** Its radius: a big target is easier to be "on" (the cone is measured to its edge) */
  r?: number;
}

export interface AimOptions<T extends AimCandidate> {
  /** Half-angle of the cone round the aim, radians (Frankengun: 0.16) */
  cone: number;
  /** Farther than this is ignored */
  range: number;
  /** 0…1: the share of the remaining angle turned per call (Frankengun: 0.6); 0 finds the target without turning */
  strength: number;
  /** At most this many radians per call (default 0.02: one fixed step's soft pull) */
  maxTurn?: number;
  /** "Close enough to fire": the angle to the target under this (default: 0.75 × cone) */
  fireCone?: number;
  /** A line of sight from the origin (asked nearest-first, only for targets in the cone and range) */
  visible?: (t: T) => boolean;
}

export interface AimResult<T> {
  target: T;
  /** The angle between the aim and the target (to its edge when it has a radius), radians, before the turn */
  angle: number;
  /** The aim after the turn: a unit vector (z 0 in 2D) */
  dir: { x: number; y: number; z: number };
  /** Radians turned this call */
  turned: number;
  /** Within fireCone: auto-fire may shoot */
  onTarget: boolean;
}

const len = (x: number, y: number, z: number) => Math.hypot(x, y, z);

/**
 * The target nearest the crosshair (by angle) within `cone` and `range` that `visible` accepts, and the aim turned toward
 * it by `strength` of the angle (at most `maxTurn`). null when there is none — leave the aim alone then
 */
export function aimAssist<T extends AimCandidate>(origin: V3, dir: V3, targets: Iterable<T>, o: AimOptions<T>): AimResult<T> | null {
  const dl = len(dir.x, dir.y, dir.z ?? 0);
  if (dl < 1e-9) return null;
  const ax = dir.x / dl;
  const ay = dir.y / dl;
  const az = (dir.z ?? 0) / dl;
  const found: { t: T; angle: number; centre: number; bx: number; by: number; bz: number }[] = [];
  for (const t of targets) {
    const dx = t.x - origin.x;
    const dy = t.y - origin.y;
    const dz = (t.z ?? 0) - (origin.z ?? 0);
    const d = len(dx, dy, dz);
    if (d < 1e-6 || d > o.range) continue;
    const bx = dx / d;
    const by = dy / d;
    const bz = dz / d;
    const centre = Math.acos(Math.max(-1, Math.min(1, ax * bx + ay * by + az * bz)));
    const edge = t.r ? Math.asin(Math.min(1, t.r / d)) : 0;
    const angle = Math.max(0, centre - edge);
    if (angle > o.cone) continue;
    found.push({ t, angle, centre, bx, by, bz });
  }
  found.sort((a, b) => a.angle - b.angle);
  const best = found.find((f) => !o.visible || o.visible(f.t));
  if (!best) return null;
  // Turn toward the centre (slerp of the two unit vectors), at most maxTurn, never past it
  const om = best.centre;
  const turn = Math.min(om, om * Math.max(0, Math.min(1, o.strength)), o.maxTurn ?? 0.02);
  let out = { x: ax, y: ay, z: az };
  if (turn > 1e-9 && om > 1e-9) {
    const s = Math.sin(om);
    const k0 = Math.sin(om - turn) / s;
    const k1 = Math.sin(turn) / s;
    out = { x: ax * k0 + best.bx * k1, y: ay * k0 + best.by * k1, z: az * k0 + best.bz * k1 };
    const l = len(out.x, out.y, out.z) || 1;
    out = { x: out.x / l, y: out.y / l, z: out.z / l };
  }
  return { target: best.t, angle: best.angle, dir: out, turned: turn > 1e-9 && om > 1e-9 ? turn : 0, onTarget: best.angle <= (o.fireCone ?? o.cone * 0.75) };
}

/** three's first-person camera: yaw to the right (+x), pitch up, forward −z (Frankengun's convention) → a unit vector */
export function forward(yaw: number, pitch: number): { x: number; y: number; z: number } {
  const c = Math.cos(pitch);
  return { x: Math.sin(yaw) * c, y: Math.sin(pitch), z: -Math.cos(yaw) * c };
}

/** The yaw and pitch of a direction, in `forward()`'s convention */
export function yawPitch(d: V3): { yaw: number; pitch: number } {
  const z = d.z ?? 0;
  return { yaw: Math.atan2(d.x, -z), pitch: Math.atan2(d.y, Math.hypot(d.x, z)) };
}

/** The difference of two angles, in −π…π (a turn the short way round) */
export const angleDiff = (a: number, b: number): number => Math.atan2(Math.sin(a - b), Math.cos(a - b));
