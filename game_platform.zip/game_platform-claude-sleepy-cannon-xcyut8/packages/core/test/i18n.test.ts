import { describe, expect, it } from 'vitest';
import {
  byLanguage,
  charsetOf,
  checkStrings,
  createI18n,
  detectLanguage,
  flattenStrings,
  FONT_FALLBACK,
  LANGUAGE_CODES,
  LANGUAGES,
  matchLanguage,
  paramsOf,
  pluralCategories,
  TOP_LANGUAGES,
  type Strings,
} from '../src/i18n.ts';
import { PLATFORM_STRINGS } from '../src/i18n-platform.ts';

const STRINGS: Strings = {
  en: { play: 'Play', score: 'Score: {n}', coins: { one: '{n} coin', other: '{n} coins' }, hello: 'Hi, {name}!', onlyEn: 'English only' },
  de: { play: 'Spielen', score: 'Punkte: {n}', coins: { one: '{n} Münze', other: '{n} Münzen' }, hello: 'Hallo, {name}!' },
  ru: { play: 'Играть', score: 'Очки: {n}', coins: { one: '{n} монета', few: '{n} монеты', many: '{n} монет', other: '{n} монеты' }, hello: 'Привет, {name}!' },
  pl: { play: 'Graj', score: 'Wynik: {n}', coins: { one: '{n} moneta', few: '{n} monety', many: '{n} monet', other: '{n} monety' }, hello: 'Cześć, {name}!' },
};

describe('the languages', () => {
  it('ten top languages for the CrazyGames audience, and three more ready (Japanese, Korean, Chinese)', () => {
    expect(TOP_LANGUAGES).toEqual(['en', 'es', 'pt-BR', 'fr', 'de', 'ru', 'tr', 'it', 'pl', 'id']);
    expect(LANGUAGE_CODES).toEqual([...TOP_LANGUAGES, 'ja', 'ko', 'zh-CN']);
    expect(LANGUAGES.every((l) => l.name && l.flag)).toBe(true);
    // CJK fonts are in the fallback stack, before the generic family
    expect(FONT_FALLBACK).toMatch(/Hiragino Sans.*Malgun Gothic.*Microsoft YaHei.*sans-serif$/);
  });

  it('matches a locale to the game languages: the exact code, else the same base language', () => {
    const langs = ['en', 'es', 'pt-BR', 'de', 'zh-CN'];
    expect(matchLanguage('de-AT', langs)).toBe('de');
    expect(matchLanguage('pt-PT', langs)).toBe('pt-BR');
    expect(matchLanguage('pt_br', langs)).toBe('pt-BR');
    expect(matchLanguage('es-419', langs)).toBe('es');
    expect(matchLanguage('EN-us', langs)).toBe('en');
    expect(matchLanguage('fr-FR', langs)).toBeNull();
    // Traditional Chinese readers don't get Simplified text
    expect(matchLanguage('zh-TW', langs)).toBeNull();
    expect(matchLanguage('zh-Hans-CN', langs)).toBe('zh-CN');
    expect(matchLanguage('', langs)).toBeNull();
    expect(matchLanguage(null, langs)).toBeNull();
  });

  it('detects in order: the first candidate the game has wins, else English', () => {
    const langs = ['en', 'de', 'ru'];
    expect(detectLanguage(['ru', 'de-DE', 'en-US'], langs)).toBe('ru'); // the saved choice
    expect(detectLanguage([null, 'de-DE', 'en-US'], langs)).toBe('de'); // the portal's locale
    expect(detectLanguage([null, null, 'ja-JP', 'ru-RU'], langs)).toBe('ru'); // the browser's second language
    expect(detectLanguage([null, 'ja-JP'], langs)).toBe('en');
    expect(detectLanguage([], ['de'])).toBe('de');
  });
});

describe('createI18n', () => {
  it('texts with parameters; numbers formatted for the language', () => {
    const i = createI18n({ strings: STRINGS, languages: ['en', 'de', 'ru', 'pl'] });
    expect(i.lang).toBe('en');
    expect(i.t('score', { n: 12345 })).toBe('Score: 12,345');
    expect(i.t('hello', { name: 'Ann' })).toBe('Hi, Ann!');
    i.setLanguage('de');
    expect(i.t('score', { n: 12345 })).toBe('Punkte: 12.345');
    i.setLanguage('ru');
    expect(i.t('score', { n: 12345 })).toBe('Очки: 12 345');
    expect(i.number(0.5, { style: 'percent' })).toBe('50 %');
    // An unknown parameter stays visible: QA and the player see it, nothing crashes
    expect(i.t('hello')).toBe('Привет, {name}!');
  });

  it('plural forms by n: Russian and Polish have three integer forms', () => {
    const i = createI18n({ strings: STRINGS, languages: ['en', 'de', 'ru', 'pl'] });
    expect([1, 2, 5].map((n) => i.t('coins', { n }))).toEqual(['1 coin', '2 coins', '5 coins']);
    i.setLanguage('ru');
    expect([1, 2, 5, 11, 21, 22, 25, 1.5].map((n) => i.t('coins', { n }))).toEqual(['1 монета', '2 монеты', '5 монет', '11 монет', '21 монета', '22 монеты', '25 монет', '1,5 монеты']);
    i.setLanguage('pl');
    expect([1, 2, 5, 12, 22, 25].map((n) => i.t('coins', { n }))).toEqual(['1 moneta', '2 monety', '5 monet', '12 monet', '22 monety', '25 monet']);
    expect(i.plural(3)).toBe('few');
  });

  it('a key missing in the language comes from English; missing everywhere, the key itself', () => {
    const missing: string[] = [];
    const i = createI18n({ strings: STRINGS, languages: ['en', 'de'], lang: 'de', onMissing: (k, l) => missing.push(`${l}:${k}`) });
    expect(i.t('onlyEn')).toBe('English only');
    expect(i.t('onlyEn')).toBe('English only');
    expect(i.t('nope')).toBe('nope');
    expect(missing).toEqual(['de:onlyEn', 'de:nope']);
  });

  it('setLanguage: only the game languages, any case, listeners told once, unsubscribe', () => {
    const i = createI18n({ strings: STRINGS, languages: ['en', 'de'] });
    const seen: string[] = [];
    const off = i.onChange((l) => seen.push(l));
    expect(i.setLanguage('ru')).toBe(false);
    expect(i.setLanguage('DE')).toBe(true);
    expect(i.setLanguage('de')).toBe(true);
    off();
    i.setLanguage('en');
    expect(seen).toEqual(['de']);
    expect(i.info().name).toBe('English');
  });

  it('several sources merge, later ones win; dump gives every key with the English fallback', () => {
    const i = createI18n({ strings: [{ en: { a: 'A', b: 'B' }, de: { a: 'A-de' } }, { en: { b: 'B2' } }], languages: ['en', 'de'], lang: 'de' });
    expect(i.dump()).toEqual({ a: 'A-de', b: 'B2' });
    expect(i.dump('en')).toEqual({ a: 'A', b: 'B2' });
    expect(i.has('b')).toBe(false);
    expect(i.has('b', 'en')).toBe(true);
  });

  it('the starting language is matched against the languages; without languages, those the strings have', () => {
    expect(createI18n({ strings: STRINGS, lang: 'pl-PL' }).lang).toBe('pl');
    expect(createI18n({ strings: STRINGS, languages: ['en', 'de'], lang: 'ru' }).lang).toBe('en');
    expect(createI18n({ strings: STRINGS }).languages).toEqual(['en', 'de', 'ru', 'pl']);
  });
});

describe('strings files', () => {
  it('flattens nested maps to dotted keys; a map of plural forms is one value; lists are reported', () => {
    const r = flattenStrings({ title: { play: 'Play', sub: { line: 'x' } }, coins: { one: '{n} coin', other: '{n} coins' }, n: 3, list: ['a'] });
    expect(r.strings).toEqual({ 'title.play': 'Play', 'title.sub.line': 'x', coins: { one: '{n} coin', other: '{n} coins' }, n: '3' });
    expect(r.bad).toEqual(['list']);
  });

  it('per-key tables become per-language ones', () => {
    expect(byLanguage({ a: { en: 'A', 'PT-br': 'Á' } })).toEqual({ en: { a: 'A' }, 'pt-BR': { a: 'Á' } });
  });

  it('params, plural categories, characters', () => {
    expect(paramsOf('{n} of {max}, {n} {x} {}')).toEqual(['max', 'n', 'x']);
    expect(pluralCategories('ru').required).toEqual(['one', 'few', 'many', 'other']);
    expect(pluralCategories('en').required).toEqual(['one', 'other']);
    expect(pluralCategories('fr').required).toEqual(['one', 'other']); // its `many` is for a million: optional
    expect(pluralCategories('id').required).toEqual(['other']);
    expect(charsetOf({ a: 'Zażółć gęślą', b: { one: 'Ğ', other: 'ı' } })).toBe([...'żółćęśąĞı'].sort().join(''));
  });
});

describe('checkStrings', () => {
  const codes = (s: Strings, languages: string[], glossary?: string[]) => checkStrings(s, { languages, glossary }).map((i) => `${i.code} ${i.lang} ${i.key}`);

  it('a complete set passes', () => {
    const { onlyEn: _, ...en } = STRINGS.en;
    expect(checkStrings({ ...STRINGS, en }, { languages: ['en', 'de', 'ru', 'pl'] })).toEqual([]);
  });

  it('missing keys, a missing language, empty and TODO texts, other params, missing plural forms, extra keys', () => {
    const s: Strings = {
      en: { a: 'Score {n}', b: 'Hi', c: { one: '{n} coin', other: '{n} coins' } },
      ru: { a: 'Очки {count}', b: 'TODO', c: { one: '{n} монета', other: '{n} монет' }, d: 'лишнее' },
      de: { a: 'Punkte {n}', b: ' ', c: { one: '{n} Münze', other: '{n} Münzen', few: 'x' } },
    };
    expect(codes(s, ['en', 'ru', 'de', 'fr'])).toEqual([
      'E_I18N_PARAMS ru a',
      'E_I18N_EMPTY ru b',
      'E_I18N_PLURAL ru c',
      'W_I18N_EXTRA ru d',
      'E_I18N_EMPTY de b',
      'W_I18N_PLURAL de c',
      'E_I18N_MISSING fr *',
    ]);
    const missing = checkStrings({ en: { a: 'A', b: 'B' }, de: { a: 'A' } }, { languages: ['en', 'de'] });
    expect(missing.map((i) => i.code)).toEqual(['E_I18N_MISSING']);
    expect(missing[0].message).toBe('de misses 1 key(s): b');
  });

  it('a word that only looks like TODO (pt and es «Todo», «todo») is a translation, not a placeholder', () => {
    const s: Strings = { en: { a: 'All of it', b: 'Everything' }, 'pt-BR': { a: 'Todo o mapa', b: 'todo' } };
    expect(codes(s, ['en', 'pt-BR'])).toEqual([]);
  });

  it('warns when a glossary name is dropped or a translation is far longer than English', () => {
    const s: Strings = { en: { a: 'Light the Everflame', b: 'Go' }, de: { a: 'Entzünde die ewige Flamme', b: 'Los geht es jetzt sofort, schnell!' } };
    expect(codes(s, ['en', 'de'], ['Everflame'])).toEqual(['W_I18N_GLOSSARY de a', 'W_I18N_LONG de b']);
  });

  it('a glossary name counts only as a whole word ("Tom" is not in "Tomorrow")', () => {
    const s: Strings = { en: { a: 'Come back tomorrow, Tom', b: 'Tomorrow' }, de: { a: 'Komm morgen wieder, Tom', b: 'Morgen' } };
    expect(codes(s, ['en', 'de'], ['Tom'])).toEqual([]);
    const dropped: Strings = { en: { a: 'Tom waits' }, de: { a: 'Er wartet' } };
    expect(codes(dropped, ['en', 'de'], ['Tom'])).toEqual(['W_I18N_GLOSSARY de a']);
  });

  it('keys must be plain', () => {
    expect(codes({ en: { 'bad key': 'x' } }, ['en'])).toEqual(['E_I18N_KEY en bad key']);
  });

  it("the platform's own texts are complete in all 13 languages, with the same parameters and plural forms", () => {
    const issues = checkStrings(byLanguage(PLATFORM_STRINGS), { languages: LANGUAGE_CODES });
    expect(issues.filter((i) => i.severity === 'error')).toEqual([]);
    expect(issues).toEqual([]);
    for (const [key, langs] of Object.entries(PLATFORM_STRINGS)) {
      expect(key.startsWith('gp.')).toBe(true);
      expect(Object.keys(langs).sort()).toEqual([...LANGUAGE_CODES].sort());
    }
  });
});
