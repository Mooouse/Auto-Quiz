// `gp dev --stop` stops exactly the game's dev server by its recorded pid (packages/cli/src/dev-pid.ts): agents killed
// their own shell with `pkill -f vite` (Craft Pickaxe Idle's report)

import { spawn } from 'node:child_process';
import { mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { clearDevRecord, devRecordFile, readDevRecord, stopDev, writeDevRecord } from '../src/dev-pid.ts';

const before = process.env.GP_DEV_DIR;
beforeAll(() => {
  process.env.GP_DEV_DIR = mkdtempSync(join(tmpdir(), 'gp-dev-test-'));
});
afterAll(() => {
  if (before === undefined) delete process.env.GP_DEV_DIR;
  else process.env.GP_DEV_DIR = before;
});

describe('gp dev --stop', () => {
  it('records the server per game folder and stops that process only', async () => {
    const child = spawn(process.execPath, ['-e', 'setInterval(() => {}, 1000)'], { stdio: 'ignore' });
    const exited = new Promise<void>((r) => child.on('exit', () => r()));
    writeDevRecord('/games/a', { pid: child.pid!, url: 'http://localhost:5173/' });
    expect(devRecordFile('/games/a')).not.toBe(devRecordFile('/games/b'));
    expect(readDevRecord('/games/a')).toMatchObject({ pid: child.pid, url: 'http://localhost:5173/' });
    expect(readDevRecord('/games/b')).toBeNull();
    expect(await stopDev('/games/b')).toBeNull();
    const stopped = await stopDev('/games/a');
    expect(stopped?.pid).toBe(child.pid);
    await exited;
    expect(readDevRecord('/games/a')).toBeNull();
  });

  it('a stale record (the process is gone) reads as none; clear removes only its own', async () => {
    const child = spawn(process.execPath, ['-e', ''], { stdio: 'ignore' });
    await new Promise<void>((r) => child.on('exit', () => r()));
    writeDevRecord('/games/c', { pid: child.pid!, url: 'x' });
    expect(readDevRecord('/games/c')).toBeNull();
    writeDevRecord('/games/d', { pid: process.pid, url: 'x' });
    clearDevRecord('/games/d', process.pid + 1);
    expect(readDevRecord('/games/d')?.pid).toBe(process.pid);
    clearDevRecord('/games/d');
    expect(readDevRecord('/games/d')).toBeNull();
  });
});
