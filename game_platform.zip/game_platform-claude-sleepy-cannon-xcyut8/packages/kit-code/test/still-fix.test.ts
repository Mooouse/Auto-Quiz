// The fix a "nothing runs" failure names (packages/kit-code/qa/suite.ts stillFix): Candle Crypt, Dread Throne and
// Starsilk ran their loop on the title and under ads, Echoflies' title animates on purpose without saying so (backlog 4)

import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import { stillFix } from '../qa/suite.ts';

const guide = readFileSync(new URL('../../../docs/guides/code-games.md', import.meta.url), 'utf8');

describe('the fix named when a still screen runs', () => {
  it.each(['title', 'pause', 'ad'] as const)('%s: the adapter call and the own-loop pattern, with the guide section', (where) => {
    const t = stillFix(where);
    expect(t).toContain("eng.setRunning(state === 'play')");
    expect(t).toContain('host.onPause');
    expect(t).toContain('!host.paused');
    expect(t).toContain('host.onResume');
    expect(t).toMatch(/app\.ticker.*setAnimationLoop/);
    expect(t).toContain('docs/guides/code-games.md#still-screens');
  });
  it('only the title may opt out, with host.qa({ idleAnimation: true })', () => {
    expect(stillFix('title')).toMatch(/host\.qa\(\{ …, idleAnimation: true \}\)/);
    expect(stillFix('pause')).not.toContain('idleAnimation');
    expect(stillFix('ad')).not.toContain('idleAnimation');
  });
  it('says where it runs', () => {
    expect(stillFix('title')).toMatch(/^the loop runs on the title/);
    expect(stillFix('pause')).toMatch(/^the loop runs on the pause screen/);
    expect(stillFix('ad')).toMatch(/^the loop runs under the ad .*"ad"/);
  });
  it('the guide has the section the message links to, with both patterns and the opt-in', () => {
    const at = guide.indexOf('\n### Still screens\n');
    expect(at).toBeGreaterThan(0);
    const section = guide.slice(at, guide.indexOf('\n#', at + 5));
    for (const s of ["eng.setRunning(state === 'play')", 'if (running() && !raf) raf = requestAnimationFrame(frame)', 'host.onResume(() => wake())', 'idleAnimation: true'])
      expect(section).toContain(s);
  });
});
