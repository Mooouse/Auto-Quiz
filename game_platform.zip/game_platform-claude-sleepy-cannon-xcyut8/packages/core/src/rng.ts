// All game randomness goes through here so a run can be made repeatable: seedRandom(n)
// (the player does it for ?seed=n in dev builds). Unseeded, it is Math.random.
// A source of its own (a bot's campaign, a level generator, a daily seed) is seededRng(n): the same mulberry32,
// independent of the run's randomness.

let source: () => number = Math.random;

/** One mulberry32 step as a pure function: the number for state `a`, and the state after it */
function step(a: number): [number, number] {
  const next = (a + 0x6d2b79f5) >>> 0;
  let t = next;
  t = Math.imul(t ^ (t >>> 15), t | 1);
  t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
  return [((t ^ (t >>> 14)) >>> 0) / 4294967296, next];
}

/** mulberry32: small, fast, good enough for games */
function mulberry32(seed: number): { next: () => number; state: () => number } {
  let a = seed >>> 0;
  return {
    next: () => {
      const [x, n] = step(a);
      a = n;
      return x;
    },
    state: () => a,
  };
}

export function seedRandom(seed: number | null): void {
  source = seed === null ? Math.random : mulberry32(seed).next;
}

/** A seeded random source of its own: call it (`r()`, the shape the progression blocks take) or use its methods */
export interface SeededRng {
  (): number;
  /** [0, 1) */
  random(): number;
  /** [a, b) */
  range(a: number, b: number): number;
  /** Integer in [0, n) */
  int(n: number): number;
  pick<T>(list: readonly T[]): T;
  /**
   * Where the sequence is now, as one integer: seededRng(r.state()) goes on with the same numbers. The table blocks
   * (Zones, Dice, Automa) keep it in their saved state, so a game loaded mid-run draws what it would have drawn.
   */
  state(): number;
}

/**
 * An independent seeded source: the same seed gives the same sequence on every machine, and it never touches `rng`
 * (the run's randomness, `?seed`). Spin Brawl, Yeet the Gnome, Brew & Banter, Germ Bait, Candle Crypt, Dread Throne,
 * Starsilk and Echoflies each pasted this mulberry32 into their bots, levels and key art; the sequence is the same as
 * theirs, so a game that switches keeps its pinned numbers.
 */
export function seededRng(seed: number): SeededRng {
  const m = mulberry32(seed);
  const next = m.next;
  return Object.assign(() => next(), {
    random: next,
    range: (a: number, b: number) => a + next() * (b - a),
    int: (n: number) => (next() * n) | 0,
    pick: <T>(list: readonly T[]): T => list[(next() * list.length) | 0],
    state: m.state,
  });
}

export const rng = {
  /** [0, 1) */
  random: (): number => source(),
  /** [a, b) */
  range: (a: number, b: number): number => a + source() * (b - a),
  /** Integer in [0, n) */
  int: (n: number): number => (source() * n) | 0,
  pick<T>(list: readonly T[]): T {
    return list[(source() * list.length) | 0];
  },
};

/**
 * A "bag" of n values: each comes up once in random order, then the bag is refilled.
 * No value repeats back-to-back, not even across the refill boundary.
 */
export class Bag {
  private items: number[] = [];
  private last = -1;
  private readonly n: number;

  constructor(n: number) {
    this.n = n;
  }

  next(): number {
    const n = this.n;
    if (!this.items.length) {
      const bag = Array.from({ length: n }, (_, i) => i);
      for (let i = n - 1; i > 0; i--) {
        const j = rng.int(i + 1);
        [bag[i], bag[j]] = [bag[j], bag[i]];
      }
      if (n > 1 && bag[n - 1] === this.last) [bag[0], bag[n - 1]] = [bag[n - 1], bag[0]];
      this.items = bag;
    }
    this.last = this.items.pop()!;
    return this.last;
  }
}
