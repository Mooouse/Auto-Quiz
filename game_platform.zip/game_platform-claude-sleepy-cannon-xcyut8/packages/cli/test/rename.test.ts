// gp rename: the id follows the game's current name, the players' saves stay

import { mkdtempSync, mkdirSync, readFileSync, writeFileSync, existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { renameGame, renamedYaml } from '../src/rename.ts';
import { redirectPage, renamedFrom, upsertPreview } from '../src/preview.ts';

describe('gp rename', () => {
  it('sets the id and pins the old saveKey once', () => {
    const y = renamedYaml('spec: 0\nid: echoflies\ntitle: "Firefly Rush"\n', 'echoflies', 'firefly-rush');
    expect(y.ok).toBe(true);
    expect(y.text).toContain('id: firefly-rush\nsaveKey: echoflies.save.v1');
    expect(y.pinned).toBe('echoflies.save.v1');
    const kept = renamedYaml('id: echoflies\nsaveKey: echo.v2\n', 'echoflies', 'firefly-rush');
    expect(kept.pinned).toBeUndefined();
    expect(kept.text).toBe('id: firefly-rush\nsaveKey: echo.v2\n');
    expect(renamedYaml('id: other\n', 'echoflies', 'x').ok).toBe(false);
  });

  it('moves the folder and lists what still names the old id', () => {
    const root = mkdtempSync(join(tmpdir(), 'gp-rename-'));
    mkdirSync(join(root, 'games', 'petri-panic'), { recursive: true });
    writeFileSync(join(root, 'games', 'petri-panic', 'game.yaml'), 'spec: 0\nid: petri-panic\ntitle: "Scrap Royale"\n');
    mkdirSync(join(root, 'scripts'));
    writeFileSync(join(root, 'scripts', 'ci.sh'), 'gp qa petri-panic\n# petri-panicky is another word\n');
    const r = renameGame(join(root, 'games', 'petri-panic'), 'scrap-royale');
    expect(r.ok).toBe(true);
    expect(existsSync(join(root, 'games', 'scrap-royale', 'game.yaml'))).toBe(true);
    expect(existsSync(join(root, 'games', 'petri-panic'))).toBe(false);
    expect(readFileSync(join(root, 'games', 'scrap-royale', 'game.yaml'), 'utf8')).toContain('saveKey: petri-panic.save.v1');
    expect(r.mentions).toEqual(['scripts/ci.sh:1']);
    expect(renameGame(join(root, 'games', 'scrap-royale'), 'Bad Id').ok).toBe(false);
  });

  it('moves a renamed game\'s preview to its new link and redirects the old one', () => {
    const list = [
      { id: 'echoflies', title: 'Firefly Rush', updated: '2026-10-03T00:00:00.000Z' },
      { id: 'kettlebot', title: 'Kettlebot', updated: '2026-10-02T00:00:00.000Z' },
    ];
    const e = { id: 'firefly-rush', title: 'Firefly Rush', updated: '2026-10-04T00:00:00.000Z' };
    expect(renamedFrom(list, e)).toEqual(['echoflies']);
    expect(upsertPreview(list, e).map((x) => x.id)).toEqual(['firefly-rush', 'kettlebot']);
    expect(redirectPage('firefly-rush', 'Firefly Rush')).toContain('url=../firefly-rush/');
  });
});
