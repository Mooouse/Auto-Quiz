// The game's texts per language: strings/<code>.yaml loaded and checked (gp validate), the brief and the fill-in for the
// game's agent (gp translate), the listing's translations (gp submission), and the platform's own tables.

import { cpSync, mkdtempSync, readFileSync, rmSync, writeFileSync, mkdirSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { execFileSync } from 'node:child_process';
import { afterAll, describe, expect, it } from 'vitest';
import { byLanguage, checkStrings, LANGUAGE_CODES, TOP_LANGUAGES } from '@gp/core/i18n';
import { CASUAL_STRINGS, CASUAL_STRINGS_EN } from '@gp/kit-casual/meta';
import { KIDS_NUMBER_WORDS, KIDS_STRINGS, KIDS_STRINGS_EN } from '@gp/kit-kids/meta';
import { loadYaml } from '@gp/spec';
import { checkGame } from '../src/game.ts';
import { i18nChecks, i18nGameOf, keysInCode, loadStrings, readSources, recordSources, runtimeStrings, sourcesFile, staleKeys, stringsDir, textHash, translateBrief, translateStatus, writeMissing } from '../src/i18n.ts';
import { locateGame, ROOT } from '../src/paths.ts';
import { listingTranslations } from '../src/submission.ts';

const tmp = mkdtempSync(join(tmpdir(), 'gp-i18n-'));
afterAll(() => rmSync(tmp, { recursive: true, force: true }));

/** A copy of the code example (Germ Dodge: ten languages) to break on purpose */
function germDodge(name: string) {
  const dir = join(tmp, name);
  cpSync(join(ROOT, 'docs/examples/code'), dir, { recursive: true, filter: (f) => !/[\\/](upload|dist|qa|node_modules|store|submission)$/.test(f) && !f.endsWith('.zip') });
  return { id: name, dir, file: join(dir, 'game.yaml') };
}
const put = (file: string, text: string) => {
  mkdirSync(join(file, '..'), { recursive: true });
  writeFileSync(file, text);
};
const codes = (loc: ReturnType<typeof germDodge>) => checkGame(loc, 'dev').issues.filter((i) => /I18N/.test(i.code)).map((i) => i.code);

describe('the examples and the template', () => {
  it('the code and casual examples are in the ten top languages, complete', () => {
    for (const f of ['docs/examples/code/game.yaml', 'docs/examples/casual.game.yaml']) {
      const r = checkGame(locateGame(join(ROOT, f)), 'dev');
      expect(r.game!.languages).toEqual([...TOP_LANGUAGES]);
      expect(r.issues.filter((i) => /I18N/.test(i.code))).toEqual([]);
    }
  });

  it("the gp init skeleton's strings are complete in all ten", () => {
    const dir = join(tmp, 'skeleton');
    cpSync(join(ROOT, 'templates/game-repo/games/__ID__'), dir, { recursive: true });
    const loc = { id: 'skeleton', dir, file: join(dir, 'game.yaml') };
    const spec = { title: 'Skeleton', channel: 'crazygames', kit: 'code', languages: [...TOP_LANGUAGES] };
    expect(i18nChecks(loc, i18nGameOf(spec as never), spec)).toEqual([]);
    expect(readFileSync(join(dir, 'game.yaml'), 'utf8')).toContain('languages: [en, es, pt-BR, fr, de, ru, tr, it, pl, id]');
    // Every key the skeleton's code asks for (literal keys) is in en.yaml or the platform's
    const en = loadStrings(loc).strings.en;
    for (const k of keysInCode(dir)) expect(k.key in en || k.key.startsWith('gp.'), k.key).toBe(true);
  });

  it('strings/ next to game.yaml; <name>.strings/ next to <name>.game.yaml', () => {
    expect(stringsDir({ id: 'a', dir: '/x/a', file: '/x/a/game.yaml' })).toBe('/x/a/strings');
    expect(stringsDir({ id: 'casual', dir: '/d', file: '/d/casual.game.yaml' })).toBe('/d/casual.strings');
  });
});

describe('gp validate: the texts', () => {
  it('a missing key, other params, a dropped plural form, an empty text, an unknown key in the code', () => {
    const loc = germDodge('broken');
    const de = join(loc.dir, 'strings/de.yaml');
    put(de, readFileSync(de, 'utf8').replace('hint: "Weiche den Keimen aus. WASD, Pfeile oder ziehen."\n', '').replace('Rekord: {time}', 'Rekord: {zeit}').replace('Spiel vorbei', ''));
    const main = join(loc.dir, 'main.ts');
    put(main, readFileSync(main, 'utf8').replace("t('ouch')", "t('ouchh')"));
    const r = checkGame(loc, 'dev');
    expect(r.ok).toBe(false);
    const msgs = r.issues.filter((i) => /I18N/.test(i.code)).map((i) => `${i.code}: ${i.message}`);
    expect(msgs.some((m) => m.startsWith('E_I18N_KEY') && m.includes('main.ts:') && m.includes('t("ouchh")'))).toBe(true);
    expect(msgs.some((m) => m.startsWith('E_I18N_PARAMS') && m.includes('strings/de.yaml:1'))).toBe(true);
    expect(msgs.some((m) => m.startsWith('E_I18N_EMPTY') && m.includes('gameOver'))).toBe(true);
    expect(msgs.some((m) => m.startsWith('E_I18N_MISSING') && m.includes('de misses 1 key(s): hint'))).toBe(true);
  });

  it('gp dev (draftTexts) plays a game whose translations are unfinished; everything else still refuses it', () => {
    const loc = germDodge('draft');
    const de = join(loc.dir, 'strings/de.yaml');
    put(de, readFileSync(de, 'utf8').replace('hint: "Weiche den Keimen aus. WASD, Pfeile oder ziehen."\n', '').replace('Spiel vorbei', ''));
    expect(checkGame(loc, 'dev').ok).toBe(false);
    const dev = checkGame(loc, 'dev', { draftTexts: true });
    expect(dev.ok).toBe(true);
    const drafts = dev.issues.filter((i) => i.code === 'E_I18N_MISSING' || i.code === 'E_I18N_EMPTY');
    expect(drafts.length).toBe(2);
    expect(drafts.every((i) => i.severity === 'warning' && i.message.includes('gp dev shows English'))).toBe(true);
    // A real error (a wrong parameter) still stops gp dev
    put(de, readFileSync(de, 'utf8').replace('Rekord: {time}', 'Rekord: {zeit}'));
    expect(checkGame(loc, 'dev', { draftTexts: true }).ok).toBe(false);
  });

  it('declared languages without strings/en.yaml; a file for an undeclared language; a file that is not YAML', () => {
    const loc = germDodge('no-en');
    rmSync(join(loc.dir, 'strings/en.yaml'));
    expect(codes(loc)).toContain('E_I18N_FILE');
    const loc2 = germDodge('extra');
    put(join(loc2.dir, 'strings/ja.yaml'), 'hint: "菌をよけろ"\n');
    put(join(loc2.dir, 'strings/xx.yaml'), 'hint: x\n');
    expect(codes(loc2)).toEqual(expect.arrayContaining(['W_I18N_UNDECLARED', 'E_I18N_FILE']));
    const loc3 = germDodge('bad-yaml');
    put(join(loc3.dir, 'strings/ru.yaml'), 'hint: "unclosed\n');
    expect(codes(loc3)).toContain('E_I18N_FILE');
  });

  it("keys starting with gp. are the platform's; the listing untranslated is a warning", () => {
    const loc = germDodge('gp-key');
    put(join(loc.dir, 'strings/en.yaml'), `${readFileSync(join(loc.dir, 'strings/en.yaml'), 'utf8')}gp.mine: "x"\n`);
    expect(codes(loc)).toContain('E_I18N_KEY');
    const loc2 = germDodge('listing');
    const fr = join(loc2.dir, 'strings/fr.yaml');
    put(fr, readFileSync(fr, 'utf8').replace(/listing:[\s\S]*$/, ''));
    const issues = checkGame(loc2, 'dev').issues.filter((i) => i.code === 'W_I18N_LISTING');
    expect(issues.map((i) => i.message)).toEqual(['the listing (description, controls) is not translated into fr']);
  });

  it('English only: nothing to check, no strings folder needed', () => {
    const loc = germDodge('english');
    put(loc.file, readFileSync(loc.file, 'utf8').replace(/^languages: .*$/m, ''));
    rmSync(join(loc.dir, 'strings'), { recursive: true });
    // The code still asks for keys: unknown without en.yaml (they'd show as keys)
    expect([...new Set(codes(loc))]).toEqual(['W_I18N_LANGS', 'E_I18N_KEY']);
  });

  it('a YAML kit: its own game.yaml texts need translations (a warning), its strings files only kit text names', () => {
    const dir = join(tmp, 'casual');
    mkdirSync(dir, { recursive: true });
    cpSync(join(ROOT, 'docs/examples/casual.game.yaml'), join(dir, 'game.yaml'));
    cpSync(join(ROOT, 'docs/examples/casual.strings'), join(dir, 'strings'), { recursive: true });
    const loc = { id: 'casual', dir, file: join(dir, 'game.yaml') };
    expect(checkGame(loc, 'dev').issues).toEqual([]);
    rmSync(join(dir, 'strings/de.yaml'));
    put(join(dir, 'strings/ru.yaml'), 'subtitle: "45 секунд"\nplay: "Жми"\nnope: "x"\n');
    const issues = checkGame(loc, 'dev').issues;
    expect(issues.map((i) => i.code).sort()).toEqual(['E_I18N_KEY', 'W_I18N_KIT_TEXT', 'W_I18N_LISTING']);
    expect(issues.find((i) => i.code === 'W_I18N_KIT_TEXT')!.message).toContain("no strings in de at all — game.yaml's English is shown there");
  });

  it('the player gets the declared languages only, without the listing', () => {
    const loc = germDodge('runtime');
    put(join(loc.dir, 'strings/ja.yaml'), 'hint: "菌をよけろ"\n');
    const s = runtimeStrings(loc, { languages: ['en', 'de'] });
    expect(Object.keys(s)).toEqual(['en', 'de']);
    expect(s.de.hint).toBe('Weiche den Keimen aus. WASD, Pfeile oder ziehen.');
    expect('listing' in s.de || 'listing.description' in s.de).toBe(false);
  });
});

describe('gp translate', () => {
  const spec = (loc: { file: string }) => {
    const text = readFileSync(loc.file, 'utf8');
    const langs = /^languages: \[(.*)\]$/m.exec(text)![1].split(',').map((x) => x.trim());
    return { title: 'Germ Dodge', channel: 'crazygames', kit: 'code', languages: langs, listing: { description: 'Germ Dodge is a tiny survival game.', controls: 'Keys.' } };
  };

  it('the status per language and a brief with the rules, the plural forms and the missing keys as YAML to fill', () => {
    const loc = germDodge('brief');
    rmSync(join(loc.dir, 'strings/ru.yaml'));
    put(join(loc.dir, 'strings/en.yaml'), `${readFileSync(join(loc.dir, 'strings/en.yaml'), 'utf8')}coins: { one: "{n} coin", other: "{n} coins" }\n`);
    const s = spec(loc);
    const st = translateStatus(loc, i18nGameOf(s as never), s);
    const ru = st.rows.find((r) => r.lang === 'ru')!;
    expect(ru.done).toBe(0);
    expect(ru.listing).toBe(false);
    expect(st.rows.find((r) => r.lang === 'de')!.missing).toEqual(['coins']);
    const brief = translateBrief(loc, i18nGameOf(s as never), s);
    expect(brief).toContain('Keep every `{name}` exactly');
    expect(brief).toContain('"Germ Dodge"');
    expect(brief).toContain('Plural forms in ru: one, few, many, other');
    expect(brief).toContain('coins: { one: "", few: "", many: "", other: "" }   # en: one: {n} coin | other: {n} coins');
    expect(brief).toContain('hint: ""   # en: Dodge the germs. WASD, arrows or drag.');
    expect(brief).toContain('## Deutsch — de (German): 10/11');
    // --lang: one language
    expect(translateBrief(loc, i18nGameOf(s as never), s, 'de')).not.toContain('## Русский');
  });

  it('--write appends the missing keys empty (validate refuses them until translated), creating a missing file', () => {
    const loc = germDodge('write');
    rmSync(join(loc.dir, 'strings/ru.yaml'));
    const s = spec(loc);
    const written = writeMissing(loc, i18nGameOf(s as never), s, (f, t) => put(f, t));
    expect(written.length).toBe(1);
    const ru = readFileSync(join(loc.dir, 'strings/ru.yaml'), 'utf8');
    expect(ru).toContain('hint: ""   # en: Dodge the germs.');
    expect(ru).toContain('listing:\n  description: ""');
    expect(loadStrings(loc).strings.ru.hint).toBe('');
    expect(codes(loc)).toContain('E_I18N_EMPTY');
    // Nothing more to add once every key is there (empty or not)
    expect(writeMissing(loc, i18nGameOf(s as never), s, () => {})).toEqual([]);
  });

  it('the command: brief, --check (a table and exit 1 while anything is missing), English-only games are told to declare', () => {
    const gp = (args: string[]) => {
      try {
        return { code: 0, out: execFileSync(process.execPath, [join(ROOT, 'packages/cli/src/gp.ts'), ...args], { encoding: 'utf8', env: { ...process.env, NO_COLOR: '1', GP_NO_LOG: '1' } }) };
      } catch (e) {
        const x = e as { status: number; stdout: string };
        return { code: x.status, out: x.stdout };
      }
    };
    const ok = gp(['translate', join(ROOT, 'docs/examples/code/game.yaml'), '--check']);
    expect(ok.code, ok.out).toBe(0);
    expect(ok.out).toContain('| pl Polish | 10/10 | ✓ |');
    const loc = germDodge('cmd');
    rmSync(join(loc.dir, 'strings/it.yaml'));
    const bad = gp(['translate', loc.file, '--check']);
    expect(bad.code).toBe(1);
    expect(bad.out).toContain('| it Italian | 0/10');
    const brief = gp(['translate', loc.file]);
    expect(brief.code).toBe(0);
    expect(readFileSync(join(loc.dir, 'qa/translate-brief.md'), 'utf8')).toContain('## Italiano — it (Italian): 0/10');
    const en = germDodge('cmd-en');
    put(en.file, readFileSync(en.file, 'utf8').replace(/^languages: .*$/m, ''));
    expect(gp(['translate', en.file]).out).toContain('is in English only');
  });
});

describe('gp translate: stale translations (the English changed since)', () => {
  // game.yaml as written (gp translate reads it so), with another English description when asked
  const spec = (loc: { file: string }, description?: string) => {
    const s = loadYaml(readFileSync(loc.file, 'utf8')).data as { languages: string[]; listing: { description: string; controls: string } };
    return description ? { ...s, listing: { ...s.listing, description } } : s;
  };
  const stale = (loc: { id: string; dir: string; file: string }, s: ReturnType<typeof spec>) => i18nChecks(loc, i18nGameOf(s as never), s).filter((i) => i.code === 'W_I18N_STALE');
  const setEn = (loc: { dir: string }, key: string, text: string) => {
    const f = join(loc.dir, 'strings/en.yaml');
    put(f, readFileSync(f, 'utf8').replace(new RegExp(`^${key}: .*$`, 'm'), `${key}: ${JSON.stringify(text)}`));
  };

  it('a game without the sources files gets no warning, even with its English changed', () => {
    const loc = germDodge('stale-none');
    setEn(loc, 'hint', 'Dodge the germs. Swipe to move.');
    const s = spec(loc);
    expect(stale(loc, s)).toEqual([]);
    expect(readSources(stringsDir(loc), 'de')).toBeNull();
    expect(translateStatus(loc, i18nGameOf(s as never), s).rows.every((r) => !r.stale.length)).toBe(true);
  });

  it('--write records the English of every translation; a changed English is stale in every language until redone', () => {
    const loc = germDodge('stale');
    const s = spec(loc);
    const game = i18nGameOf(s as never);
    const done = recordSources(loc, game, s, (f, t) => put(f, t));
    expect(done.length).toBe(9);
    const de = readSources(stringsDir(loc), 'de')!;
    const en = loadStrings(loc).strings.en;
    // Every key and the listing's two texts, the English and the translation each as a hash
    expect(Object.keys(de).sort()).toEqual([...Object.keys(en), 'listing.controls', 'listing.description'].sort());
    expect(de.hint).toEqual({ en: textHash(en.hint), text: textHash(loadStrings(loc).strings.de.hint) });
    expect(readFileSync(sourcesFile(stringsDir(loc), 'de'), 'utf8')).toContain('"about"');
    // The sources files are not languages: gp validate is still clean, and recording again changes nothing
    expect(codes(loc)).toEqual([]);
    expect(recordSources(loc, game, s, () => {})).toEqual([]);

    // The English changes: stale in all nine, with the new English and a fix line
    setEn(loc, 'hint', 'Dodge the germs. Swipe to move.');
    const w = stale(loc, s);
    expect(w.length).toBe(9);
    expect(w[0].severity).toBe('warning');
    expect(w.find((i) => i.message.includes('strings/de.yaml'))!.message).toMatch(/de\.yaml:\d+: "hint" was translated from another English — now "Dodge the germs\. Swipe to move\."/);
    expect(w[0].fix).toContain('gp translate --write');
    expect(w[0].fix).toContain('gp explain W_I18N_STALE');
    expect(codes(loc)).toContain('W_I18N_STALE');
    const st = translateStatus(loc, i18nGameOf(s as never), s);
    expect(st.rows.find((r) => r.lang === 'fr')!.stale).toEqual(['hint']);
    expect(st.rows.find((r) => r.lang === 'en')!.stale).toEqual([]);
    expect(translateBrief(loc, game, s, 'fr')).toMatch(/\*\*Stale\*\*[\s\S]*`hint` — en now: "Dodge the germs\. Swipe to move\."; fr still: "/);

    // --write without --accept keeps it stale (the old English stays recorded)
    recordSources(loc, game, s, (f, t) => put(f, t));
    expect(stale(loc, s).length).toBe(9);

    // German is redone: no longer stale (a changed translation is taken as redone), and the next --write records it
    const deFile = join(loc.dir, 'strings/de.yaml');
    put(deFile, readFileSync(deFile, 'utf8').replace(/^hint: .*$/m, 'hint: "Weiche den Keimen aus. Wische zum Bewegen."'));
    expect(staleKeys(game, loadStrings(loc), en, 'de')).toEqual([]);
    expect(stale(loc, s).length).toBe(8);
    const again = recordSources(loc, game, s, (f, t) => put(f, t));
    expect(again).toEqual([expect.stringMatching(/de\.sources\.json: \d+ translation\(s\) recorded, 1 new or redone/)]);
    expect(readSources(stringsDir(loc), 'de')!.hint.en).toBe(textHash('Dodge the germs. Swipe to move.'));

    // --accept (one language, then all): the translations as they are
    expect(recordSources(loc, game, s, (f, t) => put(f, t), { accept: true, lang: 'fr' })).toEqual([expect.stringMatching(/fr\.sources\.json: .*1 accepted as they are/)]);
    expect(stale(loc, s).length).toBe(7);
    recordSources(loc, game, s, (f, t) => put(f, t), { accept: true });
    expect(stale(loc, s)).toEqual([]);
  });

  it('the listing too: a new English description is stale where it was translated', () => {
    const loc = germDodge('stale-listing');
    const s = spec(loc);
    for (const lang of s.languages.filter((l) => l !== 'en')) put(join(loc.dir, `strings/${lang}.yaml`), `${readFileSync(join(loc.dir, `strings/${lang}.yaml`), 'utf8').replace(/^listing:[\s\S]*$/m, '')}listing:\n  description: "x ${lang}"\n  controls: "y ${lang}"\n`);
    recordSources(loc, i18nGameOf(s as never), s, (f, t) => put(f, t));
    const s2 = spec(loc, 'Germ Dodge: a cell against a swarm.');
    const w = stale(loc, s2);
    expect(w.length).toBe(9);
    expect(w[0].path).toEqual(['listing']);
    expect(w[0].message).toContain('"listing.description" was translated from another English');
  });

  it('the command: --write records, --check warns (exit 0: a warning) and lists it, --accept needs --write', () => {
    const gp = (args: string[]) => {
      try {
        return { code: 0, out: execFileSync(process.execPath, [join(ROOT, 'packages/cli/src/gp.ts'), ...args], { encoding: 'utf8', env: { ...process.env, NO_COLOR: '1', GP_NO_LOG: '1' } }) };
      } catch (e) {
        const x = e as { status: number; stdout: string };
        return { code: x.status, out: x.stdout };
      }
    };
    const loc = germDodge('stale-cmd');
    const w = gp(['translate', loc.file, '--write']);
    expect(w.code, w.out).toBe(0);
    expect(w.out).toMatch(/✓ .*strings\/de\.sources\.json: \d+ translation\(s\) recorded/);
    setEn(loc, 'gameOver', 'Game over!');
    const c = gp(['translate', loc.file, '--check']);
    expect(c.code, c.out).toBe(0);
    expect(c.out).toContain('(stale: gameOver)');
    expect(c.out).toContain('W_I18N_STALE');
    expect(c.out).toMatch(/✓ .*: 10 languages, 0 error\(s\), 9 warning\(s\)/);
    expect(gp(['translate', loc.file, '--accept']).code).toBe(1);
    expect(gp(['translate', loc.file, '--write', '--accept']).out).toContain('accepted as they are');
    expect(gp(['translate', loc.file, '--check']).out).not.toContain('W_I18N_STALE');
    expect(gp(['explain', 'W_I18N_STALE']).out).toContain('changed since');
  });
});

describe('gp submission: the listing in the other languages', () => {
  it('a section per language; the missing ones named', () => {
    const t = listingTranslations({ title: 'G', languages: ['en', 'de', 'ru'] }, { de: { description: 'Ein Spiel.', controls: 'Maus.' } });
    expect(t.done).toEqual(['de']);
    expect(t.missing).toEqual(['ru']);
    expect(t.markdown).toContain('## de\n\n**Description.** Ein Spiel.');
    expect(t.markdown).toContain('## ru\n\n**Description.** (missing: gp translate)');
    expect(t.markdown).toContain('takes the English description and controls');
  });
});

describe("the kits' texts", () => {
  it('the casual and kids kits are translated into all 13 languages, English as before', () => {
    for (const [table, en] of [
      [CASUAL_STRINGS, CASUAL_STRINGS_EN],
      [KIDS_STRINGS, KIDS_STRINGS_EN],
    ] as const) {
      expect(Object.keys(table).sort()).toEqual(Object.keys(en).sort());
      for (const [k, v] of Object.entries(en)) expect(table[k].en).toBe(v);
      expect(checkStrings(byLanguage(table), { languages: LANGUAGE_CODES })).toEqual([]);
    }
    for (const l of LANGUAGE_CODES) expect(KIDS_NUMBER_WORDS[l], l).toHaveLength(11);
  });
});
