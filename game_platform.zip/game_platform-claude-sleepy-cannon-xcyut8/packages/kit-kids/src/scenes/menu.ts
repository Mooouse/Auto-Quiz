// Main menu: one card per mode (pictures only), album with a counter, a small grey lock for grown-ups.
// Targets float in the background — they can be popped just for fun.

import {
  buttonRadius,
  drawBareIcon,
  drawEmoji,
  drawIconButton,
  drawPanel,
  drawText,
  hitCircle,
  hitRect,
  margin,
  shade,
  type Circle,
  type ProbeTarget,
  type Rect,
  type Scene,
} from '@gp/core';
import { rise, TargetField } from '@gp/blocks';
import type { KidsContext } from '../context.ts';
import type { KidsMode } from '../index.meta.ts';

interface Card extends Rect {
  mode: string;
  m: KidsMode;
}

export class MenuScene implements Scene {
  readonly id = 'menu';
  readonly isHome = true;
  private readonly field: TargetField;
  cards: Card[] = [];
  album: Circle = { x: 0, y: 0, r: 0 };
  lock: Circle = { x: 0, y: 0, r: 0 };

  constructor(private readonly ctx: KidsContext) {
    const { round } = ctx;
    this.field = new TargetField(
      ctx.app,
      { maxOnScreen: ctx.kids.menu.backgroundTargets, spawnEvery: round.spawnEvery, target: round.target },
      ctx.theme,
      rise(round.trajectory),
    );
  }

  enter(): void {
    this.field.prefill(Math.max(0, this.ctx.kids.menu.backgroundTargets - 1));
  }

  layout(): void {
    const app = this.ctx.app;
    const { w, h, u, inset } = app;
    const m = margin(app);
    const albumR = buttonRadius(app);
    this.album = { x: inset.left + m + albumR, y: inset.top + m + albumR, r: albumR };
    // The lock is small and grey — for grown-ups; its touch radius is still at least 24 px
    const lockR = Math.max(24, u * 0.045);
    this.lock = { x: w - inset.right - m - lockR, y: inset.top + m + lockR, r: lockR };

    const modes = this.ctx.kids.modes;
    const n = modes.length;
    const top = this.album.y + albumR + m;
    const bottom = h - inset.bottom - m;
    const left = inset.left + m;
    const right = w - inset.right - m;
    const cols = Math.min(n, w > h ? 4 : 2);
    const rows = Math.ceil(n / cols);
    const gap = m;
    const s = Math.min((right - left - gap * (cols - 1)) / cols, (bottom - top - gap * (rows - 1)) / rows);
    const gridW = s * cols + gap * (cols - 1);
    const gridH = s * rows + gap * (rows - 1);
    const x0 = left + (right - left - gridW) / 2;
    const y0 = top + (bottom - top - gridH) / 2;
    this.cards = modes.map((mode, i) => ({
      mode: mode.id,
      m: mode,
      x: x0 + (i % cols) * (s + gap),
      y: y0 + Math.floor(i / cols) * (s + gap),
      w: s,
      h: s,
    }));
  }

  probe(): ProbeTarget[] {
    this.layout();
    const c = (id: string, k: Circle, audience: ProbeTarget['audience'] = 'player'): ProbeTarget => ({ id, x: k.x - k.r, y: k.y - k.r, w: k.r * 2, h: k.r * 2, audience });
    return [
      ...this.cards.map((k) => ({ id: `card:${k.mode}`, x: k.x, y: k.y, w: k.w, h: k.h })),
      c('album', this.album),
      c('lock', this.lock, 'grown-up'),
    ];
  }

  pointer(x: number, y: number): void {
    this.layout();
    const { app } = this.ctx;
    if (hitCircle(this.lock, x, y, 1.2)) {
      app.audio.tap();
      app.go(this.ctx.kids.parentGate ? this.ctx.gate() : this.ctx.settings());
      return;
    }
    if (hitCircle(this.album, x, y)) {
      app.audio.tap();
      app.go(this.ctx.album());
      return;
    }
    for (const c of this.cards) {
      if (hitRect(c, x, y)) {
        app.audio.tap();
        app.go(this.ctx.play(c.m));
        return;
      }
    }
    const b = this.field.hit(x, y);
    if (b) this.field.pop(b);
  }

  update(dt: number): void {
    this.field.update(dt, true);
  }

  draw(g: CanvasRenderingContext2D): void {
    this.layout();
    const { app, theme } = this.ctx;
    const { w, h, time } = app;
    theme.drawBackground(g, w, h, time);
    this.field.draw(g);

    this.cards.forEach((c, i) => {
      // Cards gently "breathe" so the menu feels alive
      const bob = Math.sin(time * 1.6 + i * 1.3) * c.h * 0.012;
      drawPanel(g, c.x, c.y + bob, c.w, c.h, c.w * 0.14, c.m.card.fill, theme.ui.buttonShadow);
      this.drawCardPicture(g, c, c.y + bob);
    });

    drawIconButton(g, this.album.x, this.album.y, this.album.r, 'album', { icon: '#e0553d' });
    // Sticker counter — a number on a badge
    const br = this.album.r * 0.42;
    const bx = this.album.x + this.album.r * 0.72;
    const by = this.album.y - this.album.r * 0.72;
    g.fillStyle = '#ff4b4b';
    g.beginPath();
    g.arc(bx, by, br, 0, Math.PI * 2);
    g.fill();
    drawText(g, String(app.save.stickers), bx, by, br * 1.15, '#ffffff', null);

    drawBareIcon(g, 'lock', this.lock.x, this.lock.y, this.lock.r * 0.6, theme.ui.lock);
  }

  /** Mode picture: up to three small targets with content */
  private drawCardPicture(g: CanvasRenderingContext2D, c: Card, cy0: number): void {
    const r = c.w * 0.14;
    const t = this.ctx.app.time;
    const spots = [
      [c.x + c.w * 0.26, cy0 + c.h * 0.46],
      [c.x + c.w * 0.5, cy0 + c.h * 0.3],
      [c.x + c.w * 0.74, cy0 + c.h * 0.46],
    ];
    const preview = c.m.card.preview;
    const at = preview.length === 1 ? [1] : preview.length === 2 ? [0, 2] : [0, 1, 2];
    preview.forEach((p, i) => {
      const [x, y] = spots[at[i]];
      this.ctx.theme.drawTarget(g, x, y, r, p.color, t);
      if (p.label) drawText(g, p.label, x, y - r * 0.05, r * 1.05, '#ffffff', shade(p.color, -0.45));
      else if (p.emoji) drawEmoji(g, p.emoji, x, y - r * 0.05, r * 1.05);
    });
  }
}
