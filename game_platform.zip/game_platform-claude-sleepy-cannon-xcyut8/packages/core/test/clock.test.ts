import { describe, expect, it } from 'vitest';
import { checkSchedule, clockShift, durationMs, formatClock, worldClock } from '../src/clock.ts';

const T0 = Date.UTC(2026, 9, 19, 18, 3, 12); // Monday 2026-10-19 18:03:12 UTC
const fixed = (t: number) => () => t;

describe('durations and the countdown', () => {
  it('reads seconds and short text', () => {
    expect(durationMs(90)).toBe(90000);
    expect(durationMs('5m')).toBe(300000);
    expect(durationMs('1h30m')).toBe(5400000);
    expect(durationMs('2d')).toBe(2 * 86400000);
    expect(() => durationMs('five minutes')).toThrow(/90s, 5m/);
    expect(() => durationMs(-1)).toThrow();
  });
  it('formats a countdown as a clock, rounded up, never negative', () => {
    expect(formatClock(192)).toBe('3:12');
    expect(formatClock(0.2)).toBe('0:01');
    expect(formatClock(-5)).toBe('0:00');
    expect(formatClock(8045)).toBe('2:14:05');
  });
  it('QA time travel from the query: relative and absolute, nothing for a player', () => {
    expect(clockShift('?clock=+300', T0)).toBe(300000);
    expect(clockShift('?clock=%2B2h', T0)).toBe(7200000);
    expect(clockShift('?clock= 300', T0)).toBe(300000); // a raw '+' in a query reads as a space
    expect(clockShift('?clock=-60', T0)).toBe(-60000);
    expect(clockShift('?clock=2026-10-19T19:00:00Z', T0)).toBe(Date.UTC(2026, 9, 19, 19) - T0);
    expect(clockShift('?seed=3', T0)).toBe(0);
    expect(clockShift('?clock=soon', T0)).toBe(0);
  });
});

describe('worldClock: slots', () => {
  it('the same slot, key and seed for everyone in it; the next one in seconds', () => {
    const a = worldClock({ salt: 'geodes', now: fixed(T0) }).slot();
    const b = worldClock({ salt: 'geodes', now: fixed(T0 + 100_000) }).slot();
    expect(a).toEqual({ ...b, nextIn: a.nextIn });
    expect(a.key).toBe('2026-10-19#216'); // 18:00 / 5 min
    expect(a.start).toBe(Date.UTC(2026, 9, 19, 18, 0));
    expect(a.nextIn).toBe(108);
    const c = worldClock({ salt: 'geodes', now: fixed(T0 + 300_000) }).slot();
    expect(c.index).toBe(a.index + 1);
    expect(c.seed).not.toBe(a.seed);
    // Another game: other seeds, same times
    const other = worldClock({ salt: 'raccoons', now: fixed(T0) }).slot();
    expect(other.index).toBe(a.index);
    expect(other.seed).not.toBe(a.seed);
  });
  it('a slot of another length, an offset for QA, and a minute at least', () => {
    const clock = worldClock({ salt: 'g', every: '4h', now: fixed(T0), offsetMs: 3600_000 });
    expect(clock.now()).toBe(T0 + 3600_000);
    expect(clock.slot().key).toBe('2026-10-19#4'); // 19:03 → the 16:00–20:00 slot
    expect(clock.slot('1h').key).toBe('2026-10-19#19');
    expect(() => worldClock({ salt: 'g', every: '10s' })).toThrow(/1 minute/);
    expect(() => worldClock({ salt: '' })).toThrow(/salt/);
  });
  it('named streams are seeded per slot and differ by name', () => {
    const clock = worldClock({ salt: 'g', now: fixed(T0) });
    const i = clock.slot().index;
    expect(clock.rng('shop', i)()).toBe(clock.rng('shop', i)());
    expect(clock.rng('shop', i)()).not.toBe(clock.rng('sky', i)());
  });
});

describe('worldClock: events', () => {
  const clock = worldClock({ salt: 'g', now: fixed(T0) });
  it('every N with an offset: running or next, with seconds to it', () => {
    const s = clock.schedule([{ id: 'aurora', every: '2h', offset: '45m', lasts: '10m' }]);
    // 18:03 → occurrences at 16:45, 18:45 …
    expect(s.active('aurora')).toBe(false);
    const n = s.next('aurora')!;
    expect(n.start).toBe(Date.UTC(2026, 9, 19, 18, 45));
    expect(n.startsIn).toBe(42 * 60 - 12);
    expect(s.active('aurora', Date.UTC(2026, 9, 19, 18, 50))).toBe(true);
    expect(s.state(Date.UTC(2026, 9, 19, 18, 50)).active[0]).toMatchObject({ id: 'aurora', active: true, startsIn: 0, endsIn: 300 });
  });
  it('daily and weekly at a UTC time; the payload comes back', () => {
    const s = clock.schedule([
      { id: 'tea', daily: '17:00', lasts: '1h30m' },
      { id: 'festival', weekly: 'SAT 18:00', lasts: '30m', data: { mutations: 2 } },
    ]);
    const st = s.state();
    expect(st.active.map((o) => o.id)).toEqual(['tea']);
    const fest = st.upcoming.find((o) => o.id === 'festival')!;
    expect(new Date(fest.start).toISOString()).toBe('2026-10-24T18:00:00.000Z');
    expect(fest.data).toEqual({ mutations: 2 });
    expect(st.upcoming[0].start).toBeLessThanOrEqual(st.upcoming[st.upcoming.length - 1].start);
    expect(s.active('festival', Date.UTC(2026, 9, 24, 18, 20))).toBe(true);
    expect(s.active('festival', Date.UTC(2026, 9, 25, 18, 20))).toBe(false);
  });
  it('a seeded chance per window: the same for everyone, roughly at its rate', () => {
    const def = [{ id: 'meteor', chance: 0.2, per: '10m', lasts: '5m' }] as const;
    const s = clock.schedule(def);
    let hits = 0;
    for (let k = 0; k < 2000; k++) if (s.active('meteor', T0 + k * 600_000)) hits++;
    expect(hits / 2000).toBeGreaterThan(0.15);
    expect(hits / 2000).toBeLessThan(0.25);
    const twin = worldClock({ salt: 'g', now: fixed(T0) }).schedule(def);
    for (let k = 0; k < 50; k++) expect(twin.active('meteor', T0 + k * 600_000)).toBe(s.active('meteor', T0 + k * 600_000));
    expect(s.next('meteor')!.start % 600_000).toBe(0);
  });
  it('refuses a schedule it can not keep', () => {
    expect(checkSchedule([{ id: 'a', every: '1h', lasts: '2h' }])).toEqual(['a: lasts longer than its period']);
    expect(checkSchedule([{ id: 'a', daily: '25:00', lasts: '1h' }])[0]).toMatch(/HH:MM/);
    expect(checkSchedule([{ id: 'a', weekly: 'FUNDAY 10:00', lasts: '1h' }])[0]).toMatch(/weekday/);
    expect(checkSchedule([{ id: 'a', every: '1h', lasts: '1m' }, { id: 'a', every: '1h', lasts: '1m' }])).toEqual(["the event id 'a' twice"]);
    expect(() => clock.schedule([{ id: 'x', chance: 2, lasts: '1m' }])).toThrow(/share/);
  });
});

describe('worldClock: weather', () => {
  const STATES = [
    { id: 'clear', weight: 6, lasts: ['10m', '25m'] },
    { id: 'rain', weight: 3, lasts: '8m' },
    { id: 'storm', weight: 1, lasts: ['4m', '6m'] },
  ] as const;
  it('a seeded sequence the same for every player; durations within their range, whole minutes', () => {
    const a = worldClock({ salt: 'g', now: fixed(T0) }).weather({ states: STATES });
    const b = worldClock({ salt: 'g', now: fixed(T0) }).weather({ states: STATES });
    expect(a.forecast(30)).toEqual(b.forecast(30));
    const f = a.forecast(200, Date.UTC(2026, 9, 19, 0, 0, 30));
    for (let i = 1; i < f.length; i++) {
      expect(f[i].start).toBe(f[i - 1].end); // no gaps
      expect(f[i].id).not.toBe(f[i - 1].id); // repeat: false — and stretches across a cycle edge merge
    }
    for (const s of f.slice(1, -1)) {
      const min = (s.end - s.start) / 60000;
      expect(Number.isInteger(min)).toBe(true);
    }
    const storms = f.filter((s) => s.id === 'storm');
    expect(storms.length).toBeGreaterThan(5);
  });
  it('state(): since, until, what comes next — continuous across the day boundary', () => {
    const sky = worldClock({ salt: 'g', now: fixed(T0) }).weather({ states: STATES });
    const now = sky.state();
    expect(now.since).toBeLessThanOrEqual(T0);
    expect(now.until).toBeGreaterThan(T0);
    expect(now.next.at).toBe(now.until);
    expect(now.next.id).not.toBe(now.id);
    expect(now.endsIn).toBe(Math.ceil((now.until - T0) / 1000));
    const midnight = Date.UTC(2026, 9, 20);
    const before = sky.state(midnight - 1000);
    const after = sky.state(midnight);
    if (before.id === after.id) expect(before.until).toBe(after.until);
    else expect(before.until).toBe(midnight);
  });
  it('shares of the time in the long run; states must make sense', () => {
    const sky = worldClock({ salt: 'g' }).weather({ states: STATES });
    const sh = sky.shares();
    expect(sh.reduce((a, s) => a + s.share, 0)).toBeCloseTo(1);
    expect(sh.find((s) => s.id === 'clear')!.share).toBeGreaterThan(sh.find((s) => s.id === 'storm')!.share);
    const clock = worldClock({ salt: 'g' });
    expect(() => clock.weather({ states: [{ id: 'a', weight: 0, lasts: '1m' }] })).toThrow(/weight/);
    expect(() => clock.weather({ states: [{ id: 'a', weight: 1, lasts: '2d' }] })).toThrow(/cycle/);
  });
  it('one state only: a single endless stretch, cut ahead, never a hang', () => {
    const sky = worldClock({ salt: 'g', now: fixed(T0) }).weather({ states: [{ id: 'fog', weight: 1, lasts: '1h' }], repeat: true });
    const s = sky.state();
    expect(s.id).toBe('fog');
    expect(s.next.id).toBe('fog');
    expect(sky.forecast(3)).toHaveLength(1);
  });
  it('a stretch that crosses midnight starts where it began, the day before', () => {
    const sky = worldClock({ salt: 'edge' }).weather({ states: [{ id: 'a', weight: 1, lasts: ['20m', '3h'] }, { id: 'b', weight: 1, lasts: ['20m', '3h'] }], repeat: true });
    let crossed = 0;
    for (let d = 1; d <= 30; d++) {
      const midnight = Date.UTC(2026, 9, d);
      const before = sky.state(midnight - 1000);
      const after = sky.state(midnight);
      if (before.id === after.id) {
        crossed++;
        expect(after.since).toBe(before.since);
        expect(after.until).toBe(before.until);
      }
    }
    expect(crossed).toBeGreaterThan(0);
  });
  it('a chance event longer than the clock slot is refused', () => {
    expect(() => worldClock({ salt: 'g', every: '5m' }).schedule([{ id: 'x', chance: 0.5, lasts: '10m' }])).toThrow(/window/);
  });
});
