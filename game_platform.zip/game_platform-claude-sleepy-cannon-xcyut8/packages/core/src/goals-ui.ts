// The goals screen and the unlock banners. mountGoals(): a modal with a Quests tab (today's quests, each with its bar
// and its own Claim, the bonus for all of them, what waits from earlier days) and an Achievements tab (cards a page at a
// time — never a list to scroll: gp qa's one-screen rule — with the rarity's colour, "???" for a secret, a bar). One
// screen at 360×800, 1280×720 and a phone on its side. goalBanners(): one banner at a time at the top, held while a
// panel or a card is open (Garage's achQueue, main.ts:577-610: an unlock never lands under the shop).
//
//   const goals = mountGoals(null, {
//     host, quests, achievements: ach, ctx: save,
//     questText: (id, need) => host.t(`quest.${id}`, { n: need }),            // "Break 120 blocks"
//     achievement: (id) => ({ name: host.t(`ach.${id}.name`), text: host.t(`ach.${id}.desc`), icon: trophy }),
//     view: (r) => ({ icon: gemIcon, label: `${r}` }),                        // how a reward reads
//     onClaim: (claims) => { for (const c of claims) save.gems += c.reward; host.save(save); },
//   });
//   const banners = goalBanners({ host });
//   for (const a of ach.check(save)) banners.push({ title: host.t(`ach.${a.id}.name`), rarity: a.rarity, icon: trophy });
//
// Themeable: --gp-goals-bg, -panel, -ink, -muted, -accent, -accent-ink, -radius, -font (each falling back to the shared
// --gp-theme-*), and -common, -rare, -epic, -legendary on #gp-goals; the banners: --gp-banner-* on #gp-banners.
// data-gp="goals", "goals-tab" (data-gp-tab), "goals-quest" (data-gp-quest), "goals-claim", "goals-bonus",
// "goals-carried", "goals-ach" (data-gp-ach), "goals-close" for QA.

import { anyModalOpen } from './cards.ts';
import type { AchievementRow, Achievements, DailyQuests, QuestClaim, Rarity } from './goals.ts';
import type { GameHost } from './host.ts';
import { FONT_FALLBACK } from './i18n.ts';
import { readingSec } from './reading.ts';
import { button, buttonReset, el, fitGrid, iconOf, injectCss, mark, modal, pager, pagerCss, reducedMotion, tabs, tabsCss, themeVars, VEIL_CSS, type UiIcon } from './ui-kit.ts';

/** How a reward reads: an icon and a short label ("25", "Gold chest") */
export interface GoalRewardView {
  icon?: UiIcon;
  label: string;
}

/** A reward paid from the screen */
export interface GoalClaim<R> {
  kind: 'quest' | 'bonus' | 'achievement';
  id: string;
  reward: R;
}

export interface GoalsTexts {
  title: string;
  quests: string;
  achievements: string;
  claim: string;
  claimAll: (n: number) => string;
  bonus: string;
  carried: (n: number) => string;
  tomorrow: string;
  secret: string;
  secretText: string;
  rarity: (r: Rarity) => string;
  page: (n: number, max: number) => string;
  close: string;
}

export function goalsTexts(t: (key: string, params?: Record<string, string | number>) => string): GoalsTexts {
  return {
    title: t('gp.goals.title'),
    quests: t('gp.goals.quests'),
    achievements: t('gp.goals.achievements'),
    claim: t('gp.goals.claim'),
    claimAll: (n) => t('gp.goals.claimAll', { n }),
    bonus: t('gp.goals.bonus'),
    carried: (n) => t('gp.goals.carried', { n }),
    tomorrow: t('gp.goals.tomorrow'),
    secret: t('gp.goals.secret'),
    secretText: t('gp.goals.secretText'),
    rarity: (r) => t(`gp.rarity.${r}`),
    page: (n, max) => t('gp.season.page', { n, max }),
    close: t('gp.back'),
  };
}

export interface GoalsOptions<Id extends string, R, C, AR> {
  host: Pick<GameHost, 'minTouchPx' | 'screen' | 't'>;
  /** Today's quests (dailyQuests); omit for achievements alone */
  quests?: DailyQuests<Id, R> | null;
  /** The achievements; omit for quests alone */
  achievements?: Achievements<C, AR> | null;
  /** What the achievements' progress bars read (the save, the stats) */
  ctx?: C;
  /** A quest's words: "Break 120 blocks" */
  questText?: (id: Id, need: number) => string;
  /** A quest's icon (optional) */
  questIcon?: (id: Id) => UiIcon | undefined;
  /** An achievement's name, line and icon */
  achievement?: (id: string) => { name: string; text?: string; icon?: UiIcon };
  /** How a reward reads (quests, the bonus, an achievement's reward) */
  view: (reward: R | AR, kind: GoalClaim<R>['kind']) => GoalRewardView;
  /** Rewards were claimed (a tap, or Claim all): pay them, and save */
  onClaim(claims: GoalClaim<R | AR>[]): void;
  onClose?(): void;
  /** The tab it opens on (default: the one with something to claim, else quests) */
  tab?: 'quests' | 'achievements';
  texts?: Partial<GoalsTexts>;
}

export interface GoalsScreen {
  el: HTMLElement;
  close(): void;
  /** Draw again (progress came in while it is open) */
  refresh(): void;
}

const NS = 'goals';
const ID = 'gp-goals';
const CELL_W = 150;
const CELL_H = 78;
const GAP = 6;

const CSS = `
${themeVars(ID, NS, [
  ['off', 'rgba(255, 255, 255, 0.16)'],
  ['common', '#c9d2dc'],
  ['rare', '#4aa8ff'],
  ['epic', '#b26bff'],
  ['legendary', '#ffb02e'],
])}
${VEIL_CSS}
#${ID} { position: relative; box-sizing: border-box; width: min(96vw, 760px); height: min(96vh, 640px); display: flex; flex-direction: column;
  gap: 10px; padding: 14px; border-radius: var(--gp-goals-radius); background: var(--gp-goals-bg); color: var(--gp-goals-ink);
  font: 600 15px var(--gp-goals-font); font-variant-numeric: tabular-nums; text-align: left; pointer-events: auto; }
${buttonReset(ID)}
#${ID} header { display: flex; align-items: center; gap: 10px; }
#${ID} h2 { margin: 0; font-size: 24px; line-height: 1.15; flex: 1 1 auto; min-width: 0; }
#${ID} .gp-g-x { border-radius: 999px; display: inline-flex; align-items: center; justify-content: center; color: var(--gp-goals-muted); }
${tabsCss(ID, NS)}
${pagerCss(ID, NS)}
#${ID} .gp-g-body { flex: 1 1 0; min-height: 0; display: flex; flex-direction: column; gap: 8px; }
#${ID} .gp-g-list { display: grid; grid-template-columns: repeat(auto-fit, minmax(290px, 1fr)); gap: ${GAP}px; align-content: start; }
#${ID} .gp-g-row { box-sizing: border-box; display: grid; grid-template-columns: auto 1fr auto; align-items: center; gap: 4px 10px; padding: 8px 10px;
  border-radius: 14px; background: var(--gp-goals-panel); min-height: 64px; border: 2px solid transparent; }
#${ID} .gp-g-row[data-state=ready] { border-color: var(--gp-goals-accent); }
#${ID} .gp-g-row[data-state=claimed] { opacity: 0.7; }
#${ID} .gp-g-icon { width: 36px; height: 36px; display: flex; align-items: center; justify-content: center; font-size: 26px; line-height: 1; color: var(--gp-goals-accent); }
#${ID} .gp-g-icon > img, #${ID} .gp-g-icon > canvas, #${ID} .gp-g-icon > svg { width: 36px; height: 36px; object-fit: contain; }
#${ID} .gp-g-mid { min-width: 0; display: flex; flex-direction: column; gap: 4px; }
#${ID} .gp-g-text { font-size: 15px; line-height: 1.2; overflow-wrap: anywhere; }
#${ID} .gp-g-sub { display: flex; align-items: center; gap: 8px; font-size: 13px; color: var(--gp-goals-muted); }
#${ID} .gp-g-bar { flex: 1 1 auto; height: 8px; border-radius: 4px; background: var(--gp-goals-off); overflow: hidden; min-width: 40px; }
#${ID} .gp-g-bar > i { display: block; height: 100%; background: var(--gp-goals-accent); }
#${ID} .gp-g-reward { display: inline-flex; align-items: center; gap: 4px; white-space: nowrap; color: var(--gp-goals-ink); font-weight: 800; }
#${ID} .gp-g-reward > img, #${ID} .gp-g-reward > canvas, #${ID} .gp-g-reward > svg { width: 20px; height: 20px; object-fit: contain; }
#${ID} .gp-g-end { display: inline-flex; align-items: center; gap: 8px; }
#${ID} .gp-g-claim { border-radius: 999px; padding: 0 16px; background: var(--gp-goals-accent); color: var(--gp-goals-accent-ink); font-weight: 800; white-space: nowrap; }
#${ID} .gp-g-done { color: var(--gp-goals-accent); display: inline-flex; min-width: 48px; justify-content: center; }
#${ID} .gp-g-line { font-size: 13px; color: var(--gp-goals-muted); }
#${ID} .gp-g-track { flex: 1 1 0; min-height: 0; display: grid; gap: ${GAP}px; align-content: start; }
#${ID} .gp-g-ach { box-sizing: border-box; min-width: 0; display: grid; grid-template-columns: auto 1fr; grid-template-rows: auto auto 1fr; gap: 2px 8px; padding: 6px 8px;
  border-radius: 14px; background: var(--gp-goals-panel); border: 2px solid transparent; overflow: hidden; text-align: left; }
#${ID} .gp-g-ach .gp-g-icon { grid-row: 1 / span 3; width: 40px; height: 40px; border-radius: 50%; box-shadow: inset 0 0 0 3px var(--gp-r, var(--gp-goals-common)); }
#${ID} .gp-g-ach .gp-g-icon > * { width: 26px; height: 26px; }
#${ID} .gp-g-ach[data-rarity=common] { --gp-r: var(--gp-goals-common); }
#${ID} .gp-g-ach[data-rarity=rare] { --gp-r: var(--gp-goals-rare); }
#${ID} .gp-g-ach[data-rarity=epic] { --gp-r: var(--gp-goals-epic); }
#${ID} .gp-g-ach[data-rarity=legendary] { --gp-r: var(--gp-goals-legendary); }
#${ID} .gp-g-ach[data-unlocked] { border-color: var(--gp-r); }
#${ID} .gp-g-ach:not([data-unlocked]) .gp-g-icon { opacity: 0.5; filter: grayscale(0.8); }
#${ID} .gp-g-name { font-size: 14px; line-height: 1.15; font-weight: 800; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
#${ID} .gp-g-rar { font-size: 12px; line-height: 1; color: var(--gp-r); }
#${ID} .gp-g-desc { align-self: start; font-size: 12px; line-height: 1.2; color: var(--gp-goals-muted); overflow: hidden; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow-wrap: anywhere; }
#${ID} .gp-g-ach .gp-g-bar { grid-column: 2; align-self: end; height: 6px; }
#${ID} .gp-g-ach[data-claimable] { cursor: pointer; background: color-mix(in srgb, var(--gp-goals-accent) 18%, var(--gp-goals-panel)); }
#${ID} footer { display: flex; align-items: center; gap: 8px; justify-content: space-between; flex-wrap: wrap; }
#${ID} .gp-g-sum { font-size: 14px; color: var(--gp-goals-muted); }
@media (max-height: 520px) {
  #${ID} { height: 98vh; padding: 8px 12px; gap: 6px; }
  #${ID} h2 { font-size: 19px; }
  #${ID} .gp-g-row { min-height: 52px; padding: 4px 8px; }
  #${ID} .gp-g-line { display: none; }
}
@media (prefers-reduced-motion: no-preference) { #${ID} .gp-g-pop { animation: gp-g-pop 0.25s ease-out; } }
@keyframes gp-g-pop { 50% { transform: scale(1.04); } }
`;

/**
 * The goals screen, open now in `root` (a modal veil; null: document.body). host.screen('goals'). Returns close() and
 * refresh(); it closes itself on × and a tap outside.
 */
export function mountGoals<Id extends string, R, C = unknown, AR = never>(root: HTMLElement | null, opts: GoalsOptions<Id, R, C, AR>): GoalsScreen {
  const { host } = opts;
  injectCss('gp-goals-css', CSS);
  const words: GoalsTexts = { ...goalsTexts((k, p) => host.t(k, p)), ...opts.texts };
  const touch = `${host.minTouchPx}px`;
  const q = opts.quests ?? null;
  const a = opts.achievements ?? null;
  if (!q && !a) throw new Error('mountGoals: give it quests, achievements or both');
  const used = new WeakSet<Element>();

  const dismiss = () => {
    m.close();
    opts.onClose?.();
  };
  const m = modal(ID, words.title, root, dismiss, () => removeEventListener('resize', onResize));
  const box = m.box;
  box.dataset.gp = 'goals';

  const head = el('header');
  const h = el('h2', '', words.title);
  const x = button('gp-g-x', 'goals-close');
  x.append(mark('close', 22));
  x.setAttribute('aria-label', words.close);
  x.style.minWidth = x.style.minHeight = touch;
  x.addEventListener('click', dismiss);
  head.append(h, x);

  type Tab = 'quests' | 'achievements';
  const items: { id: Tab; label: string }[] = [];
  if (q) items.push({ id: 'quests', label: words.quests });
  if (a) items.push({ id: 'achievements', label: words.achievements });
  let tab: Tab = opts.tab && items.some((i) => i.id === opts.tab) ? opts.tab : items[0].id;
  if (!opts.tab && q && a && q.state().claimable === 0 && a.state().claimable > 0) tab = 'achievements';
  const bar = tabs(NS, items, host.minTouchPx, (id) => {
    tab = id;
    page = 0;
    draw();
  });
  const body = el('div', 'gp-g-body');
  const foot = el('footer');
  const sum = el('span', 'gp-g-sum');
  let page = -1;
  let per = 1;
  const pg = pager(NS, host.minTouchPx, words.page, (d) => {
    page += d;
    draw();
  });
  foot.append(sum, pg.el);
  box.append(head, bar.el, body, foot);

  const claimed = (claims: GoalClaim<R | AR>[]) => {
    if (claims.length) opts.onClaim(claims);
    draw();
  };
  const rewardNode = (reward: R | AR, kind: GoalClaim<R>['kind']) => {
    const v = opts.view(reward, kind);
    const r = el('span', 'gp-g-reward');
    if (v.icon !== undefined) r.append(iconOf(v.icon, used));
    r.append(document.createTextNode(v.label));
    return r;
  };
  const barOf = (share: number) => {
    const b = el('div', 'gp-g-bar');
    const f = el('i');
    f.style.width = `${Math.round(Math.max(0, Math.min(1, share)) * 100)}%`;
    b.append(f);
    return b;
  };
  const claimButton = (gp: string, label: string, onTap: () => void) => {
    const b = button('gp-g-claim', gp, label);
    b.style.minHeight = touch;
    b.addEventListener('click', onTap);
    return b;
  };

  const drawQuests = () => {
    const s = q!.state();
    const list = el('div', 'gp-g-list');
    for (const row of s.quests) {
      const r = el('div', 'gp-g-row');
      r.dataset.gp = 'goals-quest';
      r.dataset.gpQuest = row.id;
      r.dataset.state = row.claimed ? 'claimed' : row.done ? 'ready' : 'open';
      const ic = el('span', 'gp-g-icon');
      const qi = opts.questIcon?.(row.id);
      ic.append(qi !== undefined ? iconOf(qi, used) : mark(row.done ? 'check' : 'dot', 22, !row.done));
      const mid = el('div', 'gp-g-mid');
      const sub = el('div', 'gp-g-sub');
      sub.append(barOf(row.share), document.createTextNode(`${Math.floor(row.have)}/${row.need}`));
      mid.append(el('span', 'gp-g-text', opts.questText ? opts.questText(row.id, row.need) : row.id), sub);
      let end: HTMLElement;
      if (row.claimed) {
        end = el('span', 'gp-g-done');
        end.append(mark('check', 22));
      } else if (row.done && s.available) {
        end = el('span', 'gp-g-end');
        end.append(
          rewardNode(row.reward, 'quest'),
          claimButton('goals-claim', words.claim, () => {
            const paid = q!.claim(row.index);
            if (paid !== null) claimed([{ kind: 'quest', id: row.id, reward: paid }]);
          }),
        );
      } else end = rewardNode(row.reward, 'quest');
      r.append(ic, mid, end);
      list.append(r);
    }
    if (s.bonus) {
      const r = el('div', 'gp-g-row');
      r.dataset.gp = 'goals-bonus';
      r.dataset.state = s.bonus.claimed ? 'claimed' : s.bonus.ready ? 'ready' : 'open';
      const ic = el('span', 'gp-g-icon');
      ic.append(mark('chest', 28));
      const mid = el('div', 'gp-g-mid');
      const sub = el('div', 'gp-g-sub');
      const done = s.quests.filter((x) => x.claimed).length;
      sub.append(barOf(s.bonus.share), document.createTextNode(`${done}/${s.quests.length}`));
      mid.append(el('span', 'gp-g-text', words.bonus), sub);
      let end: HTMLElement;
      if (s.bonus.claimed) {
        end = el('span', 'gp-g-done');
        end.append(mark('check', 22));
      } else if (s.bonus.ready) {
        end = claimButton('goals-bonus-claim', words.claim, () => {
          const paid = q!.claimBonus();
          if (paid !== null) claimed([{ kind: 'bonus', id: '', reward: paid }]);
        });
      } else end = rewardNode(s.bonus.reward, 'bonus');
      r.append(ic, mid, end);
      list.append(r);
    }
    const waiting = s.carried.length + s.carriedBonus;
    if (waiting > 0) {
      const r = el('div', 'gp-g-row');
      r.dataset.gp = 'goals-carried';
      r.dataset.state = 'ready';
      const ic = el('span', 'gp-g-icon');
      ic.append(mark('gift', 26));
      const mid = el('div', 'gp-g-mid');
      mid.append(el('span', 'gp-g-text', words.carried(waiting)));
      const end = claimButton('goals-claim-carried', words.claimAll(waiting), () => claimed(q!.claimAll().map((c: QuestClaim<Id, R>) => ({ kind: c.kind, id: c.id, reward: c.reward }))));
      r.append(ic, mid, end);
      list.append(r);
    }
    body.replaceChildren(list, el('div', 'gp-g-line', words.tomorrow));
    sum.textContent = `${s.quests.filter((x) => x.claimed).length}/${s.quests.length}`;
    pg.set(0, 1);
  };

  const achCell = (row: AchievementRow<AR>): HTMLElement => {
    const c = button('gp-g-ach', 'goals-ach');
    c.dataset.gpAch = row.id;
    c.dataset.rarity = row.rarity;
    if (row.unlocked) c.dataset.unlocked = '';
    if (row.claimable) c.dataset.claimable = '';
    else c.setAttribute('aria-disabled', 'true');
    const info = row.secret ? null : opts.achievement?.(row.id);
    const ic = el('span', 'gp-g-icon');
    ic.append(row.secret ? mark('question', 24) : info?.icon !== undefined ? iconOf(info.icon, used) : mark(row.unlocked ? 'star' : 'lock', 22, row.unlocked));
    const name = el('span', 'gp-g-name', row.secret ? words.secret : (info?.name ?? row.id));
    const rar = el('span', 'gp-g-rar', words.rarity(row.rarity));
    const desc = el('span', 'gp-g-desc', row.secret ? words.secretText : (info?.text ?? ''));
    c.append(ic, name, rar, desc);
    if (row.claimable && row.reward !== null) {
      desc.replaceChildren(rewardNode(row.reward, 'achievement'));
    } else if (!row.unlocked && row.progress !== null) desc.after(barOf(row.progress));
    c.setAttribute('aria-label', `${name.textContent}, ${rar.textContent}${row.unlocked ? '' : ` (${row.secret ? '?' : Math.floor((row.progress ?? 0) * 100) + ' %'})`}`);
    c.addEventListener('click', () => {
      if (!row.claimable) return;
      const paid = a!.claim(row.id);
      if (paid !== null) claimed([{ kind: 'achievement', id: row.id, reward: paid }]);
      body.querySelector(`[data-gp-ach="${row.id}"]`)?.classList.add('gp-g-pop');
    });
    return c;
  };

  const track = el('div', 'gp-g-track');
  track.dataset.gp = 'goals-track';
  const drawAchievements = () => {
    const s = a!.state(opts.ctx);
    body.replaceChildren(track);
    pg.set(0, 2); // the pager takes its room first: the fit then knows the track's height
    per = fitGrid(track, s.rows.length, CELL_W, CELL_H, GAP);
    if (s.rows.length <= per) {
      pg.set(0, 1);
      per = fitGrid(track, s.rows.length, CELL_W, CELL_H, GAP);
    }
    const pages = Math.max(1, Math.ceil(s.rows.length / per));
    if (page < 0) {
      const first = s.rows.findIndex((r) => r.claimable);
      page = first >= 0 ? Math.floor(first / per) : 0;
    }
    page = Math.max(0, Math.min(pages - 1, page));
    track.replaceChildren(...s.rows.slice(page * per, page * per + per).map(achCell));
    sum.textContent = `${s.unlocked}/${s.total}`;
    pg.set(page, pages);
  };

  const draw = () => {
    bar.select(tab);
    if (q) bar.badge('quests', q.state().claimable);
    if (a) bar.badge('achievements', a.state().claimable);
    box.dataset.tab = tab;
    if (tab === 'quests') drawQuests();
    else drawAchievements();
  };
  const onResize = () => draw();
  addEventListener('resize', onResize);
  draw();
  host.screen('goals');
  return { el: box, close: () => m.close(), refresh: draw };
}

// --- Banners ------------------------------------------------------------------------------------------------------

export interface GoalBanner {
  title: string;
  /** A second line (what it was for) */
  text?: string;
  icon?: UiIcon;
  /** The colour of an achievement's rarity, and the small line above ("Achievement unlocked · Rare") */
  rarity?: Rarity;
  /** The small line above the title (default with a rarity: gp.goals.unlocked · the rarity; else none) */
  kicker?: string;
}

export interface GoalBannersOptions {
  host?: Pick<GameHost, 't'>;
  /** Where they show (default document.body) */
  root?: HTMLElement;
  /** Seconds each stays (default its reading time, at least 2.8 s) */
  sec?: number;
  /** Something is in the way (default: any modal, card or panel on screen): the banner waits, its time doesn't run */
  isBusy?: () => boolean;
}

export interface GoalBanners {
  push(b: GoalBanner): void;
  /** Banners waiting (the one on screen not counted) */
  readonly waiting: number;
  clear(): void;
  destroy(): void;
}

const BANNER_CSS = `
:where(#gp-banners) { --gp-banner-bg: var(--gp-theme-bg, rgba(18, 26, 42, 0.94)); --gp-banner-ink: var(--gp-theme-ink, #f2f6ff);
  --gp-banner-muted: var(--gp-theme-muted, #a7b4cc); --gp-banner-accent: var(--gp-theme-accent, #ffd166); --gp-banner-radius: var(--gp-theme-radius, 16px);
  --gp-banner-font: var(--gp-theme-font, ${FONT_FALLBACK}); --gp-banner-common: #c9d2dc; --gp-banner-rare: #4aa8ff; --gp-banner-epic: #b26bff; --gp-banner-legendary: #ffb02e; }
#gp-banners { position: fixed; left: 0; right: 0; top: calc(env(safe-area-inset-top, 0px) + 10px); z-index: 45; display: flex; justify-content: center; pointer-events: none; }
#gp-banners .gp-bn { box-sizing: border-box; max-width: min(92vw, 420px); display: flex; align-items: center; gap: 10px; padding: 8px 16px 8px 10px;
  border-radius: var(--gp-banner-radius); background: var(--gp-banner-bg); color: var(--gp-banner-ink); font: 700 15px var(--gp-banner-font);
  border: 2px solid var(--gp-r, var(--gp-banner-accent)); box-shadow: 0 6px 22px #0007; opacity: 0; transform: translateY(-12px); transition: opacity 0.25s, transform 0.25s; }
#gp-banners .gp-bn.gp-on { opacity: 1; transform: none; }
#gp-banners .gp-bn[data-rarity=common] { --gp-r: var(--gp-banner-common); }
#gp-banners .gp-bn[data-rarity=rare] { --gp-r: var(--gp-banner-rare); }
#gp-banners .gp-bn[data-rarity=epic] { --gp-r: var(--gp-banner-epic); }
#gp-banners .gp-bn[data-rarity=legendary] { --gp-r: var(--gp-banner-legendary); }
#gp-banners .gp-bn-icon { width: 36px; height: 36px; flex: none; display: flex; align-items: center; justify-content: center; font-size: 26px; color: var(--gp-r, var(--gp-banner-accent)); }
#gp-banners .gp-bn-icon > * { max-width: 36px; max-height: 36px; }
#gp-banners .gp-bn small { display: block; font-size: 12px; color: var(--gp-r, var(--gp-banner-muted)); }
#gp-banners .gp-bn span { display: block; font-size: 13px; color: var(--gp-banner-muted); font-weight: 600; }
@media (prefers-reduced-motion: reduce) { #gp-banners .gp-bn { transition: none; transform: none; } }
`;

/**
 * Banners for what was just earned (an achievement, a quest done): one at a time, each for its reading time, held while
 * a panel or a card is open (its time doesn't run behind it). No pointer events: it never takes a tap from the game
 */
export function goalBanners(opts: GoalBannersOptions = {}): GoalBanners {
  injectCss('gp-banners-css', BANNER_CSS);
  const isBusy = opts.isBusy ?? anyModalOpen;
  const wrap = el('div');
  wrap.id = 'gp-banners';
  wrap.dataset.gp = 'banners';
  wrap.setAttribute('role', 'status');
  wrap.setAttribute('aria-live', 'polite');
  (opts.root ?? document.body).append(wrap);
  const queue: GoalBanner[] = [];
  let shown: { node: HTMLElement; leftMs: number; since: number | null } | null = null;
  let timer: ReturnType<typeof setInterval> | null = null;
  const t = (k: string) => opts.host?.t(k) ?? '';

  const build = (b: GoalBanner): HTMLElement => {
    const n = el('div', 'gp-bn');
    n.dataset.gp = 'banner';
    if (b.rarity) n.dataset.rarity = b.rarity;
    const ic = el('span', 'gp-bn-icon');
    ic.append(b.icon !== undefined ? iconOf(b.icon) : mark(b.rarity ? 'star' : 'check', 26, !!b.rarity));
    const d = el('div');
    const kicker = b.kicker ?? (b.rarity && opts.host ? `${t('gp.goals.unlocked')} · ${t(`gp.rarity.${b.rarity}`)}` : '');
    if (kicker) d.append(el('small', '', kicker));
    d.append(el('b', '', b.title));
    if (b.text) d.append(el('span', '', b.text));
    n.append(ic, d);
    return n;
  };

  const tick = () => {
    const busy = isBusy();
    const now = performance.now();
    if (shown) {
      if (shown.since !== null) {
        shown.leftMs -= now - shown.since;
        shown.since = null;
      }
      if (shown.leftMs <= 0) {
        const old = shown.node;
        old.classList.remove('gp-on');
        setTimeout(() => old.remove(), reducedMotion() ? 0 : 260);
        shown = null;
      } else {
        shown.node.classList.toggle('gp-on', !busy);
        shown.node.hidden = busy;
        if (!busy) shown.since = now;
      }
    }
    if (!shown && !busy && queue.length) {
      const b = queue.shift()!;
      const node = build(b);
      wrap.append(node);
      void node.offsetWidth;
      node.classList.add('gp-on');
      const sec = opts.sec ?? Math.max(2.8, readingSec(`${b.kicker ?? ''} ${b.title} ${b.text ?? ''}`));
      shown = { node, leftMs: sec * 1000, since: now };
    }
    if (!shown && !queue.length && timer) {
      clearInterval(timer);
      timer = null;
    }
  };

  return {
    push(b) {
      queue.push(b);
      if (!timer) timer = setInterval(tick, 200);
      tick();
    },
    get waiting() {
      return queue.length;
    },
    clear() {
      queue.length = 0;
      if (shown) shown.leftMs = 0;
      tick();
    },
    destroy() {
      queue.length = 0;
      if (timer) clearInterval(timer);
      timer = null;
      wrap.remove();
    },
  };
}
