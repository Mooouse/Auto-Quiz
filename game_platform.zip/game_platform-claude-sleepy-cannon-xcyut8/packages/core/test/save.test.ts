import { describe, expect, it } from 'vitest';
import { loadJson, mergeShape } from '../src/save.ts';

const DEFAULTS = { v: 1, dna: 0, sound: true, cell: 'blobby', cells: ['blobby'], upgrades: {} as Record<string, number>, best: { stage1: 0 } };

describe('JSON saves (kit: code)', () => {
  it('keeps valid fields and defaults the rest', () => {
    const s = mergeShape(DEFAULTS, { dna: 42, sound: 'yes', cells: ['blobby', 3, 'cocco'], upgrades: { hp: 2 }, best: { stage1: 90, junk: 1 }, extra: 1 });
    expect(s).toEqual({ v: 1, dna: 42, sound: true, cell: 'blobby', cells: ['blobby', 'cocco'], upgrades: { hp: 2 }, best: { stage1: 90 } });
  });
  it('broken numbers and shapes fall back to defaults', () => {
    expect(mergeShape(DEFAULTS, { dna: NaN, cells: 'x', upgrades: [1], best: null })).toEqual(DEFAULTS);
    expect(mergeShape(DEFAULTS, 'garbage')).toEqual(DEFAULTS);
  });
  it('a null default keeps whatever was saved there (an optional value)', () => {
    const D = { day: 1, campaign: null as null | { seed: number; picks: string[] } };
    expect(mergeShape(D, { day: 3, campaign: { seed: 7, picks: ['a'] } })).toEqual({ day: 3, campaign: { seed: 7, picks: ['a'] } });
    expect(mergeShape(D, { day: 3, campaign: null })).toEqual({ day: 3, campaign: null });
    expect(mergeShape(D, { day: 3 })).toEqual({ day: 3, campaign: null });
  });
  it('arrays of nullable slots keep their strings and objects (a leading null default no longer drops them)', () => {
    // Sanction Runner's hold: 12 slots, empty ones null — every bought cargo vanished on reload
    const D = { hold: Array<string | null>(12).fill(null), mixed: [null, 'x'] as (string | null)[], crew: [null, { hp: 1 }] as ({ hp: number } | null)[], ids: [0] };
    const saved = { hold: ['coffee', 'fish', null, 'coffee'], mixed: ['a', null, 3, 'b'], crew: [{ hp: 3 }, null, 'bad'], ids: [1, null, 'x', Infinity, 2] };
    expect(mergeShape(D, JSON.parse(JSON.stringify(saved)))).toEqual({
      hold: ['coffee', 'fish', null, 'coffee'],
      mixed: ['a', null, 'b'],
      crew: [{ hp: 3 }, null],
      ids: [1, 2],
    });
    expect(loadJson('k', D, () => ({ getItem: () => JSON.stringify(saved), setItem: () => {} })).hold).toEqual(['coffee', 'fish', null, 'coffee']);
  });
  it('a map keyed by ids keeps every stored entry, shaped like the default entry', () => {
    // Garage Evolution: `sites: { shed: … }` lost every garage but the first on each reload
    const D = { sites: { shed: { cars: 0, level: 1, robots: [] as string[] } }, best: { stage1: 0 } };
    const saved = { sites: { shed: { cars: 9, level: 3, robots: ['r1'] }, dock: { cars: 4, level: 'x' }, junk: 5, bad: { other: 1 } }, best: { stage1: 2, stage2: 7 } };
    expect(mergeShape(D, JSON.parse(JSON.stringify(saved)))).toEqual({
      sites: { shed: { cars: 9, level: 3, robots: ['r1'] }, dock: { cars: 4, level: 1, robots: [] } },
      best: { stage1: 2 },
    });
    // a struct of different shapes is not a map: unknown fields are still dropped
    expect(mergeShape({ a: { x: 0 }, b: { y: 0 } }, { a: { x: 1 }, c: { x: 2 } })).toEqual({ a: { x: 1 }, b: { y: 0 } });
  });
  it('never shares the defaults object', () => {
    const s = mergeShape(DEFAULTS, null);
    s.cells.push('x');
    s.upgrades.hp = 1;
    expect(DEFAULTS.cells).toEqual(['blobby']);
    expect(DEFAULTS.upgrades).toEqual({});
  });
  it('reads from a store and survives bad JSON or a throwing store', () => {
    const store = (raw: string | null) => () => ({ getItem: () => raw, setItem: () => {} });
    expect(loadJson('k', DEFAULTS, store('{"dna":5}')).dna).toBe(5);
    expect(loadJson('k', DEFAULTS, store('{oops'))).toEqual(DEFAULTS);
    expect(loadJson('k', DEFAULTS, () => { throw new Error('private mode'); })).toEqual(DEFAULTS);
  });
});
