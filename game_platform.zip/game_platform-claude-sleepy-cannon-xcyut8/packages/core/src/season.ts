// A season pass and a weekly event: the game-as-a-service layer between runs that Frankengun wrote by hand (a 30-tier
// season with dates, its rewards every few tiers, a weekly event with its own rule and prize). Any genre may use them;
// they fit roguelites, action and idle games. Pure logic over a field of the game's own save, deterministic with an
// injected clock (`now`), never a DOM: Node tests and balance bots run them as they are. The screen is
// mountSeasonTrack() (season-ui.ts).
//
//   const pass = seasonPass(save, {
//     seasons: [{ id: 's1', from: '2026-10-01', to: '2027-01-31', tiers: 30, xp: 200 }],  // a new season is a new entry
//     reward: (tier) => (tier % 3 === 0 ? { kind: 'paint', id: PAINTS[tier / 3 - 1] } : { kind: 'coins', n: 30 + 5 * tier }),
//     rewardEvery: 3,                                   // every 3rd tier is a big one (marked on the track)
//     persist: () => host.save(save),
//   });
//   pass.add(xpOfRun);                                  // a run's end: XP in, the tiers reached come back
//   mountSeasonTrack(ui, pass, { host, view: (r) => ({ icon: iconImg(…), label: … }), onClaim: (cs) => pay(cs) });
//
//   const week = weeklyEvent(save, { rules: ['double-speed', 'glass-cannon', 'swarm'], goal: 8, reward: 200, salt: 'my-game',
//     persist: () => host.save(save) });
//   const { rule } = week.state();                      // this week's rule: the same for every player (UTC weeks)
//   if (week.record(wavesThisRun)) toast('Weekly prize!'); // true once a week, when the goal is first reached
//   save.coins += week.claim() ?? 0;
//
// Loss framing (D56, game-design.md): nothing is ever taken back. A missed day or week costs nothing — XP never decays,
// a season's tiers wait where they were. A season that ends keeps what was earned: the tiers reached but not claimed
// carry over and stay claimable (`claimAll()`), and a week's prize reached but not claimed stays claimable after the
// week turns. A new season starts its own track from tier 0; the player's lifetime XP (`log.life`) only grows.

import { dayKey, daySeed } from './daily.ts';

const KEY = /^\d{4}-\d{2}-\d{2}$/;
const isKey = (v: unknown): v is string => typeof v === 'string' && KEY.test(v);
const dayNumber = (key: string) => Math.round(Date.UTC(+key.slice(0, 4), +key.slice(5, 7) - 1, +key.slice(8, 10)) / 86400000);
const keyOf = (n: number) => new Date(n * 86400000).toISOString().slice(0, 10);
const int = (v: unknown, min: number, max: number, dflt: number) => {
  const n = Number(v);
  return Number.isFinite(n) ? Math.max(min, Math.min(max, Math.floor(n))) : dflt;
};
const record = (v: unknown): Record<string, unknown> => (v && typeof v === 'object' && !Array.isArray(v) ? (v as Record<string, unknown>) : {});

interface Clocked {
  /** The clock, in ms (default Date.now): inject one in tests and bots */
  now?: () => number;
  /**
   * Days turn over at the player's own midnight (default false here: seasons and weeks are the same dates for every
   * player, 00:00 UTC, as a live event is); true: the player's local calendar
   */
  local?: boolean;
  /** Called after every change of the block's field: `() => host.save(save)` */
  persist?: () => void;
}

const today = (o: Clocked) => dayKey(new Date((o.now ?? Date.now)()), { local: o.local ?? false });

// --- Weeks --------------------------------------------------------------------------------------------------------

/** The Monday a day's week starts on (`YYYY-MM-DD`): weeks run Monday to Sunday */
export function weekKey(day: string): string {
  if (!isKey(day)) throw new Error(`weekKey: a day like 2026-10-18, not '${day}'`);
  const n = dayNumber(day);
  // 1970-01-01 was a Thursday: day 0 → weekday 3 (Monday 0)
  const weekday = (((n + 3) % 7) + 7) % 7;
  return keyOf(n - weekday);
}

/** Whole days from `day` to `until` (0 on the same day, negative when it is past) */
export const daysBetween = (day: string, until: string): number => dayNumber(until) - dayNumber(day);

// --- The season pass ----------------------------------------------------------------------------------------------

/** A season: its dates (both days included), its tiers and the XP each takes. A new season is a new entry */
export interface SeasonDef {
  id: string;
  /** The first day (`YYYY-MM-DD`) … */
  from: string;
  /** … and the last (included) */
  to: string;
  /** How many tiers (1 … 200) */
  tiers: number;
  /** XP a tier takes: the same for every tier, or by the tier (1 … tiers): `(t) => 100 + 10 * t` */
  xp: number | ((tier: number) => number);
}

/** What the season keeps in the save (`save.season` by default) */
export interface SeasonLog {
  /** The season the XP is for ('' none yet) */
  season: string;
  /** XP this season */
  xp: number;
  /** The tiers of this season claimed (paid) */
  claimed: number[];
  /** Tiers of ended seasons reached but never claimed: still the player's (D56), paid by claimAll() */
  carry: { season: string; tier: number }[];
  /** XP in all seasons: only grows (a rank, a profile line) */
  life: number;
  /** Seasons the player has earned XP in */
  played: string[];
}

export interface SeasonOptions<R> extends Clocked {
  /** The seasons, in order of their dates (they must not overlap) */
  seasons: readonly SeasonDef[];
  /** What tier t of a season gives: a reward of the game's own (a currency amount, a cosmetic), or null (nothing) */
  reward: (tier: number, season: SeasonDef) => R | null;
  /** Every K-th tier is a big one (`major` on the track: a cosmetic among coins). Default 0: none marked */
  rewardEvery?: number;
  /**
   * 'tap' (default): a tier reached waits on the track until the player claims it — the moment the season screen is
   * for; 'auto': reaching a tier pays it, `add()` returns the rewards
   */
  claim?: 'tap' | 'auto';
  /** The save field (default 'season') */
  key?: string;
}

/** One tier on the track */
export interface SeasonTier<R> {
  tier: number;
  /** The season's XP it takes to reach (cumulative) */
  at: number;
  reward: R | null;
  /** A big one (every `rewardEvery` tiers) */
  major: boolean;
  /** 'claimed' (paid), 'ready' (reached, waiting to be claimed) or 'locked' (not reached yet) */
  state: 'claimed' | 'ready' | 'locked';
  /** The next tier to reach */
  next: boolean;
}

export interface SeasonState<R> {
  season: SeasonDef;
  /** 'running' (today is within its dates), 'ended' (its last day passed, no next one yet: its track stays open) or 'upcoming' (before the first season) */
  phase: 'running' | 'ended' | 'upcoming';
  /** Days left, today included (0 once ended); days until it starts when upcoming */
  daysLeft: number;
  startsIn: number;
  /** The season after this one, if one is announced */
  next: SeasonDef | null;
  /** Tiers reached, 0 … tiers */
  tier: number;
  tiers: number;
  /** XP this season, XP into the next tier and what that tier takes (need 0: every tier reached) */
  xp: number;
  into: number;
  need: number;
  /** Toward the next tier, 0 … 1 (1 when every tier is reached) */
  share: number;
  /** Every tier reached */
  done: boolean;
  track: SeasonTier<R>[];
  /** Rewards waiting to be claimed: this season's reached tiers and the carried ones of ended seasons */
  claimable: number;
  carried: number;
  /** XP in all seasons */
  life: number;
}

/** A tier paid */
export interface SeasonClaim<R> {
  season: string;
  tier: number;
  reward: R;
}

export interface SeasonGain<R> {
  /** The tiers this XP reached, in order */
  reached: number[];
  /** What it paid ('auto' claim; 'tap': empty — the tiers wait on the track) */
  paid: SeasonClaim<R>[];
  tier: number;
}

export interface SeasonPass<R> {
  readonly seasons: readonly SeasonDef[];
  /** Where things stand today (it re-reads the clock: a session over midnight sees a new season) */
  state(): SeasonState<R>;
  /** XP earned (a run's end, a daily order): the tiers it reaches; paid at once with claim: 'auto' */
  add(xp: number): SeasonGain<R>;
  /** Claim one reached tier of the current season: its reward, or null (not reached, claimed, or a tier with nothing) */
  claim(tier: number): R | null;
  /** Everything waiting: this season's reached tiers and the carried ones of ended seasons, in order */
  claimAll(): SeasonClaim<R>[];
  /** The season of a day (the one running, else the last started, else the first) */
  seasonOn(day: string): SeasonDef;
  readonly log: SeasonLog;
}

/** A season list's problems (empty: fine): bad dates, overlaps, out-of-order, duplicate ids, bad tiers or XP */
export function checkSeasons(seasons: readonly SeasonDef[]): string[] {
  const out: string[] = [];
  if (!seasons.length) out.push('no season');
  const ids = new Set<string>();
  seasons.forEach((s, i) => {
    if (!s.id || ids.has(s.id)) out.push(`season ${i + 1}: ${s.id ? `the id '${s.id}' twice` : 'no id'}`);
    ids.add(s.id);
    if (!isKey(s.from) || !isKey(s.to)) out.push(`season ${s.id}: from and to are days like 2026-10-01`);
    else if (s.to < s.from) out.push(`season ${s.id}: ends (${s.to}) before it starts (${s.from})`);
    if (!Number.isInteger(s.tiers) || s.tiers < 1 || s.tiers > 200) out.push(`season ${s.id}: tiers is a whole number 1 … 200`);
    if (typeof s.xp === 'number' ? !(s.xp > 0) : typeof s.xp !== 'function') out.push(`season ${s.id}: xp is a number above 0 or a function of the tier`);
    const prev = seasons[i - 1];
    if (prev && isKey(prev.to) && isKey(s.from) && s.from <= prev.to) out.push(`season ${s.id} starts (${s.from}) before ${prev.id} ends (${prev.to}): list seasons in order, without overlaps`);
  });
  return out;
}

/** The saved season made safe: wrong types, junk tiers and duplicates go */
export function loadSeason(saved: unknown): SeasonLog {
  const s = record(saved);
  const nums = (v: unknown) => (Array.isArray(v) ? [...new Set(v.map((x) => int(x, 0, 200, 0)).filter((x) => x > 0))].sort((a, b) => a - b) : []);
  const carry = Array.isArray(s.carry)
    ? s.carry
        .map(record)
        .filter((c) => typeof c.season === 'string' && c.season && Number.isInteger(c.tier) && (c.tier as number) > 0)
        .map((c) => ({ season: c.season as string, tier: c.tier as number }))
    : [];
  return {
    season: typeof s.season === 'string' ? s.season : '',
    xp: int(s.xp, 0, Number.MAX_SAFE_INTEGER, 0),
    claimed: nums(s.claimed),
    carry: carry.filter((c, i) => carry.findIndex((d) => d.season === c.season && d.tier === c.tier) === i),
    life: int(s.life, 0, Number.MAX_SAFE_INTEGER, 0),
    played: Array.isArray(s.played) ? [...new Set(s.played.filter((x): x is string => typeof x === 'string'))] : [],
  };
}

/**
 * The season pass over `save[key]`: the season of today (by its dates; UTC days unless `local`), its tiers from the
 * season's XP, what each gives and whether it was claimed. A new season starts its track at 0 and carries the old
 * one's unclaimed tiers (they stay the player's). Deterministic with `now`.
 */
export function seasonPass<R>(save: object, opts: SeasonOptions<R>): SeasonPass<R> {
  const problems = checkSeasons(opts.seasons);
  if (problems.length) throw new Error(`seasonPass: ${problems.join('; ')}`);
  const seasons = opts.seasons;
  const key = opts.key ?? 'season';
  const holder = save as Record<string, unknown>;
  const log = loadSeason(holder[key]);
  holder[key] = log;
  const persist = () => opts.persist?.();
  const every = int(opts.rewardEvery ?? 0, 0, 200, 0);
  const auto = opts.claim === 'auto';
  const byId = new Map(seasons.map((s) => [s.id, s]));

  const tierXp = (s: SeasonDef, t: number) => {
    const v = Number(typeof s.xp === 'function' ? s.xp(t) : s.xp);
    return Number.isFinite(v) && v > 0 ? v : 1;
  };
  /** The cumulative XP of each tier of a season */
  const cache = new Map<string, number[]>();
  const steps = (s: SeasonDef) => {
    let a = cache.get(s.id);
    if (!a) {
      a = [];
      let sum = 0;
      for (let t = 1; t <= s.tiers; t++) a.push((sum += tierXp(s, t)));
      cache.set(s.id, a);
    }
    return a;
  };
  const tierAt = (s: SeasonDef, xp: number) => {
    const a = steps(s);
    let t = 0;
    while (t < a.length && xp >= a[t]) t++;
    return t;
  };
  const rewardOf = (s: SeasonDef, t: number) => opts.reward(t, s) ?? null;

  const seasonOn = (day: string): SeasonDef => {
    let cur: SeasonDef | null = null;
    for (const s of seasons) if (s.from <= day) cur = s;
    return cur ?? seasons[0];
  };

  /** Today's season; a new one moves the old one's unclaimed tiers to `carry` and starts at 0 */
  const roll = (): { s: SeasonDef; day: string } => {
    const day = today(opts);
    const s = seasonOn(day);
    if (log.season !== s.id) {
      const old = byId.get(log.season);
      if (old) {
        const reached = tierAt(old, log.xp);
        for (let t = 1; t <= reached; t++) if (!log.claimed.includes(t) && rewardOf(old, t) !== null && !log.carry.some((c) => c.season === old.id && c.tier === t)) log.carry.push({ season: old.id, tier: t });
      }
      log.season = s.id;
      log.xp = 0;
      log.claimed = [];
      persist();
    }
    return { s, day };
  };

  const pay = (s: SeasonDef, t: number): SeasonClaim<R> | null => {
    const reward = rewardOf(s, t);
    // A tier with nothing counts as claimed once reached (the track shows it so); never marked, never paid
    if (reward === null || log.claimed.includes(t)) return null;
    log.claimed.push(t);
    log.claimed.sort((a, b) => a - b);
    return { season: s.id, tier: t, reward };
  };

  roll();

  return {
    seasons,
    log,
    seasonOn,
    state() {
      const { s, day } = roll();
      const a = steps(s);
      const tier = tierAt(s, log.xp);
      const done = tier >= s.tiers;
      const base = tier > 0 ? a[tier - 1] : 0;
      const need = done ? 0 : a[tier] - base;
      const into = done ? 0 : log.xp - base;
      const idx = seasons.indexOf(s);
      const phase = day < s.from ? 'upcoming' : day > s.to ? 'ended' : 'running';
      const track: SeasonTier<R>[] = a.map((at, i) => {
        const t = i + 1;
        const reward = rewardOf(s, t);
        const state = t > tier ? 'locked' : log.claimed.includes(t) || reward === null ? 'claimed' : 'ready';
        return { tier: t, at, reward, major: every > 0 && t % every === 0, state, next: t === tier + 1 };
      });
      const carried = log.carry.filter((c) => byId.has(c.season)).length;
      return {
        season: s,
        phase,
        daysLeft: phase === 'running' ? daysBetween(day, s.to) + 1 : 0,
        startsIn: phase === 'upcoming' ? daysBetween(day, s.from) : 0,
        next: seasons[idx + 1] ?? null,
        tier,
        tiers: s.tiers,
        xp: log.xp,
        into,
        need,
        share: done ? 1 : need > 0 ? into / need : 0,
        done,
        track,
        claimable: track.filter((x) => x.state === 'ready').length + carried,
        carried,
        life: log.life,
      };
    },
    add(xp) {
      const { s } = roll();
      const n = Math.max(0, Math.floor(Number(xp) || 0));
      const before = tierAt(s, log.xp);
      if (!n) return { reached: [], paid: [], tier: before };
      log.xp += n;
      log.life += n;
      if (!log.played.includes(s.id)) log.played.push(s.id);
      const after = tierAt(s, log.xp);
      const reached: number[] = [];
      const paid: SeasonClaim<R>[] = [];
      for (let t = before + 1; t <= after; t++) {
        reached.push(t);
        if (auto) {
          const c = pay(s, t);
          if (c) paid.push(c);
        }
      }
      persist();
      return { reached, paid, tier: after };
    },
    claim(tier) {
      const { s } = roll();
      if (!Number.isInteger(tier) || tier < 1 || tier > tierAt(s, log.xp)) return null;
      const c = pay(s, tier);
      if (c) persist();
      return c ? c.reward : null;
    },
    claimAll() {
      const { s } = roll();
      const out: SeasonClaim<R>[] = [];
      // The carried tiers of ended seasons first (oldest), then this season's
      for (const c of log.carry.splice(0)) {
        const old = byId.get(c.season);
        const reward = old ? rewardOf(old, c.tier) : null;
        if (old && reward !== null) out.push({ season: c.season, tier: c.tier, reward });
      }
      const reached = tierAt(s, log.xp);
      for (let t = 1; t <= reached; t++) {
        const c = pay(s, t);
        if (c) out.push(c);
      }
      persist();
      return out;
    },
  };
}

// --- The weekly event ---------------------------------------------------------------------------------------------

/** What the weekly event keeps in the save (`save.week` by default) */
export interface WeekLog {
  /** The Monday of the week the record is for ('' none yet) */
  week: string;
  /** The best score this week */
  best: number;
  /** The goal was reached this week (the prize is the player's) … */
  reached: boolean;
  /** … and paid */
  claimed: boolean;
  /** A prize reached in an earlier week and never claimed: still the player's (D56), claim() pays it */
  owed: number;
  /** Weeks whose goal was reached */
  total: number;
}

export interface WeeklyOptions<Rule> extends Clocked {
  /** The rules a week's event is chosen from (a modifier, a map, a daily-run variant): one a week, by the week's seed */
  rules: readonly Rule[];
  /** The score that wins the week's prize (waves cleared, a distance); null: no goal, the event is for the best alone */
  goal: number | null;
  /** The prize (a number of the game's currency) */
  reward: number;
  /** Mixed into the week's seed: the game's id, so two games don't share their weeks (default '') */
  salt?: string;
  /** The save field (default 'week') */
  key?: string;
}

export interface WeeklyState<Rule> {
  /** The Monday it started */
  week: string;
  rule: Rule;
  /** The week's own seed (for a seeded run of the event) */
  seed: number;
  /** Days left, today included (7 on a Monday, 1 on Sunday) */
  daysLeft: number;
  best: number;
  goal: number | null;
  /** The goal was reached this week */
  reached: boolean;
  claimed: boolean;
  /** The prize waiting to be claimed (this week's and an earlier unclaimed one) */
  claimable: number;
  reward: number;
}

export interface WeeklyEvent<Rule> {
  state(): WeeklyState<Rule>;
  /** An event run's score: the week's best kept; true when this score first reaches the goal this week */
  record(score: number): boolean;
  /** The prize waiting (this week's, and one carried from an earlier week): the amount, or null */
  claim(): number | null;
  readonly log: WeekLog;
}

/** The saved weekly event made safe */
export function loadWeek(saved: unknown): WeekLog {
  const s = record(saved);
  const num = (v: unknown) => (Number.isFinite(Number(v)) ? Math.max(0, Number(v)) : 0);
  return {
    week: isKey(s.week) ? s.week : '',
    best: num(s.best),
    reached: s.reached === true,
    claimed: s.claimed === true,
    owed: num(s.owed),
    total: int(s.total, 0, Number.MAX_SAFE_INTEGER, 0),
  };
}

/**
 * This week's event over `save[key]`: a rule from `rules` picked by the week's seed (the same for every player that
 * week: UTC weeks unless `local`), the best score, the prize once a week for reaching `goal`. A new week brings a new
 * rule and a fresh best; a prize reached and not claimed is carried, never lost.
 */
export function weeklyEvent<Rule>(save: object, opts: WeeklyOptions<Rule>): WeeklyEvent<Rule> {
  if (!opts.rules.length) throw new Error('weeklyEvent: `rules` lists no rule');
  const key = opts.key ?? 'week';
  const holder = save as Record<string, unknown>;
  const log = loadWeek(holder[key]);
  holder[key] = log;
  const persist = () => opts.persist?.();
  const reward = Number.isFinite(opts.reward) && opts.reward > 0 ? opts.reward : 0;

  const refresh = (): { week: string; day: string } => {
    const day = today(opts);
    const week = weekKey(day);
    if (log.week !== week) {
      if (log.reached && !log.claimed) log.owed += reward;
      Object.assign(log, { week, best: 0, reached: false, claimed: false });
      persist();
    }
    return { week, day };
  };
  const seedOf = (week: string) => daySeed(week, `week:${opts.salt ?? ''}`);

  refresh();
  return {
    log,
    state() {
      const { week, day } = refresh();
      const seed = seedOf(week);
      return {
        week,
        rule: opts.rules[(seed >>> 0) % opts.rules.length],
        seed,
        daysLeft: 7 - daysBetween(week, day),
        best: log.best,
        goal: opts.goal,
        reached: log.reached,
        claimed: log.claimed,
        claimable: (log.reached && !log.claimed ? reward : 0) + log.owed,
        reward,
      };
    },
    record(score) {
      refresh();
      const v = Number(score);
      if (!Number.isFinite(v) || v < 0) return false;
      let changed = false;
      if (v > log.best) [log.best, changed] = [v, true];
      const first = opts.goal !== null && !log.reached && v >= opts.goal;
      if (first) {
        log.reached = true;
        log.total++;
        changed = true;
      }
      if (changed) persist();
      return first;
    },
    claim() {
      refresh();
      const now = log.reached && !log.claimed ? reward : 0;
      const n = now + log.owed;
      if (!(n > 0)) return null;
      if (now) log.claimed = true;
      log.owed = 0;
      persist();
      return n;
    },
  };
}
