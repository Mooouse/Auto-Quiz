// The engine adapters' shared part (@gp/core/engines/*): what the engine lab's shell.ts and world.ts did by hand for
// every engine (QmaCyber/game12, docs/engine-lab.md), once.
//
// The contract every adapter keeps (Canvas 2D, Pixi, Phaser, three):
// - created STOPPED: no engine frame, no requestAnimationFrame, no step until setRunning(true);
// - runs only while the game says a run is on (setRunning(true)) AND the host has no pause reason (a hidden tab, an ad,
//   a lost WebGL context): the adapter listens to host.onPause / onResume itself;
// - stops at once, also from inside a step (a run that ends in a collision): no more steps and no draw in that frame;
// - resumes without counting the time it stood still (the frame delta is reset; engine clocks too);
// - resizes from the window with the device pixel ratio capped (2), never by the engine's own listeners; a render scale
//   (a quality level's strongest lever) draws fewer pixels, the CSS size unchanged: setRenderScale();
// - renderOnce() draws one complete frame synchronously (the ?cover frame, the pause screen, after a resize or a context
//   restore while standing still);
// - sound only through host.audio.out on host.audio.ctx, and nothing scheduled while that context isn't 'running'.
//
// The adapters never import an engine: the game passes the engine's module (or the pieces the adapter needs), so the
// engine stays the game's own npm dependency (games/<id>/package.json) and @gp/core builds and type-checks without it.

import type { GameHost } from '../host';

/** CSS size of the game's canvas and the pixel ratio the adapter draws at: the device's, capped, × the render scale */
export interface EngineSize {
  width: number;
  height: number;
  dpr: number;
  /** The render scale in that ratio (1: full; 0.5: a quarter of the pixels, scaled up by the browser) */
  scale: number;
}

/** What every adapter takes, besides its engine's own options */
export interface EngineOptions {
  /** Seconds per simulation step: onStep gets exactly this (default 1/60). 0: one step per frame with the frame's delta */
  step?: number;
  /** The longest frame delta counted, seconds (default 0.1): a slow frame never becomes a jump */
  maxDt?: number;
  /** Device pixel ratio cap (default 2: sharp on phones, a quarter of the pixels of DPR 4) */
  dprMax?: number;
  /**
   * Draw at this share of the pixels' resolution (default 1): the drawing buffer is CSS size × capped DPR × scale, the
   * page still shows it at the CSS size. Change it with setRenderScale() (a quality level). Below `pixelatedBelow`
   * (default 0.6) the canvas is upscaled nearest-neighbour: a filtered full-screen upscale cost a software compositor ≈ 10 ms
   */
  renderScale?: number;
  pixelatedBelow?: number;
}

/** Sound through the host: one AudioContext (the host's), the portal's mute and the ad's silence apply */
export interface EngineAudio {
  /**
   * The host's audio while a sound can start now: the context exists (after the player's first tap), is 'running' and
   * the host isn't paused. null otherwise — schedule nothing then: a suspended context's clock stands still, and sounds
   * queued on it would all play at once when it resumes
   */
  live(): { ctx: AudioContext; out: GainNode } | null;
  /** Play a buffer now into host.audio.out; nothing (null) when not live */
  play(buffer: AudioBuffer, opts?: { volume?: number; rate?: number; detune?: number }): AudioBufferSourceNode | null;
}

/** What every adapter returns (plus its engine's objects: renderer, stage, game, context…) */
export interface Engine {
  /** A run is on (setRunning(true)) and the host has no pause reason: the loop runs */
  readonly running: boolean;
  /**
   * The game's side: a run is on (true) or not (menus, the game's own pause screen, results). The adapter runs only while
   * this is true AND the host isn't paused. Safe to call from inside a step or an engine callback: after
   * setRunning(false) returns, no more steps and no draw in that frame. setRunning(true) resumes without a time jump
   */
  setRunning(on: boolean): void;
  /** Draw one complete frame now, synchronously (onFrame listeners first), running or not */
  renderOnce(): void;
  /** Every simulation step while running: dt seconds (fixed, see EngineOptions.step). Returns an unsubscribe */
  onStep(fn: (dt: number) => void): () => void;
  /** Before every drawn frame and every renderOnce(): move the views to the state (on Canvas 2D: draw). Returns an unsubscribe */
  onFrame(fn: () => void): () => void;
  /** After the adapter resized the engine to the window (CSS size, capped DPR): keep the game inside the new arena */
  onResize(fn: (size: EngineSize) => void): () => void;
  /** The current CSS size and capped DPR */
  readonly size: EngineSize;
  /**
   * Draw at a share of the resolution (and, optionally, another DPR cap): a quality level's render scale. Resizes the
   * engine's drawing buffer now, calls the onResize listeners and redraws a still frame. The CSS size doesn't change
   */
  setRenderScale(scale: number, opts?: { dprMax?: number }): void;
  /** A callback (an engine's collision or timer callback) that does nothing while the adapter stands still */
  guard<A extends unknown[]>(fn: (...args: A) => void): (...args: A) => void;
  readonly audio: EngineAudio;
  /** Stop for good and remove the adapter's listeners (the engine itself is the game's to destroy) */
  destroy(): void;
}

/** What one engine plugs into the driver */
export interface DriverImpl {
  /** Start the engine's loop (the driver's own loop when `loop` is used) */
  start(): void;
  /** Stop it at once (may be called from inside a step) */
  stop(): void;
  /** Draw one frame of the current state, synchronously (after onFrame listeners) */
  render(): void;
  /** Size the engine's drawing buffer: CSS size × dpr */
  resize(size: EngineSize): void;
  /** WebGL: call preventDefault() on a context loss (so it can come back) */
  webgl?: boolean;
  /** False while the engine can't draw yet (Phaser before its boot): renderOnce() then does nothing */
  canRender?(): boolean;
  destroy?(): void;
}

export interface Driver {
  readonly engine: Engine;
  /** Fire the step listeners (an engine with its own loop calls it from its fixed step); stops at once when stopped */
  step(dt: number): void;
  /** Fire the frame listeners (an engine with its own loop calls it before it draws) */
  frame(): void;
  /** The driver's own requestAnimationFrame loop, for engines driven by hand (Canvas 2D, Pixi, three) */
  loop(opts: { render: () => void; beforeFrame?: (ts: number) => void }): { start(): void; stop(): void };
  /** True while running (the same as engine.running) */
  readonly on: boolean;
  readonly opts: Required<EngineOptions>;
}

/** The size the adapters draw at: the window (the platform's CSS sizes #game to it), DPR capped, × the render scale */
export function windowSize(dprMax = 2, scale = 1): EngineSize {
  const k = clampScale(scale);
  return { width: Math.max(1, window.innerWidth), height: Math.max(1, window.innerHeight), dpr: Math.min(dprMax, window.devicePixelRatio || 1) * k, scale: k };
}

/** A render scale within 0.1…2 (a typo can't draw a 0-pixel or a 16× buffer) */
const clampScale = (k: number): number => (Number.isFinite(k) ? Math.max(0.1, Math.min(2, k)) : 1);

/**
 * The shared driver: the run/pause gate (game ∧ ¬host.paused), the window resize, the WebGL context listeners, the
 * audio helper and, for engines driven by hand, a fixed-step loop. `impl(driver)` builds the engine's part.
 */
export function createDriver(host: GameHost, canvas: HTMLCanvasElement, options: EngineOptions, impl: (d: Driver) => DriverImpl): Driver {
  const opts: Required<EngineOptions> = {
    step: options.step ?? 1 / 60,
    maxDt: options.maxDt ?? 0.1,
    dprMax: options.dprMax ?? 2,
    renderScale: clampScale(options.renderScale ?? 1),
    pixelatedBelow: options.pixelatedBelow ?? 0.6,
  };
  const stepFns: ((dt: number) => void)[] = [];
  const frameFns: (() => void)[] = [];
  const resizeFns: ((s: EngineSize) => void)[] = [];
  let want = false;
  let on = false;
  let dead = false;
  let size = windowSize(opts.dprMax, opts.renderScale);
  /** The canvas's own image-rendering before the adapter set 'pixelated' (null: never set it) */
  let cssBefore: string | null = null;
  const pixelate = () => {
    const low = size.scale < opts.pixelatedBelow;
    if (low && cssBefore === null) {
      cssBefore = canvas.style.imageRendering;
      canvas.style.imageRendering = 'pixelated';
    } else if (!low && cssBefore !== null) {
      canvas.style.imageRendering = cssBefore;
      cssBefore = null;
    }
  };
  const sub = <F>(list: F[], fn: F) => {
    list.push(fn);
    return () => {
      const i = list.indexOf(fn);
      if (i >= 0) list.splice(i, 1);
    };
  };

  function sync(): void {
    const next = want && !host.paused && !dead;
    if (next === on) return;
    on = next;
    if (on) part.start();
    else part.stop();
  }

  const audio: EngineAudio = {
    live() {
      const a = host.audio;
      return a && a.ctx.state === 'running' && !host.paused ? a : null;
    },
    play(buffer, o = {}) {
      const a = audio.live();
      if (!a) return null;
      const src = a.ctx.createBufferSource();
      src.buffer = buffer;
      if (o.rate !== undefined) src.playbackRate.value = o.rate;
      if (o.detune !== undefined) src.detune.value = o.detune;
      let node: AudioNode = src;
      let gain: GainNode | null = null;
      if (o.volume !== undefined && o.volume !== 1) {
        gain = a.ctx.createGain();
        gain.gain.value = o.volume;
        node = src.connect(gain);
      }
      node.connect(a.out);
      src.onended = () => {
        src.disconnect();
        gain?.disconnect();
      };
      src.start();
      return src;
    },
  };

  const engine: Engine = {
    get running() {
      return on;
    },
    setRunning(v) {
      want = v;
      sync();
    },
    renderOnce() {
      if (dead || part.canRender?.() === false) return;
      driver.frame();
      part.render();
    },
    onStep: (fn) => sub(stepFns, fn),
    onFrame: (fn) => sub(frameFns, fn),
    onResize: (fn) => sub(resizeFns, fn),
    get size() {
      return size;
    },
    setRenderScale(scale, o = {}) {
      opts.renderScale = clampScale(scale);
      if (o.dprMax !== undefined) opts.dprMax = o.dprMax;
      onWindowResize();
    },
    guard(fn) {
      return (...args) => {
        if (on) fn(...args);
      };
    },
    audio,
    destroy() {
      if (dead) return;
      want = false;
      sync();
      dead = true;
      window.removeEventListener('resize', onWindowResize);
      canvas.removeEventListener('webglcontextlost', onLost);
      part.destroy?.();
    },
  };

  const driver: Driver = {
    engine,
    step(dt) {
      for (const fn of stepFns) {
        if (!on) return;
        fn(dt);
      }
    },
    frame() {
      for (const fn of frameFns) fn();
    },
    loop({ render, beforeFrame }) {
      let raf = 0;
      let last = 0;
      let acc = 0;
      const frame = (ts: number) => {
        raf = requestAnimationFrame(frame);
        const dt = last ? Math.min(opts.maxDt, Math.max(0, (ts - last) / 1000)) : 0;
        last = ts;
        beforeFrame?.(ts);
        if (opts.step > 0) {
          acc += dt;
          // A step may stop the run (a hook ends it): no more steps and no draw in this frame then
          while (on && acc >= opts.step) {
            acc -= opts.step;
            driver.step(opts.step);
          }
        } else if (on && dt > 0) driver.step(dt);
        if (!on) return;
        driver.frame();
        render();
      };
      return {
        start() {
          // Resume without the time it stood still: the first frame counts 0 s
          last = 0;
          acc = 0;
          cancelAnimationFrame(raf);
          raf = requestAnimationFrame(frame);
        },
        stop() {
          cancelAnimationFrame(raf);
          raf = 0;
        },
      };
    },
    get on() {
      return on;
    },
    opts,
  };

  const part = impl(driver);

  function onWindowResize(): void {
    if (dead) return;
    size = windowSize(opts.dprMax, opts.renderScale);
    pixelate();
    part.resize(size);
    for (const fn of resizeFns) fn(size);
    if (!on) engine.renderOnce();
  }
  // An engine that can rebuild wants its context back: without preventDefault() the browser never restores it (the host
  // then shows its "reload" screen). The host pauses the game meanwhile ('context') and resumes it after the restore
  const onLost = (e: Event) => e.preventDefault();

  pixelate();
  part.resize(size);
  window.addEventListener('resize', onWindowResize);
  if (part.webgl) canvas.addEventListener('webglcontextlost', onLost);
  host.onPause(() => sync());
  // After a context restore (the engine re-created its GPU state in its own listener), an ad or a hidden tab: run on, or
  // redraw the still frame (a restored canvas is blank until something draws)
  host.onResume(() => {
    if (dead) return;
    sync();
    if (!on) engine.renderOnce();
  });
  return driver;
}

/** Dev builds only: a warning once, prefixed like the platform's own */
export function devWarn(key: string, message: string): void {
  if (!import.meta.env.DEV || warned.has(key)) return;
  warned.add(key);
  console.warn(`[gp] ${message}`);
}
const warned = new Set<string>();
