import { describe, expect, it } from 'vitest';
import { aimAssist, angleDiff, forward, yawPitch } from '../src/aim.ts';

const angle = (a: { x: number; y: number; z?: number }, b: { x: number; y: number; z?: number }) => {
  const d = (a.x * b.x + a.y * b.y + (a.z ?? 0) * (b.z ?? 0)) / (Math.hypot(a.x, a.y, a.z ?? 0) * Math.hypot(b.x, b.y, b.z ?? 0));
  return Math.acos(Math.max(-1, Math.min(1, d)));
};

describe('aimAssist', () => {
  const eye = { x: 0, y: 1.6, z: 0 };
  const ahead = forward(0, 0);

  it('picks the target nearest the crosshair inside the cone and range, and pulls softly toward it', () => {
    const near = { id: 'near', x: 0.8, y: 1.6, z: -10 }; // ≈ 0.08 rad off
    const off = { id: 'off', x: 5, y: 1.6, z: -10 }; // ≈ 0.46 rad: outside the cone
    const far = { id: 'far', x: 0, y: 1.6, z: -50 }; // dead ahead but out of range
    const r = aimAssist(eye, ahead, [off, near, far], { cone: 0.16, range: 30, strength: 0.6, maxTurn: 0.02 })!;
    expect(r.target.id).toBe('near');
    expect(r.angle).toBeCloseTo(0.08, 2);
    // A soft pull: at most maxTurn per call, never a snap
    expect(r.turned).toBeCloseTo(0.02, 5);
    expect(angle(ahead, r.dir)).toBeCloseTo(0.02, 4);
    // Turned toward it (to the right: +x)
    expect(r.dir.x).toBeGreaterThan(0);
    expect(r.onTarget).toBe(true);
  });

  it('the strength is a share of the remaining angle; repeated calls converge without overshooting', () => {
    let dir = ahead as { x: number; y: number; z: number };
    const t = { x: 1, y: 2.1, z: -10 };
    let last = Infinity;
    for (let i = 0; i < 200; i++) {
      const r = aimAssist(eye, dir, [t], { cone: 0.3, range: 30, strength: 0.5, maxTurn: 0.05 })!;
      expect(r.angle).toBeLessThanOrEqual(last + 1e-9);
      last = r.angle;
      dir = r.dir;
    }
    expect(last).toBeLessThan(1e-4);
    expect(aimAssist(eye, ahead, [t], { cone: 0.3, range: 30, strength: 0 })!.turned).toBe(0);
  });

  it('a target behind a wall (visible false) gives way to the next one; none in sight: null', () => {
    const a = { id: 'a', x: 0.2, y: 1.6, z: -10 };
    const b = { id: 'b', x: -1, y: 1.6, z: -10 };
    const seen: string[] = [];
    const r = aimAssist(eye, ahead, [b, a], { cone: 0.2, range: 30, strength: 0.6, visible: (t) => (seen.push(t.id), t.id !== 'a') })!;
    expect(r.target.id).toBe('b');
    // Asked nearest-first, and only for those in the cone
    expect(seen).toEqual(['a', 'b']);
    expect(aimAssist(eye, ahead, [a], { cone: 0.2, range: 30, strength: 1, visible: () => false })).toBeNull();
    expect(aimAssist(eye, ahead, [], { cone: 0.2, range: 30, strength: 1 })).toBeNull();
  });

  it('a big target is measured to its edge: inside the cone sooner, and on target', () => {
    const t = { x: 3, y: 1.6, z: -10 }; // ≈ 0.29 rad to its centre
    expect(aimAssist(eye, ahead, [t], { cone: 0.2, range: 30, strength: 1 })).toBeNull();
    const big = aimAssist(eye, ahead, [{ ...t, r: 1.5 }], { cone: 0.2, range: 30, strength: 1, fireCone: 0.2 })!;
    expect(big).not.toBeNull();
    expect(big.onTarget).toBe(true);
  });

  it('works top-down in 2D (z left out)', () => {
    const r = aimAssist({ x: 0, y: 0 }, { x: 1, y: 0 }, [{ x: 10, y: 1 }], { cone: 0.2, range: 20, strength: 1, maxTurn: 1 })!;
    expect(r.dir.z).toBe(0);
    expect(Math.atan2(r.dir.y, r.dir.x)).toBeCloseTo(Math.atan2(1, 10));
  });
});

describe('forward / yawPitch / angleDiff', () => {
  it('round-trip in three\'s first-person convention (forward −z, yaw to the right, pitch up)', () => {
    expect(forward(0, 0)).toEqual({ x: 0, y: 0, z: -1 });
    expect(forward(Math.PI / 2, 0).x).toBeCloseTo(1);
    expect(forward(0, 0.5).y).toBeCloseTo(Math.sin(0.5));
    const yp = yawPitch(forward(0.7, -0.3));
    expect(yp.yaw).toBeCloseTo(0.7);
    expect(yp.pitch).toBeCloseTo(-0.3);
    expect(angleDiff(0.1, 2 * Math.PI - 0.1)).toBeCloseTo(0.2);
  });
});
