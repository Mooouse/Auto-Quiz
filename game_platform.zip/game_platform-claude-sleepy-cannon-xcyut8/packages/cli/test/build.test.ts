// The web build: a web channel's bundle has no native plugins (Capacitor, AdMob), an Android channel's keeps them;
// the portal upload's size report (upload/size.json) and what gp forecast reads from it.

import { cpSync, mkdtempSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest';
import type { SizeReport } from '@gp/spec';
import { gameForecast } from '../src/forecast.ts';
import { checkGame } from '../src/game.ts';
import { locateGame, ROOT } from '../src/paths.ts';
import { buildPortal } from '../src/portal-build.ts';
import { sizeLines, uploadFacts } from '../src/size.ts';
import { BUILD_TARGETS, gpGame } from '../src/vite-plugin.ts';
import { buildWeb } from '../src/vite.ts';

const tmp = mkdtempSync(join(tmpdir(), 'gp-build-'));
afterAll(() => rmSync(tmp, { recursive: true, force: true }));

/** All the JS a build wrote */
function js(dir: string): string {
  const assets = join(dir, 'assets');
  return readdirSync(assets)
    .filter((f) => f.endsWith('.js'))
    .map((f) => readFileSync(join(assets, f), 'utf8'))
    .join('\n');
}
// Strings only the real packages have: @capacitor/core's bridge and @capacitor-community/admob's web plugin
const CAPACITOR = /androidBridge|CapacitorException/;

/** A copy of the code example, so its upload/ is this test's own */
function codeCopy(name: string) {
  const dir = join(tmp, name);
  cpSync(join(ROOT, 'docs/examples/code'), dir, { recursive: true, filter: (f) => !/[\\/](upload|dist|qa|node_modules|store|submission)$/.test(f) });
  return { id: name, dir, file: join(dir, 'game.yaml') };
}

describe('native plugins by channel', () => {
  it('a crazygames build has no Capacitor or AdMob code', { timeout: 60_000 }, async () => {
    const out = await buildWeb(locateGame(join(ROOT, 'docs/examples/code/game.yaml')), 'dev', false, join(tmp, 'code'), { singleFile: true });
    const code = js(out);
    expect(code).not.toMatch(CAPACITOR);
    expect(code).toContain('isNativePlatform');
  });
  it('an android-families build keeps them (the Capacitor app needs them)', { timeout: 60_000 }, async () => {
    const out = await buildWeb(locateGame('balloon-pop'), 'dev', false, join(tmp, 'kids'));
    expect(js(out)).toMatch(CAPACITOR);
  });
});

/** The platform packages a build's JS comes from (@gp/<dir>), from its sourcemaps */
function gpPackages(dir: string): Set<string> {
  const assets = join(dir, 'assets');
  const out = new Set<string>();
  for (const f of readdirSync(assets).filter((x) => x.endsWith('.js.map'))) {
    const map = JSON.parse(readFileSync(join(assets, f), 'utf8')) as { sources: string[] };
    for (const s of map.sources) {
      const m = /packages\/([^/]+)\/src\//.exec(s.split('\\').join('/'));
      if (m) out.add(`@gp/${m[1]}`);
    }
  }
  return out;
}
// Strings only the kids kit has (its default texts, packages/kit-kids/src/index.meta.ts)
const KIDS_KIT = /For parents|Purchase restored/;

describe('only the game’s own kit is bundled', () => {
  // Casual builds carried 13 KB of @gp/kit-kids (backlog item 4): the player's kit table imported both kits
  it('a casual game’s upload has no kids kit', { timeout: 60_000 }, async () => {
    const out = await buildWeb(locateGame(join(ROOT, 'docs/examples/casual.game.yaml')), 'dev', false, join(tmp, 'casual'), { singleFile: true });
    const pkgs = gpPackages(out);
    expect(pkgs).toContain('@gp/kit-casual');
    expect(pkgs).not.toContain('@gp/kit-kids');
    expect(js(out)).not.toMatch(KIDS_KIT);
  });
  it('a code game’s upload has neither block kit', { timeout: 60_000 }, async () => {
    const out = await buildWeb(locateGame(join(ROOT, 'docs/examples/code/game.yaml')), 'dev', false, join(tmp, 'code-kits'), { singleFile: true });
    const pkgs = gpPackages(out);
    for (const p of ['@gp/kit-kids', '@gp/kit-casual', '@gp/blocks']) expect(pkgs).not.toContain(p);
    expect(js(out)).not.toMatch(KIDS_KIT);
  });
  it('a kids game keeps the kids kit and has no casual kit', { timeout: 60_000 }, async () => {
    const out = await buildWeb(locateGame('balloon-pop'), 'dev', false, join(tmp, 'kids-kits'), { singleFile: true });
    const pkgs = gpPackages(out);
    expect(pkgs).toContain('@gp/kit-kids');
    expect(pkgs).not.toContain('@gp/kit-casual');
    expect(js(out)).toMatch(KIDS_KIT);
  });
});

describe('the browsers a build is for', () => {
  it('web: the first versions with top-level await; android: es2020', () => {
    const target = (yaml: string) => {
      const plugin = gpGame(locateGame(yaml), 'dev');
      return ((plugin.config as () => { build: { target: unknown } })()).build.target;
    };
    expect(target(join(ROOT, 'docs/examples/code/game.yaml'))).toEqual(['chrome89', 'edge89', 'firefox89', 'safari15']);
    expect(target(join(ROOT, 'docs/examples/casual.game.yaml'))).toEqual([...BUILD_TARGETS.web]);
    expect(target(join(ROOT, 'docs/examples/kids/game.yaml'))).toBe('es2020');
  });

  // A WebAssembly package imported as a module (Rapier) compiles to a top-level `await initWasm(…)`: with es2020 the
  // bundler kept it and warned "Top-level await is not available in the configured target environment" (backlog item 4)
  it('a portal game whose module awaits at the top level builds without the warning, the await kept', { timeout: 60_000 }, async () => {
    const loc = codeCopy('code-tla');
    writeFileSync(join(loc.dir, 'tla.ts'), '(globalThis as { __tla?: number }).__tla = await Promise.resolve(42);\n');
    writeFileSync(join(loc.dir, 'main.ts'), `import './tla.ts';\n${readFileSync(join(loc.dir, 'main.ts'), 'utf8')}`);
    const warnings: string[] = [];
    const spy = vi.spyOn(console, 'warn').mockImplementation((...a: unknown[]) => void warnings.push(a.map(String).join(' ')));
    try {
      const out = await buildWeb(loc, 'dev', false, join(tmp, 'code-tla-out'), { singleFile: true });
      expect(js(out)).toMatch(/await Promise\.resolve\(42\)/);
    } finally {
      spy.mockRestore();
    }
    expect(warnings.join('\n')).not.toMatch(/top-level await/i);
  });
});

describe('the size and load budget of a portal upload', () => {
  // vitest sets NODE_ENV=test, which Vite would take over the production mode (a dev bundle with the stubs): as in gp
  const env = process.env.NODE_ENV;
  beforeAll(() => {
    delete process.env.NODE_ENV;
  });
  afterAll(() => {
    process.env.NODE_ENV = env;
  });
  it('buildPortal writes upload/size.json: raw, gzipped, by package from the sourcemap, the load estimate; gp forecast reads it', { timeout: 60_000 }, async () => {
    const loc = codeCopy('code-budget');
    const r = checkGame(loc, 'dev');
    const pkg = await buildPortal(loc, r.game!);
    expect(pkg.problems).toEqual([]);
    const size = JSON.parse(readFileSync(join(loc.dir, 'upload/size.json'), 'utf8')) as SizeReport;
    expect(size.rawBytes).toBe(statSync(join(loc.dir, 'upload/index.html')).size);
    expect(size.gzipBytes).toBeLessThan(size.rawBytes);
    const names = size.packages.map((p) => p.name);
    expect(names).toEqual(expect.arrayContaining(['@gp/core', 'game']));
    expect(names.some((n) => n.startsWith('@capacitor'))).toBe(false);
    expect(size.packages.reduce((a, p) => a + p.bytes, 0)).toBe(size.rawBytes);
    expect(size.load.tappableMs).toBeGreaterThan(150);
    expect(size.load.tappableMs).toBeLessThan(1000);
    expect(size.budget).toMatchObject({ gzipKB: 400, warnLoadSec: 3, hardMB: 20 });
    expect(size.over).toEqual([]);
    // The upload is index.html alone: the sourcemap stays out of it
    expect(readFileSync(join(loc.dir, 'upload/index.html'), 'utf8')).not.toContain('sourceMappingURL');
    const lines = sizeLines(size).join('\n');
    expect(lines).toMatch(/KB raw, [\d.]+ KB gzipped — budget 400 KB gzipped/);
    expect(lines).toMatch(/≈ 0\.\d s to a tappable Play on a slow phone \(1\.6 Mbps, 150 ms RTT, 4× CPU/);
    expect(lines).toContain('@gp/core');

    // The same game with the numbers of the engine lab's 3.4 MB upload (7.9 s to Play) forecasts less
    const small = await gameForecast(loc, r.game!, r.issues, { balance: false });
    expect(small.design.loadSec).toBeCloseTo(size.load.tappableMs / 1000, 5);
    expect(small.design.from.upload).toContain('size.json');
    writeFileSync(join(loc.dir, 'upload/index.html'), 'x'.repeat(3_448_791));
    writeFileSync(join(loc.dir, 'upload/size.json'), JSON.stringify({ ...size, rawBytes: 3_448_791, gzipBytes: 1_297_567, load: { ...size.load, tappableMs: 7883 } }));
    const big = await gameForecast(loc, r.game!, r.issues, { balance: false });
    expect(big.design.loadSec).toBeCloseTo(7.883, 5);
    expect(big.forecast.pFullLaunch.mid).toBeLessThan(small.forecast.pFullLaunch.mid);
    expect(big.forecast.expected.mid).toBeLessThan(small.forecast.expected.mid);
    // A stale size.json (another upload) is not read: the numbers come from the file itself
    writeFileSync(join(loc.dir, 'upload/index.html'), 'y'.repeat(1000));
    expect(uploadFacts(loc)!.mb).toBeCloseTo(1000 / 1048576, 8);
  });

  it('over the budget: a warning, the upload still written', { timeout: 60_000 }, async () => {
    const loc = codeCopy('code-tight');
    const r = checkGame(loc, 'dev');
    const pkg = await buildPortal(loc, { ...r.game!, budget: { gzipKB: 1, warnLoadSec: 0.1, hardMB: 20, from: 'game.yaml budget.gzipKB' } });
    expect(pkg.problems).toEqual([]);
    expect(pkg.size.over).toHaveLength(2);
    expect(sizeLines(pkg.size).join('\n')).toContain('⚠ over budget');
    expect(statSync(join(loc.dir, 'upload/index.html')).size).toBe(pkg.bytes);
  });
});

describe('the iDos Games upload', () => {
  const env = process.env.NODE_ENV;
  beforeAll(() => {
    delete process.env.NODE_ENV;
  });
  afterAll(() => {
    process.env.NODE_ENV = env;
  });
  it('a portal game without any portal SDK, one index.html in upload-idos/ and its zip', { timeout: 60_000 }, async () => {
    const loc = codeCopy('code-idos');
    const r = checkGame(loc, 'dev');
    const pkg = await buildPortal(loc, r.game!, 'dev', 'idos');
    expect(pkg.problems).toEqual([]);
    expect(pkg.dir).toBe(join(loc.dir, 'upload-idos'));
    const html = readFileSync(join(pkg.dir, 'index.html'), 'utf8');
    // The resolved game as built: no portal (its adapters stay in the bundle, unused)
    expect(html).toMatch(/\bportal:null\b/);
    expect(html).not.toMatch(/\bportal:[`"']/);
    const zip = readFileSync(join(pkg.dir, `${r.game!.id}-idos.zip`));
    // A stored ZIP: its one entry is index.html at the root
    expect(zip.subarray(0, 4).toString('hex')).toBe('504b0304');
    expect(zip.toString('latin1')).toContain('index.html');
    expect(zip.toString('latin1')).not.toContain('/index.html');
  });
});
