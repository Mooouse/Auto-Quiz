// Titles players recognise (docs/guides/naming.md): a hook of the genre + a word of the game's own
import { describe, expect, it } from 'vitest';
import { hooksFor, scoreTitle, suggestTitles } from '../src/naming.ts';

describe('scoreTitle', () => {
  it('rewards a genre hook with a word of its own (Spin Brawl had 7× the plays of the hookless titles)', () => {
    const s = scoreTitle('Spin Brawl', 'io');
    expect(s.hooks.map((h) => h.word)).toEqual(['brawl']);
    expect(s.score).toBe(100);
  });
  it('flags a title with no hook, a hook of another genre, and a one-word coined compound', () => {
    expect(scoreTitle('Dread Throne', 'strategy').issues[0]).toMatch(/no word a strategy player knows/);
    expect(scoreTitle('Nimbus Drift', 'puzzle').issues[0]).toMatch(/promises another game/);
    const one = scoreTitle('Starsilk', 'puzzle');
    expect(one.score).toBeLessThan(50);
    expect(one.issues.join(' ')).toMatch(/coined word/);
  });
  it('a hook alone is a category, not a name', () => {
    expect(scoreTitle('Tower Defense', 'strategy').issues.join(' ')).toMatch(/no word of its own/);
  });
  it('reads ".io" as the io hook', () => {
    expect(scoreTitle('Spinner.io', 'io').hooks[0].word).toBe('io');
  });
});

describe('suggestTitles', () => {
  it('pairs the own words with the genre hooks and keeps a live name with a subtitle', () => {
    const t = suggestTitles('strategy', ['throne'], { base: 'Dread Throne', n: 20 }).map((x) => x.title);
    expect(t).toContain('Dread Throne: Tower Defense');
    expect(t).toContain('Throne Clash');
    expect(t.every((x) => x.length <= 35)).toBe(true);
  });
  it('a sub-genre gets its own hooks and phrases first: a deckbuilder "deck", "card", not "defense"', () => {
    expect(hooksFor('strategy', 'deckbuilder').slice(0, 3).map((k) => k.word)).toEqual(['deck', 'deckbuilder', 'card']);
    expect(hooksFor('strategy')[0].word).not.toBe('deck');
    expect(scoreTitle('Velvet Domino', 'strategy', 'deckbuilder').issues[0]).toMatch(/no word a deckbuilder player knows: add a hook \(deck/);
    const t = suggestTitles('strategy', ['domino'], { base: 'Velvet Domino', sub: 'deckbuilder', n: 20 }).map((x) => x.title);
    expect(t).toContain('Velvet Domino: Deckbuilder');
    expect(t).toContain('Domino Deck');
    expect(t).not.toContain('Velvet Domino: Tower Defense');
  });
  it('skips what avoid() rejects', () => {
    expect(suggestTitles('puzzle', ['moth'], { avoid: (x) => /Blast/.test(x) }).some((x) => /Blast/.test(x.title))).toBe(false);
  });
});
