// Rivals: named NPC characters with a seeded behaviour — the honest stand-in for other players in a single-player web
// game (a raccoon who counts her shelf at dawn, a fisherman who always beats your daily by a little: docs/research/
// roblox-2026-10.md §3). They are characters, drawn as characters and labelled as rivals: never a username, never "a
// player", never a count of people online. Every rival this block hands out carries `npc: true` and `kind: 'rival'`,
// and a name that reads as a character's (no digits, underscores or @: 'xX_Pro99' would pass for a real player — the
// block refuses it).
//
//   const RIVALS = rivals({
//     salt: 'raccoon-rummage',
//     cast: [{ id: 'maple', name: 'Maple', skill: 0.7 }, { id: 'bram', name: 'Old Bram', skill: 0.45 }],
//     behave: (r, rng) => ({ wakes: 4 + rng.int(4), traps: rng() < r.skill }),   // today's routine, the same for everyone
//   });
//   RIVALS.get('maple').behaviour;            // { wakes: 6, traps: true } — changes each UTC day (or each clock slot)
//   RIVALS.score('maple', [200, 600]);        // Maple's score on today's daily: seeded, the same on every machine
//   RIVALS.board({ score: 412 }, [200, 600]); // you among the rivals, best first: [{ id: 'maple', name, score, npc: true }, { you: true, … }]
//   host.t('gp.rival')                        // "Rival": the label next to each name on screen
//
// The scores and routines are a function of the day (or the clock's slot) and the salt: a rival is the same opponent
// for every player today. Show it so ("Maple's best today"), not as a leaderboard of people.

import { dayKey, daySeed } from './daily.ts';
import { durationMs, type Duration, type WorldClock } from './clock.ts';
import { seededRng, type SeededRng } from './rng.ts';

export interface RivalDef<P = unknown> {
  id: string;
  /** A character's name (letters, spaces, apostrophes, hyphens; 2–24 characters) */
  name: string;
  /** How good they are, 0 … 1: where their scores fall in a range */
  skill: number;
  /** The game's own data (a portrait id, a colour, a taunt list) */
  traits?: P;
}

export interface RivalsOptions<P = unknown, B = undefined> {
  /** The game's id: two games' rivals differ */
  salt: string;
  cast: readonly RivalDef<P>[];
  /** A rival's behaviour for a period (a routine, a mood, a target), from the period's own rng */
  behave?: (rival: RivalDef<P>, rng: SeededRng, period: { key: string }) => B;
  /** Periods are the clock's slots (of `every`, default its own) instead of UTC days */
  clock?: WorldClock;
  every?: Duration;
  /** How much a rival's score varies around their skill, 0 … 1 (default 0.25) */
  spread?: number;
  /** The clock in ms for UTC days (default Date.now; ignored with `clock`) */
  now?: () => number;
}

/** A rival as the game shows it: always marked as a character */
export interface Rival<P = unknown, B = undefined> {
  id: string;
  name: string;
  skill: number;
  traits: P | undefined;
  behaviour: B;
  /** Never a real player */
  npc: true;
  kind: 'rival';
}

export interface BoardEntry {
  id: string;
  name: string;
  score: number;
  /** A rival (an NPC character) — label it so on screen */
  npc: boolean;
  /** The player */
  you: boolean;
}

export interface Rivals<P = unknown, B = undefined> {
  /** The period key behaviours and scores are for (a day 'YYYY-MM-DD', or a clock slot's key) */
  period(at?: number): string;
  list(at?: number): Rival<P, B>[];
  get(id: string, at?: number): Rival<P, B>;
  /** The rival's score in [min, max] for the period (or a given key: a day's daily): seeded, the same for every player */
  score(id: string, range: readonly [number, number], opts?: { key?: string; better?: 'high' | 'low'; round?: boolean }): number;
  /** The player among the rivals, best first (ties: the player first) */
  board(you: { score: number; name?: string }, range: readonly [number, number], opts?: { key?: string; better?: 'high' | 'low'; ids?: readonly string[] }): BoardEntry[];
}

const NAME = /^\p{L}[\p{L}\p{M} '’.-]{1,23}$/u;

/** A rival name's problem (null: fine): it must read as a character's, never as a username or a real player */
export function rivalNameProblem(name: string): string | null {
  if (!NAME.test(name.trim())) return `'${name}': a rival is a character — letters, spaces, apostrophes or hyphens, 2–24 characters; no digits, underscores or @ (that reads as a real player's username)`;
  if (/\b(player|user|guest|admin|online)\b/i.test(name)) return `'${name}': don't name a rival as a player ("Player", "Guest", "Admin")`;
  return null;
}

/** The rivals of a game: see the module's comment */
export function rivals<P = unknown, B = undefined>(opts: RivalsOptions<P, B>): Rivals<P, B> {
  if (!opts.salt) throw new Error('rivals: salt (the game id) is required');
  if (!opts.cast.length) throw new Error('rivals: no rival in the cast');
  const ids = new Set<string>();
  for (const r of opts.cast) {
    if (!r.id || ids.has(r.id)) throw new Error(`rivals: ${r.id ? `the id '${r.id}' twice` : 'a rival without an id'}`);
    ids.add(r.id);
    const p = rivalNameProblem(r.name);
    if (p) throw new Error(`rivals: ${p}`);
    if (!(r.skill >= 0 && r.skill <= 1)) throw new Error(`rivals: ${r.id}'s skill is 0 … 1`);
  }
  const spread = Number.isFinite(opts.spread) ? Math.max(0, Math.min(1, opts.spread as number)) : 0.25;
  const every = opts.clock ? (opts.every === undefined ? opts.clock.everyMs : durationMs(opts.every)) : 0;
  const period = (at?: number): string => {
    if (opts.clock) return opts.clock.slot(every / 1000, at ?? opts.clock.now()).key;
    return dayKey(new Date(at ?? (opts.now ?? Date.now)()));
  };
  const rngOf = (id: string, key: string, what: string) => seededRng(daySeed(key, `${opts.salt}:rival:${id}:${what}`));
  const def = (id: string) => {
    const r = opts.cast.find((x) => x.id === id);
    if (!r) throw new Error(`rivals: no rival '${id}'`);
    return r;
  };
  const make = (r: RivalDef<P>, key: string): Rival<P, B> => ({
    id: r.id,
    name: r.name,
    skill: r.skill,
    traits: r.traits,
    behaviour: (opts.behave ? opts.behave(r, rngOf(r.id, key, 'behave'), { key }) : undefined) as B,
    npc: true,
    kind: 'rival',
  });
  const score: Rivals<P, B>['score'] = (id, [min, max], o = {}) => {
    const r = def(id);
    const key = o.key ?? period();
    const x = Math.max(0, Math.min(1, r.skill + (rngOf(id, key, 'score')() - 0.5) * 2 * spread));
    const v = o.better === 'low' ? max - (max - min) * x : min + (max - min) * x;
    return o.round === false ? v : Math.round(v);
  };
  return {
    period,
    list: (at) => opts.cast.map((r) => make(r, period(at))),
    get: (id, at) => make(def(id), period(at)),
    score,
    board(you, range, o = {}) {
      const low = o.better === 'low';
      const cast = o.ids ? opts.cast.filter((r) => o.ids!.includes(r.id)) : opts.cast;
      const rows: BoardEntry[] = cast.map((r) => ({ id: r.id, name: r.name, score: score(r.id, range, o), npc: true, you: false }));
      rows.push({ id: 'you', name: you.name ?? '', score: you.score, npc: false, you: true });
      return rows.sort((a, b) => (low ? a.score - b.score : b.score - a.score) || Number(b.you) - Number(a.you));
    },
  };
}
