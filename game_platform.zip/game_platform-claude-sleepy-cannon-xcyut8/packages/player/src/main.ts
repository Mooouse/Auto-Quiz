// Entry point: the game resolved from game.yaml on <canvas id="game">.

import game from 'virtual:gp/game';
import { boot } from './boot.ts';

const canvas = document.getElementById('game') as HTMLCanvasElement | null;
if (!canvas) throw new Error('No <canvas id="game">');
void boot(canvas, game);
