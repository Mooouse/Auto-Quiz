// The page's sound for `gp video --sound` lives in @gp/qa (packages/qa/src/audio-tap.ts), beside the meter `gp qa`'s sound
// section listens with: one interception of the page's AudioContext for both.
export { audioTap, audioMeter, runAudio, takeAudio, takeMeter, connectMeter, fadeOut, type MeterTake } from '@gp/qa/audio-tap';
