// The genres: what each one's players expect, and which runtime blocks fit it. One registry, keyed by the money
// genres (money.ts GENRES: the ids with CrazyGames benchmarks) and their sub-genres (money.ts SUBGENRES: roguelite →
// action, clicker → idle …). game.yaml says the genre once, in `money.genre`. `gp catalog genres`, `gp catalog blocks
// --genre <g>`, `gp explain genre.<g>`, docs/guides/genres.md and two `gp validate` checks read it:
// - I_GENRE_EXPECTS (a hint): a code game's genre has must-haves its code doesn't seem to have;
// - W_GENRE_BLOCK: a code game imports a block that only makes sense in another genre (offline earnings in an action game)
//   — unless money.hybrid declares a second layer of that genre (an idle base under an action raid: hybrid: [idle]);
// - W_LOOT_ODDS: a code game rolls a LootTable and its code never reads the odds to show them.
// Pure data and string functions: Node reads it, the names are the runtime's exports (never imported from here).

import type { Issue } from './errors.ts';
import { GENRES, MONEY_TABLE, SUBGENRES, genreOf, moneyGenre, type Genre, type MoneyInput, type ReturnKind, type RewardedKind, type SubGenre } from './money.ts';

/** A runtime block a genre uses: its export name, the module it comes from, what it gives the player */
export interface GenreBlock {
  name: string;
  from: string;
  what: string;
  /** Only these genres: anywhere else it is a sign of the wrong genre or the wrong block (W_GENRE_BLOCK) */
  only?: readonly Genre[];
}

/** Something a genre's players expect to find (a must-have), and how `gp validate` sees it in a code game */
export interface Expectation {
  id: string;
  /** What the player expects, in their words */
  what: string;
  /** Imported from @gp/*, any of these counts */
  blocks: readonly string[];
  /** The game's own code for it (identifiers or words in the source, comments stripped) */
  signs?: RegExp;
  /** The money design has it: a rewarded offer of one of these kinds, or a reason to return of one of these kinds */
  rewarded?: readonly RewardedKind[];
  returns?: readonly ReturnKind[];
  /** Not in the first version: after the first session (a prestige layer) — the hint says so */
  later?: string;
}

export interface GenreInfo {
  id: Genre;
  name: string;
  /** What players come to this genre on CrazyGames for, one sentence */
  players: string;
  expects: readonly Expectation[];
  /** The blocks that fit (names in GENRE_BLOCKS), the general ones (GENERAL_BLOCKS) come on top */
  blocks: readonly string[];
  /** The money rows it is benchmarked with (MONEY_TABLE ids) */
  money: { minutes: string; d1: string; breakEvery: string };
  /** Where the platform's docs say more */
  guide: string;
}

export interface SubGenreInfo {
  id: SubGenre;
  name: string;
  genre: Genre;
  /** listing.tags that name it (a game with money.genre: action and the tag Roguelike is a roguelite) */
  tags: RegExp;
  players: string;
  /** On top of its genre's */
  expects: readonly Expectation[];
  /** The genre's must-haves that don't apply to it (a deckbuilder has no stages with stars) */
  drops?: readonly string[];
  blocks: readonly string[];
}

// --- The blocks ---------------------------------------------------------------------------------------------------

const B = (name: string, from: string, what: string, only?: readonly Genre[]): GenreBlock => ({ name, from, what, ...(only ? { only } : {}) });

/** Every block the genres name. The idle-only ones are the genre system's reason to exist: they must not be offered to every game */
export const GENRE_BLOCKS: Record<string, GenreBlock> = Object.fromEntries(
  [
    // Progression shapes (docs/guides/upgrades.md)
    B('UpgradeShop', '@gp/core', 'a level shop: "+stat" levels bought with a currency, ×1/×10/Max, milestones'),
    B('mountUpgradeShop', '@gp/core', 'the ready level-shop screen for an UpgradeShop'),
    B('formatAmount', '@gp/core', 'big numbers that read (1.2K, 3.4M, 5.6e15)'),
    B('Roster', '@gp/core', 'unlocks that play differently: heroes, weapons, cars, one in play'),
    B('Tiers', '@gp/core', 'tiers: buying in one opens the next set'),
    B('PactTree', '@gp/core', 'gains with a cost on paths, Oaths, forks'),
    B('RunChoices', '@gp/core', 'pick 1 of N in a run (a level-up, a floor): weights, stacks, a reroll'),
    // Levels and puzzles
    B('levelOpen', '@gp/core', 'levels opened in order'),
    B('firstOpenLevel', '@gp/core', 'the level a returning player continues from'),
    B('loadStars', '@gp/core', 'the stars saved per level'),
    B('recordStars', '@gp/core', '1–3 stars a level, the best kept'),
    B('starsFromPar', '@gp/core', 'stars from a par (moves, time)'),
    B('UndoHistory', '@gp/core', 'undo moves (and restart) in a puzzle'),
    // The table: cards, bags, boards, dice and a rival (docs/guides/table-blocks.md) — for card, bag, tile, dice and backpack games
    B('Zones', '@gp/core', 'cards and tokens in piles: deck, hand, discard, a blind bag with counts, a market row, a bust rule and its odds'),
    B('Board', '@gp/core', 'square and hex grids: pieces that turn, legal placements, matching edges, regions, patterns, a backpack grid'),
    B('Dice', '@gp/core', 'a seeded dice pool: rerolls, forged faces, slots with rules, the odds for a hint'),
    B('Automa', '@gp/core', 'a rival run by priority rules: its next move shown in ≤ 6 words, levels, seeded'),
    // Seeds and the daily
    B('newRunSeed', '@gp/core/seed', 'a run seed for a roguelite run'),
    B('runSeedFrom', '@gp/core/seed', 'a run seed typed back by the player'),
    B('seedField', '@gp/core/seed', 'the seed on screen: see, copy, share, type back'),
    B('dailyRunSeed', '@gp/core/seed', 'the same seeded run for everyone today'),
    B('daySeed', '@gp/core', 'a day\'s seed (a daily level, a daily order)'),
    B('recordDaily', '@gp/core', 'a calendar of solved days (never a punishing streak)'),
    // Idle only (being added: offline earnings, prestige, several sites with a map)
    B('offlineEarnings', '@gp/core', 'what the game earned while the player was away, shown on return (×2 for an ad)', ['idle']),
    B('Prestige', '@gp/core', 'a reset for a permanent multiplier, after the first session', ['idle']),
    B('Sites', '@gp/core', 'several places (sites) that earn in parallel, each with its own upgrades', ['idle']),
    B('mountSitesMap', '@gp/core', 'the map of the sites: open the next one, switch between them', ['idle']),
    // The live world (docs/guides/live-world.md): a shared clock, a restock shop, loot with visible odds, variants, the daily table, share codes and rivals
    B('worldClock', '@gp/core/clock', 'shared time slots, scheduled events, festival hours and weather: the same for every player at the same moment'),
    B('restockShop', '@gp/core/restock', 'a stock that rotates every few minutes for everyone, rarity weights, a pity, a rewarded "restock now"'),
    B('mountRestockTimer', '@gp/core', 'the "New stock in 3:12" countdown'),
    B('LootTable', '@gp/core/loot', 'rarity rolls with the odds on screen, a pity, a lucky floor (never sold, never a rewarded spin)'),
    B('variants', '@gp/core/variants', 'mutations by the world\'s conditions (the weather), combos and multipliers on one item'),
    B('dailyTable', '@gp/core/daily-table', 'a different setup each day for everyone, named score bands, "12 points from Gold", a share card'),
    B('shareCode', '@gp/core/share', 'a run, a build or a base as a short code a friend types back: a visit, a ghost, a raid on a copy'),
    B('rivals', '@gp/core/rivals', 'named NPC rivals with a seeded routine and scores, labelled as characters, never as players'),
    // Every genre: the first minute, the results, the return (docs/guides/first-minute.md)
    B('hints', '@gp/core', 'one short hint at a time: show the rule, don\'t write it'),
    B('mountResults', '@gp/core', 'the results screen whose big button is the next run, with the next goal'),
    B('welcomeBack', '@gp/core', 'a welcome back on a new day'),
    B('recordVisit', '@gp/core', 'visits per day: the return the welcome and the daily read'),
    B('dailyStreak', '@gp/core', 'a streak of days played that never takes anything away'),
    B('dailyOrder', '@gp/core', 'a daily order: one goal for today'),
    B('mountStreakCard', '@gp/core', 'the card on the title that shows the daily and the streak'),
    // The game as a service between runs (Frankengun): a season, a weekly event — for action, roguelites and idle games
    B('seasonPass', '@gp/core', 'a season pass: dated tiers climbed with XP, a big reward every few tiers, nothing lost when it ends'),
    B('mountSeasonTrack', '@gp/core', 'the season screen: its tiers a page at a time, claim, the days left'),
    B('weeklyEvent', '@gp/core', 'a weekly event: one rule for every player this week, its prize once'),
    B('rewardedButton', '@gp/core', 'a rewarded offer done right: says what it gives, hides without an ad'),
    B('rewardedOffer', '@gp/core', 'a rewarded offer with its own same-size "No thanks": both disabled under the ad, a late reward ignored'),
    // Goals, teaching, the collection, the daily hub, the title's cards (Craft Pickaxe, Garage, Velvet, Frankengun)
    B('dailyQuests', '@gp/core', 'daily quests: a few goals a day from a pool, each claimed, a bonus for all; what was earned is kept'),
    B('achievements', '@gp/core', 'achievements: permanent goals with rarities and secret ones, earned once'),
    B('mountGoals', '@gp/core', 'the goals screen: the day\'s quests and the achievements, a page at a time'),
    B('goalBanners', '@gp/core', 'unlock banners one at a time, held while a panel is open'),
    B('coachHand', '@gp/core', 'a ghost hand that shows the gesture (tap, swipe, drag, hold): with a hint or alone'),
    B('inspect', '@gp/core', 'inspect plates: hover or hold a thing to read what it does, without picking it'),
    B('collection', '@gp/core', 'a collection: found or a silhouette, rarities, new marks, a permanent bonus per entry'),
    B('mountAlbum', '@gp/core', 'the album: a collection\'s pages per group, rows labelled'),
    B('playtimeGifts', '@gp/core', 'gifts for the minutes played (today\'s, kept across sessions)'),
    B('luckyWheel', '@gp/core', 'a lucky wheel: a free spin a day, then one for an ad; the prize saved at the spin'),
    B('dailyOffers', '@gp/core', 'the day\'s offers in the shop, the first free; currency for an ad'),
    B('timedBoost', '@gp/core', 'a timed ×2 that never multiplies the offline earnings'),
    B('mountRewardsHub', '@gp/core', 'the rewards screen: gifts, the wheel, the day\'s offers'),
    B('cards', '@gp/core', 'one card at a time on the title: welcome back, the week, the season, story, goals'),
    // Story, input, physics, the look
    B('StoryRunner', '@gp/core', 'chapters unlocked by progress (docs/guides/story.md)'),
    B('MoveInput', '@gp/core', 'keyboard, drag and a visible touch stick in one'),
    // Shooters and action (Frankengun, Candle Crypt, Swarm Smash): aim, look, enemies, bosses, the announcer, threat cues
    B('TwinStick', '@gp/core', 'top-down aim and fire: the mouse from the hero, the arrows fire; on touch a move stick and an aim stick (no drag: auto-aim)'),
    B('LookInput', '@gp/core', 'first-person look: pointer lock with "Click to aim", the lock lost pauses, drag to look; on touch a look half and Fire'),
    B('aimAssist', '@gp/core', 'a soft pull to the target nearest the crosshair (with a line of sight), and onTarget for auto-fire on touch'),
    B('steer', '@gp/core', 'enemy steering without a library: seek, arrive, pursuit with a lead, separation, avoidance, slots round the player, flanks'),
    B('BossPatterns', '@gp/core', 'a boss as a pattern machine: phases at health thresholds, telegraphed attacks never twice in a row; fan, ring, spiral, aimed and wave bullets'),
    B('callouts', '@gp/core', 'an announcer that takes turns: ranks, cooldowns, stale lines dropped, a streak keeps its latest step, the music ducks'),
    B('QualityLadder', '@gp/core', 'quality levels for a WebGL game: a start by device, judged on the frame interval, a render scale on the engine'),
    B('HitArcs', '@gp/art/hud', 'red arcs round the crosshair toward what hit you (behind: at the bottom)'),
    B('DamageNumbers', '@gp/art/hud', 'pooled damage numbers that merge per area or target; crits or big hits only'),
    B('edgeArrow', '@gp/art/hud', 'an arrow on the screen\'s edge toward a boss the camera lost'),
    B('physicsAfterInit', '@gp/physics', 'Rapier 2D on the game\'s fixed step (stacking, piles, joints)'),
    B('Camera', '@gp/art/camera', 'a camera with shake, follow and zoom: hits that feel'),
    B('Fx', '@gp/art/fx', 'pooled effects: sparks, smoke, numbers'),
    // Sound and juice (docs/guides/code-games.md → Effects, Juice)
    B('createSfx', '@gp/core/sound', 'effects from files or recipes: pitch variation, a throttle, pan, voice lines, a limiter'),
    B('ScoreSequencer', '@gp/core', 'a score played beat by beat: quickening beats, count-up, labels, a land, a preview before the move'),
    B('readout', '@gp/art/hud', 'a number on the HUD that reads at a glance'),
    // Every genre: the platform's screens in the game's look, drawn icons, game type (not the system's)
    B('screenTheme', '@gp/core', 'one call that dresses every platform screen (results, shop, streak, season …) in the game\'s panel, accent and font'),
    B('icon', '@gp/core/icons', 'drawn icons on one 24 grid for DOM screens and the canvas: never emoji or glyphs'),
    B('useFont', '@gp/art/type', 'a bundled game face (Latin + Cyrillic) or the pixel font instead of the system\'s; outlined HUD numbers'),
  ].map((b) => [b.name, b]),
);

/** Blocks every genre uses: the first minute, the results, the return */
export const GENERAL_BLOCKS: readonly string[] = [
  'hints',
  'coachHand',
  'mountResults',
  'welcomeBack',
  'recordVisit',
  'dailyStreak',
  'dailyOrder',
  'mountStreakCard',
  'cards',
  'dailyQuests',
  'achievements',
  'mountGoals',
  'goalBanners',
  'collection',
  'mountAlbum',
  'inspect',
  'playtimeGifts',
  'luckyWheel',
  'dailyOffers',
  'timedBoost',
  'mountRewardsHub',
  'rewardedOffer',
  'rewardedButton',
  'Fx',
  'screenTheme',
  'icon',
  'useFont',
  'createSfx',
  'ScoreSequencer',
];

// --- The genres ---------------------------------------------------------------------------------------------------

const rows = (g: Genre) => ({ minutes: `genre.${g}.minutes`, d1: `genre.${g}.d1`, breakEvery: `genre.${g}.breakEvery` });

const META: Expectation = {
  id: 'meta',
  what: 'meta progression between runs, in the genre\'s shape: unlocks that play differently, tiers, pacts',
  blocks: ['Roster', 'Tiers', 'PactTree', 'UpgradeShop'],
  signs: /\b(unlock|upgrade)s?\b/i,
};

export const GENRE_INFO: Record<Genre, GenreInfo> = {
  puzzle: {
    id: 'puzzle',
    name: 'Puzzle',
    players: 'a clear rule and levels that get harder, solved at their own pace — the longest sessions on CrazyGames',
    expects: [
      { id: 'levels', what: 'levels opened in order, a level select to come back to', blocks: ['levelOpen', 'firstOpenLevel'], signs: /\blevel ?select|LEVELS\b/ },
      { id: 'stars', what: '1–3 stars for solving a level well (a par)', blocks: ['recordStars', 'starsFromPar', 'loadStars'], signs: /\bstars\b/i },
      { id: 'undo', what: 'undo and restart a level without penalty', blocks: ['UndoHistory'], signs: /\bundo\b/i },
      { id: 'hint', what: 'a hint when stuck (a rewarded "Stuck?" panel)', blocks: [], rewarded: ['hint'], signs: /\bstuck\b|\bsolveHint|\bshowHint/i },
    ],
    blocks: ['levelOpen', 'firstOpenLevel', 'loadStars', 'recordStars', 'starsFromPar', 'UndoHistory', 'Tiers', 'daySeed', 'recordDaily', 'physicsAfterInit', 'StoryRunner', 'dailyTable', 'shareCode', 'Board', 'Dice'],
    money: rows('puzzle'),
    guide: 'docs/guides/upgrades.md#1-pick-a-shape (levels and stars), docs/guides/code-games.md',
  },
  idle: {
    id: 'idle',
    name: 'Idle / incremental',
    players: 'a number that keeps growing, a purchase every minute, and something earned while away',
    expects: [
      { id: 'growth', what: 'a number that keeps growing: a currency in big, readable numbers', blocks: ['formatAmount', 'UpgradeShop'], signs: /\b(perSec|perSecond|income)\b/i },
      { id: 'shop', what: 'a level shop: dozens of levels, ×10 / Max, milestones', blocks: ['UpgradeShop', 'mountUpgradeShop'] },
      { id: 'offline', what: 'offline earnings: what it made while the player was away, ×2 for an ad', blocks: ['offlineEarnings'], signs: /\boffline/i },
      { id: 'prestige', what: 'prestige: a reset for a permanent multiplier', blocks: ['Prestige'], signs: /\b(prestige|rebirth|ascend|ascension)\b/i, later: 'after the first session' },
    ],
    blocks: ['UpgradeShop', 'mountUpgradeShop', 'formatAmount', 'offlineEarnings', 'Prestige', 'Sites', 'mountSitesMap', 'Tiers', 'readout', 'StoryRunner', 'seasonPass', 'mountSeasonTrack', 'weeklyEvent', 'worldClock', 'restockShop', 'mountRestockTimer', 'LootTable', 'variants'],
    money: rows('idle'),
    guide: 'docs/guides/upgrades.md#4-the-math-of-a-level-shop',
  },
  action: {
    id: 'action',
    name: 'Action',
    players: 'a hook in seconds, runs that escalate to a peak, and a meta that makes the next run different — the best D1 on CrazyGames',
    expects: [META, { id: 'peak', what: 'a peak every few minutes: a boss or a wave with a new rule', blocks: ['BossPatterns'], signs: /\b(boss|elite|wave)\w*/i }, { id: 'revive', what: 'a second chance: a revive or a continue (once a session)', blocks: [], rewarded: ['revive', 'continue'], signs: /\b(revive|continue)\b/i }],
    blocks: ['Roster', 'Tiers', 'PactTree', 'RunChoices', 'UpgradeShop', 'MoveInput', 'Camera', 'physicsAfterInit', 'StoryRunner', 'seasonPass', 'mountSeasonTrack', 'weeklyEvent', 'LootTable', 'worldClock', 'TwinStick', 'LookInput', 'aimAssist', 'steer', 'BossPatterns', 'callouts', 'HitArcs', 'DamageNumbers', 'edgeArrow', 'QualityLadder'],
    money: rows('action'),
    guide: 'docs/guides/upgrades.md#1-pick-a-shape',
  },
  shooting: {
    id: 'shooting',
    name: 'Shooting',
    players: 'weapons that feel different, enemies in waves, hits that land',
    expects: [
      { id: 'weapons', what: 'weapons that play differently, unlocked between runs', blocks: ['Roster', 'Tiers'], signs: /\bweapons?\b/i },
      { id: 'peak', what: 'escalating waves and a boss', blocks: ['BossPatterns'], signs: /\b(boss|wave)\w*/i },
    ],
    blocks: ['Roster', 'Tiers', 'UpgradeShop', 'RunChoices', 'TwinStick', 'LookInput', 'aimAssist', 'steer', 'BossPatterns', 'HitArcs', 'DamageNumbers', 'edgeArrow', 'callouts', 'QualityLadder', 'MoveInput', 'Camera'],
    money: rows('shooting'),
    guide: 'docs/guides/upgrades.md#1-pick-a-shape',
  },
  strategy: {
    id: 'strategy',
    name: 'Strategy / tower defense',
    players: 'a plan that pays off: build choices with a cost, stages to clear well, a harder tier after the campaign',
    expects: [
      { id: 'pacts', what: 'choices with a cost: pacts, forks, tiers', blocks: ['PactTree', 'Tiers'], signs: /\b(pact|fork|ascen)\w*/i },
      { id: 'stages', what: 'stages with stars, opened in order', blocks: ['levelOpen', 'recordStars'], signs: /\bstages?\b/i },
    ],
    blocks: ['PactTree', 'Tiers', 'UpgradeShop', 'levelOpen', 'recordStars', 'RunChoices', 'dailyTable', 'rivals', 'Board', 'Automa', 'Zones', 'Dice'],
    money: rows('strategy'),
    guide: 'docs/guides/upgrades.md#1-pick-a-shape (Dread Throne)',
  },
  io: {
    id: 'io',
    name: '.io',
    players: 'other players (or bots that pass for them) in a round, a rank, instant respawn, skins to unlock',
    expects: [
      { id: 'rank', what: 'a rank or leaderboard inside the round', blocks: [], signs: /\b(leaderboard|rank)\w*/i },
      { id: 'skins', what: 'skins or classes to unlock', blocks: ['Roster'], signs: /\bskins?\b/i },
    ],
    blocks: ['Roster', 'MoveInput', 'Camera'],
    money: rows('io'),
    guide: 'AGENTS.md §5 (portal multiplayer services are a known gap)',
  },
  driving: {
    id: 'driving',
    name: 'Driving',
    players: 'cars to unlock and tune, tracks to beat, a race that ends in 2–3 minutes',
    expects: [
      { id: 'cars', what: 'cars to unlock and upgrade', blocks: ['Roster', 'UpgradeShop'], signs: /\bcars?\b|\bvehicles?\b/i },
      { id: 'tracks', what: 'tracks or levels with stars or medals', blocks: ['levelOpen', 'recordStars'], signs: /\btracks?\b|\bmedals?\b/i },
    ],
    blocks: ['Roster', 'UpgradeShop', 'levelOpen', 'recordStars', 'MoveInput', 'Camera', 'physicsAfterInit', 'shareCode', 'rivals', 'dailyTable'],
    money: rows('driving'),
    guide: 'docs/guides/upgrades.md#1-pick-a-shape',
  },
  hypercasual: {
    id: 'hypercasual',
    name: 'Hypercasual',
    players: 'one action, a short round, a best to beat and Play again at once — the shortest sessions: add a reason to come back',
    expects: [
      { id: 'again', what: 'Play again at once: the next run is the big button', blocks: ['mountResults'], signs: /\bplay ?again\b|\brestart\b/i },
      { id: 'best', what: 'a best score or time to beat, kept between visits', blocks: [], signs: /\bbest\b|\bhigh ?score\b|\brecord\b/i },
    ],
    blocks: ['mountResults', 'UpgradeShop', 'dailyRunSeed', 'recordDaily', 'dailyTable', 'rivals'],
    money: rows('hypercasual'),
    guide: 'docs/guides/game-design.md#web-portals-crazygames-13-what-players-stay-for',
  },
  kids: {
    id: 'kids',
    name: 'Kids (Google Play Families)',
    players: 'a child: big targets, a voice, a reward after every round, never a loss — the kids kit has all of it',
    expects: [],
    blocks: [],
    money: rows('kids'),
    guide: 'docs/guides/game-design.md#children-audiences-ages-',
  },
  other: {
    id: 'other',
    name: 'Other (genre unknown)',
    players: 'nothing the platform can name: set money.genre, and the benchmarks and the must-haves follow',
    expects: [],
    blocks: [],
    money: rows('other'),
    guide: 'docs/guides/genres.md',
  },
};

export const SUBGENRE_INFO: Record<SubGenre, SubGenreInfo> = {
  roguelite: {
    id: 'roguelite',
    name: 'Roguelite',
    genre: 'action',
    tags: /^rogue-?(lite|like)s?$/i,
    players: 'a run that is different every time, a build made in the run, and a meta that carries over',
    expects: [
      { id: 'seed', what: 'a run seed: see it, copy it, type it back; a daily run', blocks: ['seedField', 'newRunSeed', 'runSeedFrom', 'dailyRunSeed'], signs: /\bseed\b/i },
      { id: 'choices', what: 'run choices: pick 1 of 3 at a level-up or a floor, a reroll', blocks: ['RunChoices'], signs: /\b(reroll|pick ?one|choices)\b/i },
    ],
    blocks: ['seedField', 'newRunSeed', 'runSeedFrom', 'dailyRunSeed', 'RunChoices', 'Roster', 'weeklyEvent', 'seasonPass', 'dailyTable', 'LootTable', 'shareCode', 'rivals', 'Zones', 'Board', 'Dice'],
  },
  survivors: {
    id: 'survivors',
    name: 'Survivors-like',
    genre: 'action',
    tags: /^survivors?(-like)?$/i,
    players: 'a swarm that grows, weapons that fire on their own, a level-up every half minute',
    expects: [{ id: 'choices', what: 'a pick of 1 of 3 upgrades at every level-up', blocks: ['RunChoices'], signs: /\b(level ?up|reroll)\b/i }],
    blocks: ['RunChoices', 'Roster', 'steer', 'TwinStick', 'aimAssist', 'BossPatterns', 'DamageNumbers', 'edgeArrow', 'Camera'],
  },
  platformer: {
    id: 'platformer',
    name: 'Platformer',
    genre: 'action',
    tags: /^platform(er|ing)s?$/i,
    players: 'tight controls, levels to clear, collectibles that show how well',
    expects: [{ id: 'levels', what: 'levels opened in order, with stars or collectibles', blocks: ['levelOpen', 'recordStars'], signs: /\blevels?\b/i }],
    blocks: ['levelOpen', 'recordStars', 'MoveInput', 'physicsAfterInit'],
  },
  'tower-defense': {
    id: 'tower-defense',
    name: 'Tower defense',
    genre: 'strategy',
    tags: /^(tower[- ]?defen[cs]e|td)$/i,
    players: 'towers that counter enemies, waves to read, stages with stars',
    expects: [{ id: 'waves', what: 'waves announced ahead, so the player can plan', blocks: [], signs: /\bwaves?\b/i }],
    blocks: ['PactTree', 'Tiers', 'levelOpen', 'recordStars'],
  },
  deckbuilder: {
    id: 'deckbuilder',
    name: 'Deckbuilder',
    genre: 'strategy',
    tags: /^(deck-?build(er|ing)s?|roguelike deck-?builders?|card (battler|roguelike|roguelite)s?)$/i,
    players: 'a deck that grows in the run — cards drafted after each fight or round, removed and upgraded — fights that are puzzles because the enemy shows its next move, and a play whose outcome they can read before they commit it',
    expects: [
      { id: 'draft', what: 'a card draft: pick 1 of 3 after a fight or a round, with a reroll or a skip', blocks: ['RunChoices'], signs: /\b(draft|reroll|skip|pick|card ?reward)\b/i, rewarded: ['reroll'] },
      { id: 'deck', what: 'the deck on view: the draw and discard piles, cards removed and upgraded (a thin deck is a choice)', blocks: ['Zones'], signs: /\b(deck|discard|draw ?pile)\b/i },
      { id: 'preview', what: 'the outcome before the commit: what a play will score or deal, on the card or the board ("how much will I get?" — Velvet Domino Rogue\'s players)', blocks: [], signs: /\b(preview|projected|forecast|will (score|deal))\b/i },
      { id: 'intent', what: "the enemy's next move shown before it acts (its intent)", blocks: ['Automa'], signs: /\b(intent|telegraph)\w*/i },
      { id: 'seed', what: 'a run seed and a daily run: the same deal for everyone', blocks: ['seedField', 'newRunSeed', 'runSeedFrom', 'dailyRunSeed'], signs: /\bseed\b/i },
    ],
    drops: ['stages'],
    blocks: ['Zones', 'Automa', 'RunChoices', 'seedField', 'newRunSeed', 'runSeedFrom', 'dailyRunSeed', 'Roster', 'PactTree', 'Tiers', 'Dice', 'weeklyEvent', 'seasonPass'],
  },
  clicker: {
    id: 'clicker',
    name: 'Clicker',
    genre: 'idle',
    tags: /^click(er|ing)s?$/i,
    players: 'a tap that pays, then automation that pays more',
    expects: [],
    blocks: ['UpgradeShop', 'mountUpgradeShop', 'formatAmount', 'offlineEarnings', 'Prestige'],
  },
  incremental: {
    id: 'incremental',
    name: 'Incremental',
    genre: 'idle',
    tags: /^incremental$/i,
    players: 'new layers that open as the numbers grow',
    expects: [],
    blocks: ['UpgradeShop', 'Tiers', 'formatAmount', 'offlineEarnings', 'Prestige', 'variants'],
  },
  tycoon: {
    id: 'tycoon',
    name: 'Tycoon',
    genre: 'idle',
    tags: /^(tycoon|management|business)$/i,
    players: 'a business that grows from one site to many: managers, upgrades, a map of places',
    expects: [{ id: 'sites', what: 'several places (sites) to open, each with its own upgrades, on a map', blocks: ['Sites', 'mountSitesMap'], signs: /\b(sites?|locations?|branch(es)?)\b/i, later: 'when the first site is built out' }],
    blocks: ['Sites', 'mountSitesMap', 'UpgradeShop', 'offlineEarnings', 'Prestige', 'restockShop', 'rivals', 'shareCode'],
  },
  merge: {
    id: 'merge',
    name: 'Merge',
    genre: 'idle',
    tags: /^merge$/i,
    players: 'two of a kind become the next, a board that fills, a collection of every tier',
    expects: [{ id: 'collection', what: 'a collection of every tier reached', blocks: ['Tiers', 'Roster'], signs: /\b(collection|album|discover)\w*/i }],
    blocks: ['Tiers', 'Roster', 'offlineEarnings', 'formatAmount', 'LootTable', 'variants', 'restockShop', 'Board'],
  },
};

// --- Lookups ------------------------------------------------------------------------------------------------------

/** "idle", "genre.idle", "roguelite", "genre.roguelite" → the genre (and the sub-genre); null for anything else */
export function genreTopic(topic: string): { genre: GenreInfo; sub: SubGenreInfo | null } | null {
  const id = topic.replace(/^genres?\./, '');
  const sub = (SUBGENRE_INFO as Record<string, SubGenreInfo>)[id] ?? null;
  const g = moneyGenre(id);
  return g ? { genre: GENRE_INFO[g], sub } : null;
}

/** The sub-genres of a genre */
export const subGenresOf = (g: Genre): SubGenreInfo[] => Object.values(SUBGENRE_INFO).filter((s) => s.genre === g);

/** The blocks that fit a genre (and its sub-genre), the general ones last; each once */
export function blocksFor(genre: Genre, sub: SubGenre | null = null): GenreBlock[] {
  const names = [...(sub ? SUBGENRE_INFO[sub].blocks : []), ...GENRE_INFO[genre].blocks, ...(genre === 'kids' || genre === 'other' ? [] : GENERAL_BLOCKS)];
  return [...new Set(names)].map((n) => GENRE_BLOCKS[n]).filter((b) => b && (!b.only || b.only.includes(genre)));
}

/** What a genre's players expect (the sub-genre's on top), each id once */
export function expectationsFor(genre: Genre, sub: SubGenre | null = null): Expectation[] {
  const seen = new Set<string>(sub ? SUBGENRE_INFO[sub].drops : []);
  return [...GENRE_INFO[genre].expects, ...(sub ? SUBGENRE_INFO[sub].expects : [])].filter((e) => !seen.has(e.id) && seen.add(e.id));
}

/**
 * The game's genre: money.genre (a genre or a sub-genre), else the first listing tag that names one (money.ts genreOf);
 * the sub-genre from money.genre or a listing tag. `named`: the game said it (the must-haves apply)
 */
export function gameGenre(g: { kit: string; audience: string; money?: MoneyInput | null; tags?: readonly string[] }): { genre: Genre; sub: SubGenre | null; from: string; named: boolean; hybrid: Genre[] } {
  const r = gameGenreOnly(g);
  const hybrid = (g.money?.hybrid ?? []).map(moneyGenre).filter((x): x is Genre => !!x && x !== 'kids' && x !== 'other' && x !== r.genre);
  return { ...r, hybrid: [...new Set(hybrid)] };
}

function gameGenreOnly(g: { kit: string; audience: string; money?: MoneyInput | null; tags?: readonly string[] }): { genre: Genre; sub: SubGenre | null; from: string; named: boolean } {
  const tags = g.tags ?? [];
  const named = g.money?.genre;
  const mg = moneyGenre(named);
  const subOfTags = (genre: Genre) => Object.values(SUBGENRE_INFO).find((s) => s.genre === genre && tags.some((t) => s.tags.test(t.trim()) || t.trim().toLowerCase().replace(/\s+/g, '-') === s.id))?.id ?? null;
  if (mg) {
    const sub = named && named in SUBGENRES ? (named as SubGenre) : subOfTags(mg);
    return { genre: mg, sub, from: `money.genre ${named}${sub && sub !== named ? ` (sub-genre ${sub} from listing.tags)` : ''}`, named: true };
  }
  const o = genreOf(g.kit, g.audience, tags);
  const sub = subOfTags(o.genre);
  // A genre guessed from the kit alone (hypercasual for the casual kit, other) names nothing the game said: no must-haves then
  return { genre: o.genre, sub, from: o.from, named: o.from.startsWith('listing') };
}

// --- What the code shows ------------------------------------------------------------------------------------------

const stripComments = (src: string) => src.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|[^:])\/\/.*$/gm, '$1');

/** The names a source file imports from the platform's packages (@gp/*): `import { UpgradeShop, x as y, type T } from '@gp/core'` → UpgradeShop, x */
export function importedBlocks(src: string): string[] {
  const out = new Set<string>();
  for (const m of stripComments(src).matchAll(/import\s+(type\s+)?\{([^}]*)\}\s*from\s*['"]@gp\/[^'"]+['"]/g)) {
    if (m[1]) continue;
    for (const part of m[2].split(',')) {
      const p = part.trim();
      if (!p || /^type\s/.test(p)) continue;
      out.add(p.split(/\s+as\s+/)[0].trim());
    }
  }
  return [...out];
}

/**
 * The genre checks of a code game: W_GENRE_BLOCK for each imported block outside its genre, I_GENRE_EXPECTS (one hint)
 * for the must-haves the code doesn't seem to have — no block imported, no sign of its own code, nothing in the money design
 */
export function genreChecks(o: { genre: Genre; sub: SubGenre | null; from: string; named: boolean; imported: readonly string[]; source: string; money?: MoneyInput | null; hybrid?: readonly Genre[] }): Issue[] {
  const issues: Issue[] = [];
  const imported = new Set(o.imported);
  const label = o.sub ? `${SUBGENRE_INFO[o.sub].name} (${o.genre})` : GENRE_INFO[o.genre].name;
  // The game's layers: its genre and the hybrid ones it declares (money.hybrid) — their blocks fit
  const layers: readonly Genre[] = [o.genre, ...(o.hybrid ?? [])];
  for (const name of imported) {
    const b = GENRE_BLOCKS[name];
    if (!b?.only || b.only.some((g) => layers.includes(g))) continue;
    const only = b.only.join(' / ');
    issues.push({
      code: 'W_GENRE_BLOCK',
      severity: 'warning',
      path: ['money', 'genre'],
      message: `the code imports ${name} (${b.from}: ${b.what}) — a block for ${only} games only, and this game's genre is ${o.genre} (${o.from})`,
      fix: `If the game is a${/^[aeiou]/i.test(only) ? 'n' : ''} ${only} game, say so: money.genre: ${b.only[0]}. If it is a hybrid — a${/^[aeiou]/i.test(only) ? 'n' : ''} ${only} layer on top of ${o.genre} (a base that earns while you raid, a rebirth) — declare the layer: money.hybrid: [${b.only[0]}]. Otherwise drop ${name}: ${o.genre} players don't look for it — gp catalog blocks --genre ${o.genre} lists what fits, gp explain W_GENRE_BLOCK.`,
    });
  }
  if (!o.named) return issues;
  const code = stripComments(o.source);
  const rewarded = new Set((o.money?.rewarded ?? []).map((r) => r.kind));
  const returns = o.money?.returns?.kind;
  const missing = expectationsFor(o.genre, o.sub).filter(
    (e) => !e.blocks.some((b) => imported.has(b)) && !(e.signs && e.signs.test(code)) && !(e.rewarded ?? []).some((k) => rewarded.has(k)) && !(returns && (e.returns ?? []).includes(returns)),
  );
  if (missing.length) {
    const id = o.sub ?? o.genre;
    issues.push({
      code: 'I_GENRE_EXPECTS',
      severity: 'info',
      path: ['money', 'genre'],
      message: `${label} players on CrazyGames expect ${missing.map((e) => `${e.what}${e.later ? ` (${e.later})` : ''}${e.blocks.length ? ` [${e.blocks.join(', ')}]` : ''}`).join('; ')} — the code doesn't seem to have ${missing.length === 1 ? 'it' : 'them'}`,
      fix: `Add what fits the game, from the blocks in brackets (gp catalog blocks --genre ${id}), or say in the report why it doesn't need it. gp explain genre.${id}.`,
    });
  }
  return issues;
}

/**
 * A code game that rolls a LootTable shows its odds (W_LOOT_ODDS): the code reads them somewhere — odds(), oddsText()
 * or formatOdds() — to put them on the screen with the roll. A cheap search: it can't see that the panel is on screen
 * (`gp review` asks the reviewer), only that the code never asks for the odds at all.
 */
export function lootChecks(o: { imported: readonly string[]; source: string }): Issue[] {
  if (!o.imported.includes('LootTable')) return [];
  if (/\.(odds|oddsText|expected)\s*\(|\bformatOdds\s*\(/.test(stripComments(o.source))) return [];
  return [
    {
      code: 'W_LOOT_ODDS',
      severity: 'warning',
      path: ['money', 'loot'],
      message: "the code rolls a LootTable but never reads its odds (odds(), oddsText(), formatOdds()): the player must see each tier's chance before every roll",
      fix: 'Put table.oddsText(source) (or a row per table.odds(source)) on the screen with the roll button, before the roll; declare the roll in money.loot with `odds: "where they are shown"` (docs/guides/live-world.md → Fair randomness).',
    },
  ];
}

// --- Text for gp catalog, gp explain and the guide ----------------------------------------------------------------

const range = (id: string) => {
  const r = MONEY_TABLE[id];
  return r ? `${r.mid} ${r.unit}` : '?';
};

/** One line per genre and sub-genre, for `gp catalog genres` */
export function genreRows(): { id: string; genre: Genre; name: string; minutes: string; d1: string; expects: string; only: string }[] {
  const only = (g: Genre) => Object.values(GENRE_BLOCKS).filter((b) => b.only?.includes(g)).map((b) => b.name).join(', ');
  const out: ReturnType<typeof genreRows> = [];
  for (const g of GENRES) {
    const i = GENRE_INFO[g];
    out.push({ id: g, genre: g, name: i.name, minutes: range(i.money.minutes), d1: range(i.money.d1), expects: i.expects.map((e) => e.id).join(', '), only: only(g) });
    for (const s of subGenresOf(g)) out.push({ id: s.id, genre: g, name: `  ${s.name}`, minutes: '″', d1: '″', expects: expectationsFor(g, s.id).map((e) => e.id).join(', '), only: '' });
  }
  return out;
}

/** `gp explain genre.<id>` */
export function explainGenre(topic: string): string | null {
  const t = genreTopic(topic);
  if (!t) return null;
  const { genre: g, sub } = t;
  const L = [sub ? `genre: ${sub.id} — ${sub.name}, a sub-genre of ${g.id} (benchmarked as ${g.id})` : `genre: ${g.id} — ${g.name}`, '', `Players come for: ${sub ? sub.players : g.players}.`];
  if (sub) L.push(`As ${g.id}: ${g.players}.`);
  L.push('', `${g.id === 'kids' ? 'Google Play' : 'CrazyGames'} benchmarks (MONEY_TABLE ${g.money.minutes}, ${g.money.d1}): average play ${range(g.money.minutes)}, D1 ${range(g.money.d1)}, a natural break about every ${range(g.money.breakEvery)}.`);
  const ex = expectationsFor(g.id, sub?.id ?? null);
  L.push('', ex.length ? 'Must-haves (gp validate hints I_GENRE_EXPECTS for a code game that seems to lack one):' : 'Must-haves: none the platform checks.');
  for (const e of ex) L.push(`  - ${e.what}${e.later ? ` (${e.later})` : ''}${e.blocks.length ? ` — ${e.blocks.join(', ')}` : ''}${e.rewarded ? ` — or a rewarded offer of kind ${e.rewarded.join('/')}` : ''}`);
  const blocks = blocksFor(g.id, sub?.id ?? null);
  if (blocks.length) {
    L.push('', 'Blocks that fit:');
    for (const b of blocks) L.push(`  ${b.name.padEnd(17)} ${b.from.padEnd(15)} ${b.what}${b.only ? ` [${b.only.join('/')} only]` : ''}`);
  }
  const elsewhere = Object.values(GENRE_BLOCKS).filter((b) => b.only && !b.only.includes(g.id));
  if (elsewhere.length) L.push('', `Not for ${g.id} (W_GENRE_BLOCK): ${elsewhere.map((b) => `${b.name} (${b.only!.join('/')})`).join(', ')} — unless the game declares a second layer of that genre: money.hybrid: [${elsewhere[0].only![0]}].`);
  const subs = sub ? [] : subGenresOf(g.id);
  if (subs.length) L.push('', `Sub-genres (money.genre takes them too): ${subs.map((s) => `${s.id} — ${s.name}`).join(', ')}.`);
  L.push('', `In game.yaml: money: { genre: ${sub?.id ?? g.id} }. More: ${g.guide} · docs/guides/genres.md`);
  return L.join('\n');
}
