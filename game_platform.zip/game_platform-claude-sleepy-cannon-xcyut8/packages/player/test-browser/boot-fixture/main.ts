// Test game for the player's boot (packages/player/test-browser/boot.test.ts): its start() fails the ways an engine does
// in a browser without what it needs. ?fail=throw (a sync throw), reject (an async Error), string (a rejected string);
// no ?fail: it starts.
import type { GameContext } from '@gp/core';

export default function start({ ui, host }: GameContext): void | Promise<void> {
  const fail = new URLSearchParams(location.search).get('fail');
  if (fail === 'throw') throw new Error('WebGL2 is not available');
  if (fail === 'string') return Promise.reject('no WebAssembly');
  return (async () => {
    host.gameplay(true);
    await new Promise((r) => setTimeout(r, 50));
    if (fail === 'reject') throw new Error('Error creating WebGL context.');
    ui.textContent = 'started';
  })();
}
