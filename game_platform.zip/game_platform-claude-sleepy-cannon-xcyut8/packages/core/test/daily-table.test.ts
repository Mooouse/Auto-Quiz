import { describe, expect, it } from 'vitest';
import { dailyTable, loadTable, shareText } from '../src/daily-table.ts';
import { byLanguage, createI18n } from '../src/i18n.ts';
import { PLATFORM_STRINGS } from '../src/i18n-platform.ts';
import { dailyRunSeed } from '../src/seed.ts';

const day = (d: number, h = 12) => Date.UTC(2026, 9, d, h);
const BANDS = [
  { id: 'bronze', at: 100 },
  { id: 'silver', at: 250 },
  { id: 'gold', at: 400 },
  { id: 'legend', at: 600 },
];
const MODULES = ['wind', 'bees', 'frost', 'market', 'moles'] as const;

describe('dailyTable', () => {
  it('a setup a day from the day seed, the same for everyone; modules in the list order; the setup a stream of its own', () => {
    let t = day(19);
    const mk = () => dailyTable({}, { salt: 'nine-plots', bands: BANDS, modules: { from: MODULES, pick: 2 }, setup: (r) => ({ start: r.int(9) }), now: () => t });
    const a = mk().today();
    const b = mk().today();
    expect(a).toEqual(b);
    expect(a.key).toBe('2026-10-19');
    expect(a.seed).toEqual(dailyRunSeed('nine-plots', '2026-10-19'));
    expect(a.modules).toHaveLength(2);
    expect(a.modules).toEqual(MODULES.filter((m) => a.modules.includes(m)));
    const seen = new Set<string>();
    for (let d = 1; d <= 20; d++) {
      t = day(d);
      seen.add(mk().today().modules.join());
    }
    expect(seen.size).toBeGreaterThan(5);
    // Adding a module to the list doesn't move the setup's own stream
    const withMore = dailyTable({}, { salt: 'nine-plots', bands: BANDS, modules: { from: [...MODULES, 'owls'], pick: 2 }, setup: (r) => ({ start: r.int(9) }), now: () => day(19) });
    expect(withMore.today().setup).toEqual(a.setup);
  });

  it('bands, the next one, how far, and a near miss', () => {
    const table = dailyTable({}, { salt: 'g', bands: BANDS });
    expect(table.band(50)).toMatchObject({ band: null, next: { id: 'bronze' }, need: 50, share: 0.5, near: false });
    expect(table.band(388)).toMatchObject({ band: { id: 'silver' }, next: { id: 'gold' }, need: 12, near: true });
    expect(table.band(300).near).toBe(false);
    expect(table.band(700)).toMatchObject({ band: { id: 'legend' }, next: null, need: null, share: 1 });
    const t = createI18n({ strings: byLanguage(PLATFORM_STRINGS), lang: 'en' }).t;
    expect(table.nearLine(388, t)).toBe('12 points from Gold');
    expect(table.nearLine(399, t)).toBe('1 point from Gold');
    expect(table.nearLine(300, t)).toBeNull();
    const de = createI18n({ strings: byLanguage(PLATFORM_STRINGS), lang: 'de' }).t;
    expect(table.nearLine(388, de, { name: () => 'Gold' })).toBe('12 Punkte bis Gold');
  });

  it('lower is better (a time): bands fall', () => {
    const table = dailyTable({}, { salt: 'g', better: 'low', bands: [{ id: 'bronze', at: 120 }, { id: 'silver', at: 90 }, { id: 'gold', at: 60 }] });
    expect(table.band(95)).toMatchObject({ band: { id: 'bronze' }, next: { id: 'silver' }, need: 5, near: true });
    expect(table.band(55).band!.id).toBe('gold');
    const t = createI18n({ strings: byLanguage(PLATFORM_STRINGS), lang: 'en' }).t;
    expect(table.nearLine(95, t, { unit: (n) => `${n} s` })).toBe('5 s from Silver');
    expect(() => dailyTable({}, { salt: 'g', better: 'low', bands: [{ id: 'a', at: 60 }, { id: 'b', at: 90 }] })).toThrow(/easiest/);
  });

  it('record(): today\'s best, the first run of the day on the calendar, a new day starts fresh (a missed day costs nothing)', () => {
    let t = day(19, 9);
    const save: Record<string, unknown> = {};
    const table = dailyTable(save, { salt: 'g', bands: BANDS, now: () => t });
    expect(table.record(120)).toMatchObject({ best: 120, newBest: true, first: true, band: { id: 'bronze' } });
    expect(table.record(80)).toMatchObject({ best: 120, newBest: false, first: false });
    expect(table.record(260)).toMatchObject({ best: 260, newBest: true, band: { id: 'silver' } });
    expect(table.log).toMatchObject({ day: '2026-10-19', best: 260, plays: 3, days: { days: ['2026-10-19'], count: 1 } });
    t = day(22, 23); // three days later, late evening UTC
    expect(table.record(50)).toMatchObject({ best: 50, first: true });
    expect(table.log.days.count).toBe(2);
    expect(loadTable(JSON.parse(JSON.stringify(save.table)))).toEqual(table.log);
    expect(loadTable({ day: 'yesterday', best: 5 })).toMatchObject({ day: '', best: null, plays: 0 });
  });

  it('the share card: text with the band bar, the seed and the near line', () => {
    const save: Record<string, unknown> = {};
    const table = dailyTable(save, { salt: 'nine-plots', bands: BANDS, now: () => day(19) });
    table.record(388);
    const t = createI18n({ strings: byLanguage(PLATFORM_STRINGS), lang: 'en' }).t;
    const card = table.card(null, { title: 'Nine Plots', t, url: 'https://example.org/nine' });
    expect(card).toMatchObject({ title: 'Nine Plots', day: '2026-10-19', score: '388', band: 'Silver', reached: 2, total: 4, near: '12 points from Gold' });
    expect(shareText(card)).toBe(`Nine Plots · 2026-10-19\nSilver · 388\n▰▰▱▱\n12 points from Gold\n#${dailyRunSeed('nine-plots', '2026-10-19').code}\nhttps://example.org/nine`);
    expect(shareText(table.card(20, { title: 'Nine Plots' }))).toMatch(/^Nine Plots · 2026-10-19\n20\n▱▱▱▱\n#/);
  });
});
