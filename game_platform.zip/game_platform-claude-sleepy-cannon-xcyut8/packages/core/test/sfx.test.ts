import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { createMixer, createSfx, MATERIALS, RECIPES, sfxRecipe, SFX_MAX_VOICES, type SoundHost } from '../src/sound';

// A fake WebAudio: nodes remember where they connect, sources when they start and at what rate, gains their value

class Param {
  value: number;
  events: [string, number, number][] = [];
  constructor(v = 0) {
    this.value = v;
  }
  setValueAtTime(v: number, t: number) {
    this.events.push(['set', v, t]);
    this.value = v;
    return this;
  }
  linearRampToValueAtTime(v: number, t: number) {
    this.events.push(['lin', v, t]);
    this.value = v;
    return this;
  }
  exponentialRampToValueAtTime(v: number, t: number) {
    this.events.push(['exp', v, t]);
    this.value = v;
    return this;
  }
  cancelScheduledValues() {
    return this;
  }
}

class Node {
  out: Node[] = [];
  constructor(readonly ctx: FakeCtx) {}
  connect<T>(n: T): T {
    if (n instanceof Node) this.out.push(n);
    return n;
  }
  disconnect() {
    this.out = [];
  }
}

class Source extends Node {
  frequency = new Param(440);
  detune = new Param();
  playbackRate = new Param(1);
  type = 'sine';
  buffer: { duration: number } | null = null;
  loop = false;
  stopped = Infinity;
  start(t = 0) {
    this.ctx.started.push({ node: this, t });
  }
  stop(t = 0) {
    this.stopped = t;
  }
}

class FakeCtx {
  currentTime = 1;
  state: 'running' | 'suspended' = 'running';
  sampleRate = 48000;
  started: { node: Source; t: number }[] = [];
  decoded = 0;
  createGain() {
    return Object.assign(new Node(this), { gain: new Param(1) });
  }
  createOscillator() {
    return new Source(this);
  }
  createBufferSource() {
    return new Source(this);
  }
  createBiquadFilter() {
    return Object.assign(new Node(this), { type: 'lowpass', frequency: new Param(350), Q: new Param(1) });
  }
  createStereoPanner() {
    return Object.assign(new Node(this), { pan: new Param(0) });
  }
  createDynamicsCompressor() {
    return Object.assign(new Node(this), { threshold: new Param(-24), knee: new Param(30), ratio: new Param(12), attack: new Param(0.003), release: new Param(0.25) });
  }
  createBuffer(_ch: number, len: number, rate: number) {
    const data = new Float32Array(len);
    return { getChannelData: () => data, sampleRate: rate, duration: len / rate };
  }
  async decodeAudioData(b: ArrayBuffer) {
    this.decoded++;
    return { duration: b.byteLength / 1000, sampleRate: this.sampleRate } as unknown as AudioBuffer;
  }
}

function reaches(n: Node, target: Node, seen = new Set<Node>()): boolean {
  if (n === target) return true;
  if (seen.has(n)) return false;
  seen.add(n);
  return n.out.some((o) => reaches(o, target, seen));
}

function setup() {
  const ctx = new FakeCtx();
  const out = ctx.createGain();
  let pauseFn = () => {};
  const host = {
    unlocked: true,
    paused: false,
    portalMuted: false,
    get audio() {
      return this.unlocked ? { ctx: ctx as unknown as AudioContext, out: out as unknown as GainNode } : null;
    },
    onPause: (f: () => void) => (pauseFn = f),
    onResume: () => {},
  };
  const mixer = createMixer(host as typeof host & SoundHost);
  return { ctx, out, host, mixer, pause: () => pauseFn() };
}

beforeEach(() => vi.useFakeTimers());
afterEach(() => vi.useRealTimers());

describe('createSfx: recipes', () => {
  it('every recipe and material plays on the sfx bus — through host.audio.out, never around the ducked music', () => {
    const { ctx, out, mixer } = setup();
    const sounds = Object.fromEntries([...RECIPES, ...Object.keys(MATERIALS)].map((k) => [k, sfxRecipe(k as never)]));
    const sfx = createSfx(mixer, sounds);
    const sfxBus = mixer.bus('sfx') as unknown as Node;
    for (const name of sfx.names) {
      ctx.started = [];
      ctx.currentTime += 1;
      expect(sfx.play(name), name).toBe(true);
      expect(ctx.started.length, name).toBeGreaterThan(0);
      for (const s of ctx.started) {
        expect(reaches(s.node, sfxBus), name).toBe(true);
        expect(reaches(s.node, out), name).toBe(true);
        // Every source stops: nothing rings forever
        expect(s.node.stopped, name).toBeLessThan(ctx.currentTime + 2.5);
      }
    }
    expect(sfx.ready()).toBe(true);
    expect(() => sfxRecipe('bogus' as never)).toThrow(/no recipe/);
    expect(sfxRecipe('bell').length).toBeGreaterThan(sfxRecipe('click').length);
  });
  it('a play varies its pitch a little (±6 % by default); `rate` moves it; vary 0 keeps it exact', () => {
    const { ctx, mixer } = setup();
    const sfx = createSfx(mixer, { coin: sfxRecipe('coin'), jingle: { src: sfxRecipe('coin'), vary: 0 } });
    const firstFreq = () => (ctx.started[0].node.frequency.events[0]?.[1] ?? 0) as number;
    const freqs: number[] = [];
    for (let i = 0; i < 20; i++) {
      ctx.started = [];
      ctx.currentTime += 0.1;
      sfx.play('coin');
      freqs.push(firstFreq());
    }
    expect(new Set(freqs.map((f) => f.toFixed(2))).size).toBeGreaterThan(10);
    for (const f of freqs) expect(Math.abs(f / 988 - 1)).toBeLessThanOrEqual(0.0601);
    ctx.started = [];
    ctx.currentTime += 0.1;
    sfx.play('jingle', { rate: 2 });
    expect(firstFreq()).toBeCloseTo(1976);
  });
});

describe('createSfx: files', () => {
  it('decodes the files once the context exists; plays before that are skipped; the rate is the playback rate', async () => {
    const { ctx, host, mixer } = setup();
    host.unlocked = false;
    const sfx = createSfx(mixer, { hit: new ArrayBuffer(300), tick: { src: new ArrayBuffer(50), vary: 0 } });
    expect(sfx.play('hit')).toBe(false);
    await sfx.load();
    expect(ctx.decoded).toBe(0);
    host.unlocked = true;
    expect(sfx.play('hit')).toBe(false);
    await sfx.load();
    expect(ctx.decoded).toBe(2);
    expect(sfx.ready('hit')).toBe(true);
    expect(sfx.duration('hit')).toBeCloseTo(0.3);
    ctx.started = [];
    expect(sfx.play('tick', { rate: 1.5 })).toBe(true);
    expect(ctx.started[0].node.playbackRate.value).toBe(1.5);
    expect(sfx.play('nope')).toBe(false);
  });
  it('the same sound within its gap (40 ms) plays once; others play; voices are capped per sound and in all', async () => {
    const { ctx, mixer } = setup();
    const sfx = createSfx(mixer, { a: sfxRecipe('hit'), b: sfxRecipe('click'), long: { src: sfxRecipe('bell'), gap: 0, max: 3 } });
    expect(sfx.play('a')).toBe(true);
    expect(sfx.play('a')).toBe(false);
    expect(sfx.play('b')).toBe(true);
    ctx.currentTime += 0.05;
    expect(sfx.play('a')).toBe(true);
    // A bell rings for over a second: four at once, the fourth is skipped
    expect([1, 2, 3, 4].map(() => sfx.play('long'))).toEqual([true, true, true, false]);
    const many = createSfx(mixer, Object.fromEntries(Array.from({ length: 40 }, (_, i) => [`s${i}`, sfxRecipe('bell')])));
    const played = many.names.filter((n) => many.play(n)).length;
    expect(played).toBeLessThanOrEqual(SFX_MAX_VOICES);
  });
});

describe('createSfx: the host and the mixer', () => {
  it('nothing starts while the portal mutes, the host is paused or the context is not running', () => {
    const { ctx, host, mixer } = setup();
    const sfx = createSfx(mixer, { a: sfxRecipe('pop') });
    host.portalMuted = true;
    expect(sfx.play('a')).toBe(false);
    host.portalMuted = false;
    host.paused = true;
    expect(sfx.play('a')).toBe(false);
    host.paused = false;
    ctx.state = 'suspended';
    expect(sfx.play('a')).toBe(false);
    ctx.state = 'running';
    expect(ctx.started).toHaveLength(0);
    expect(sfx.play('a')).toBe(true);
  });
  it('a sound at a distance is quieter and panned to its side of the listener', () => {
    const { ctx, mixer } = setup();
    const sfx = createSfx(mixer, { a: { src: sfxRecipe('hit'), gap: 0 } });
    sfx.listener({ x: 0, y: 0, range: 100 });
    // The voice's own gain: source → envelope → voice gain (→ panner) → the bus
    const gainOf = () => {
      const s = ctx.started.at(-1)!.node;
      let n: Node = s;
      while (n.out[0] && !('pan' in n.out[0]) && !('threshold' in n.out[0])) n = n.out[0];
      return n as Node & { gain: Param; out: Node[] };
    };
    sfx.play('a');
    const near = gainOf().gain.value;
    sfx.play('a', { at: { x: 300, y: 0 } });
    const far = gainOf();
    expect(far.gain.value).toBeCloseTo(near / 4);
    const pan = far.out[0] as Node & { pan: Param };
    expect(pan.pan.value).toBeGreaterThan(0.5);
    sfx.play('a', { at: { x: -300, y: 0 } });
    expect((gainOf().out[0] as Node & { pan: Param }).pan.value).toBeLessThan(-0.5);
    // Facing right (+x, yaw π/2): a sound straight ahead is in the middle, one below the listener (+y) is on its right
    sfx.listener({ yaw: Math.PI / 2 });
    sfx.play('a', { at: { x: 300, y: 0 } });
    expect('threshold' in gainOf().out[0]).toBe(true);
    sfx.play('a', { at: { x: 0, y: 300 } });
    expect((gainOf().out[0] as Node & { pan: Param }).pan.value).toBeGreaterThan(0.5);
  });
  it('say(): one line at a time, the music ducks under it for its length; hush() fades everything out', async () => {
    const { ctx, mixer } = setup();
    const duck = vi.spyOn(mixer, 'duck');
    const sfx = createSfx(mixer, { line1: new ArrayBuffer(2000), line2: new ArrayBuffer(1000), boom: sfxRecipe('boom') });
    await sfx.load();
    expect(sfx.say('line1')).toBeCloseTo(2, 1);
    expect(duck).toHaveBeenLastCalledWith(0.45, expect.closeTo(2.3, 1));
    const first = ctx.started.at(-1)!.node;
    ctx.currentTime += 0.5;
    expect(sfx.say('line2', { duck: 0.6 })).toBeCloseTo(1, 1);
    // The first line was cut: it stops within the fade
    expect(first.stopped).toBeLessThan(ctx.currentTime + 0.1);
    expect(duck).toHaveBeenLastCalledWith(0.6, expect.closeTo(1.3, 1));
    sfx.play('boom');
    const second = ctx.started.find((s) => s.node.buffer?.duration === 1)!.node;
    sfx.hush();
    expect(second.stopped).toBeLessThan(ctx.currentTime + 0.1);
  });
  it('the host pausing hushes what is ringing', async () => {
    const { ctx, mixer, pause } = setup();
    const sfx = createSfx(mixer, { line: new ArrayBuffer(3000) });
    await sfx.load();
    sfx.say('line');
    const src = ctx.started.at(-1)!.node;
    pause();
    expect(src.stopped).toBeLessThan(ctx.currentTime + 0.1);
  });
  it('the mixer\'s buses say what they carry (gp qa tells effects from music by it)', () => {
    const { mixer } = setup();
    for (const k of ['music', 'ambient', 'sfx'] as const) expect((mixer.bus(k) as unknown as { __gpBus: string }).__gpBus).toBe(k);
  });
});
