import { describe, expect, it } from 'vitest';
import { achievements, checkQuests, dailyQuests, loadAchievements, loadQuests, type QuestDef } from '../src/goals.ts';

// A local clock at noon of a day in October 2026 (quests turn over at the player's midnight by default)
const at = (day: number, hour = 12) => new Date(2026, 9, day, hour).getTime();
const clock = (day: number) => {
  const c = { t: at(day), now: () => c.t, go: (d: number, h = 12) => void (c.t = at(d, h)) };
  return c;
};
type Id = 'blocks' | 'chests' | 'merges' | 'items' | 'taps' | 'forge';
const POOL: QuestDef<Id, number>[] = [
  { id: 'blocks', need: 120, reward: 15 },
  { id: 'chests', need: 15, reward: 15 },
  { id: 'merges', need: 5, reward: 15 },
  { id: 'items', need: 4, reward: 10 },
  { id: 'taps', need: 50, reward: 10 },
  { id: 'forge', need: 4, reward: 10 },
];
const finish = (q: ReturnType<typeof dailyQuests<Id, number>>) => {
  for (const r of q.state().quests) q.add(r.id, r.need);
};

describe('dailyQuests', () => {
  it('draws perDay distinct quests by the day, the same draw for the same day and salt, another on another day', () => {
    const c = clock(1);
    const a = dailyQuests<Id>({}, { pool: POOL, perDay: 3, salt: 'g', now: c.now });
    const b = dailyQuests<Id>({}, { pool: POOL, perDay: 3, salt: 'g', now: c.now });
    const ids = a.state().quests.map((q) => q.id);
    expect(ids).toHaveLength(3);
    expect(new Set(ids).size).toBe(3);
    expect(b.state().quests.map((q) => q.id)).toEqual(ids);
    const days = new Set<string>();
    for (let d = 1; d <= 10; d++) {
      c.go(d);
      days.add(a.state().quests.map((q) => q.id).join());
    }
    expect(days.size).toBeGreaterThan(3);
  });

  it('progress is counted in memory (no save per add) and saved with the game; a claim pays once and saves', () => {
    const c = clock(1);
    const save: Record<string, unknown> = {};
    let saves = 0;
    const q = dailyQuests<Id>(save, { pool: POOL, now: c.now, persist: () => saves++ });
    const first = q.state().quests[0];
    const before = saves;
    for (let i = 0; i < first.need - 1; i++) expect(q.add(first.id)).toBe(false);
    expect(saves).toBe(before); // never a save per add
    expect(q.claim(first.id)).toBeNull(); // not done yet
    expect(q.add(first.id)).toBe(true); // this one completes it
    expect(q.add(first.id)).toBe(false); // done already
    expect((save.quests as { list: { have: number }[] }).list[0].have).toBe(first.need); // in the save object, for the game's next save
    expect(q.claim(first.id)).toBe(first.reward);
    expect(saves).toBe(before + 1);
    expect(q.claim(0)).toBeNull();
    expect(q.state().quests[0]).toMatchObject({ claimed: true, done: true, share: 1 });
    // A quest that isn't one of today's, or a bad amount, counts nothing
    const other = POOL.find((p) => !q.state().quests.some((r) => r.id === p.id))!;
    expect(q.add(other.id, 999)).toBe(false);
    expect(q.add(q.state().quests[1].id, -5)).toBe(false);
  });

  it('the bonus is ready when every quest is claimed, once; claimAll pays the done ones and the bonus', () => {
    const c = clock(1);
    const q = dailyQuests<Id>({}, { pool: POOL, bonus: 25, now: c.now });
    expect(q.claimBonus()).toBeNull();
    finish(q);
    expect(q.state().claimable).toBe(3);
    const paid = q.claimAll();
    expect(paid.map((p) => p.kind)).toEqual(['quest', 'quest', 'quest', 'bonus']);
    expect(paid.at(-1)!.reward).toBe(25);
    expect(q.state()).toMatchObject({ claimable: 0, bonus: { ready: false, claimed: true, share: 1 } });
    expect(q.claimBonus()).toBeNull();
    expect(q.claimAll()).toEqual([]);
  });

  it('a missed day takes nothing (D56): done and unclaimed quests and an earned bonus carry over; the day gets new quests', () => {
    const c = clock(1);
    const save: Record<string, unknown> = {};
    const q = dailyQuests<Id>(save, { pool: POOL, bonus: 25, now: c.now });
    finish(q);
    const yesterday = q.state().quests.map((r) => r.id);
    c.go(4); // three days later
    const s = q.state();
    expect(s.quests.every((r) => r.have === 0 && !r.claimed)).toBe(true);
    expect(s.carried.map((r) => r.id)).toEqual(yesterday);
    expect(s.carriedBonus).toBe(1);
    expect(s.claimable).toBe(4);
    const paid = q.claimAll();
    expect(paid.filter((p) => p.kind === 'quest')).toHaveLength(3);
    expect(paid.filter((p) => p.kind === 'bonus')).toHaveLength(1);
    expect(q.state().claimable).toBe(0);
    // A half-done quest is simply new the next day: nothing was earned, nothing is lost
    const r = q.state().quests[0];
    q.add(r.id, 1);
    c.go(5);
    expect(q.state().carried).toEqual([]);
  });

  it("from: 'secondVisit' offers nothing on the first day; a clock set back keeps the day", () => {
    const c = clock(10);
    const q = dailyQuests<Id>({}, { pool: POOL, from: 'secondVisit', now: c.now });
    expect(q.state().available).toBe(false);
    expect(q.add(q.state().quests[0].id, 999)).toBe(false);
    c.go(11);
    expect(q.state().available).toBe(true);
    const ids = q.state().quests.map((x) => x.id);
    c.go(9);
    // An earlier day than the log's: its quests are drawn, but nothing carries backwards
    expect(q.state().carried).toEqual([]);
    void ids;
  });

  it('a save from an older pool keeps the progress of the quests still there; junk saves load clean', () => {
    const c = clock(1);
    const save: Record<string, unknown> = {};
    const q = dailyQuests<Id>(save, { pool: POOL, now: c.now });
    const ids = q.state().quests.map((r) => r.id);
    q.add(ids[0], 2);
    // The game drops the third quest of today from its pool
    const smaller = POOL.filter((p) => p.id !== ids[2]);
    const again = dailyQuests<Id>(save, { pool: smaller, now: c.now });
    const now = again.state().quests;
    expect(now.map((r) => r.id)).not.toContain(ids[2]);
    expect(now.find((r) => r.id === ids[0])?.have ?? 2).toBe(2);
    expect(loadQuests({ day: 'x', list: [{ id: 3 }, { id: 'a', have: 'NaN' }, { id: 'a' }], carry: [{ id: 'b', day: 'nope' }], total: -4 })).toEqual({
      day: '',
      list: [{ id: 'a', have: 0, claimed: false }],
      bonus: false,
      carry: [],
      carryBonus: 0,
      first: '',
      total: 0,
    });
  });

  it('checkQuests names a pool too small, a duplicate id and a need under 1', () => {
    expect(checkQuests(POOL, 3)).toEqual([]);
    expect(checkQuests(POOL.slice(0, 2), 3)[0]).toMatch(/takes 3/);
    expect(checkQuests([...POOL, POOL[0]], 3)).toContain("the id 'blocks' twice");
    expect(checkQuests([{ id: 'x', need: 0, reward: 1 }, ...POOL], 3)).toContain('quest x: need is 1 or more');
    expect(() => dailyQuests({}, { pool: POOL.slice(0, 1), perDay: 3 })).toThrow(/dailyQuests/);
  });
});

describe('achievements', () => {
  type S = { runs: number; hour: number; coins: number };
  const list = [
    { id: 'first', rarity: 'common' as const, test: (s: S) => s.runs >= 1, progress: (s: S) => s.runs },
    { id: 'ten', rarity: 'rare' as const, test: (s: S) => s.runs >= 10, progress: (s: S) => s.runs / 10, reward: 50 },
    { id: 'night', rarity: 'epic' as const, hidden: true, test: (s: S) => s.hour < 5 },
    { id: 'prestige', rarity: 'legendary' as const },
  ];

  it('earned once, in the list order, saved when there are new ones; never taken back', () => {
    const save: Record<string, unknown> = {};
    let saves = 0;
    const a = achievements<S, number>(save, { list, now: () => 1000, persist: () => saves++ });
    expect(a.check({ runs: 0, hour: 12, coins: 0 })).toEqual([]);
    expect(saves).toBe(0);
    expect(a.check({ runs: 12, hour: 3, coins: 0 }).map((x) => x.id)).toEqual(['first', 'ten', 'night']);
    expect(saves).toBe(1);
    expect(a.check({ runs: 12, hour: 3, coins: 0 })).toEqual([]);
    // A reset (prestige) makes the tests fail: still earned
    expect(a.check({ runs: 0, hour: 12, coins: 0 })).toEqual([]);
    expect(a.unlocked('ten')).toBe(true);
    expect(save.achievements).toEqual({ got: { first: 1000, ten: 1000, night: 1000 }, paid: [] });
  });

  it('a secret is "???" until earned and shows no progress; progress bars are 0 … 1; a reward is claimed once', () => {
    const a = achievements<S, number>({}, { list });
    let st = a.state({ runs: 4, hour: 12, coins: 0 });
    expect(st.rows.map((r) => [r.id, r.secret, r.progress])).toEqual([
      ['first', false, 1],
      ['ten', false, 0.4],
      ['night', true, null],
      ['prestige', false, null],
    ]);
    expect(st).toMatchObject({ unlocked: 0, total: 4, claimable: 0 });
    a.check({ runs: 10, hour: 12, coins: 0 });
    st = a.state();
    expect(st.claimable).toBe(1);
    expect(a.claim('first')).toBeNull(); // no reward
    expect(a.claim('ten')).toBe(50);
    expect(a.claim('ten')).toBeNull();
    expect(a.state().claimable).toBe(0);
  });

  it("unlock() earns one by the game's own event; a test that throws is not earned; duplicate ids throw", () => {
    const a = achievements<S, number>({}, { list: [...list, { id: 'boom', test: () => { throw new Error('no field'); } }] });
    expect(a.unlock('prestige')).toBe(true);
    expect(a.unlock('prestige')).toBe(false);
    expect(a.unlock('nope')).toBe(false);
    expect(a.check({ runs: 0, hour: 12, coins: 0 })).toEqual([]);
    expect(() => achievements<S, number>({}, { list: [list[0], list[0]] })).toThrow(/twice/);
  });

  it('loads an old plain list of ids (Garage) and junk safely', () => {
    expect(loadAchievements(['first', 3, 'ten'])).toEqual({ got: { first: 0, ten: 0 }, paid: [] });
    expect(loadAchievements({ got: { a: 'x', b: 5 }, paid: ['b', 'zz', 4] })).toEqual({ got: { a: 0, b: 5 }, paid: ['b'] });
    expect(loadAchievements(null)).toEqual({ got: {}, paid: [] });
  });
});
