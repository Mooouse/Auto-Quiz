// Variants: one item, many values. Mutations that can land on an item under conditions of the world (the clock's
// weather, a place, a tool), combos that turn two of them into a named third, and multipliers that stack (Grow a
// Garden's weather mutations, Fisch's mutations by place and bait, Neon/Mega Neon: docs/research/roblox-2026-10.md P3).
// Pure and seeded: an item is plain data ({ base, variants }), the roll takes the game's rng, the expected multiplier is
// exact (the balance model and the bot read it).
//
//   const MUT = variants<{ weather: string }>({
//     list: [
//       { id: 'wet', mult: 2, chance: 0.1, when: (c) => c.weather === 'rain' },
//       { id: 'frozen', mult: 3, chance: 0.05, when: (c) => c.weather === 'snow' },
//       { id: 'shocked', mult: 50, chance: 0.01, when: (c) => c.weather === 'storm' },
//       { id: 'frost-shock', mult: 120, combo: ['frozen', 'shocked'] },     // both on one item → this one instead
//     ],
//     stack: 'multiply', max: 3,
//   });
//   const item = MUT.apply({ base: 'crystal', variants: [] }, { weather: sky.state().id }, host.rng);
//   MUT.value(item, 40);                     // 40 × the multipliers
//   MUT.label(item, (id) => host.t(`mut.${id}`), host.t('crystal'));   // "Frozen Shocked Crystal"
//   MUT.odds({ weather: 'storm' });          // [{ id: 'shocked', chance: 0.01 }]: what the forecast strip can say
//   MUT.expected({ weather: 'storm' });      // the mean multiplier of one roll, for balanceModel()
//
// Show what can land and when ("Storm: Shocked 1 in 100"), like the odds of a loot table: a variant is randomness the
// player plans around (the weather is announced: worldClock().weather().forecast()).

import { seededRng } from './rng.ts';

export interface VariantDef<Ctx = unknown> {
  id: string;
  /** × the value (stack 'multiply' and 'highest'); default 1 */
  mult?: number;
  /** + to the multiplier (stack 'add': 1 + Σ add); default mult − 1 */
  add?: number;
  /** The chance it lands on a roll (0 … 1, or from the world); a combo has none: it forms from its parts */
  chance?: number | ((ctx: Ctx) => number);
  /** It can land only when this holds (the weather is a storm, the bait is gold) */
  when?: (ctx: Ctx) => boolean;
  /** A recipe: an item with all of these gets this variant instead of them */
  combo?: readonly string[];
  /** Can't share an item with these (a frozen thing is not burning) */
  excludes?: readonly string[];
}

export interface VariantsOptions<Ctx = unknown> {
  list: readonly VariantDef<Ctx>[];
  /** How multipliers combine: 'multiply' (default: ×2 and ×3 → ×6), 'add' (1 + 1 + 2 → ×4), 'highest' (the biggest one) */
  stack?: 'multiply' | 'add' | 'highest';
  /** At most this many variants on one item (default 3): over it, the most valuable stay */
  max?: number;
}

/** An item with its variants: plain data, saved as it is */
export interface VariantItem {
  base: string;
  variants: string[];
}

export interface Variants<Ctx = unknown> {
  readonly list: readonly VariantDef<Ctx>[];
  /** The variants one roll gives under `ctx` (combos formed, capped at max), in the list's order */
  roll(ctx: Ctx, rng: () => number, opts?: { luck?: number; have?: readonly string[] }): string[];
  /** The item with a roll's variants added to the ones it has (combos formed again) — a new object */
  apply(item: VariantItem, ctx: Ctx, rng: () => number, opts?: { luck?: number }): VariantItem;
  /** Combos formed, exclusions and the cap applied: the variants an item really has */
  resolve(ids: readonly string[]): string[];
  /** The multiplier of a set of variants */
  multiplier(ids: readonly string[]): number;
  /** The item's value: base × its multiplier */
  value(item: VariantItem, base: number): number;
  /** "Frozen Shocked Crystal": the variants' names (in the list's order) before the base's */
  label(item: VariantItem, name?: (id: string) => string, baseName?: string): string;
  /** The chance of each variant that can land under `ctx` (combos are left out: they form) */
  odds(ctx: Ctx, opts?: { luck?: number }): { id: string; chance: number }[];
  /** The mean multiplier of one roll under `ctx` (exact up to 12 possible variants, sampled with a fixed seed above) */
  expected(ctx: Ctx, opts?: { luck?: number }): number;
}

/** The variants of a game: see the module's comment */
export function variants<Ctx = unknown>(opts: VariantsOptions<Ctx>): Variants<Ctx> {
  const list = opts.list;
  const byId = new Map(list.map((v) => [v.id, v]));
  if (byId.size !== list.length) throw new Error('variants: an id twice');
  for (const v of list) {
    for (const p of v.combo ?? []) if (!byId.has(p)) throw new Error(`variants: the combo ${v.id} needs the unknown '${p}'`);
    for (const p of v.excludes ?? []) if (!byId.has(p)) throw new Error(`variants: ${v.id} excludes the unknown '${p}'`);
    if (v.combo && v.combo.length < 2) throw new Error(`variants: the combo ${v.id} needs two parts or more`);
    if (v.mult !== undefined && !(v.mult > 0)) throw new Error(`variants: ${v.id} has a multiplier ≤ 0`);
  }
  const stack = opts.stack ?? 'multiply';
  const max = Math.max(1, Math.floor(opts.max ?? 3));
  const order = (ids: Iterable<string>) => [...new Set(ids)].filter((id) => byId.has(id)).sort((a, b) => list.indexOf(byId.get(a)!) - list.indexOf(byId.get(b)!));
  const mult = (id: string) => byId.get(id)?.mult ?? 1;
  const add = (id: string) => {
    const v = byId.get(id);
    return v?.add ?? (v?.mult ?? 1) - 1;
  };
  const multiplier = (ids: readonly string[]): number => {
    const set = resolve(ids);
    if (!set.length) return 1;
    if (stack === 'add') return Math.max(0, 1 + set.reduce((a, id) => a + add(id), 0));
    if (stack === 'highest') return Math.max(1, ...set.map(mult));
    return set.reduce((a, id) => a * mult(id), 1);
  };
  /** Exclusions (the earlier in the list wins), combos (biggest recipe first, until none forms), exclusions again, then the cap */
  const exclude = (ids: Iterable<string>): string[] => {
    const kept: string[] = [];
    for (const id of order(ids)) {
      const v = byId.get(id)!;
      if (kept.some((k) => byId.get(k)!.excludes?.includes(id) || v.excludes?.includes(k))) continue;
      kept.push(id);
    }
    return kept;
  };
  const combos = list.filter((v) => v.combo).sort((a, b) => b.combo!.length - a.combo!.length);
  function resolve(ids: readonly string[]): string[] {
    const set = new Set(exclude(ids));
    for (let changed = true; changed; ) {
      changed = false;
      for (const c of combos)
        if (c.combo!.every((p) => set.has(p))) {
          for (const p of c.combo!) set.delete(p);
          set.add(c.id);
          changed = true;
        }
    }
    let kept = exclude(set);
    if (kept.length > max) kept = [...kept].sort((a, b) => mult(b) - mult(a) || list.indexOf(byId.get(a)!) - list.indexOf(byId.get(b)!)).slice(0, max);
    return order(kept);
  }
  const chanceOf = (v: VariantDef<Ctx>, ctx: Ctx, luck: number) => {
    if (v.combo || (v.when && !v.when(ctx))) return 0;
    const c = typeof v.chance === 'function' ? v.chance(ctx) : (v.chance ?? 0);
    return Number.isFinite(c) ? Math.max(0, Math.min(1, c * luck)) : 0;
  };
  const luckOf = (o?: { luck?: number }) => (o?.luck !== undefined && Number.isFinite(o.luck) && o.luck > 0 ? o.luck : 1);
  const roll = (ctx: Ctx, rng: () => number, o?: { luck?: number; have?: readonly string[] }): string[] => {
    const luck = luckOf(o);
    const got: string[] = [...(o?.have ?? [])];
    // One rng call per variant that can land here, in the list's order: the same ctx and seed give the same roll
    for (const v of list) {
      const c = chanceOf(v, ctx, luck);
      if (c > 0 && rng() < c) got.push(v.id);
    }
    return resolve(got);
  };
  const odds = (ctx: Ctx, o?: { luck?: number }) =>
    list.map((v) => ({ id: v.id, chance: chanceOf(v, ctx, luckOf(o)) })).filter((x) => x.chance > 0);
  return {
    list,
    roll,
    apply: (item, ctx, rng, o) => ({ base: item.base, variants: roll(ctx, rng, { ...o, have: item.variants }) }),
    resolve,
    multiplier,
    value: (item, base) => base * multiplier(item.variants),
    label(item, name, baseName) {
      const n = name ?? ((id: string) => id.charAt(0).toUpperCase() + id.slice(1).replace(/-/g, ' '));
      return [...resolve(item.variants).map(n), baseName ?? n(item.base)].join(' ');
    },
    odds,
    expected(ctx, o) {
      const can = odds(ctx, o);
      if (can.length <= 12) {
        let sum = 0;
        for (let mask = 0; mask < 1 << can.length; mask++) {
          let p = 1;
          const ids: string[] = [];
          can.forEach((v, i) => {
            if (mask & (1 << i)) {
              p *= v.chance;
              ids.push(v.id);
            } else p *= 1 - v.chance;
          });
          if (p > 0) sum += p * multiplier(ids);
        }
        return sum;
      }
      // Many variants: a fixed-seed sample (the same answer every time)
      const r = seededRng(0x2545f491);
      const N = 20000;
      let sum = 0;
      for (let i = 0; i < N; i++) sum += multiplier(roll(ctx, r, o));
      return sum / N;
    },
  };
}
