// Profiles: the platform's rules as data. A game picks an `audience` and a `channel` in game.yaml;
// the validator enforces the rules below and the resolver turns them into runtime settings.
// Sources: Google Play Families policy, COPPA, and what "Pop the balloon!" proved in QA and on a device.

import type { AdMobConfig, AdPolicy } from '@gp/core/ads-policy';

export interface AudienceProfile {
  id: string;
  title: string;
  description: string;
  /** Child-directed: COPPA/Families rules apply, grown-up things go behind a parent gate */
  child: boolean;
  /** Smallest touch target (diameter, CSS px ≈ dp) for player-facing buttons */
  minTouchPx: number;
  /** Smallest tap-target radius, CSS px (a round's `target.min` may not go below) */
  minTargetRadiusPx: number;
  /** Rules shown in docs and `gp explain` */
  rules: string[];
}

export const AUDIENCES: Record<string, AudienceProfile> = {
  'ages-2-5': {
    id: 'ages-2-5',
    title: 'Toddlers and preschoolers (2–5)',
    description: 'Children who do not read yet. Everything is pictures and voice.',
    child: true,
    minTouchPx: 64,
    minTargetRadiusPx: 38,
    rules: [
      'No text is needed to play: pictures, sound and voice only (words on screen only supplement the voice).',
      'No losing, no lives, no timers, no negative feedback.',
      'Touch targets ≥ 64 dp; tap targets ≥ 76 dp across (radius ≥ 38).',
      'One tap, instant reward. No swipes, long presses or double taps.',
      'Multitouch never breaks the game: several fingers at once are normal.',
      'No flashing: at most 3 flashes per second, no sharp full-screen brightness changes.',
      'Soft sounds; sound and voice can be switched off by a grown-up.',
      'Settings, purchases and external links only behind a parent gate.',
    ],
  },
  'ages-6-8': {
    id: 'ages-6-8',
    title: 'Early readers (6–8)',
    description: 'Children who read simple words.',
    child: true,
    minTouchPx: 48,
    minTargetRadiusPx: 28,
    rules: [
      'Text needed to play at most at a Grade 2 reading level.',
      'Mistakes are gentle (a shake, try again); no punishing failure.',
      'Touch targets ≥ 48 dp.',
      'Settings, purchases and external links only behind a parent gate.',
    ],
  },
  'ages-9-12': {
    id: 'ages-9-12',
    title: 'Older children (9–12)',
    description: 'Children who read fluently.',
    child: true,
    minTouchPx: 48,
    minTargetRadiusPx: 24,
    rules: ['Touch targets ≥ 48 dp (Android accessibility guideline).', 'Settings, purchases and external links only behind a parent gate.'],
  },
  general: {
    id: 'general',
    title: 'General audience (13+)',
    description: 'Teens and adults. Not child-directed.',
    child: false,
    minTouchPx: 48,
    minTargetRadiusPx: 24,
    rules: ['Touch targets ≥ 48 dp (Android accessibility guideline).'],
  },
};

export interface ChannelProfile {
  id: string;
  title: string;
  description: string;
  platform: 'android' | 'web';
  /** Only child audiences may use this channel */
  childOnly: boolean;
  /** Audiences the channel accepts (default: all) */
  audiences?: readonly string[];
  /** Ad provider; null — the channel has no ads yet */
  ads: 'admob' | 'portal' | null;
  /** Rewarded ads (player-chosen) are available on this channel */
  rewardedAds: boolean;
  /** Web portal SDK the game talks to */
  portal?: 'crazygames';
  /**
   * Web portals: build limits checked by `gp build --target <channel>` — maxInitialMB fails the build (the hard limit;
   * game.yaml can't raise it); budgetGzipKB (the upload gzipped) and warnLoadSec (to a tappable Play on a slow phone:
   * budget.ts) warn. game.yaml `budget: { gzipKB }` raises the size budget on purpose, never above maxInitialMB.
   */
  webLimits?: { maxFiles: number; maxInitialMB: number; budgetGzipKB: number; warnLoadSec: number };
  /** The channel reviews every game for originality: game.yaml must have a `concept` (what makes it its own) */
  conceptReview?: boolean;
  /** Store / portal graphics `gp covers` renders from the game (width × height, px) */
  covers?: readonly { name: string; width: number; height: number }[];
  /** Preview videos `gp video` films: the page size and pixel ratio (1280×720 at 1.5 → a 1920×1080 video) */
  videos?: readonly { name: string; orientation: 'landscape' | 'portrait'; width: number; height: number; dpr: number }[];
  /** Ad limits the game may only make stricter (testAdCloseSec is a ceiling, the rest are floors) */
  adPolicy: AdPolicy | null;
  /** AdMob request settings */
  admob: Omit<AdMobConfig, 'interstitialId' | 'isTesting'> | null;
  /** Ads need a consent flow (GDPR/UMP) the platform doesn't have yet */
  adsNeedConsent: boolean;
  billing: boolean;
  privacyPolicyRequired: boolean;
  /** Android only: every permission of the merged manifest must be on this list (`${appId}` is the game's appId) */
  androidPermissions?: readonly string[];
  /** Android only: Google Play's minimum targetSdkVersion */
  minTargetSdk?: number;
  rules: string[];
}

/** Permissions of "Pop the balloon!"'s release build — each one explained in its docs/REPORT.md */
const FAMILIES_PERMISSIONS = [
  'android.permission.INTERNET', // AdMob ads
  'android.permission.ACCESS_NETWORK_STATE', // the AdMob SDK checks for a network
  'com.android.vending.BILLING', // "Remove ads"
  'android.permission.WAKE_LOCK', // WorkManager inside the AdMob SDK
  'android.permission.FOREGROUND_SERVICE', // same
  '${appId}.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION', // androidx.core, internal
];

/** Google Play Families-safe limits, proven in "Pop the balloon!" (tests/ads.test.ts there) */
export const FAMILIES_AD_POLICY: AdPolicy = {
  noAdsAfterLaunchSec: 60,
  firstAdAfterRound: 2,
  everyRounds: 2,
  minIntervalSec: 90,
  maxAdWaitSec: 120,
  testAdCloseSec: 5,
};

export const CHANNELS: Record<string, ChannelProfile> = {
  'android-families': {
    covers: [{ name: 'feature-graphic-1024x500', width: 1024, height: 500 }],
    id: 'android-families',
    title: 'Google Play, Families (child-directed)',
    description: 'Android app on Google Play for a child audience: Families policy, COPPA, AdMob with child-directed settings.',
    platform: 'android',
    childOnly: true,
    ads: 'admob',
    rewardedAds: false, // AdMob rewarded isn't in the platform yet
    adPolicy: FAMILIES_AD_POLICY,
    admob: { childDirected: true, underAgeOfConsent: true, maxAdContentRating: 'G', nonPersonalized: true },
    adsNeedConsent: false,
    billing: true,
    privacyPolicyRequired: true,
    androidPermissions: FAMILIES_PERMISSIONS,
    minTargetSdk: 36,
    rules: [
      'Interstitial ads only in the natural break after a round; never during play or at round start.',
      'No ads in the first 60 s, not before the end of round 2, at most once per 2 rounds and per 90 s.',
      'AdMob with tagForChildDirectedTreatment, tagForUnderAgeOfConsent, rating G, non-personalized.',
      'No advertising ID (AD_ID) and no Privacy Sandbox permissions: the merged manifest may contain only the allowlisted permissions (checked after every Android build).',
      'No banners, no rewarded ads; display-only interstitials recommended (closable within 5 s).',
      'Purchases and external links only behind the parent gate.',
      'A privacy policy URL is required (https).',
      "Each game needs something of its own (mechanic, content, listing): the Repetitive Content policy bans near-identical apps.",
    ],
  },
  android: {
    covers: [{ name: 'feature-graphic-1024x500', width: 1024, height: 500 }],
    id: 'android',
    title: 'Google Play (general audience)',
    description: 'Android app on Google Play, not child-directed.',
    platform: 'android',
    childOnly: false,
    ads: 'admob',
    rewardedAds: false, // AdMob rewarded isn't in the platform yet
    adPolicy: { noAdsAfterLaunchSec: 30, firstAdAfterRound: 1, everyRounds: 2, minIntervalSec: 60, maxAdWaitSec: 120, testAdCloseSec: 5 },
    admob: { childDirected: false, underAgeOfConsent: false, maxAdContentRating: 'PG', nonPersonalized: true },
    adsNeedConsent: true,
    billing: true,
    privacyPolicyRequired: true,
    androidPermissions: FAMILIES_PERMISSIONS,
    minTargetSdk: 36,
    rules: [
      'Ads need a GDPR consent flow (Google UMP) — not in the platform yet: turn ads off (`monetization.ads.enabled: false`) until it is.',
      'A privacy policy URL is required (https).',
    ],
  },
  crazygames: {
    id: 'crazygames',
    title: 'CrazyGames (web portal, 13+)',
    description: 'HTML5 game on CrazyGames: the portal brings the players, pays a share of ad revenue, and needs its SDK for gameplay events and ads.',
    platform: 'web',
    childOnly: false,
    audiences: ['general'],
    ads: 'portal',
    rewardedAds: true,
    portal: 'crazygames',
    // The portal requires the first midgame "after the tutorial or 3–5 min of play", then at most one per 3 minutes
    // (Basic Launch guide; the portal enforces the cap on top). The platform: never in the first 3 minutes; the first at
    // the end of round 3 (the pacing guide: "after level 3–4, not after level 1", to protect D1) OR once the session has
    // lasted 5 minutes (the top of the portal's 3–5 min), whichever comes first — so a game of 4–5-min runs gets its
    // first ad at 5 min, not at 12–15 (D36); then at most one per round and per 3 minutes
    adPolicy: { noAdsAfterLaunchSec: 180, firstAdAfterRound: 3, firstAdAfterSec: 300, everyRounds: 1, minIntervalSec: 180, maxAdWaitSec: 60, testAdCloseSec: 3 },
    admob: null,
    adsNeedConsent: false,
    billing: false,
    privacyPolicyRequired: false,
    // 400 KB gzipped ≈ 3 s to a tappable Play on a slow phone (budget.ts): the engine lab's Phaser upload (362 KB) is
    // at it, Canvas 2D (16 KB) far below; players decide in the first 10 s (docs/research/forums-2026-09.md)
    webLimits: { maxFiles: 1500, maxInitialMB: 20, budgetGzipKB: 400, warnLoadSec: 3 },
    // "Unoriginal content (e.g. clones or asset flips)" is a rejection reason; Petri Panic was rejected for its concept
    conceptReview: true,
    // The portal's cover sizes (the submission form: landscape 16:9, portrait 2:3, square 1:1), and Playgama's portrait
    // 9:16 (gp build --target playgama: its form takes 1920×1080, 1080×1920 and 800×800 exactly); the title is the only text on a cover
    covers: [
      { name: 'cover-1920x1080', width: 1920, height: 1080 },
      { name: 'cover-800x1200', width: 800, height: 1200 },
      { name: 'cover-1080x1920', width: 1080, height: 1920 },
      { name: 'cover-800x800', width: 800, height: 800 },
    ],
    // Both mandatory on the form: 15 s, H.264, no sound; landscape with a laptop's layout, portrait with a phone's
    videos: [
      { name: 'preview-1920x1080', orientation: 'landscape', width: 1280, height: 720, dpr: 1.5 },
      { name: 'preview-1080x1920', orientation: 'portrait', width: 540, height: 960, dpr: 2 },
    ],
    rules: [
      'Content must be PEGI 12 compliant; the audience is teens and adults (kids games go to the separate kids site — not supported yet).',
      'The SDK gets loadingStart/loadingStop, gameplayStart/gameplayStop (on every break: menu, result, pause, ad, hidden tab) and happytime — the platform sends them automatically from the round lifecycle.',
      'Midgame ads only in natural breaks on the way into the next round (death, level end → Play again), never during play and never on a navigational button (menu, home, settings, shop): the casual kit shows them when the player taps Play again, at most once per round and per 3 minutes, not in the first 3 minutes, and the first one at the end of round 3 or after 5 minutes of the session, whichever comes first.',
      'Rewarded ads only when the player chooses one (a button that says what they get), the reward is always given after a finished ad, and nothing in the game requires watching one. `host.rewarded()` (kit: code) refuses an ad that doesn\'t follow the player\'s tap.',
      'The upload is one file: `gp build --target crazygames` folds the build into games/<id>/upload/index.html (the form takes files, not archives). Initial download ≤ 50 MB, ≤ 20 MB for the mobile homepage (the platform holds games to 20 MB); ≤ 1500 files, ≤ 250 MB in all; relative paths only.',
      'Basic Launch (the first 7–21 days) has CrazyGames monetization off: every ad request fails. The game must not freeze and must not show reward buttons that do nothing (`host.rewardedAvailable` turns false once ads are off for the session (Basic Launch, an ad blocker) or after two failed ads in a row; `gp qa` checks it). Full Launch also requires that it works with an ad blocker.',
      'Originality is reviewed: `concept` in game.yaml (E_CONCEPT); the title is ≤ 35 characters, the same in the game and on the form, not a common word or someone else\'s name (E_TITLE_GENERIC).',
      'Full Launch: land new players in gameplay at once, at most 1 click; text legible at devicePixelRatio 1 in 821×462 and 800×450 frames; no custom fullscreen button; Esc and Ctrl+W are not game keys (use e.code, so WASD is ZQSD on AZERTY).',
      'Works with mouse and touch on desktop and mobile browsers (Chrome, Edge); no right-click menu; no text selection.',
      'Saves go through the SDK data module (cloud-synced for logged-in players) — automatic.',
      'No external links, no other portals\' branding, no login walls.',
    ],
  },
  web: {
    id: 'web',
    title: 'Web (own site, portals)',
    description: 'HTML5 build for a website or a web game portal.',
    platform: 'web',
    childOnly: false,
    ads: null,
    rewardedAds: false,
    adPolicy: null,
    admob: null,
    adsNeedConsent: false,
    billing: false,
    privacyPolicyRequired: false,
    rules: ['No ads and no purchases yet: a portal SDK becomes another ad provider when a game needs it.'],
  },
};

/** Google's public test IDs — used in every non-release build */
export const ADMOB_TEST_IDS = {
  appId: 'ca-app-pub-3940256099942544~3347511713',
  interstitial: 'ca-app-pub-3940256099942544/1033173712',
  publisherPrefix: 'ca-app-pub-3940256099942544',
};
