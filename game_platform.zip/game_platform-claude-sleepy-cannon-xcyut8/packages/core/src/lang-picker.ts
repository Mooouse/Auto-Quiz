// A ready language picker for a game's menu (kit: code): one button with the current language's flag and name; a tap
// opens a sheet of every language the game has, each a button with its flag and its own name ("Deutsch", "Русский").
// - Flags are inline SVG, drawn here: emoji flags are letters on Windows ("🇩🇪" shows as "DE"), and an image would be a
//   request. A flag is decoration (aria-hidden): the language's own name says which it is — Spanish is not only Spain's;
// - every button is at least minTouchPx (48 px for 13+), the sheet fits 360×800 to 800×450 (a grid that scrolls inside);
// - choosing saves the choice (host.setLanguage) and calls onChange, so the screen re-renders in the new language;
// - Escape, a tap outside or the choice closes the sheet; focus goes into it and back to the button;
// - data-gp="lang" on the button, data-gp-lang="<code>" on each choice: `gp qa` finds and taps them.
// Theme it with screenTheme() (every platform screen at once) or CSS variables on #gp-lang-sheet { --gp-lang-*: … }
// (no specificity: the game's win).

import { FONT_FALLBACK, languageInfo, type FlagId, type I18n } from './i18n.ts';

export interface LanguagePickerOptions {
  /** The host (or anything with an i18n): its languages are offered, setLanguage saves the choice */
  host: { readonly i18n: I18n; setLanguage?(code: string): boolean; readonly minTouchPx?: number };
  /** After a switch: re-render the screen (or listen to host.onLanguage) */
  onChange?(lang: string): void;
  /** Show the flags (default true); false: the names alone */
  flags?: boolean;
  /** The game's own class for the button, to look like its other buttons */
  className?: string;
  /** What the button shows: the flag and the language's name (default), or the flag and its code ("DE") where room is short */
  compact?: boolean;
}

const SVG_NS = 'http://www.w3.org/2000/svg';

/** A five-pointed star as SVG points (r1 outer, r2 inner), a point at angle `rot` (radians, 0 = right) */
function star(cx: number, cy: number, r1: number, r2: number, rot = -Math.PI / 2): string {
  const p: string[] = [];
  for (let i = 0; i < 10; i++) {
    const r = i % 2 ? r2 : r1;
    const a = rot + (i * Math.PI) / 5;
    p.push(`${(cx + r * Math.cos(a)).toFixed(2)},${(cy + r * Math.sin(a)).toFixed(2)}`);
  }
  return p.join(' ');
}

const bands = (dir: 'h' | 'v', colors: string[], weights?: number[]): string => {
  const w = weights ?? colors.map(() => 1);
  const total = w.reduce((a, b) => a + b, 0);
  let at = 0;
  return colors
    .map((c, i) => {
      const size = ((dir === 'h' ? 20 : 30) * w[i]) / total;
      const r = dir === 'h' ? `<rect x="0" y="${at}" width="30" height="${size}" fill="${c}"/>` : `<rect x="${at}" y="0" width="${size}" height="20" fill="${c}"/>`;
      at += size;
      return r;
    })
    .join('');
};

/** Each flag in a 30×20 box (3:2), simplified to what reads at 28 px */
const FLAGS: Record<FlagId, string> = {
  gb:
    '<rect width="30" height="20" fill="#012169"/><path d="M0,0L30,20M30,0L0,20" stroke="#fff" stroke-width="4"/>' +
    '<path d="M0,0L30,20M30,0L0,20" stroke="#C8102E" stroke-width="1.4"/><path d="M15,0V20M0,10H30" stroke="#fff" stroke-width="6"/>' +
    '<path d="M15,0V20M0,10H30" stroke="#C8102E" stroke-width="3.4"/>',
  es: bands('h', ['#AA151B', '#F1BF00', '#AA151B'], [1, 2, 1]),
  br:
    '<rect width="30" height="20" fill="#009C3B"/><polygon points="15,2.2 27.6,10 15,17.8 2.4,10" fill="#FFDF00"/>' +
    '<circle cx="15" cy="10" r="4.7" fill="#002776"/><path d="M10.5,9.1Q15,7.6 19.6,10.6" stroke="#fff" stroke-width="0.9" fill="none"/>',
  fr: bands('v', ['#002654', '#FFFFFF', '#CE1126']),
  de: bands('h', ['#000000', '#DD0000', '#FFCE00']),
  ru: bands('h', ['#FFFFFF', '#0039A6', '#D52B1E']),
  tr: `<rect width="30" height="20" fill="#E30A17"/><circle cx="11.2" cy="10" r="5" fill="#fff"/><circle cx="12.5" cy="10" r="4" fill="#E30A17"/><polygon points="${star(17.4, 10, 2.3, 0.95, Math.PI)}" fill="#fff"/>`,
  it: bands('v', ['#009246', '#FFFFFF', '#CE2B37']),
  pl: bands('h', ['#FFFFFF', '#DC143C']),
  id: bands('h', ['#CE1126', '#FFFFFF']),
  jp: '<rect width="30" height="20" fill="#fff"/><circle cx="15" cy="10" r="6" fill="#BC002D"/>',
  kr:
    '<rect width="30" height="20" fill="#fff"/><circle cx="15" cy="10" r="5" fill="#0047A0"/>' +
    '<path d="M10,10A5,5 0 0 1 20,10A2.5,2.5 0 0 1 15,10A2.5,2.5 0 0 0 10,10Z" fill="#CD2E3A"/>' +
    '<g stroke="#000" stroke-width="0.8"><path d="M4.2,5.6l2.6,-3.4M5.2,6.4l2.6,-3.4M6.2,7.2l2.6,-3.4"/><path d="M21.2,2.8l2.6,3.4M22.2,2l2.6,3.4M23.2,1.2l2.6,3.4" transform="translate(0,1.4)"/>' +
    '<path d="M4.2,14.4l2.6,3.4M5.2,13.6l2.6,3.4M6.2,12.8l2.6,3.4"/><path d="M21.2,17.2l2.6,-3.4M22.2,18l2.6,-3.4M23.2,18.8l2.6,-3.4" transform="translate(0,-1.4)"/></g>',
  cn:
    `<rect width="30" height="20" fill="#DE2910"/><polygon points="${star(5, 5, 3, 1.15)}" fill="#FFDE00"/>` +
    [
      [10, 2],
      [12, 4],
      [12, 7],
      [10, 9],
    ]
      .map(([x, y]) => `<polygon points="${star(x, y, 1, 0.38, Math.atan2(5 - y, 5 - x))}" fill="#FFDE00"/>`)
      .join(''),
};

/** A flag as an inline SVG element (aria-hidden: the language's name next to it is what a screen reader says) */
export function flagSvg(flag: FlagId, width = 28): SVGSVGElement {
  const svg = document.createElementNS(SVG_NS, 'svg');
  svg.setAttribute('viewBox', '0 0 30 20');
  svg.setAttribute('width', String(width));
  svg.setAttribute('height', String(Math.round((width * 2) / 3)));
  svg.setAttribute('aria-hidden', 'true');
  svg.setAttribute('focusable', 'false');
  svg.classList.add('gp-flag');
  svg.innerHTML = FLAGS[flag];
  return svg;
}

// :where() keeps the defaults at zero specificity: a game's #gp-lang-sheet { --gp-lang-bg: … } wins
const CSS = `
:where(#gp-lang-sheet) { --gp-lang-bg: var(--gp-theme-backdrop, #14202bf2); --gp-lang-panel: var(--gp-theme-bg, #1d2c3a);
  --gp-lang-ink: var(--gp-theme-ink, #eef6ff); --gp-lang-btn: var(--gp-theme-panel, #2a3d4f); --gp-lang-on: var(--gp-theme-accent, #ffd166);
  --gp-lang-on-ink: var(--gp-theme-accent-ink, #14202b); --gp-lang-radius: var(--gp-theme-radius, 16px); --gp-lang-font: var(--gp-theme-font, ${FONT_FALLBACK}); }
#gp-lang-sheet { position: fixed; inset: 0; z-index: 2147483000; display: flex; align-items: center; justify-content: center;
  background: var(--gp-lang-bg); padding: max(10px, env(safe-area-inset-top)) max(10px, env(safe-area-inset-right))
  max(10px, env(safe-area-inset-bottom)) max(10px, env(safe-area-inset-left)); box-sizing: border-box; pointer-events: auto; }
#gp-lang-sheet .gp-lang-panel { background: var(--gp-lang-panel); color: var(--gp-lang-ink); border-radius: var(--gp-lang-radius); padding: 12px;
  box-sizing: border-box; width: min(100%, 620px); max-height: 100%; overflow: auto; display: grid; gap: 8px;
  grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); font: 600 15px/1.2 var(--gp-lang-font); }
#gp-lang-sheet .gp-lang-title { grid-column: 1 / -1; margin: 0 0 2px; font-size: 18px; text-align: center; font-family: var(--gp-theme-display, inherit); }
#gp-lang-sheet button { display: flex; align-items: center; gap: 8px; min-width: 0; margin: 0; padding: 6px 10px; border: 0;
  border-radius: 12px; background: var(--gp-lang-btn); color: inherit; font: inherit; text-align: left; cursor: pointer; }
#gp-lang-sheet button[aria-pressed=true] { background: var(--gp-lang-on); color: var(--gp-lang-on-ink); }
#gp-lang-sheet button:focus-visible { outline: 3px solid var(--gp-lang-on); outline-offset: 2px; }
#gp-lang-sheet .gp-flag, .gp-lang .gp-flag { flex: none; border-radius: 3px; box-shadow: 0 0 0 1px #0004; }
/* Words never break inside: "Português (Brasil)" wraps between its words */
#gp-lang-sheet .gp-lang-name { overflow-wrap: normal; word-break: normal; hyphens: manual; }
.gp-lang { display: inline-flex; align-items: center; justify-content: center; gap: 8px; }
`;

function ensureCss(): void {
  if (document.getElementById('gp-lang-css')) return;
  const s = document.createElement('style');
  s.id = 'gp-lang-css';
  s.textContent = CSS;
  document.head.append(s);
}

/**
 * The picker's button for a menu. Returns null when the game has one language (nothing to pick). The button takes the
 * game's own button styles (className); the sheet it opens is the platform's.
 */
export function languagePicker(opts: LanguagePickerOptions): HTMLButtonElement | null {
  const { i18n } = opts.host;
  if (i18n.languages.length < 2) return null;
  ensureCss();
  const min = opts.host.minTouchPx ?? 48;
  const flags = opts.flags !== false;
  const b = document.createElement('button');
  b.type = 'button';
  b.dataset.gp = 'lang';
  b.classList.add('gp-lang');
  if (opts.className) b.classList.add(...opts.className.split(/\s+/).filter(Boolean));
  b.style.minHeight = `${min}px`;
  b.style.minWidth = `${min}px`;
  b.setAttribute('aria-haspopup', 'dialog');
  const paint = () => {
    const info = languageInfo(i18n.lang) ?? { code: i18n.lang, name: i18n.lang, flag: 'gb' as FlagId };
    const name = document.createElement('span');
    name.textContent = opts.compact ? info.code.split('-')[0].toUpperCase() : info.name;
    b.replaceChildren(...(flags ? [flagSvg(info.flag)] : []), name);
    b.setAttribute('aria-label', `${i18n.t('gp.lang.label')}: ${info.name}`);
    b.lang = info.code;
  };
  paint();
  b.addEventListener('click', () => openLanguageSheet({ ...opts, returnFocus: b, onPicked: paint }));
  return b;
}

/** The sheet of languages, open now (a settings screen may open it from its own button). Resolves with the choice or null */
export function openLanguageSheet(opts: LanguagePickerOptions & { returnFocus?: HTMLElement; onPicked?(): void }): Promise<string | null> {
  ensureCss();
  document.getElementById('gp-lang-sheet')?.remove();
  const { i18n } = opts.host;
  const min = opts.host.minTouchPx ?? 48;
  const flags = opts.flags !== false;
  return new Promise((resolve) => {
    const sheet = document.createElement('div');
    sheet.id = 'gp-lang-sheet';
    sheet.dataset.gp = 'lang-sheet';
    sheet.setAttribute('role', 'dialog');
    sheet.setAttribute('aria-modal', 'true');
    sheet.setAttribute('aria-label', i18n.t('gp.lang.label'));
    const panel = document.createElement('div');
    panel.className = 'gp-lang-panel';
    panel.dataset.gpScroll = 'the list of languages'; // on a short landscape phone it may not fit
    const title = document.createElement('h2');
    title.className = 'gp-lang-title';
    title.textContent = i18n.t('gp.lang.label');
    panel.append(title);
    let done = false;
    const close = (choice: string | null) => {
      if (done) return;
      done = true;
      sheet.remove();
      document.removeEventListener('keydown', onKey, true);
      if (choice && choice !== i18n.lang) {
        const ok = opts.host.setLanguage ? opts.host.setLanguage(choice) : i18n.setLanguage(choice);
        if (ok) {
          opts.onPicked?.();
          opts.onChange?.(i18n.lang);
        }
      }
      if (opts.returnFocus?.isConnected) opts.returnFocus.focus();
      resolve(choice);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        e.stopPropagation();
        close(null);
      }
    };
    for (const code of i18n.languages) {
      const info = languageInfo(code) ?? { code, name: code, flag: 'gb' as FlagId };
      const c = document.createElement('button');
      c.type = 'button';
      c.dataset.gpLang = info.code;
      c.lang = info.code;
      c.style.minHeight = `${min}px`;
      c.setAttribute('aria-pressed', String(info.code === i18n.lang));
      const name = document.createElement('span');
      name.className = 'gp-lang-name';
      name.textContent = info.name;
      c.append(...(flags ? [flagSvg(info.flag, 26)] : []), name);
      c.addEventListener('click', (e) => {
        e.stopPropagation();
        close(info.code);
      });
      panel.append(c);
    }
    sheet.append(panel);
    // A click (down and up) on the backdrop, not a pointerdown: the release must not land on the game's button below
    sheet.addEventListener('click', (e) => {
      if (e.target === sheet) close(null);
    });
    document.addEventListener('keydown', onKey, true);
    document.body.append(sheet);
    (panel.querySelector<HTMLButtonElement>('button[aria-pressed=true]') ?? panel.querySelector('button'))?.focus();
  });
}
