import { describe, expect, it } from 'vitest';
import { pickNavButton } from '../qa/suite.ts';

const b = (text: string, gp: string | null = null, rewarded = false) => ({ text, gp, rewarded });

describe('the navigational button QA taps on the results screen', () => {
  it("Candle Crypt's results: Menu, not Play again, the ×2 offer or Candles", () => {
    const labels = [b('▶ Double gems (ad)', null, true), b('Play again', 'again'), b('Menu'), b('Candles')];
    expect(pickNavButton(labels)).toBe(2);
  });
  it("Echoflies' results: Menu, never Retry or the One more loop offer", () => {
    expect(pickNavButton([b('▶ One more loop', null, true), b('Retry', 'again'), b('Menu')])).toBe(2);
  });
  it('a menu-like button first, then a level map, then the shop', () => {
    expect(pickNavButton([b('Shop'), b('Levels'), b('Back to title')])).toBe(2);
    expect(pickNavButton([b('Shop'), b('Levels')])).toBe(1);
    expect(pickNavButton([b('Upgrades'), b('⚙ Settings')])).toBe(1);
  });
  it('never a button that goes into the next run, even when its text reads like one', () => {
    expect(pickNavButton([b('Menu', 'again'), b('Next night', 'again')])).toBe(-1);
    expect(pickNavButton([b('Next level'), b('Continue'), b('Play again')])).toBe(-1);
    expect(pickNavButton([b('Home', 'play')])).toBe(-1);
  });
  it('a word that only starts like one does not count', () => {
    expect(pickNavButton([b('Menus of the day'), b('Homecoming')])).toBe(-1);
  });
});
